import { Editor, createServiceToken, type Transaction } from '@soeditor/core';
import {
    DiagnosticsPlugin as SdkDiagnosticsPlugin,
    Plugin,
    ProjectionCoordinatorPlugin as SdkProjectionCoordinatorPlugin,
    SplitViewPlugin as SdkSplitViewPlugin,
    UiPlugin as SdkUiPlugin,
    diagnosticsServiceToken as sdkDiagnosticsServiceToken,
    commentsServiceToken,
    createCommentsPlugin,
    createRevisionsPlugin,
    mapEditingPoint,
    pastePipelineServiceToken as sdkPastePipelineServiceToken,
    revisionsServiceToken,
    splitViewServiceToken as sdkSplitViewServiceToken,
    StructuredEditingPlugin,
    structuredEditingRegistryToken,
    uiRegistryServiceToken as sdkUiRegistryServiceToken,
    uploadServiceToken as sdkUploadServiceToken,
    type CmsObjectDefinition as SdkCmsObjectDefinition,
    type DiagnosticProvider as SdkDiagnosticProvider,
    type CommentStorageAdapter,
    type CommentThread,
    type DiagnosticsWorkflowConfig,
    type EditingOperation,
    type EditingStructuredBlockContent,
    type EditorUiIconResource,
    type EditorUiThemeVariables,
    type EditorUiTranslationResource as SdkEditorUiTranslationResource,
    type PasteProcessor,
    type ProjectionAdapter as SdkProjectionAdapter,
    type RevisionSnapshot,
    type RevisionStorage,
    type SplitViewAdapter as SdkSplitViewAdapter,
    type SplitViewPair as SdkSplitViewPair,
    type StatusItemFactory,
    type StructuredBlockConversion,
    type StructuredNodeViewFactory,
    type UploadService as SdkUploadService,
} from '@soeditor/plugin-sdk';
import {
    classicPreset,
    developerPreset,
    extendPreset,
    markdownPreset,
    minimalPreset,
    type EditorPreset,
} from '@soeditor/presets';
import { minimalPreset as subpathMinimalPreset } from '@soeditor/presets/minimal';
import {
    createEditorWorkspace as createUmbrellaWorkspace,
    SoEditor,
    minimalPreset as umbrellaMinimalPreset,
} from '@soeditor/editor';
import {
    createEditorSaveWorkflow,
    createEditorWorkspace,
    type EditorSaveAdapter,
    type EditorSaveRequest,
    type WorkspaceAttachmentFactory,
    type WorkspaceDiagnostic,
} from '@soeditor/workspace';
import {
    useSoEditorWorkspace as useReactSoEditorWorkspace,
    type ReactWorkspaceOptions,
} from '@soeditor/react';
import {
    useSoEditorWorkspace as useVueSoEditorWorkspace,
    type VueWorkspaceOptions,
} from '@soeditor/vue';
import { pluginTemplateVersion } from '@soeditor/plugin-tools';
import {
    createDeveloperToolsEngine,
    createDocumentOutline,
    DeveloperToolsPlugin,
    type DeveloperToolsEngineOptions,
    type InspectorElement,
    type OutlineItem,
} from '@soeditor/dev-tools';
import {
    FileManagerPlugin,
    UploadPlugin,
    fileManagerServiceToken,
    normalizeFileManagerResult,
    uploadServiceToken,
    uploadWorkflowServiceToken,
    type FileManager,
    type FileManagerOpenOptions,
    type FileManagerResult,
    type UploadService,
} from '@soeditor/file-manager';
import {
    SoFinderAdapter,
    type SoFinderAdapterOptions,
    type SoFinderSelection,
} from '@soeditor/adapter-sofinder';
import {
    parseHtmlFragment,
    serializeHtmlFragment,
    type HtmlElement,
} from '@soeditor/html';
import {
    AccessibilityDiagnosticsPlugin,
    DiagnosticsPlugin,
    HtmlFormattingPlugin,
    SeoDiagnosticsPlugin,
    diagnosticsServiceToken,
    type AccessibilityDiagnosticsConfig,
    type DiagnosticProvider,
    type HtmlFormattingOptions,
    type Problem,
} from '@soeditor/html-tools';
import {
    SplitViewPlugin,
    splitViewServiceToken,
    type SplitViewPair,
} from '@soeditor/layout';
import {
    createVisualEditingEngine,
    HistoryPlugin,
    type EditingSelection,
} from '@soeditor/engine';
import {
    BoldPlugin,
    CmsObjectsPlugin,
    MediaPlugin,
    TablePlugin,
    cmsEmbedProviderServiceToken,
    linkTargetProviderServiceToken,
    type CmsEmbedProvider,
    type CmsObjectDefinition,
    type LinkTargetProvider,
    type LinkOptions,
    type MediaInsertOptions,
    type TableCellRange,
    type TableCellProperties,
    type TableColumnResizeOptions,
    type TableProperties,
    type TableRowProperties,
} from '@soeditor/rich-text';
import {
    createSourceEditingEngine,
    SourceEditingPlugin,
    sourceEditingServiceToken,
    type SourceEditingEngineOptions,
} from '@soeditor/source';
import {
    UiPlugin,
    uiRegistryServiceToken,
    type EditorUiTheme,
    type EditorUiDirection,
    type EditorUiTranslationResource,
    type ContextMenuItemDefinition,
    type KeyboardShortcutDefinition,
    type ToolbarConfiguration,
    type ToolbarLayoutOptions,
} from '@soeditor/ui';
import {
    createMarkdownEditingEngine,
    createMarkdownPreviewRenderer,
    htmlToMarkdown,
    markdownToHtml,
    MarkdownPlugin,
    type MarkdownEditingEngineOptions,
    type MarkdownRenderOptions,
} from '@soeditor/markdown';
import {
    createPreviewEngine,
    PreviewPlugin,
    previewServiceToken,
    type PreviewConfiguration,
    type PreviewEngineOptions,
} from '@soeditor/preview';
import {
    ProjectionCoordinatorPlugin,
    projectionCoordinatorServiceToken,
    type ProjectionActivity,
} from '@soeditor/projections';
// @ts-expect-error Editing-model internals are not a package subpath API.
import type { EditingModel } from '@soeditor/engine/model';

interface ExampleService {
    readonly value: string;
}

const typedThreads: readonly CommentThread[] = [];
const typedCommentStorage: CommentStorageAdapter = {
    load: async () => typedThreads,
    save: async () => undefined,
};
const typedRevisions: RevisionSnapshot[] = [];
const typedRevisionStorage: RevisionStorage = {
    erase: async () => undefined,
    list: async () => typedRevisions,
    load: async (id) => {
        const revision = typedRevisions.find((item) => item.id === id);
        if (revision === undefined) throw new Error(`Missing revision ${id}.`);
        return revision;
    },
    save: async (input) => ({
        ...input,
        createdAt: 1,
        id: 'revision-1',
    }),
};
void [
    commentsServiceToken,
    createCommentsPlugin,
    createRevisionsPlugin,
    revisionsServiceToken,
    typedCommentStorage,
    typedRevisionStorage,
];

const ExampleServiceToken = createServiceToken<ExampleService>('example');
const mediaOptions: MediaInsertOptions = { src: '/media.png', alt: 'Media' };
const tableRange: TableCellRange = {
    anchor: { column: 0, row: 0 },
    focus: { column: 1, row: 1 },
};
const tableProperties: TableProperties = {
    alignment: 'center',
    caption: 'Consumer table',
    width: '100%',
};
const tableRowProperties: TableRowProperties = {
    height: 48,
    section: 'head',
};
const tableCellProperties: TableCellProperties = {
    horizontalAlignment: 'right',
    scope: 'col',
};
const tableColumnResize: TableColumnResizeOptions = { width: 240 };
const contextMenuItem: ContextMenuItemDefinition = {
    command: 'consumer.replace',
    label: 'Replace content',
};
const toolbarLayout: ToolbarLayoutOptions = {
    collapsible: true,
    overflow: 'scroll',
    sticky: true,
};
const uiDirection: EditorUiDirection = 'rtl';
const uiTranslation: EditorUiTranslationResource = {
    direction: uiDirection,
    locale: 'ar',
    messages: { Bold: 'عريض' },
};
void [
    MediaPlugin,
    TablePlugin,
    mediaOptions,
    tableCellProperties,
    tableColumnResize,
    tableProperties,
    tableRange,
    tableRowProperties,
    contextMenuItem,
    toolbarLayout,
    uiDirection,
    uiTranslation,
];

class ConsumerPlugin extends Plugin {
    static readonly id = 'consumer';
    static readonly requires = [
        SdkUiPlugin,
        SdkDiagnosticsPlugin,
        StructuredEditingPlugin,
    ];
    #disposeDiagnostic: (() => void) | undefined;
    #disposeContextMenu: (() => void) | undefined;
    #disposeStatus: (() => void) | undefined;
    #disposeStructuredBlock: (() => void) | undefined;
    #disposeStructuredNodeView: (() => void) | undefined;

    override init(): void {
        this.editor.commands.register({
            id: 'consumer.replace',
            execute: ({ editor }, source) => {
                editor.update(
                    (transaction: Transaction) => {
                        transaction.replaceDocument(String(source));
                    },
                    { origin: 'command' },
                );
            },
        });
        const statusFactory: StatusItemFactory = ({ document, editor }) => {
            const element = document.createElement('span');
            return {
                element,
                update: () => {
                    element.textContent = String(editor.getData().length);
                },
            };
        };
        this.#disposeStatus = this.editor.services
            .get(sdkUiRegistryServiceToken)
            .registerStatusItem('consumer.length', statusFactory);
        this.#disposeContextMenu = this.editor.services
            .get(sdkUiRegistryServiceToken)
            .registerContextMenuItem('consumer.replace', contextMenuItem);
        const provider: SdkDiagnosticProvider = {
            id: 'consumer.nonempty',
            provide: (source) =>
                source.length === 0
                    ? [
                          {
                              code: 'consumer.empty',
                              message: 'Document is empty.',
                              severity: 'warning',
                          },
                      ]
                    : [],
        };
        this.#disposeDiagnostic = this.editor.services
            .get(sdkDiagnosticsServiceToken)
            .register(provider);
        const conversion: StructuredBlockConversion = {
            behavior: 'atomic',
            fromHtml: (node) => ({
                attributes: node.attributes,
                children: node.children,
            }),
            id: 'consumer.product-card',
            matches: (node) => node.tagName === 'product-card',
            toHtml: (block): HtmlElement => ({
                attributes: block.attributes,
                children: block.children,
                namespace: 'html',
                tagName: 'product-card',
                type: 'element',
            }),
            type: 'consumer.product-card',
        };
        const structuredRegistry = this.editor.services.get(
            structuredEditingRegistryToken,
        );
        this.#disposeStructuredBlock =
            structuredRegistry.registerBlock(conversion);
        const nodeView: StructuredNodeViewFactory = () => {
            throw new Error('The NodeNext type smoke test does not mount DOM.');
        };
        this.#disposeStructuredNodeView = structuredRegistry.registerNodeView(
            conversion.type,
            nodeView,
        );
    }

    override destroy(): void {
        this.#disposeStructuredNodeView?.();
        this.#disposeStructuredBlock?.();
        this.#disposeDiagnostic?.();
        this.#disposeContextMenu?.();
        this.#disposeStatus?.();
    }
}

const editor = await Editor.create({
    config: { nested: { enabled: true } },
    data: '<p>NodeNext</p>',
    plugins: [
        ConsumerPlugin,
        HistoryPlugin,
        BoldPlugin,
        SourceEditingPlugin,
        DiagnosticsPlugin,
        HtmlFormattingPlugin,
        UiPlugin,
        PreviewPlugin,
    ],
});
const umbrellaEditor = await SoEditor.create({
    data: '<p>Umbrella</p>',
    plugins: umbrellaMinimalPreset.plugins,
});
await umbrellaEditor.destroy();

const accessibilityConfig: AccessibilityDiagnosticsConfig = {
    rules: { 'a11y.iframe-title': 'error' },
};
const diagnosticsWorkflow: DiagnosticsWorkflowConfig = {
    validation: { delay: 250, mode: 'debounced' },
};
const qualityEditor = await Editor.create({
    data: '<!doctype html><html><head></head><body><button></button></body></html>',
    plugins: [AccessibilityDiagnosticsPlugin, SeoDiagnosticsPlugin],
    config: {
        htmlTools: {
            accessibility: accessibilityConfig,
            diagnostics: diagnosticsWorkflow,
        },
    },
});
const qualityProblems = await qualityEditor.services
    .get(diagnosticsServiceToken)
    .validate();
if (
    !qualityProblems.some(
        ({ provider }) => provider === 'html.accessibility',
    ) ||
    !qualityProblems.some(({ provider }) => provider === 'html.seo')
) {
    throw new Error('Packed quality diagnostic plugins were not registered.');
}
await qualityEditor.destroy();

const projectionEditor = await Editor.create({
    plugins: [ProjectionCoordinatorPlugin],
});
const projectionService = projectionEditor.services.get(
    projectionCoordinatorServiceToken,
);
const visualActivity: ProjectionActivity[] = [];
const adapter: SdkProjectionAdapter = {
    id: 'visual',
    update: (activity) => visualActivity.push(activity),
};
projectionService.attach(adapter);
if (
    SdkProjectionCoordinatorPlugin !== ProjectionCoordinatorPlugin ||
    visualActivity.at(-1)?.primary !== true
) {
    throw new Error('Packed projection contracts were not coordinated.');
}
await projectionEditor.destroy();

const sdkLayoutEditor = await Editor.create({
    plugins: [SdkSplitViewPlugin],
});
const sdkProjections = sdkLayoutEditor.services.get(
    projectionCoordinatorServiceToken,
);
sdkProjections.attach({ id: 'visual', update: () => undefined });
sdkProjections.attach({ id: 'source', update: () => undefined });
const sdkLayoutUpdates: string[] = [];
const sdkLayoutAdapter: SdkSplitViewAdapter = {
    focus: () => undefined,
    supports: () => true,
    update: (snapshot) => sdkLayoutUpdates.push(snapshot.pair ?? 'closed'),
};
sdkLayoutEditor.services.get(sdkSplitViewServiceToken).attach(sdkLayoutAdapter);
const sdkLayoutPair: SdkSplitViewPair = 'visual-source';
sdkLayoutEditor.execute('layout.split.open', sdkLayoutPair);
if (sdkLayoutUpdates.at(-1) !== sdkLayoutPair) {
    throw new Error('Packed SDK split-view adapter was not updated.');
}
await sdkLayoutEditor.destroy();

const layoutEditor = await Editor.create({ plugins: [SplitViewPlugin] });
const layoutPair: SplitViewPair = 'visual-source';
if (
    !layoutEditor.commands.has('layout.split.open') ||
    layoutEditor.services.get(splitViewServiceToken).attached
) {
    throw new Error(`Packed layout contract failed for ${layoutPair}.`);
}
await layoutEditor.destroy();

editor.services.register(ExampleServiceToken, { value: 'available' });
editor.execute('consumer.replace', '<p>Compiled</p>');
const serviceValue: string = editor.services.get(ExampleServiceToken).value;

if (serviceValue.length === 0) {
    throw new Error('Typed service lookup returned an invalid value.');
}

const htmlResult = parseHtmlFragment(
    '<product-card data-id="123">Content</product-card>',
);
const firstHtmlNode = htmlResult.document.children[0];

if (firstHtmlNode?.type !== 'element') {
    throw new Error('Packed HTML package returned an unexpected tree.');
}

const htmlElement: HtmlElement = firstHtmlNode;
const serializedHtml: string = serializeHtmlFragment(htmlResult.document);
const visualFactory: typeof createVisualEditingEngine =
    createVisualEditingEngine;
const visualSelection: EditingSelection = {
    anchor: { block: 0, offset: 0 },
    focus: { block: 0, offset: 0 },
};
const editingOperations: readonly EditingOperation[] = [
    {
        block: 0,
        from: 0,
        insertedLength: 1,
        kind: 'replace-text',
        to: 0,
    },
    {
        fromBlock: 1,
        kind: 'move-block',
        toBlock: 0,
    },
];
const structuredContent: EditingStructuredBlockContent = {
    attributes: [],
    children: [],
};
const mappedVisualPoint = mapEditingPoint(
    visualSelection.focus,
    editingOperations,
);

if (
    htmlElement.tagName !== 'product-card' ||
    !serializedHtml.includes('data-id="123"')
) {
    throw new Error('Packed HTML package failed semantic preservation.');
}

void visualFactory;
void visualSelection;
void mappedVisualPoint;
void structuredContent;
const linkOptions: LinkOptions = { href: '/relative' };
const cmsObjectDefinition: CmsObjectDefinition = {
    element: 'aside',
    id: 'promo',
    label: 'Promotion',
    properties: ['campaign'],
};
const linkTargetProvider: LinkTargetProvider = {
    select: async () => ({ href: '/content/42', title: 'Content' }),
};
const cmsEmbedProvider: CmsEmbedProvider = {
    resolve: async (url) => ({ provider: 'consumer', title: 'Embed', url }),
};
void [
    CmsObjectsPlugin,
    cmsEmbedProvider,
    cmsEmbedProviderServiceToken,
    cmsObjectDefinition,
    linkOptions,
    linkTargetProvider,
    linkTargetProviderServiceToken,
];
const sourceFactory: typeof createSourceEditingEngine =
    createSourceEditingEngine;
const sourceOptions = undefined as SourceEditingEngineOptions | undefined;
void sourceFactory;
void sourceOptions;
void sourceEditingServiceToken;
const diagnosticProvider: DiagnosticProvider = {
    id: 'consumer',
    provide: () => [],
};
const formattingOptions: HtmlFormattingOptions = { printWidth: 80 };
const problems: readonly Problem[] = [];
void diagnosticProvider;
void formattingOptions;
void problems;
void diagnosticsServiceToken;
const toolbar: ToolbarConfiguration = ['undo', '|', 'source'];
const theme: EditorUiTheme = 'auto';
const shortcut: KeyboardShortcutDefinition = {
    id: 'consumer.shortcut',
    chord: 'Alt+K',
    command: 'consumer.replace',
};
editor.services.get(uiRegistryServiceToken).registerShortcut(shortcut);
void toolbar;
void theme;
const previewFactory: typeof createPreviewEngine = createPreviewEngine;
const previewConfiguration: PreviewConfiguration = {
    template: '<main>{{ content }}</main>',
};
const previewOptions = undefined as PreviewEngineOptions | undefined;
void previewFactory;
void previewConfiguration;
void previewOptions;
void previewServiceToken;
const markdownFactory: typeof createMarkdownEditingEngine =
    createMarkdownEditingEngine;
const markdownOptions = undefined as MarkdownEditingEngineOptions | undefined;
const markdownRenderOptions: MarkdownRenderOptions = { rawHtml: 'preserve' };
const markdownRenderer = createMarkdownPreviewRenderer(markdownRenderOptions);
const markdownHtml: string = markdownToHtml('# Consumer');
const convertedMarkdown: string = htmlToMarkdown('<h1>Consumer</h1>').source;
void markdownFactory;
void markdownOptions;
void markdownRenderer;
void markdownHtml;
void convertedMarkdown;
void MarkdownPlugin;
const developerToolsFactory: typeof createDeveloperToolsEngine =
    createDeveloperToolsEngine;
const developerToolsOptions = undefined as
    DeveloperToolsEngineOptions | undefined;
const outline: readonly OutlineItem[] = createDocumentOutline('<h1>Title</h1>');
const inspector = undefined as InspectorElement | undefined;
void developerToolsFactory;
void developerToolsOptions;
void outline;
void inspector;
void DeveloperToolsPlugin;
const presets: readonly EditorPreset[] = [
    minimalPreset,
    classicPreset,
    developerPreset,
    markdownPreset,
];
void subpathMinimalPreset;
const extendedPreset = extendPreset(minimalPreset, {
    plugins: [ConsumerPlugin],
});
void presets;
void extendedPreset;
const fileManager: FileManager = new SoFinderAdapter({
    pick: async (
        options: FileManagerOpenOptions,
    ): Promise<SoFinderSelection> => ({
        metadata: { kind: options.kind },
        mimeType: 'image/png',
        url: '/consumer.png',
    }),
});
const adapterOptions: SoFinderAdapterOptions = {
    pick: async () => ({ url: '/consumer.png' }),
};
const fileResult: FileManagerResult | null = normalizeFileManagerResult({
    url: '/consumer.png',
});
void fileManager;
void adapterOptions;
void fileResult;
void fileManagerServiceToken;
void FileManagerPlugin;
const uploadService: UploadService = {
    create: (request) => ({
        cancel: () => undefined,
        result: Promise.resolve({
            mime: request.type,
            name: request.name,
            url: '/consumer-upload.png',
        }),
        subscribe: (listener) => {
            listener({ loaded: request.size, total: request.size });
            return () => undefined;
        },
    }),
};
void uploadService;
void uploadServiceToken;
void uploadWorkflowServiceToken;
void UploadPlugin;
const rejectInternalModel = (value: EditingModel): void => {
    void value;
};
void rejectInternalModel;

const attachment: WorkspaceAttachmentFactory = {
    id: 'consumer.attachment',
    attach: () => ({ destroy: () => undefined }),
    requirements: { formats: ['html'] },
};
const diagnostics: WorkspaceDiagnostic[] = [];
const workspace = await createEditorWorkspace({
    attachments: [attachment],
    createEditor: ({ source }) => Editor.create({ data: source }),
    onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
    value: { initialValue: '<p>Workspace</p>', kind: 'uncontrolled' },
});
const saveRequests: EditorSaveRequest[] = [];
const saveAdapter: EditorSaveAdapter = {
    save: async (request) => {
        saveRequests.push(request);
        return { revisionToken: 'consumer-v1', status: 'saved' };
    },
};
const saveWorkflow = createEditorSaveWorkflow({
    adapter: saveAdapter,
    editor: workspace.editor,
});
workspace.editor.setData('<p>Packed save</p>');
await saveWorkflow.save();
if (
    saveRequests[0]?.source !== '<p>Packed save</p>' ||
    workspace.editor.state.dirty
) {
    throw new Error('Packed save workflow did not persist canonical source.');
}
saveWorkflow.destroy();
await workspace.destroy();
const reactOptions = {
    attachments: [attachment],
    createEditor: ({ source }) => Editor.create({ data: source }),
    initialValue: '<p>React</p>',
    onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
    previewIsolation: 'isolated',
} satisfies ReactWorkspaceOptions;
const vueOptions = {
    attachments: [attachment],
    createEditor: ({ source }) => Editor.create({ data: source }),
    initialValue: '<p>Vue</p>',
    onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
    previewIsolation: 'isolated',
} satisfies VueWorkspaceOptions;
const sdkCmsObjects = [
    { id: 'product-card', label: 'Product card' },
] satisfies readonly SdkCmsObjectDefinition[];
const sdkPasteProcessor = {
    id: 'consumer.paste',
    process: ({ html }) => ({ html }),
} satisfies PasteProcessor;
const sdkUploadService = {
    create: () => {
        throw new Error('Consumer-only upload adapter.');
    },
} satisfies SdkUploadService;
const sdkTranslations = [
    { locale: 'en-CMS', messages: { Inspect: 'Inspect' } },
] satisfies readonly SdkEditorUiTranslationResource[];
const sdkIcons = { 'format.bold': 'B' } satisfies EditorUiIconResource;
const sdkTheme = { accent: '#005ea8' } satisfies EditorUiThemeVariables;
void [
    createUmbrellaWorkspace,
    diagnostics,
    pluginTemplateVersion,
    sdkCmsObjects,
    sdkIcons,
    sdkPastePipelineServiceToken,
    sdkPasteProcessor,
    sdkTheme,
    sdkTranslations,
    sdkUploadService,
    sdkUploadServiceToken,
    reactOptions,
    saveRequests,
    useReactSoEditorWorkspace,
    useVueSoEditorWorkspace,
    vueOptions,
];

// @ts-expect-error Cleanup is owned by Editor.destroy().
editor.commands.clear();
// @ts-expect-error Plugin lifecycle is not a consumer capability.
editor.plugins.destroy();
// @ts-expect-error Cleanup is owned by Editor.destroy().
editor.services.clear();
// @ts-expect-error Cleanup is owned by Editor.destroy().
editor.events.clear();
// @ts-expect-error Event publication is owned by core infrastructure.
editor.events.emit('editor:ready', { editor });

await editor.destroy();
