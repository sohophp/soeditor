import{P as f,E as b,c as P,b as g,s as ne,a as I,d as te,_ as R}from"./index-hSfr3Xru.js";class re extends Error{constructor(e){super(`Diagnostic provider "${e}" is already registered.`),this.name="DiagnosticProviderAlreadyRegisteredError"}}class y extends TypeError{constructor(e,t){super(`Diagnostic provider "${e}" ${t}`),this.name="InvalidDiagnosticError"}}const C=P("soeditor.html-diagnostics");class O extends f{static id="html-diagnostics";#e=new Map;#r=new Set;#a;#n;#c;#s=0;#t=D("idle",[],[]);#l=!1;init(){this.#a=ie(this.editor.config.get("htmlTools.diagnostics.validation")),this.#u(oe),this.#u(ce);const e=()=>this.#h(),r=Object.freeze({get failures(){return e().failures},get problems(){return e().problems},get snapshot(){return e()},getCounts:a=>this.#D(a),getProblems:a=>this.#p(a),register:a=>this.#u(a),subscribe:a=>this.#T(a),validate:a=>this.#A(a)});this.editor.services.register(C,r),this.editor.commands.register({id:"document.validate",label:"Validate HTML",execute:(a,...o)=>{if(o.length!==0)throw new TypeError('Command "document.validate" does not accept arguments.');return this.#A()}}),this.#a!==void 0&&(this.#c=this.editor.events.on("document:change",()=>this.#o()),this.#o())}destroy(){this.#l=!0,this.#c?.(),this.#c=void 0,this.#n!==void 0&&(k.clearTimeout(this.#n),this.#n=void 0),this.#e.clear(),this.#r.clear(),this.#t=D("idle",[],[]),this.#s+=1}#u(e){if(this.#i(),typeof e!="object"||e===null)throw new TypeError("A diagnostic provider must be an object.");if(typeof e.id!="string"||e.id.trim().length===0)throw new TypeError("A diagnostic provider ID must be a non-empty string.");if(typeof e.provide!="function")throw new TypeError(`Diagnostic provider "${e.id}" requires a provide function.`);if(this.#e.has(e.id))throw new re(e.id);this.#e.set(e.id,e),this.#s+=1,this.#o();let t=!0;return()=>{t&&this.#e.get(e.id)===e&&(this.#e.delete(e.id),this.#s+=1,this.#o()),t=!1}}async#A(e=this.editor.getData()){this.#i();const t=++this.#s,r=e===this.editor.getData(),a=[...this.#e.values()];r&&this.#d(D("validating",this.#t.problems,this.#t.failures));const o=await Promise.all(a.map(l=>ae(l,e))),s=o.flatMap(l=>l.problems),c=o.flatMap(l=>l.failures),i=Object.freeze(s);return t===this.#s&&e===this.editor.getData()&&this.#d(D("ready",i,c)),i}#h(){return this.#i(),this.#t}#p(e){if(this.#i(),e===void 0)return this.#t.problems;const t=se(e);return Object.freeze(this.#t.problems.filter(r=>(t.providers===void 0||t.providers.has(r.provider))&&(t.severities===void 0||t.severities.has(r.severity))))}#D(e){return L(this.#p(e))}#T(e){if(this.#i(),typeof e!="function")throw new TypeError("A diagnostics listener must be a function.");this.#r.add(e);let t=!0;return()=>{t&&this.#r.delete(e),t=!1}}#d(e){this.#t=e;for(const t of[...this.#r])t(e)}#o(){this.#a===void 0||this.#l||(this.#n!==void 0&&k.clearTimeout(this.#n),this.#n=k.setTimeout(()=>{this.#n=void 0,this.#A()},this.#a))}#i(){if(this.#l)throw new b}}const k=globalThis;async function ae(n,e){try{const t=await n.provide(e);if(!Array.isArray(t))throw new y(n.id,"must return an array of diagnostics.");return{failures:[],problems:t.map((r,a)=>ue(n.id,r,a,e.length))}}catch(t){return{failures:Object.freeze([Object.freeze({provider:n.id,error:t})]),problems:Object.freeze([])}}}function D(n,e,t){const r=Object.isFrozen(e)?e:Object.freeze([...e]),a=Object.isFrozen(t)?t:Object.freeze([...t]);return Object.freeze({counts:L(r),failures:a,problems:r,status:n})}function L(n){const e=Object.create(null),t={error:0,warning:0,info:0,hint:0};for(const r of n)e[r.provider]=(e[r.provider]??0)+1,t[r.severity]+=1;return Object.freeze({total:n.length,byProvider:Object.freeze(e),bySeverity:Object.freeze(t)})}function se(n){if(typeof n!="object"||n===null)throw new TypeError("A diagnostic filter must be an object.");if(n.providers!==void 0&&!Array.isArray(n.providers))throw new TypeError("Diagnostic filter providers must be an array.");if(n.severities!==void 0&&!Array.isArray(n.severities))throw new TypeError("Diagnostic filter severities must be an array.");const e=n.providers?.map(r=>{if(typeof r!="string"||r.trim().length===0)throw new TypeError("Diagnostic filter providers must be non-empty strings.");return r}),t=n.severities?.map(r=>{if(!H(r))throw new TypeError("Diagnostic filter severities must be supported severities.");return r});return{...e===void 0?{}:{providers:new Set(e)},...t===void 0?{}:{severities:new Set(t)}}}function ie(n){if(n===void 0)return;if(typeof n!="object"||n===null||Array.isArray(n))throw new TypeError('"htmlTools.diagnostics.validation" must be a validation policy object.');const e=Reflect.get(n,"mode");if(e==="manual")return;if(e!=="debounced")throw new TypeError('Diagnostics validation mode must be "manual" or "debounced".');const t=Reflect.get(n,"delay")??300;if(!Number.isInteger(t)||Number(t)<0||Number(t)>6e4)throw new TypeError("Diagnostics debounce delay must be an integer from 0 to 60000 milliseconds.");return Number(t)}const oe=Object.freeze({id:"html.parser",provide:n=>x(n).diagnostics.map(e=>({code:e.code,message:e.message,severity:e.severity,...e.source===void 0?{}:{source:e.source}}))}),ce=Object.freeze({id:"html.structure",provide:n=>le(n)});function le(n){const e=x(n),t=[],r=new Set;if(U(e.document.children,a=>{if(a.namespace!=="html")return;const o=a.attributes.find(s=>s.name==="id");o!==void 0&&o.value.length>0&&(r.has(o.value)&&t.push({code:"html.duplicate-id",message:`Duplicate HTML id "${o.value}".`,severity:"warning",...o.source===void 0?{}:{source:o.source}}),r.add(o.value)),a.tagName==="img"&&!a.attributes.some(s=>s.name==="alt")&&t.push({code:"html.image-alt",message:"Image element is missing an alt attribute.",severity:"warning",...a.source?.startTag===void 0?{}:{source:a.source.startTag}})}),e.complete){const a=e.document.children.find(o=>o.type==="element"&&o.namespace==="html"&&o.tagName==="html");a!==void 0&&!a.attributes.some(o=>o.name==="lang")&&t.push({code:"html.document-lang",message:"HTML document root is missing a lang attribute.",severity:"warning",...a.source?.startTag===void 0?{}:{source:a.source.startTag}})}return t}function x(n){const e=pe(n),t=e?g(n):I(n);return{complete:e,diagnostics:t.diagnostics,document:t.document}}function U(n,e){for(const t of n)t.type==="element"&&(e(t),U(t.children,e))}function ue(n,e,t,r){if(typeof e!="object"||e===null||!H(e.severity)||typeof e.code!="string"||e.code.length===0||typeof e.message!="string"||e.message.length===0)throw new y(n,`returned an invalid diagnostic at index ${t}.`);return Object.freeze({code:e.code,message:e.message,provider:n,severity:e.severity,...e.source===void 0?{}:{source:Ae(n,e.source,t,r)}})}function Ae(n,e,t,r){if(typeof e!="object"||e===null)throw F(n,t);const a=B(n,e.start,t,r),o=B(n,e.end,t,r);if(o.offset<a.offset)throw F(n,t);return Object.freeze({start:a,end:o})}function B(n,e,t,r){if(typeof e!="object"||e===null||!Number.isInteger(e.line)||e.line<1||!Number.isInteger(e.column)||e.column<1||!Number.isInteger(e.offset)||e.offset<0||e.offset>r)throw F(n,t);return Object.freeze({...e})}function F(n,e){return new y(n,`returned an invalid source range at index ${e}.`)}function H(n){return n==="error"||n==="warning"||n==="info"||n==="hint"}function pe(n){return/<!doctype\s|<\/?(?:html|head|body)(?:\s|>)/iu.test(n)}const $=`(function() {
  "use strict";
  var Ru = Object.defineProperty;
  var yt$1 = (t, e) => {
    for (var r in e) Ru(t, r, { get: e[r], enumerable: true });
  };
  var Su = {};
  yt$1(Su, { __debug: () => $i$1, check: () => Vi$1, doc: () => ar$1, format: () => Pu, formatWithCursor: () => Ou, getSupportInfo: () => Wi$1, util: () => fr$1, version: () => gu });
  var X$1 = (t, e) => (r, n, ...u) => r | 1 && n == null ? void 0 : (e.call(n) ?? n[t]).apply(n, u);
  var vu = String.prototype.replaceAll ?? function(t, e) {
    return t.global ? this.replace(t, e) : this.split(t).join(e);
  }, Lu = X$1("replaceAll", function() {
    if (typeof this == "string") return vu;
  }), ne$1 = Lu;
  var Ne$1 = class Ne {
    diff(e, r, n = {}) {
      let u;
      typeof n == "function" ? (u = n, n = {}) : "callback" in n && (u = n.callback);
      let o = this.castInput(e, n), i = this.castInput(r, n), D = this.removeEmpty(this.tokenize(o, n)), s = this.removeEmpty(this.tokenize(i, n));
      return this.diffWithOptionsObj(D, s, n, u);
    }
    diffWithOptionsObj(e, r, n, u) {
      var o;
      let i = (C2) => {
        if (C2 = this.postProcess(C2, n), u) {
          setTimeout(function() {
            u(C2);
          }, 0);
          return;
        } else return C2;
      }, D = r.length, s = e.length, a = 1, c = D + s;
      n.maxEditLength != null && (c = Math.min(c, n.maxEditLength));
      let p2 = (o = n.timeout) !== null && o !== void 0 ? o : 1 / 0, l = Date.now() + p2, m2 = [{ oldPos: -1, lastComponent: void 0 }], f = this.extractCommon(m2[0], r, e, 0, n);
      if (m2[0].oldPos + 1 >= s && f + 1 >= D) return i(this.buildValues(m2[0].lastComponent, r, e));
      let F2 = -1 / 0, d = 1 / 0, E2 = () => {
        for (let C2 = Math.max(F2, -a); C2 <= Math.min(d, a); C2 += 2) {
          let h, _ = m2[C2 - 1], P2 = m2[C2 + 1];
          _ && (m2[C2 - 1] = void 0);
          let A2 = false;
          if (P2) {
            let J2 = P2.oldPos - C2;
            A2 = P2 && 0 <= J2 && J2 < D;
          }
          let B2 = _ && _.oldPos + 1 < s;
          if (!A2 && !B2) {
            m2[C2] = void 0;
            continue;
          }
          if (!B2 || A2 && _.oldPos < P2.oldPos ? h = this.addToPath(P2, true, false, 0, n) : h = this.addToPath(_, false, true, 1, n), f = this.extractCommon(h, r, e, C2, n), h.oldPos + 1 >= s && f + 1 >= D) return i(this.buildValues(h.lastComponent, r, e)) || true;
          m2[C2] = h, h.oldPos + 1 >= s && (d = Math.min(d, C2 - 1)), f + 1 >= D && (F2 = Math.max(F2, C2 + 1));
        }
        a++;
      };
      if (u) (function C2() {
        setTimeout(function() {
          if (a > c || Date.now() > l) return u(void 0);
          E2() || C2();
        }, 0);
      })();
      else for (; a <= c && Date.now() <= l; ) {
        let C2 = E2();
        if (C2) return C2;
      }
    }
    addToPath(e, r, n, u, o) {
      let i = e.lastComponent;
      return i && !o.oneChangePerToken && i.added === r && i.removed === n ? { oldPos: e.oldPos + u, lastComponent: { count: i.count + 1, added: r, removed: n, previousComponent: i.previousComponent } } : { oldPos: e.oldPos + u, lastComponent: { count: 1, added: r, removed: n, previousComponent: i } };
    }
    extractCommon(e, r, n, u, o) {
      let i = r.length, D = n.length, s = e.oldPos, a = s - u, c = 0;
      for (; a + 1 < i && s + 1 < D && this.equals(n[s + 1], r[a + 1], o); ) a++, s++, c++, o.oneChangePerToken && (e.lastComponent = { count: 1, previousComponent: e.lastComponent, added: false, removed: false });
      return c && !o.oneChangePerToken && (e.lastComponent = { count: c, previousComponent: e.lastComponent, added: false, removed: false }), e.oldPos = s, a;
    }
    equals(e, r, n) {
      return n.comparator ? n.comparator(e, r) : e === r || !!n.ignoreCase && e.toLowerCase() === r.toLowerCase();
    }
    removeEmpty(e) {
      let r = [];
      for (let n = 0; n < e.length; n++) e[n] && r.push(e[n]);
      return r;
    }
    castInput(e, r) {
      return e;
    }
    tokenize(e, r) {
      return Array.from(e);
    }
    join(e) {
      return e.join("");
    }
    postProcess(e, r) {
      return e;
    }
    get useLongestToken() {
      return false;
    }
    buildValues(e, r, n) {
      let u = [], o;
      for (; e; ) u.push(e), o = e.previousComponent, delete e.previousComponent, e = o;
      u.reverse();
      let i = u.length, D = 0, s = 0, a = 0;
      for (; D < i; D++) {
        let c = u[D];
        if (c.removed) c.value = this.join(n.slice(a, a + c.count)), a += c.count;
        else {
          if (!c.added && this.useLongestToken) {
            let p2 = r.slice(s, s + c.count);
            p2 = p2.map(function(l, m2) {
              let f = n[a + m2];
              return f.length > l.length ? f : l;
            }), c.value = this.join(p2);
          } else c.value = this.join(r.slice(s, s + c.count));
          s += c.count, c.added || (a += c.count);
        }
      }
      return u;
    }
  };
  var At$1 = class At extends Ne$1 {
    tokenize(e) {
      return e.slice();
    }
    join(e) {
      return e;
    }
    removeEmpty(e) {
      return e;
    }
  }, pr$1 = new At$1();
  function xt$1(t, e, r) {
    return pr$1.diff(t, e, r);
  }
  var Mu = () => {
  }, k$1 = Mu;
  var dr$1 = "cr", Fr$1 = "crlf", Yu = "lf", ju = Yu, Bt$1 = "\\r", Er$1 = \`\\r
\`, ze$1 = \`
\`, Uu = ze$1;
  function Cr$1(t) {
    let e = t.indexOf(Bt$1);
    return e !== -1 ? t.charAt(e + 1) === ze$1 ? Fr$1 : dr$1 : ju;
  }
  function we$1(t) {
    return t === dr$1 ? Bt$1 : t === Fr$1 ? Er$1 : Uu;
  }
  var Vu = /* @__PURE__ */ new Map([[ze$1, /\\n/g], [Bt$1, /\\r/g], [Er$1, /\\r\\n/g]]);
  function Tt$1(t, e) {
    let r = Vu.get(e);
    return t.match(r)?.length ?? 0;
  }
  var Wu = /\\r\\n?/g;
  function hr$1(t) {
    return ne$1(0, t, Wu, ze$1);
  }
  var ue$1 = /* @__PURE__ */ Symbol.for("comments");
  function $u(t) {
    return this[t < 0 ? this.length + t : t];
  }
  var zu = X$1("at", function() {
    if (Array.isArray(this) || typeof this == "string") return $u;
  }), y$1 = zu;
  var G$1 = "string", U$1 = "array", V$1 = "cursor", I$1 = "indent", R$1 = "align", v = "trim", x$1 = "group", S$1 = "fill", T$1 = "if-break", L$1 = "indent-if-break", M$1 = "line-suffix", Y$1 = "line-suffix-boundary", g = "line", b$1 = "label", N$1 = "break-parent", Ge$1 = /* @__PURE__ */ new Set([V$1, I$1, R$1, v, x$1, S$1, T$1, L$1, M$1, Y$1, g, b$1, N$1]);
  function gr$1(t) {
    let e = t.length;
    for (; e > 0 && (t[e - 1] === "\\r" || t[e - 1] === \`
\`); ) e--;
    return e < t.length ? t.slice(0, e) : t;
  }
  function Fe$1(t, e, r) {
    if (!t.has(e)) {
      let n = r(e);
      t.set(e, n);
    }
    return t.get(e);
  }
  function Gu(t) {
    if (typeof t == "string") return G$1;
    if (Array.isArray(t)) return U$1;
    if (!t) return;
    let { type: e } = t;
    if (Ge$1.has(e)) return e;
  }
  var q$1 = Gu;
  var Ku = (t) => new Intl.ListFormat("en-US", { type: "disjunction" }).format(t);
  function Hu(t) {
    let e = t === null ? "null" : typeof t;
    if (e !== "string" && e !== "object") return \`Unexpected doc '\${e}', 
Expected it to be 'string' or 'object'.\`;
    if (q$1(t)) throw new Error("doc is valid.");
    let r = Object.prototype.toString.call(t);
    if (r !== "[object Object]") return \`Unexpected doc '\${r}'.\`;
    let n = Ku([...Ge$1].map((u) => \`'\${u}'\`));
    return \`Unexpected doc.type '\${t.type}'.
Expected it to be \${n}.\`;
  }
  var Nt$1 = class Nt extends Error {
    name = "InvalidDocError";
    constructor(e) {
      super(Hu(e)), this.doc = e;
    }
  }, Z$1 = Nt$1;
  var _r$1 = {};
  function Ju(t, e, r, n) {
    let u = [t];
    for (; u.length > 0; ) {
      let o = u.pop();
      if (o === _r$1) {
        r(u.pop());
        continue;
      }
      r && u.push(o, _r$1);
      let i = q$1(o);
      if (!i) throw new Z$1(o);
      if (e?.(o) !== false) switch (i) {
        case U$1:
        case S$1: {
          let D = i === U$1 ? o : o.parts;
          for (let s = D.length, a = s - 1; a >= 0; --a) u.push(D[a]);
          break;
        }
        case T$1:
          u.push(o.flatContents, o.breakContents);
          break;
        case x$1:
          if (n && o.expandedStates) for (let D = o.expandedStates.length, s = D - 1; s >= 0; --s) u.push(o.expandedStates[s]);
          else u.push(o.contents);
          break;
        case R$1:
        case I$1:
        case L$1:
        case b$1:
        case M$1:
          u.push(o.contents);
          break;
        case G$1:
        case V$1:
        case v:
        case Y$1:
        case g:
        case N$1:
          break;
        default:
          throw new Z$1(o);
      }
    }
  }
  var Oe$1 = Ju;
  function Se$1(t, e) {
    if (typeof t == "string") return e(t);
    let r = /* @__PURE__ */ new Map();
    return n(t);
    function n(o) {
      return Fe$1(r, o, u);
    }
    function u(o) {
      switch (q$1(o)) {
        case U$1:
          return e(o.map(n));
        case S$1:
          return e({ ...o, parts: o.parts.map(n) });
        case T$1:
          return e({ ...o, breakContents: n(o.breakContents), flatContents: n(o.flatContents) });
        case x$1: {
          let { expandedStates: i, contents: D } = o;
          return i ? (i = i.map(n), D = i[0]) : D = n(D), e({ ...o, contents: D, expandedStates: i });
        }
        case R$1:
        case I$1:
        case L$1:
        case b$1:
        case M$1:
          return e({ ...o, contents: n(o.contents) });
        case G$1:
        case V$1:
        case v:
        case Y$1:
        case g:
        case N$1:
          return e(o);
        default:
          throw new Z$1(o);
      }
    }
  }
  function Ke$1(t, e, r) {
    let n = r, u = false;
    function o(i) {
      if (u) return false;
      let D = e(i);
      D !== void 0 && (u = true, n = D);
    }
    return Oe$1(t, o), n;
  }
  function qu(t) {
    if (t.type === x$1 && t.break || t.type === g && t.hard || t.type === N$1) return true;
  }
  function xr$1(t) {
    return Ke$1(t, qu, false);
  }
  function yr$1(t) {
    if (t.length > 0) {
      let e = y$1(0, t, -1);
      !e.expandedStates && !e.break && (e.break = "propagated");
    }
    return null;
  }
  function Br(t) {
    let e = /* @__PURE__ */ new Set(), r = [];
    function n(o) {
      if (o.type === N$1 && yr$1(r), o.type === x$1) {
        if (r.push(o), e.has(o)) return false;
        e.add(o);
      }
    }
    function u(o) {
      o.type === x$1 && r.pop().break && yr$1(r);
    }
    Oe$1(t, n, u, true);
  }
  function Xu(t) {
    return t.type === g && !t.hard ? t.soft ? "" : " " : t.type === T$1 ? t.flatContents : t;
  }
  function Tr$1(t) {
    return Se$1(t, Xu);
  }
  function Ar$1(t) {
    for (t = [...t]; t.length >= 2 && y$1(0, t, -2).type === g && y$1(0, t, -1).type === N$1; ) t.length -= 2;
    if (t.length > 0) {
      let e = Pe$1(y$1(0, t, -1));
      t[t.length - 1] = e;
    }
    return t;
  }
  function Pe$1(t) {
    switch (q$1(t)) {
      case I$1:
      case L$1:
      case x$1:
      case M$1:
      case b$1: {
        let e = Pe$1(t.contents);
        return { ...t, contents: e };
      }
      case T$1:
        return { ...t, breakContents: Pe$1(t.breakContents), flatContents: Pe$1(t.flatContents) };
      case S$1:
        return { ...t, parts: Ar$1(t.parts) };
      case U$1:
        return Ar$1(t);
      case G$1:
        return gr$1(t);
      case R$1:
      case V$1:
      case v:
      case Y$1:
      case g:
      case N$1:
        break;
      default:
        throw new Z$1(t);
    }
    return t;
  }
  function He$1(t) {
    return Pe$1(Zu(t));
  }
  function Qu(t) {
    switch (q$1(t)) {
      case S$1: {
        let { parts: e } = t;
        if (e.every((r) => r === "")) return "";
        if (e.length === 1) return e[0];
        break;
      }
      case x$1:
        if (!t.contents && !t.id && !t.break && !t.expandedStates) return "";
        if (t.contents.type === x$1 && t.contents.id === t.id && t.contents.break === t.break && t.contents.expandedStates === t.expandedStates) return t.contents;
        break;
      case R$1:
      case I$1:
      case L$1:
      case M$1:
        if (!t.contents) return "";
        break;
      case T$1:
        if (!t.flatContents && !t.breakContents) return "";
        break;
      case U$1: {
        let e = [];
        for (let r of t) {
          if (!r) continue;
          let [n, ...u] = Array.isArray(r) ? r : [r];
          typeof n == "string" && typeof y$1(0, e, -1) == "string" ? e[e.length - 1] += n : e.push(n), e.push(...u);
        }
        return e.length === 0 ? "" : e.length === 1 ? e[0] : e;
      }
      case G$1:
      case V$1:
      case v:
      case Y$1:
      case g:
      case b$1:
      case N$1:
        break;
      default:
        throw new Z$1(t);
    }
    return t;
  }
  function Zu(t) {
    return Se$1(t, (e) => Qu(e));
  }
  function Nr$1(t, e = Je$1) {
    return Se$1(t, (r) => typeof r == "string" ? be$1(e, r.split(\`
\`)) : r);
  }
  function eo$1(t) {
    if (t.type === g) return true;
  }
  function wr$1(t) {
    return Ke$1(t, eo$1, false);
  }
  function Ee$1(t, e) {
    return t.type === b$1 ? { ...t, contents: e(t.contents) } : e(t);
  }
  var qe$1 = k$1;
  function oe$1(t) {
    return { type: I$1, contents: t };
  }
  function De$1(t, e) {
    return { type: R$1, contents: e, n: t };
  }
  function Sr(t) {
    return De$1(Number.NEGATIVE_INFINITY, t);
  }
  function Xe$1(t) {
    return De$1({ type: "root" }, t);
  }
  function br$1(t) {
    return De$1(-1, t);
  }
  function Qe$1(t, e, r) {
    let n = t;
    if (e > 0) {
      for (let u = 0; u < Math.floor(e / r); ++u) n = oe$1(n);
      n = De$1(e % r, n), n = De$1(Number.NEGATIVE_INFINITY, n);
    }
    return n;
  }
  var ae$1 = { type: N$1 };
  var ee$1 = { type: V$1 };
  function kr$1(t) {
    return { type: S$1, parts: t };
  }
  function wt$1(t, e = {}) {
    return qe$1(e.expandedStates), { type: x$1, id: e.id, contents: t, break: !!e.shouldBreak, expandedStates: e.expandedStates };
  }
  function Ir$1(t, e) {
    return wt$1(t[0], { ...e, expandedStates: t });
  }
  function Rr$1(t, e = "", r = {}) {
    return { type: T$1, breakContents: t, flatContents: e, groupId: r.groupId };
  }
  function vr(t, e) {
    return { type: L$1, contents: t, groupId: e.groupId, negate: e.negate };
  }
  function be$1(t, e) {
    let r = [];
    for (let n = 0; n < e.length; n++) n !== 0 && r.push(t), r.push(e[n]);
    return r;
  }
  function Lr$1(t, e) {
    return t ? { type: b$1, label: t, contents: e } : e;
  }
  var Ze$1 = { type: g }, Mr$1 = { type: g, soft: true }, ke$1 = { type: g, hard: true }, W = [ke$1, ae$1], Ot$1 = { type: g, hard: true, literal: true }, Je$1 = [Ot$1, ae$1];
  function Ie$1(t) {
    return { type: M$1, contents: t };
  }
  var Yr$1 = { type: Y$1 };
  var jr$1 = { type: v };
  function te$1(t) {
    if (!t) return "";
    if (Array.isArray(t)) {
      let e = [];
      for (let r of t) if (Array.isArray(r)) e.push(...te$1(r));
      else {
        let n = te$1(r);
        n !== "" && e.push(n);
      }
      return e;
    }
    return t.type === T$1 ? { ...t, breakContents: te$1(t.breakContents), flatContents: te$1(t.flatContents) } : t.type === x$1 ? { ...t, contents: te$1(t.contents), expandedStates: t.expandedStates?.map(te$1) } : t.type === S$1 ? { type: "fill", parts: t.parts.map(te$1) } : t.contents ? { ...t, contents: te$1(t.contents) } : t;
  }
  function Ur$1(t) {
    let e = /* @__PURE__ */ Object.create(null), r = /* @__PURE__ */ new Set();
    return n(te$1(t));
    function n(o, i, D) {
      if (typeof o == "string") return JSON.stringify(o);
      if (Array.isArray(o)) {
        let s = o.map(n).filter(Boolean);
        return s.length === 1 ? s[0] : \`[\${s.join(", ")}]\`;
      }
      if (o.type === g) {
        let s = D?.[i + 1]?.type === N$1;
        return o.literal ? s ? "literalline" : "literallineWithoutBreakParent" : o.hard ? s ? "hardline" : "hardlineWithoutBreakParent" : o.soft ? "softline" : "line";
      }
      if (o.type === N$1) return D?.[i - 1]?.type === g && D[i - 1].hard ? void 0 : "breakParent";
      if (o.type === v) return "trim";
      if (o.type === I$1) return "indent(" + n(o.contents) + ")";
      if (o.type === R$1) return o.n === Number.NEGATIVE_INFINITY ? "dedentToRoot(" + n(o.contents) + ")" : o.n < 0 ? "dedent(" + n(o.contents) + ")" : o.n.type === "root" ? "markAsRoot(" + n(o.contents) + ")" : "align(" + JSON.stringify(o.n) + ", " + n(o.contents) + ")";
      if (o.type === T$1) return "ifBreak(" + n(o.breakContents) + (o.flatContents ? ", " + n(o.flatContents) : "") + (o.groupId ? (o.flatContents ? "" : ', ""') + \`, { groupId: \${u(o.groupId)} }\` : "") + ")";
      if (o.type === L$1) {
        let s = [];
        o.negate && s.push("negate: true"), o.groupId && s.push(\`groupId: \${u(o.groupId)}\`);
        let a = s.length > 0 ? \`, { \${s.join(", ")} }\` : "";
        return \`indentIfBreak(\${n(o.contents)}\${a})\`;
      }
      if (o.type === x$1) {
        let s = [];
        o.break && o.break !== "propagated" && s.push("shouldBreak: true"), o.id && s.push(\`id: \${u(o.id)}\`);
        let a = s.length > 0 ? \`, { \${s.join(", ")} }\` : "";
        return o.expandedStates ? \`conditionalGroup([\${o.expandedStates.map((c) => n(c)).join(",")}]\${a})\` : \`group(\${n(o.contents)}\${a})\`;
      }
      if (o.type === S$1) return \`fill([\${o.parts.map((s) => n(s)).join(", ")}])\`;
      if (o.type === M$1) return "lineSuffix(" + n(o.contents) + ")";
      if (o.type === Y$1) return "lineSuffixBoundary";
      if (o.type === b$1) return \`label(\${JSON.stringify(o.label)}, \${n(o.contents)})\`;
      if (o.type === V$1) return "cursor";
      throw new Error("Unknown doc type " + o.type);
    }
    function u(o) {
      if (typeof o != "symbol") return JSON.stringify(String(o));
      if (o in e) return e[o];
      let i = o.description || "symbol";
      for (let D = 0; ; D++) {
        let s = i + (D > 0 ? \` #\${D}\` : "");
        if (!r.has(s)) return r.add(s), e[o] = \`Symbol.for(\${JSON.stringify(s)})\`;
      }
    }
  }
  var Vr$1 = () => /[#*0-9]\\uFE0F?\\u20E3|[\\xA9\\xAE\\u203C\\u2049\\u2122\\u2139\\u2194-\\u2199\\u21A9\\u21AA\\u231A\\u231B\\u2328\\u23CF\\u23ED-\\u23EF\\u23F1\\u23F2\\u23F8-\\u23FA\\u24C2\\u25AA\\u25AB\\u25B6\\u25C0\\u25FB\\u25FC\\u25FE\\u2600-\\u2604\\u260E\\u2611\\u2614\\u2615\\u2618\\u2620\\u2622\\u2623\\u2626\\u262A\\u262E\\u262F\\u2638-\\u263A\\u2640\\u2642\\u2648-\\u2653\\u265F\\u2660\\u2663\\u2665\\u2666\\u2668\\u267B\\u267E\\u267F\\u2692\\u2694-\\u2697\\u2699\\u269B\\u269C\\u26A0\\u26A7\\u26AA\\u26B0\\u26B1\\u26BD\\u26BE\\u26C4\\u26C8\\u26CF\\u26D1\\u26E9\\u26F0-\\u26F5\\u26F7\\u26F8\\u26FA\\u2702\\u2708\\u2709\\u270F\\u2712\\u2714\\u2716\\u271D\\u2721\\u2733\\u2734\\u2744\\u2747\\u2757\\u2763\\u27A1\\u2934\\u2935\\u2B05-\\u2B07\\u2B1B\\u2B1C\\u2B55\\u3030\\u303D\\u3297\\u3299]\\uFE0F?|[\\u261D\\u270C\\u270D](?:\\uD83C[\\uDFFB-\\uDFFF]|\\uFE0F)?|[\\u270A\\u270B](?:\\uD83C[\\uDFFB-\\uDFFF])?|[\\u23E9-\\u23EC\\u23F0\\u23F3\\u25FD\\u2693\\u26A1\\u26AB\\u26C5\\u26CE\\u26D4\\u26EA\\u26FD\\u2705\\u2728\\u274C\\u274E\\u2753-\\u2755\\u2795-\\u2797\\u27B0\\u27BF\\u2B50]|\\u26D3\\uFE0F?(?:\\u200D\\uD83D\\uDCA5)?|\\u26F9(?:\\uD83C[\\uDFFB-\\uDFFF]|\\uFE0F)?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|\\u2764\\uFE0F?(?:\\u200D(?:\\uD83D\\uDD25|\\uD83E\\uDE79))?|\\uD83C(?:[\\uDC04\\uDD70\\uDD71\\uDD7E\\uDD7F\\uDE02\\uDE37\\uDF21\\uDF24-\\uDF2C\\uDF36\\uDF7D\\uDF96\\uDF97\\uDF99-\\uDF9B\\uDF9E\\uDF9F\\uDFCD\\uDFCE\\uDFD4-\\uDFDF\\uDFF5\\uDFF7]\\uFE0F?|[\\uDF85\\uDFC2\\uDFC7](?:\\uD83C[\\uDFFB-\\uDFFF])?|[\\uDFC4\\uDFCA](?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|[\\uDFCB\\uDFCC](?:\\uD83C[\\uDFFB-\\uDFFF]|\\uFE0F)?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|[\\uDCCF\\uDD8E\\uDD91-\\uDD9A\\uDE01\\uDE1A\\uDE2F\\uDE32-\\uDE36\\uDE38-\\uDE3A\\uDE50\\uDE51\\uDF00-\\uDF20\\uDF2D-\\uDF35\\uDF37-\\uDF43\\uDF45-\\uDF4A\\uDF4C-\\uDF7C\\uDF7E-\\uDF84\\uDF86-\\uDF93\\uDFA0-\\uDFC1\\uDFC5\\uDFC6\\uDFC8\\uDFC9\\uDFCF-\\uDFD3\\uDFE0-\\uDFF0\\uDFF8-\\uDFFF]|\\uDDE6\\uD83C[\\uDDE8-\\uDDEC\\uDDEE\\uDDF1\\uDDF2\\uDDF4\\uDDF6-\\uDDFA\\uDDFC\\uDDFD\\uDDFF]|\\uDDE7\\uD83C[\\uDDE6\\uDDE7\\uDDE9-\\uDDEF\\uDDF1-\\uDDF4\\uDDF6-\\uDDF9\\uDDFB\\uDDFC\\uDDFE\\uDDFF]|\\uDDE8\\uD83C[\\uDDE6\\uDDE8\\uDDE9\\uDDEB-\\uDDEE\\uDDF0-\\uDDF7\\uDDFA-\\uDDFF]|\\uDDE9\\uD83C[\\uDDEA\\uDDEC\\uDDEF\\uDDF0\\uDDF2\\uDDF4\\uDDFF]|\\uDDEA\\uD83C[\\uDDE6\\uDDE8\\uDDEA\\uDDEC\\uDDED\\uDDF7-\\uDDFA]|\\uDDEB\\uD83C[\\uDDEE-\\uDDF0\\uDDF2\\uDDF4\\uDDF7]|\\uDDEC\\uD83C[\\uDDE6\\uDDE7\\uDDE9-\\uDDEE\\uDDF1-\\uDDF3\\uDDF5-\\uDDFA\\uDDFC\\uDDFE]|\\uDDED\\uD83C[\\uDDF0\\uDDF2\\uDDF3\\uDDF7\\uDDF9\\uDDFA]|\\uDDEE\\uD83C[\\uDDE8-\\uDDEA\\uDDF1-\\uDDF4\\uDDF6-\\uDDF9]|\\uDDEF\\uD83C[\\uDDEA\\uDDF2\\uDDF4\\uDDF5]|\\uDDF0\\uD83C[\\uDDEA\\uDDEC-\\uDDEE\\uDDF2\\uDDF3\\uDDF5\\uDDF7\\uDDFC\\uDDFE\\uDDFF]|\\uDDF1\\uD83C[\\uDDE6-\\uDDE8\\uDDEE\\uDDF0\\uDDF7-\\uDDFB\\uDDFE]|\\uDDF2\\uD83C[\\uDDE6\\uDDE8-\\uDDED\\uDDF0-\\uDDFF]|\\uDDF3\\uD83C[\\uDDE6\\uDDE8\\uDDEA-\\uDDEC\\uDDEE\\uDDF1\\uDDF4\\uDDF5\\uDDF7\\uDDFA\\uDDFF]|\\uDDF4\\uD83C\\uDDF2|\\uDDF5\\uD83C[\\uDDE6\\uDDEA-\\uDDED\\uDDF0-\\uDDF3\\uDDF7-\\uDDF9\\uDDFC\\uDDFE]|\\uDDF6\\uD83C\\uDDE6|\\uDDF7\\uD83C[\\uDDEA\\uDDF4\\uDDF8\\uDDFA\\uDDFC]|\\uDDF8\\uD83C[\\uDDE6-\\uDDEA\\uDDEC-\\uDDF4\\uDDF7-\\uDDF9\\uDDFB\\uDDFD-\\uDDFF]|\\uDDF9\\uD83C[\\uDDE6\\uDDE8\\uDDE9\\uDDEB-\\uDDED\\uDDEF-\\uDDF4\\uDDF7\\uDDF9\\uDDFB\\uDDFC\\uDDFF]|\\uDDFA\\uD83C[\\uDDE6\\uDDEC\\uDDF2\\uDDF3\\uDDF8\\uDDFE\\uDDFF]|\\uDDFB\\uD83C[\\uDDE6\\uDDE8\\uDDEA\\uDDEC\\uDDEE\\uDDF3\\uDDFA]|\\uDDFC\\uD83C[\\uDDEB\\uDDF8]|\\uDDFD\\uD83C\\uDDF0|\\uDDFE\\uD83C[\\uDDEA\\uDDF9]|\\uDDFF\\uD83C[\\uDDE6\\uDDF2\\uDDFC]|\\uDF44(?:\\u200D\\uD83D\\uDFEB)?|\\uDF4B(?:\\u200D\\uD83D\\uDFE9)?|\\uDFC3(?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D(?:[\\u2640\\u2642]\\uFE0F?(?:\\u200D\\u27A1\\uFE0F?)?|\\u27A1\\uFE0F?))?|\\uDFF3\\uFE0F?(?:\\u200D(?:\\u26A7\\uFE0F?|\\uD83C\\uDF08))?|\\uDFF4(?:\\u200D\\u2620\\uFE0F?|\\uDB40\\uDC67\\uDB40\\uDC62\\uDB40(?:\\uDC65\\uDB40\\uDC6E\\uDB40\\uDC67|\\uDC73\\uDB40\\uDC63\\uDB40\\uDC74|\\uDC77\\uDB40\\uDC6C\\uDB40\\uDC73)\\uDB40\\uDC7F)?)|\\uD83D(?:[\\uDC3F\\uDCFD\\uDD49\\uDD4A\\uDD6F\\uDD70\\uDD73\\uDD76-\\uDD79\\uDD87\\uDD8A-\\uDD8D\\uDDA5\\uDDA8\\uDDB1\\uDDB2\\uDDBC\\uDDC2-\\uDDC4\\uDDD1-\\uDDD3\\uDDDC-\\uDDDE\\uDDE1\\uDDE3\\uDDE8\\uDDEF\\uDDF3\\uDDFA\\uDECB\\uDECD-\\uDECF\\uDEE0-\\uDEE5\\uDEE9\\uDEF0\\uDEF3]\\uFE0F?|[\\uDC42\\uDC43\\uDC46-\\uDC50\\uDC66\\uDC67\\uDC6B-\\uDC6D\\uDC72\\uDC74-\\uDC76\\uDC78\\uDC7C\\uDC83\\uDC85\\uDC8F\\uDC91\\uDCAA\\uDD7A\\uDD95\\uDD96\\uDE4C\\uDE4F\\uDEC0\\uDECC](?:\\uD83C[\\uDFFB-\\uDFFF])?|[\\uDC6E-\\uDC71\\uDC73\\uDC77\\uDC81\\uDC82\\uDC86\\uDC87\\uDE45-\\uDE47\\uDE4B\\uDE4D\\uDE4E\\uDEA3\\uDEB4\\uDEB5](?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|[\\uDD74\\uDD90](?:\\uD83C[\\uDFFB-\\uDFFF]|\\uFE0F)?|[\\uDC00-\\uDC07\\uDC09-\\uDC14\\uDC16-\\uDC25\\uDC27-\\uDC3A\\uDC3C-\\uDC3E\\uDC40\\uDC44\\uDC45\\uDC51-\\uDC65\\uDC6A\\uDC79-\\uDC7B\\uDC7D-\\uDC80\\uDC84\\uDC88-\\uDC8E\\uDC90\\uDC92-\\uDCA9\\uDCAB-\\uDCFC\\uDCFF-\\uDD3D\\uDD4B-\\uDD4E\\uDD50-\\uDD67\\uDDA4\\uDDFB-\\uDE2D\\uDE2F-\\uDE34\\uDE37-\\uDE41\\uDE43\\uDE44\\uDE48-\\uDE4A\\uDE80-\\uDEA2\\uDEA4-\\uDEB3\\uDEB7-\\uDEBF\\uDEC1-\\uDEC5\\uDED0-\\uDED2\\uDED5-\\uDED8\\uDEDC-\\uDEDF\\uDEEB\\uDEEC\\uDEF4-\\uDEFC\\uDFE0-\\uDFEB\\uDFF0]|\\uDC08(?:\\u200D\\u2B1B)?|\\uDC15(?:\\u200D\\uD83E\\uDDBA)?|\\uDC26(?:\\u200D(?:\\u2B1B|\\uD83D\\uDD25))?|\\uDC3B(?:\\u200D\\u2744\\uFE0F?)?|\\uDC41\\uFE0F?(?:\\u200D\\uD83D\\uDDE8\\uFE0F?)?|\\uDC68(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDC68\\uDC69]\\u200D\\uD83D(?:\\uDC66(?:\\u200D\\uD83D\\uDC66)?|\\uDC67(?:\\u200D\\uD83D[\\uDC66\\uDC67])?)|[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC66(?:\\u200D\\uD83D\\uDC66)?|\\uDC67(?:\\u200D\\uD83D[\\uDC66\\uDC67])?)|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]))|\\uD83C(?:\\uDFFB(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFC-\\uDFFF])|\\uD83E(?:[\\uDD1D\\uDEEF]\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFC-\\uDFFF]|[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3])))?|\\uDFFC(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])|\\uD83E(?:[\\uDD1D\\uDEEF]\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB\\uDFFD-\\uDFFF]|[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3])))?|\\uDFFD(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])|\\uD83E(?:[\\uDD1D\\uDEEF]\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF]|[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3])))?|\\uDFFE(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])|\\uD83E(?:[\\uDD1D\\uDEEF]\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB-\\uDFFD\\uDFFF]|[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3])))?|\\uDFFF(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?\\uDC68\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB-\\uDFFE])|\\uD83E(?:[\\uDD1D\\uDEEF]\\u200D\\uD83D\\uDC68\\uD83C[\\uDFFB-\\uDFFE]|[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3])))?))?|\\uDC69(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:\\uDC8B\\u200D\\uD83D)?[\\uDC68\\uDC69]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC66(?:\\u200D\\uD83D\\uDC66)?|\\uDC67(?:\\u200D\\uD83D[\\uDC66\\uDC67])?|\\uDC69\\u200D\\uD83D(?:\\uDC66(?:\\u200D\\uD83D\\uDC66)?|\\uDC67(?:\\u200D\\uD83D[\\uDC66\\uDC67])?))|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]))|\\uD83C(?:\\uDFFB(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:[\\uDC68\\uDC69]|\\uDC8B\\u200D\\uD83D[\\uDC68\\uDC69])\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFC-\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]|\\uDD1D\\u200D\\uD83D[\\uDC68\\uDC69]\\uD83C[\\uDFFC-\\uDFFF]|\\uDEEF\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFC-\\uDFFF])))?|\\uDFFC(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:[\\uDC68\\uDC69]|\\uDC8B\\u200D\\uD83D[\\uDC68\\uDC69])\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]|\\uDD1D\\u200D\\uD83D[\\uDC68\\uDC69]\\uD83C[\\uDFFB\\uDFFD-\\uDFFF]|\\uDEEF\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])))?|\\uDFFD(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:[\\uDC68\\uDC69]|\\uDC8B\\u200D\\uD83D[\\uDC68\\uDC69])\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]|\\uDD1D\\u200D\\uD83D[\\uDC68\\uDC69]\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF]|\\uDEEF\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])))?|\\uDFFE(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:[\\uDC68\\uDC69]|\\uDC8B\\u200D\\uD83D[\\uDC68\\uDC69])\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]|\\uDD1D\\u200D\\uD83D[\\uDC68\\uDC69]\\uD83C[\\uDFFB-\\uDFFD\\uDFFF]|\\uDEEF\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])))?|\\uDFFF(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D\\uD83D(?:[\\uDC68\\uDC69]|\\uDC8B\\u200D\\uD83D[\\uDC68\\uDC69])\\uD83C[\\uDFFB-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB-\\uDFFE])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3]|\\uDD1D\\u200D\\uD83D[\\uDC68\\uDC69]\\uD83C[\\uDFFB-\\uDFFE]|\\uDEEF\\u200D\\uD83D\\uDC69\\uD83C[\\uDFFB-\\uDFFE])))?))?|\\uDD75(?:\\uD83C[\\uDFFB-\\uDFFF]|\\uFE0F)?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|\\uDE2E(?:\\u200D\\uD83D\\uDCA8)?|\\uDE35(?:\\u200D\\uD83D\\uDCAB)?|\\uDE36(?:\\u200D\\uD83C\\uDF2B\\uFE0F?)?|\\uDE42(?:\\u200D[\\u2194\\u2195]\\uFE0F?)?|\\uDEB6(?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D(?:[\\u2640\\u2642]\\uFE0F?(?:\\u200D\\u27A1\\uFE0F?)?|\\u27A1\\uFE0F?))?)|\\uD83E(?:[\\uDD0C\\uDD0F\\uDD18-\\uDD1F\\uDD30-\\uDD34\\uDD36\\uDD77\\uDDB5\\uDDB6\\uDDBB\\uDDD2\\uDDD3\\uDDD5\\uDEC3-\\uDEC5\\uDEF0\\uDEF2-\\uDEF8](?:\\uD83C[\\uDFFB-\\uDFFF])?|[\\uDD26\\uDD35\\uDD37-\\uDD39\\uDD3C-\\uDD3E\\uDDB8\\uDDB9\\uDDCD\\uDDCF\\uDDD4\\uDDD6-\\uDDDD](?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|[\\uDDDE\\uDDDF](?:\\u200D[\\u2640\\u2642]\\uFE0F?)?|[\\uDD0D\\uDD0E\\uDD10-\\uDD17\\uDD20-\\uDD25\\uDD27-\\uDD2F\\uDD3A\\uDD3F-\\uDD45\\uDD47-\\uDD76\\uDD78-\\uDDB4\\uDDB7\\uDDBA\\uDDBC-\\uDDCC\\uDDD0\\uDDE0-\\uDDFF\\uDE70-\\uDE7C\\uDE80-\\uDE8A\\uDE8E-\\uDEC2\\uDEC6\\uDEC8\\uDECD-\\uDEDC\\uDEDF-\\uDEEA\\uDEEF]|\\uDDCE(?:\\uD83C[\\uDFFB-\\uDFFF])?(?:\\u200D(?:[\\u2640\\u2642]\\uFE0F?(?:\\u200D\\u27A1\\uFE0F?)?|\\u27A1\\uFE0F?))?|\\uDDD1(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1|\\uDDD1\\u200D\\uD83E\\uDDD2(?:\\u200D\\uD83E\\uDDD2)?|\\uDDD2(?:\\u200D\\uD83E\\uDDD2)?))|\\uD83C(?:\\uDFFB(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D(?:\\uD83D\\uDC8B\\u200D)?\\uD83E\\uDDD1\\uD83C[\\uDFFC-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFC-\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFF]|\\uDEEF\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFC-\\uDFFF])))?|\\uDFFC(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D(?:\\uD83D\\uDC8B\\u200D)?\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFD-\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFF]|\\uDEEF\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])))?|\\uDFFD(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D(?:\\uD83D\\uDC8B\\u200D)?\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFF]|\\uDEEF\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])))?|\\uDFFE(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D(?:\\uD83D\\uDC8B\\u200D)?\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFD\\uDFFF]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFF]|\\uDEEF\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])))?|\\uDFFF(?:\\u200D(?:[\\u2695\\u2696\\u2708]\\uFE0F?|\\u2764\\uFE0F?\\u200D(?:\\uD83D\\uDC8B\\u200D)?\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFE]|\\uD83C[\\uDF3E\\uDF73\\uDF7C\\uDF84\\uDF93\\uDFA4\\uDFA8\\uDFEB\\uDFED]|\\uD83D(?:[\\uDCBB\\uDCBC\\uDD27\\uDD2C\\uDE80\\uDE92]|\\uDC30\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFE])|\\uD83E(?:[\\uDDAF\\uDDBC\\uDDBD](?:\\u200D\\u27A1\\uFE0F?)?|[\\uDDB0-\\uDDB3\\uDE70]|\\uDD1D\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFF]|\\uDEEF\\u200D\\uD83E\\uDDD1\\uD83C[\\uDFFB-\\uDFFE])))?))?|\\uDEF1(?:\\uD83C(?:\\uDFFB(?:\\u200D\\uD83E\\uDEF2\\uD83C[\\uDFFC-\\uDFFF])?|\\uDFFC(?:\\u200D\\uD83E\\uDEF2\\uD83C[\\uDFFB\\uDFFD-\\uDFFF])?|\\uDFFD(?:\\u200D\\uD83E\\uDEF2\\uD83C[\\uDFFB\\uDFFC\\uDFFE\\uDFFF])?|\\uDFFE(?:\\u200D\\uD83E\\uDEF2\\uD83C[\\uDFFB-\\uDFFD\\uDFFF])?|\\uDFFF(?:\\u200D\\uD83E\\uDEF2\\uD83C[\\uDFFB-\\uDFFE])?))?)/g;
  var Wr$1 = 12288, $r$1 = 65510, zr$1 = [12288, 12288, 65281, 65376, 65504, 65510];
  var Gr$1 = 4352, Kr$1 = 262141, Pt$1 = [4352, 4447, 8986, 8987, 9001, 9002, 9193, 9196, 9200, 9200, 9203, 9203, 9725, 9726, 9748, 9749, 9776, 9783, 9800, 9811, 9855, 9855, 9866, 9871, 9875, 9875, 9889, 9889, 9898, 9899, 9917, 9918, 9924, 9925, 9934, 9934, 9940, 9940, 9962, 9962, 9970, 9971, 9973, 9973, 9978, 9978, 9981, 9981, 9989, 9989, 9994, 9995, 10024, 10024, 10060, 10060, 10062, 10062, 10067, 10069, 10071, 10071, 10133, 10135, 10160, 10160, 10175, 10175, 11035, 11036, 11088, 11088, 11093, 11093, 11904, 11929, 11931, 12019, 12032, 12245, 12272, 12287, 12289, 12350, 12353, 12438, 12441, 12543, 12549, 12591, 12593, 12686, 12688, 12773, 12783, 12830, 12832, 12871, 12880, 42124, 42128, 42182, 43360, 43388, 44032, 55203, 63744, 64255, 65040, 65049, 65072, 65106, 65108, 65126, 65128, 65131, 94176, 94180, 94192, 94198, 94208, 101589, 101631, 101662, 101760, 101874, 110576, 110579, 110581, 110587, 110589, 110590, 110592, 110882, 110898, 110898, 110928, 110930, 110933, 110933, 110948, 110951, 110960, 111355, 119552, 119638, 119648, 119670, 126980, 126980, 127183, 127183, 127374, 127374, 127377, 127386, 127488, 127490, 127504, 127547, 127552, 127560, 127568, 127569, 127584, 127589, 127744, 127776, 127789, 127797, 127799, 127868, 127870, 127891, 127904, 127946, 127951, 127955, 127968, 127984, 127988, 127988, 127992, 128062, 128064, 128064, 128066, 128252, 128255, 128317, 128331, 128334, 128336, 128359, 128378, 128378, 128405, 128406, 128420, 128420, 128507, 128591, 128640, 128709, 128716, 128716, 128720, 128722, 128725, 128728, 128732, 128735, 128747, 128748, 128756, 128764, 128992, 129003, 129008, 129008, 129292, 129338, 129340, 129349, 129351, 129535, 129648, 129660, 129664, 129674, 129678, 129734, 129736, 129736, 129741, 129756, 129759, 129770, 129775, 129784, 131072, 196605, 196608, 262141];
  var St$1 = (t, e) => {
    let r = 0, n = Math.floor(t.length / 2) - 1;
    for (; r <= n; ) {
      let u = Math.floor((r + n) / 2), o = u * 2;
      if (e < t[o]) n = u - 1;
      else if (e > t[o + 1]) r = u + 1;
      else return true;
    }
    return false;
  };
  var Hr$1 = 19968, [to$1, ro$1] = no$1(Pt$1);
  function no$1(t) {
    let e = t[0], r = t[1];
    for (let n = 0; n < t.length; n += 2) {
      let u = t[n], o = t[n + 1];
      if (Hr$1 >= u && Hr$1 <= o) return [u, o];
      o - u > r - e && (e = u, r = o);
    }
    return [e, r];
  }
  var bt$1 = (t) => t < Wr$1 || t > $r$1 ? false : St$1(zr$1, t);
  var kt$1 = (t) => t >= to$1 && t <= ro$1 ? true : t < Gr$1 || t > Kr$1 ? false : St$1(Pt$1, t);
  var uo$1 = /^(?:[\\xA9\\xAE\\u203C\\u2049\\u2122\\u2139\\u2194-\\u2199\\u21A9\\u21AA\\u2328\\u23CF\\u23ED-\\u23EF\\u23F1\\u23F2\\u23F8-\\u23FA\\u24C2\\u25AA\\u25AB\\u25B6\\u25C0\\u25FB\\u25FC\\u2600-\\u2604\\u260E\\u2611\\u2618\\u2620\\u2622\\u2623\\u2626\\u262A\\u262E\\u262F\\u2638-\\u263A\\u2640\\u2642\\u265F\\u2660\\u2663\\u2665\\u2666\\u2668\\u267B\\u267E\\u2692\\u2694-\\u2697\\u2699\\u269B\\u269C\\u26A0\\u26A7\\u26B0\\u26B1\\u26C8\\u26CF\\u26D1\\u26D3\\u26E9\\u26F0\\u26F1\\u26F4\\u26F7\\u26F8\\u2702\\u2708\\u2709\\u270F\\u2712\\u2714\\u2716\\u271D\\u2721\\u2733\\u2734\\u2744\\u2747\\u2763\\u2764\\u27A1\\u2934\\u2935\\u2B05-\\u2B07]|\\uD83C[\\uDD70\\uDD71\\uDD7E\\uDD7F\\uDF21\\uDF24-\\uDF2C\\uDF36\\uDF7D\\uDF96\\uDF97\\uDF99-\\uDF9B\\uDF9E\\uDF9F\\uDFCD\\uDFCE\\uDFD4-\\uDFDF\\uDFF3\\uDFF5\\uDFF7]|\\uD83D[\\uDC3F\\uDC41\\uDCFD\\uDD49\\uDD4A\\uDD6F\\uDD70\\uDD73\\uDD76-\\uDD79\\uDD87\\uDD8A-\\uDD8D\\uDDA5\\uDDA8\\uDDB1\\uDDB2\\uDDBC\\uDDC2-\\uDDC4\\uDDD1-\\uDDD3\\uDDDC-\\uDDDE\\uDDE1\\uDDE3\\uDDE8\\uDDEF\\uDDF3\\uDDFA\\uDECB\\uDECD-\\uDECF\\uDEE0-\\uDEE5\\uDEE9\\uDEF0\\uDEF3])$/, Jr$1 = (t) => uo$1.test(t);
  var oo$1 = /[^\\x20-\\x7F]/;
  function io$1(t) {
    if (!t) return 0;
    if (!oo$1.test(t)) return t.length;
    let e = 0;
    t = t.replace(Vr$1(), (r) => (e += Jr$1(r) ? 1 : 2, ""));
    for (let r of t) {
      let n = r.codePointAt(0);
      n <= 31 || n >= 127 && n <= 159 || n >= 768 && n <= 879 || n >= 65024 && n <= 65039 || (e += bt$1(n) || kt$1(n) ? 2 : 1);
    }
    return e;
  }
  var Re$1 = io$1;
  var so$1 = { type: 0 }, Do$1 = { type: 1 }, It$1 = { value: "", length: 0, queue: [], get root() {
    return It$1;
  } };
  function qr(t, e, r) {
    let n = e.type === 1 ? t.queue.slice(0, -1) : [...t.queue, e], u = "", o = 0, i = 0, D = 0;
    for (let f of n) switch (f.type) {
      case 0:
        c(), r.useTabs ? s(1) : a(r.tabWidth);
        break;
      case 3: {
        let { string: F2 } = f;
        c(), u += F2, o += F2.length;
        break;
      }
      case 2: {
        let { width: F2 } = f;
        i += 1, D += F2;
        break;
      }
      default:
        throw new Error(\`Unexpected indent comment '\${f.type}'.\`);
    }
    return l(), { ...t, value: u, length: o, queue: n };
    function s(f) {
      u += "	".repeat(f), o += r.tabWidth * f;
    }
    function a(f) {
      u += " ".repeat(f), o += f;
    }
    function c() {
      r.useTabs ? p2() : l();
    }
    function p2() {
      i > 0 && s(i), m2();
    }
    function l() {
      D > 0 && a(D), m2();
    }
    function m2() {
      i = 0, D = 0;
    }
  }
  function Xr$1(t, e, r) {
    if (!e) return t;
    if (e.type === "root") return { ...t, root: t };
    if (e === Number.NEGATIVE_INFINITY) return t.root;
    let n;
    return typeof e == "number" ? e < 0 ? n = Do$1 : n = { type: 2, width: e } : n = { type: 3, string: e }, qr(t, n, r);
  }
  function Qr$1(t, e) {
    return qr(t, so$1, e);
  }
  function ao$1(t) {
    let e = 0;
    for (let r = t.length - 1; r >= 0; r--) {
      let n = t[r];
      if (n === " " || n === "	") e++;
      else break;
    }
    return e;
  }
  function et$1(t) {
    let e = ao$1(t);
    return { text: e === 0 ? t : t.slice(0, t.length - e), count: e };
  }
  var Rt$1 = class Rt {
    #t = [];
    #e = "";
    #n = 0;
    #u = [];
    #r = [];
    #o() {
      let e = this.#e;
      e !== "" && (this.#t.push(e), this.#n += e.length, this.#e = "");
      for (let r of this.#r) this.#u.push(Math.min(r, this.#n));
      this.#r.length = 0;
    }
    markPosition() {
      if (this.#u.length + this.#r.length >= 2) throw new Error("There are too many 'cursor' in doc.");
      this.#r.push(this.#n + this.#e.length);
    }
    write(e) {
      this.#e += e;
    }
    trim() {
      let { text: e, count: r } = et$1(this.#e);
      return this.#e = e, this.#o(), r;
    }
    finish() {
      return this.#o(), { text: this.#t.join(""), positions: this.#u };
    }
  }, Zr$1 = Rt$1;
  var K$1 = /* @__PURE__ */ Symbol("MODE_BREAK"), Q = /* @__PURE__ */ Symbol("MODE_FLAT"), vt$1 = /* @__PURE__ */ Symbol("DOC_FILL_PRINTED_LENGTH");
  function tt$1(t, e, r, n, u, o) {
    if (r === Number.POSITIVE_INFINITY) return true;
    let i = e.length, D = false, s = [t], a = "";
    for (; r >= 0; ) {
      if (s.length === 0) {
        if (i === 0) return true;
        s.push(e[--i]);
        continue;
      }
      let { mode: c, doc: p2 } = s.pop(), l = q$1(p2);
      switch (l) {
        case G$1:
          p2 && (D && (a += " ", r -= 1, D = false), a += p2, r -= Re$1(p2));
          break;
        case U$1:
        case S$1: {
          let m2 = l === U$1 ? p2 : p2.parts, f = p2[vt$1] ?? 0;
          for (let F2 = m2.length - 1; F2 >= f; F2--) s.push({ mode: c, doc: m2[F2] });
          break;
        }
        case I$1:
        case R$1:
        case L$1:
        case b$1:
          s.push({ mode: c, doc: p2.contents });
          break;
        case v: {
          let { text: m2, count: f } = et$1(a);
          a = m2, r += f;
          break;
        }
        case x$1: {
          if (o && p2.break) return false;
          let m2 = p2.break ? K$1 : c, f = p2.expandedStates && m2 === K$1 ? y$1(0, p2.expandedStates, -1) : p2.contents;
          s.push({ mode: m2, doc: f });
          break;
        }
        case T$1: {
          let f = (p2.groupId ? u[p2.groupId] || Q : c) === K$1 ? p2.breakContents : p2.flatContents;
          f && s.push({ mode: c, doc: f });
          break;
        }
        case g:
          if (c === K$1 || p2.hard) return true;
          p2.soft || (D = true);
          break;
        case M$1:
          n = true;
          break;
        case Y$1:
          if (n) return false;
          break;
      }
    }
    return false;
  }
  function Ce(t, e) {
    let r = /* @__PURE__ */ Object.create(null), n = e.printWidth, u = we$1(e.endOfLine), o = 0, i = [{ indent: It$1, mode: K$1, doc: t }], D = false, s = [], a = new Zr$1();
    for (Br(t); i.length > 0; ) {
      let { indent: f, mode: F2, doc: d } = i.pop();
      switch (q$1(d)) {
        case G$1: {
          let E2 = u !== \`
\` ? ne$1(0, d, \`
\`, u) : d;
          E2 && (a.write(E2), i.length > 0 && (o += Re$1(E2)));
          break;
        }
        case U$1:
          for (let E2 = d.length - 1; E2 >= 0; E2--) i.push({ indent: f, mode: F2, doc: d[E2] });
          break;
        case V$1:
          a.markPosition();
          break;
        case I$1:
          i.push({ indent: Qr$1(f, e), mode: F2, doc: d.contents });
          break;
        case R$1:
          i.push({ indent: Xr$1(f, d.n, e), mode: F2, doc: d.contents });
          break;
        case v:
          o -= a.trim();
          break;
        case x$1: {
          let E2 = (function() {
            if (F2 === Q && !D) return { indent: f, mode: d.break ? K$1 : Q, doc: d.contents };
            D = false;
            let h = n - o, _ = s.length > 0, P2 = { indent: f, mode: Q, doc: d.contents };
            if (!d.break && tt$1(P2, i, h, _, r)) return P2;
            if (!d.expandedStates) return { indent: f, mode: K$1, doc: d.contents };
            if (!d.break) for (let A2 = 1; A2 < d.expandedStates.length - 1; A2++) {
              let B2 = { indent: f, mode: Q, doc: d.expandedStates[A2] };
              if (tt$1(B2, i, h, _, r)) return B2;
            }
            return { indent: f, mode: K$1, doc: y$1(0, d.expandedStates, -1) };
          })();
          i.push(E2), d.id && (r[d.id] = E2.mode);
          break;
        }
        case S$1: {
          let E2 = n - o, C2 = d[vt$1] ?? 0, { parts: h } = d, _ = h.length - C2;
          if (_ === 0) break;
          let P2 = h[C2 + 0], A2 = h[C2 + 1], B2 = { indent: f, mode: Q, doc: P2 }, J2 = { indent: f, mode: K$1, doc: P2 }, $e2 = tt$1(B2, [], E2, s.length > 0, r, true);
          if (_ === 1) {
            $e2 ? i.push(B2) : i.push(J2);
            break;
          }
          let lr2 = { indent: f, mode: Q, doc: A2 }, _t2 = { indent: f, mode: K$1, doc: A2 };
          if (_ === 2) {
            $e2 ? i.push(lr2, B2) : i.push(_t2, J2);
            break;
          }
          let bu = h[C2 + 2], ku = { indent: f, mode: F2, doc: { ...d, [vt$1]: C2 + 2 } }, Iu = tt$1({ indent: f, mode: Q, doc: [P2, A2, bu] }, [], E2, s.length > 0, r, true);
          i.push(ku), Iu ? i.push(lr2, B2) : $e2 ? i.push(_t2, B2) : i.push(_t2, J2);
          break;
        }
        case T$1:
        case L$1: {
          let E2 = d.groupId ? r[d.groupId] : F2;
          if (E2 === K$1) {
            let C2 = d.type === T$1 ? d.breakContents : d.negate ? d.contents : oe$1(d.contents);
            C2 && i.push({ indent: f, mode: F2, doc: C2 });
          }
          if (E2 === Q) {
            let C2 = d.type === T$1 ? d.flatContents : d.negate ? oe$1(d.contents) : d.contents;
            C2 && i.push({ indent: f, mode: F2, doc: C2 });
          }
          break;
        }
        case M$1:
          s.push({ indent: f, mode: F2, doc: d.contents });
          break;
        case Y$1:
          s.length > 0 && i.push({ indent: f, mode: F2, doc: ke$1 });
          break;
        case g:
          switch (F2) {
            case Q:
              if (!d.hard) {
                d.soft || (a.write(" "), o += 1);
                break;
              }
              D = true;
            case K$1:
              if (s.length > 0) {
                i.push({ indent: f, mode: F2, doc: d }, ...s.reverse()), s.length = 0;
                break;
              }
              d.literal ? (a.write(u), o = 0, f.root && (f.root.value && a.write(f.root.value), o = f.root.length)) : (a.trim(), a.write(u + f.value), o = f.length);
              break;
          }
          break;
        case b$1:
          i.push({ indent: f, mode: F2, doc: d.contents });
          break;
        case N$1:
          break;
        default:
          throw new Z$1(d);
      }
      i.length === 0 && s.length > 0 && (i.push(...s.reverse()), s.length = 0);
    }
    let { text: c, positions: p2 } = a.finish();
    if (p2.length !== 2) return { formatted: c };
    let [l, m2] = p2;
    return { formatted: c, cursorNodeStart: l, cursorNodeText: c.slice(l, m2) };
  }
  function co$1(t, e, r = 0) {
    let n = 0;
    for (let u = r; u < t.length; ++u) t[u] === "	" ? n = n + e - n % e : n++;
    return n;
  }
  var he$1 = co$1;
  var Lt$1 = class Lt {
    constructor(e) {
      this.stack = [e];
    }
    get key() {
      let { stack: e, siblings: r } = this;
      return y$1(0, e, r === null ? -2 : -4) ?? null;
    }
    get index() {
      return this.siblings === null ? null : y$1(0, this.stack, -2);
    }
    get node() {
      return y$1(0, this.stack, -1);
    }
    get parent() {
      return this.getNode(1);
    }
    get grandparent() {
      return this.getNode(2);
    }
    get isInArray() {
      return this.siblings !== null;
    }
    get siblings() {
      let { stack: e } = this, r = y$1(0, e, -3);
      return Array.isArray(r) ? r : null;
    }
    get next() {
      let { siblings: e } = this;
      return e === null ? null : e[this.index + 1];
    }
    get previous() {
      let { siblings: e } = this;
      return e === null ? null : e[this.index - 1];
    }
    get isFirst() {
      return this.index === 0;
    }
    get isLast() {
      let { siblings: e, index: r } = this;
      return e !== null && r === e.length - 1;
    }
    get isRoot() {
      return this.stack.length === 1;
    }
    get root() {
      return this.stack[0];
    }
    get ancestors() {
      return [...this.#e()];
    }
    getName() {
      let { stack: e } = this, { length: r } = e;
      return r > 1 ? y$1(0, e, -2) : null;
    }
    getValue() {
      return y$1(0, this.stack, -1);
    }
    getNode(e = 0) {
      let r = this.#t(e);
      return r === -1 ? null : this.stack[r];
    }
    getParentNode(e = 0) {
      return this.getNode(e + 1);
    }
    #t(e) {
      let { stack: r } = this;
      for (let n = r.length - 1; n >= 0; n -= 2) if (!Array.isArray(r[n]) && --e < 0) return n;
      return -1;
    }
    call(e, ...r) {
      let { stack: n } = this, { length: u } = n, o = y$1(0, n, -1);
      for (let i of r) o = o?.[i], n.push(i, o);
      try {
        return e(this);
      } finally {
        n.length = u;
      }
    }
    callParent(e, r = 0) {
      let n = this.#t(r + 1), u = this.stack.splice(n + 1);
      try {
        return e(this);
      } finally {
        this.stack.push(...u);
      }
    }
    each(e, ...r) {
      let { stack: n } = this, { length: u } = n, o = y$1(0, n, -1);
      for (let i of r) o = o[i], n.push(i, o);
      try {
        for (let i = 0; i < o.length; ++i) n.push(i, o[i]), e(this, i, o), n.length -= 2;
      } finally {
        n.length = u;
      }
    }
    map(e, ...r) {
      let n = [];
      return this.each((u, o, i) => {
        n[o] = e(u, o, i);
      }, ...r), n;
    }
    match(...e) {
      let r = this.stack.length - 1, n = null, u = this.stack[r--];
      for (let o of e) {
        if (u === void 0) return false;
        let i = null;
        if (typeof n == "number" && (i = n, n = this.stack[r--], u = this.stack[r--]), o && !o(u, n, i)) return false;
        n = this.stack[r--], u = this.stack[r--];
      }
      return true;
    }
    findAncestor(e) {
      for (let r of this.#e()) if (e(r)) return r;
    }
    hasAncestor(e) {
      for (let r of this.#e()) if (e(r)) return true;
      return false;
    }
    *#e() {
      let { stack: e } = this;
      for (let r = e.length - 3; r >= 0; r -= 2) {
        let n = e[r];
        Array.isArray(n) || (yield n);
      }
    }
  }, en$1 = Lt$1;
  function fo$1(t) {
    return Array.isArray(t) && t.length > 0;
  }
  var rt$1 = fo$1;
  function lo$1(t) {
    return t !== null && typeof t == "object";
  }
  var ge$1 = lo$1;
  function _e$1(t) {
    return (e, r, n) => {
      if (r === false) return false;
      let u = !!n?.backwards, { length: o } = e, i = r;
      for (; i >= 0 && i < o; ) {
        let D = e.charAt(i);
        if (t instanceof RegExp) {
          if (!t.test(D)) return i;
        } else if (!t.includes(D)) return i;
        u ? i-- : i++;
      }
      return i === -1 || i === o ? i : false;
    };
  }
  var tn$1 = _e$1(/\\s/), j$1 = _e$1(" 	"), nt$1 = _e$1(",; 	"), ut$1 = _e$1(/[^\\n\\r]/);
  var rn$1 = (t) => t === \`
\` || t === "\\r" || t === "\\u2028" || t === "\\u2029";
  function po$1(t, e, r) {
    if (e === false) return false;
    let n = !!r?.backwards, u = t.charAt(e);
    if (n) {
      if (t.charAt(e - 1) === "\\r" && u === \`
\`) return e - 2;
      if (rn$1(u)) return e - 1;
    } else {
      if (u === "\\r" && t.charAt(e + 1) === \`
\`) return e + 2;
      if (rn$1(u)) return e + 1;
    }
    return e;
  }
  var $$2 = po$1;
  function mo$1(t, e, r = {}) {
    let n = j$1(t, r.backwards ? e - 1 : e, r), u = $$2(t, n, r);
    return n !== u;
  }
  var H$1 = mo$1;
  function* ye$1(t, e) {
    let { getVisitorKeys: r, filter: n = () => true } = e, u = (o) => ge$1(o) && n(o);
    for (let o of r(t)) {
      let i = t[o];
      if (Array.isArray(i)) for (let D of i) u(D) && (yield D);
      else u(i) && (yield i);
    }
  }
  function* nn$1(t, e) {
    let r = [t];
    for (let n = 0; n < r.length; n++) {
      let u = r[n];
      for (let o of ye$1(u, e)) yield o, r.push(o);
    }
  }
  function un$1(t, e) {
    return ye$1(t, e).next().done;
  }
  function Fo$1(t, e, r) {
    let { filter: n } = r;
    if (!n) return [];
    let u, o = (r.getChildren?.(t, r) ?? [...ye$1(t, { getVisitorKeys: r.getVisitorKeys })]).flatMap((s) => (u ?? (u = [t, ...e]), n(s, u) ? [s] : on$1(s, u, r))), { locStart: i, locEnd: D } = r;
    return o.sort((s, a) => i(s) - i(a) || D(s) - D(a)), o;
  }
  function on$1(t, e, r) {
    return Fe$1(r.cache, t, (n) => Fo$1(n, e, r));
  }
  var ot$1 = on$1;
  function Eo$1(t) {
    let e = t.type || t.kind || "(unknown type)", r = String(t.name || t.id && (typeof t.id == "object" ? t.id.name : t.id) || t.key && (typeof t.key == "object" ? t.key.name : t.key) || t.value && (typeof t.value == "object" ? "" : String(t.value)) || t.operator || "");
    return r.length > 20 && (r = r.slice(0, 19) + "…"), e + (r ? " " + r : "");
  }
  function Mt$1(t, e) {
    (t.comments ?? (t.comments = [])).push(e), e.printed = false, e.nodeDescription = Eo$1(t);
  }
  function ce$1(t, e) {
    e.leading = true, e.trailing = false, Mt$1(t, e);
  }
  function re$1(t, e, r) {
    e.leading = false, e.trailing = false, r && (e.marker = r), Mt$1(t, e);
  }
  function fe$1(t, e) {
    e.leading = false, e.trailing = true, Mt$1(t, e);
  }
  var Ut = /* @__PURE__ */ new WeakMap();
  function Dn$1(t, e, r, n, u = []) {
    let { locStart: o, locEnd: i } = r, D = o(e), s = i(e), a = ot$1(t, u, { cache: Ut, locStart: o, locEnd: i, getVisitorKeys: r.getVisitorKeys, filter: r.printer.canAttachComment, getChildren: r.printer.getCommentChildNodes }), c, p2, l = 0, m2 = a.length;
    for (; l < m2; ) {
      let f = l + m2 >> 1, F2 = a[f], d = o(F2), E2 = i(F2);
      if (d <= D && s <= E2) return Dn$1(F2, e, r, F2, [F2, ...u]);
      if (E2 <= D) {
        c = F2, l = f + 1;
        continue;
      }
      if (s <= d) {
        p2 = F2, m2 = f;
        continue;
      }
      throw new Error("Comment location overlaps with node location");
    }
    if (n?.type === "TemplateLiteral") {
      let { quasis: f } = n, F2 = jt$1(f, e, r);
      c && jt$1(f, c, r) !== F2 && (c = null), p2 && jt$1(f, p2, r) !== F2 && (p2 = null);
    }
    return { enclosingNode: n, precedingNode: c, followingNode: p2 };
  }
  var Yt$1 = () => false;
  function an$1(t, e) {
    let { comments: r } = t;
    if (delete t.comments, !rt$1(r) || !e.printer.canAttachComment) return;
    let n = [], { printer: { features: { experimental_avoidAstMutation: u }, handleComments: o = {} }, originalText: i } = e, { ownLine: D = Yt$1, endOfLine: s = Yt$1, remaining: a = Yt$1 } = o, c = r.map((l, m2) => ({ ...Dn$1(t, l, e), comment: l, text: i, options: e, ast: t, isLastComment: r.length - 1 === m2, placement: void 0 })), p2 = !u;
    for (let [l, m2] of c.entries()) {
      let { comment: f, precedingNode: F2, enclosingNode: d, followingNode: E2, text: C2, options: h, ast: _, isLastComment: P2 } = m2, A2 = Co$1(C2, h, c, l) ? "ownLine" : ho$1(C2, h, c, l) ? "endOfLine" : "remaining", B2;
      if (u ? (m2.placement = A2, B2 = [m2]) : B2 = [f, C2, h, _, P2], p2 && (f.enclosingNode = d, f.precedingNode = F2, f.followingNode = E2), f.placement = A2, A2 === "ownLine") D(...B2) || (E2 ? ce$1(E2, f) : F2 ? fe$1(F2, f) : d ? re$1(d, f) : re$1(_, f));
      else if (A2 === "endOfLine") s(...B2) || (F2 ? fe$1(F2, f) : E2 ? ce$1(E2, f) : d ? re$1(d, f) : re$1(_, f));
      else if (!a(...B2)) if (F2 && E2) {
        let J2 = n.length;
        J2 > 0 && n[J2 - 1].followingNode !== E2 && sn$1(n, h), n.push(m2);
      } else F2 ? fe$1(F2, f) : E2 ? ce$1(E2, f) : d ? re$1(d, f) : re$1(_, f);
    }
    if (sn$1(n, e), p2) for (let l of r) delete l.precedingNode, delete l.enclosingNode, delete l.followingNode;
  }
  var cn$1 = (t) => !/[\\S\\n\\u2028\\u2029]/.test(t);
  function Co$1(t, e, r, n) {
    let { comment: u, precedingNode: o } = r[n], { locStart: i, locEnd: D } = e, s = i(u);
    if (o) for (let a = n - 1; a >= 0; a--) {
      let { comment: c, precedingNode: p2 } = r[a];
      if (p2 !== o || !cn$1(t.slice(D(c), s))) break;
      s = i(c);
    }
    return H$1(t, s, { backwards: true });
  }
  function ho$1(t, e, r, n) {
    let { comment: u, followingNode: o } = r[n], { locStart: i, locEnd: D } = e, s = D(u);
    if (o) for (let a = n + 1; a < r.length; a++) {
      let { comment: c, followingNode: p2 } = r[a];
      if (p2 !== o || !cn$1(t.slice(s, i(c)))) break;
      s = D(c);
    }
    return H$1(t, s);
  }
  function sn$1(t, e) {
    let r = t.length;
    if (r === 0) return;
    let { precedingNode: n, followingNode: u } = t[0], o = e.locStart(u), i;
    for (i = r; i > 0; --i) {
      let { comment: D, precedingNode: s, followingNode: a } = t[i - 1];
      let c = e.originalText.slice(e.locEnd(D), o);
      if (e.printer.isGap?.(c, e) ?? /^[\\s(]*$/.test(c)) o = e.locStart(D);
      else break;
    }
    for (let [D, { comment: s }] of t.entries()) D < i ? fe$1(n, s) : ce$1(u, s);
    for (let D of [n, u]) D.comments && D.comments.length > 1 && D.comments.sort((s, a) => e.locStart(s) - e.locStart(a));
    t.length = 0;
  }
  function jt$1(t, e, r) {
    let n = r.locStart(e) - 1;
    for (let u = 1; u < t.length; ++u) if (n < r.locStart(t[u])) return u - 1;
    return 0;
  }
  function go$1(t, e) {
    let r = e - 1;
    r = j$1(t, r, { backwards: true }), r = $$2(t, r, { backwards: true }), r = j$1(t, r, { backwards: true });
    let n = $$2(t, r, { backwards: true });
    return r !== n;
  }
  var ve$1 = go$1;
  var fn$1 = () => true;
  function ln$1(t, e) {
    let r = t.node;
    return r.printed = true, e.printer.printComment(t, e);
  }
  function _o$1(t, e) {
    let r = t.node, n = [ln$1(t, e)], { printer: u, originalText: o, locStart: i, locEnd: D } = e;
    if (u.isBlockComment?.(r)) {
      let c = " ";
      H$1(o, D(r)) && (H$1(o, i(r), { backwards: true }) ? c = W : c = Ze$1), n.push(c);
    } else n.push(W);
    let a = $$2(o, j$1(o, D(r)));
    return a !== false && H$1(o, a) && n.push(W), n;
  }
  function yo$1(t, e, r) {
    let n = t.node, u = ln$1(t, e), { printer: o, originalText: i, locStart: D } = e, s = o.isBlockComment?.(n);
    if (r?.hasLineSuffix && !r?.isBlock || H$1(i, D(n), { backwards: true })) {
      let a = ve$1(i, D(n));
      return { doc: Ie$1([W, a ? W : "", u]), isBlock: s, hasLineSuffix: true };
    }
    return !s || r?.hasLineSuffix ? { doc: [Ie$1([" ", u]), ae$1], isBlock: s, hasLineSuffix: true } : { doc: [" ", u], isBlock: s, hasLineSuffix: false };
  }
  function Ao$1(t, e, r) {
    let n = e[/* @__PURE__ */ Symbol.for("printedComments")], u = fn$1, o = new Set(t.node?.comments?.filter((i) => !n?.has(i) && i.leading && u(i)));
    return o.size === 0 ? "" : t.map(({ node: i }) => o.has(i) ? _o$1(t, e) : "", "comments").filter(Boolean);
  }
  function xo$1(t, e, r) {
    let n = t.node?.comments, u = new Set(n?.filter((c) => c.trailing)), o = e[/* @__PURE__ */ Symbol.for("printedComments")], i = fn$1, D = new Set(n?.filter((c) => u.has(c) && !o?.has(c) && i(c)));
    if (D.size === 0) return "";
    let s = [], a;
    return t.each(({ node: c }) => {
      u.has(c) && (a = yo$1(t, e, a), D.has(c) && s.push(a.doc));
    }, "comments"), s;
  }
  function pn$1(t, e, r, n) {
    let u = Ao$1(t, r), o = xo$1(t, r);
    return u || o ? Ee$1(e, (i) => [u, i, o]) : e;
  }
  function mn$1(t) {
    let { [ue$1]: e, [/* @__PURE__ */ Symbol.for("printedComments")]: r } = t;
    for (let n of e) {
      if (!n.printed && !r.has(n)) throw new Error('Comment "' + n.value.trim() + '" was not printed. Please report this error!');
      delete n.printed;
    }
  }
  var Le$1 = class Le extends Error {
    name = "ConfigError";
  }, Me$1 = class Me extends Error {
    name = "UndefinedParserError";
  };
  var Bo$1 = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), le$1 = Bo$1;
  var Fn$1 = { checkIgnorePragma: { category: "Special", type: "boolean", default: false, description: "Check whether the file's first docblock comment contains '@noprettier' or '@noformat' to determine if it should be formatted.", cliCategory: "Other" }, cursorOffset: { category: "Special", type: "int", default: -1, range: { start: -1, end: 1 / 0, step: 1 }, description: "Print (to stderr) where a cursor at the given position would move to after formatting.", cliCategory: "Editor" }, endOfLine: { category: "Global", type: "choice", default: "lf", description: "Which end of line characters to apply.", choices: [{ value: "lf", description: "Line Feed only (\\\\n), common on Linux and macOS as well as inside git repos" }, { value: "crlf", description: "Carriage Return + Line Feed characters (\\\\r\\\\n), common on Windows" }, { value: "cr", description: "Carriage Return character only (\\\\r), used very rarely" }, { value: "auto", description: \`Maintain existing
(mixed values within one file are normalised by looking at what's used after the first line)\` }] }, filepath: { category: "Special", type: "path", description: "Specify the input filepath. This will be used to do parser inference.", cliName: "stdin-filepath", cliCategory: "Other", cliDescription: "Path to the file to pretend that stdin comes from." }, insertPragma: { category: "Special", type: "boolean", default: false, description: "Insert @format pragma into file's first docblock comment.", cliCategory: "Other" }, parser: { category: "Global", type: "choice", default: void 0, description: "Which parser to use.", exception: (t) => typeof t == "string" || typeof t == "function", choices: [{ value: "flow", description: "Flow" }, { value: "babel", description: "JavaScript" }, { value: "babel-flow", description: "Flow" }, { value: "babel-ts", description: "TypeScript" }, { value: "typescript", description: "TypeScript" }, { value: "acorn", description: "JavaScript" }, { value: "espree", description: "JavaScript" }, { value: "meriyah", description: "JavaScript" }, { value: "css", description: "CSS" }, { value: "less", description: "Less" }, { value: "scss", description: "SCSS" }, { value: "json", description: "JSON" }, { value: "json5", description: "JSON5" }, { value: "jsonc", description: "JSON with Comments" }, { value: "json-stringify", description: "JSON.stringify" }, { value: "graphql", description: "GraphQL" }, { value: "markdown", description: "Markdown" }, { value: "mdx", description: "MDX" }, { value: "vue", description: "Vue" }, { value: "yaml", description: "YAML" }, { value: "glimmer", description: "Ember / Handlebars" }, { value: "html", description: "HTML" }, { value: "angular", description: "Angular" }, { value: "lwc", description: "Lightning Web Components" }, { value: "mjml", description: "MJML" }] }, plugins: { type: "path", array: true, default: [{ value: [] }], category: "Global", description: "Add a plugin. Multiple plugins can be passed as separate \`--plugin\`s.", exception: (t) => typeof t == "string" || typeof t == "object", cliName: "plugin", cliCategory: "Config" }, printWidth: { category: "Global", type: "int", default: 80, description: "The line length where Prettier will try wrap.", range: { start: 0, end: 1 / 0, step: 1 } }, rangeEnd: { category: "Special", type: "int", default: 1 / 0, range: { start: 0, end: 1 / 0, step: 1 }, description: \`Format code ending at a given character offset (exclusive).
The range will extend forwards to the end of the selected statement.\`, cliCategory: "Editor" }, rangeStart: { category: "Special", type: "int", default: 0, range: { start: 0, end: 1 / 0, step: 1 }, description: \`Format code starting at a given character offset.
The range will extend backwards to the start of the first line containing the selected statement.\`, cliCategory: "Editor" }, requirePragma: { category: "Special", type: "boolean", default: false, description: "Require either '@prettier' or '@format' to be present in the file's first docblock comment in order for it to be formatted.", cliCategory: "Other" }, tabWidth: { type: "int", category: "Global", default: 2, description: "Number of spaces per indentation level.", range: { start: 0, end: 1 / 0, step: 1 } }, useTabs: { category: "Global", type: "boolean", default: false, description: "Indent with tabs instead of spaces." }, embeddedLanguageFormatting: { category: "Global", type: "choice", default: "auto", description: "Control how Prettier formats quoted code embedded in the file.", choices: [{ value: "auto", description: "Format embedded code if Prettier can automatically identify it." }, { value: "off", description: "Never automatically format embedded code." }] } };
  function it$1({ plugins: t = [], showDeprecated: e = false } = {}) {
    let r = t.flatMap((u) => u.languages ?? []), n = [];
    for (let u of No$1(Object.assign({}, ...t.map(({ options: o }) => o), Fn$1))) !e && u.deprecated || (Array.isArray(u.choices) && (e || (u.choices = u.choices.filter((o) => !o.deprecated)), u.name === "parser" && (u.choices = [...u.choices, ...To$1(u.choices, r, t)])), u.pluginDefaults = Object.fromEntries(t.filter((o) => o.defaultOptions?.[u.name] !== void 0).map((o) => [o.name, o.defaultOptions[u.name]])), n.push(u));
    return { languages: r, options: n };
  }
  function* To$1(t, e, r) {
    let n = new Set(t.map((u) => u.value));
    for (let u of e) if (u.parsers) {
      for (let o of u.parsers) if (!n.has(o)) {
        n.add(o);
        let i = r.find((s) => s.parsers && le$1(s.parsers, o)), D = u.name;
        i?.name && (D += \` (plugin: \${i.name})\`), yield { value: o, description: D };
      }
    }
  }
  function No$1(t) {
    let e = [];
    for (let [r, n] of Object.entries(t)) {
      let u = { name: r, ...n };
      Array.isArray(u.default) && (u.default = y$1(0, u.default, -1).value), e.push(u);
    }
    return e;
  }
  var wo$1 = Array.prototype.toReversed ?? function() {
    return [...this].reverse();
  }, Oo$1 = X$1("toReversed", function() {
    if (Array.isArray(this)) return wo$1;
  }), En$1 = Oo$1;
  function Po$1() {
    let t = globalThis, e = t.process?.platform;
    if (typeof e == "string") return e.startsWith("win");
    let r = t.Deno?.build?.os;
    return typeof r == "string" ? r === "windows" : t.navigator?.platform?.startsWith("Win") ?? false;
  }
  var So$1 = Po$1();
  function Cn$1(t) {
    if (t = t instanceof URL ? t : new URL(t), t.protocol !== "file:") throw new TypeError(\`URL must be a file URL: received "\${t.protocol}"\`);
    return t;
  }
  function bo$1(t) {
    return t = Cn$1(t), decodeURIComponent(t.pathname.replace(/%(?![0-9A-Fa-f]{2})/g, "%25"));
  }
  function ko$1(t) {
    t = Cn$1(t);
    let e = decodeURIComponent(t.pathname.replace(/\\//g, "\\\\").replace(/%(?![0-9A-Fa-f]{2})/g, "%25")).replace(/^\\\\*([A-Za-z]:)(\\\\|$)/, "$1\\\\");
    return t.hostname !== "" && (e = \`\\\\\\\\\${t.hostname}\${e}\`), e;
  }
  function Vt$1(t) {
    return So$1 ? ko$1(t) : bo$1(t);
  }
  var hn$1 = (t) => String(t).split(/[/\\\\]/).pop(), gn$1 = (t) => String(t).startsWith("file:");
  function _n$1(t, e) {
    if (!e) return;
    let r = hn$1(e).toLowerCase();
    return t.find(({ filenames: n }) => n?.some((u) => u.toLowerCase() === r)) ?? t.find(({ extensions: n }) => n?.some((u) => r.endsWith(u)));
  }
  function Io$1(t, e) {
    if (e) return t.find(({ name: r }) => r.toLowerCase() === e) ?? t.find(({ aliases: r }) => r?.includes(e)) ?? t.find(({ extensions: r }) => r?.includes(\`.\${e}\`));
  }
  var Ro$1 = void 0;
  function yn$1(t, e) {
    if (e) {
      if (gn$1(e)) try {
        e = Vt$1(e);
      } catch {
        return;
      }
      if (typeof e == "string") return t.find(({ isSupported: r }) => r?.({ filepath: e }));
    }
  }
  function vo$1(t, e) {
    let r = En$1(0, t.plugins).flatMap((u) => u.languages ?? []);
    return (Io$1(r, e.language) ?? _n$1(r, e.physicalFile) ?? _n$1(r, e.file) ?? yn$1(r, e.physicalFile) ?? yn$1(r, e.file) ?? Ro$1?.(r, e.physicalFile))?.parsers[0];
  }
  var st$1 = vo$1;
  var ie = { key: (t) => /^[$_a-zA-Z][$_a-zA-Z0-9]*$/.test(t) ? t : JSON.stringify(t), value(t) {
    if (t === null || typeof t != "object") return JSON.stringify(t);
    if (Array.isArray(t)) return \`[\${t.map((r) => ie.value(r)).join(", ")}]\`;
    let e = Object.keys(t);
    return e.length === 0 ? "{}" : \`{ \${e.map((r) => \`\${ie.key(r)}: \${ie.value(t[r])}\`).join(", ")} }\`;
  }, pair: ({ key: t, value: e }) => ie.value({ [t]: e }) };
  var An$1 = new Proxy(String, { get: () => An$1 }), z$1 = An$1;
  var xn$1 = (t, e, { descriptor: r }) => {
    let n = [\`\${z$1.yellow(typeof t == "string" ? r.key(t) : r.pair(t))} is deprecated\`];
    return e && n.push(\`we now treat it as \${z$1.blue(typeof e == "string" ? r.key(e) : r.pair(e))}\`), n.join("; ") + ".";
  };
  var Dt$1 = /* @__PURE__ */ Symbol.for("vnopts.VALUE_NOT_EXIST"), Ae$1 = /* @__PURE__ */ Symbol.for("vnopts.VALUE_UNCHANGED");
  var Bn$1 = " ".repeat(2), Nn$1 = (t, e, r) => {
    let { text: n, list: u } = r.normalizeExpectedResult(r.schemas[t].expected(r)), o = [];
    return n && o.push(Tn$1(t, e, n, r.descriptor)), u && o.push([Tn$1(t, e, u.title, r.descriptor)].concat(u.values.map((i) => wn$1(i, r.loggerPrintWidth))).join(\`
\`)), On$1(o, r.loggerPrintWidth);
  };
  function Tn$1(t, e, r, n) {
    return [\`Invalid \${z$1.red(n.key(t))} value.\`, \`Expected \${z$1.blue(r)},\`, \`but received \${e === Dt$1 ? z$1.gray("nothing") : z$1.red(n.value(e))}.\`].join(" ");
  }
  function wn$1({ text: t, list: e }, r) {
    let n = [];
    return t && n.push(\`- \${z$1.blue(t)}\`), e && n.push([\`- \${z$1.blue(e.title)}:\`].concat(e.values.map((u) => wn$1(u, r - Bn$1.length).replace(/^|\\n/g, \`$&\${Bn$1}\`))).join(\`
\`)), On$1(n, r);
  }
  function On$1(t, e) {
    if (t.length === 1) return t[0];
    let [r, n] = t, [u, o] = t.map((i) => i.split(\`
\`, 1)[0].length);
    return u > e && u > o ? n : r;
  }
  var xe$1 = [], Wt$1 = [];
  function at(t, e, r) {
    if (t === e) return 0;
    let n = r?.maxDistance, u = t;
    t.length > e.length && (t = e, e = u);
    let o = t.length, i = e.length;
    for (; o > 0 && t.charCodeAt(~-o) === e.charCodeAt(~-i); ) o--, i--;
    let D = 0;
    for (; D < o && t.charCodeAt(D) === e.charCodeAt(D); ) D++;
    if (o -= D, i -= D, n !== void 0 && i - o > n) return n;
    if (o === 0) return n !== void 0 && i > n ? n : i;
    let s, a, c, p2, l = 0, m2 = 0;
    for (; l < o; ) Wt$1[l] = t.charCodeAt(D + l), xe$1[l] = ++l;
    for (; m2 < i; ) {
      for (s = e.charCodeAt(D + m2), c = m2++, a = m2, l = 0; l < o; l++) p2 = s === Wt$1[l] ? c : c + 1, c = xe$1[l], a = xe$1[l] = c > a ? p2 > a ? a + 1 : p2 : p2 > c ? c + 1 : p2;
      if (n !== void 0) {
        let f = a;
        for (l = 0; l < o; l++) xe$1[l] < f && (f = xe$1[l]);
        if (f > n) return n;
      }
    }
    return xe$1.length = o, Wt$1.length = o, n !== void 0 && a > n ? n : a;
  }
  function Pn$1(t, e, r) {
    if (!Array.isArray(e) || e.length === 0) return;
    let n = r?.maxDistance, u = t.length;
    for (let s of e) if (s === t) return s;
    let o, i = Number.POSITIVE_INFINITY, D = /* @__PURE__ */ new Set();
    for (let s of e) {
      if (D.has(s)) continue;
      D.add(s);
      let a = Math.abs(s.length - u);
      if (a >= i || a > n) continue;
      let c = Number.isFinite(i) ? Math.min(i, n) : n, p2 = c === void 0 ? at(t, s) : at(t, s, { maxDistance: c });
      if (p2 > n) continue;
      let l = p2;
      if (c !== void 0 && p2 === c && c === n && (l = at(t, s)), l < i && (i = l, o = s, i === 0)) break;
    }
    if (!(i > n)) return o;
  }
  var ct$1 = (t, e, { descriptor: r, logger: n, schemas: u }) => {
    let o = [\`Ignored unknown option \${z$1.yellow(r.pair({ key: t, value: e }))}.\`], i = Pn$1(t, Object.keys(u), { maxDistance: 3 });
    i && o.push(\`Did you mean \${z$1.blue(r.key(i))}?\`), n.warn(o.join(" "));
  };
  var Lo$1 = ["default", "expected", "validate", "deprecated", "forward", "redirect", "overlap", "preprocess", "postprocess"];
  function Mo$1(t, e) {
    let r = new t(e), n = Object.create(r);
    for (let u of Lo$1) u in e && (n[u] = Yo(e[u], r, O$1.prototype[u].length));
    return n;
  }
  var O$1 = class O {
    static create(e) {
      return Mo$1(this, e);
    }
    constructor(e) {
      this.name = e.name;
    }
    default(e) {
    }
    expected(e) {
      return "nothing";
    }
    validate(e, r) {
      return false;
    }
    deprecated(e, r) {
      return false;
    }
    forward(e, r) {
    }
    redirect(e, r) {
    }
    overlap(e, r, n) {
      return e;
    }
    preprocess(e, r) {
      return e;
    }
    postprocess(e, r) {
      return Ae$1;
    }
  };
  function Yo(t, e, r) {
    return typeof t == "function" ? (...n) => t(...n.slice(0, r - 1), e, ...n.slice(r - 1)) : () => t;
  }
  var ft$1 = class ft extends O$1 {
    constructor(e) {
      super(e), this._sourceName = e.sourceName;
    }
    expected(e) {
      return e.schemas[this._sourceName].expected(e);
    }
    validate(e, r) {
      return r.schemas[this._sourceName].validate(e, r);
    }
    redirect(e, r) {
      return this._sourceName;
    }
  };
  var lt$1 = class lt extends O$1 {
    expected() {
      return "anything";
    }
    validate() {
      return true;
    }
  };
  var pt$1 = class pt extends O$1 {
    constructor({ valueSchema: e, name: r = e.name, ...n }) {
      super({ ...n, name: r }), this._valueSchema = e;
    }
    expected(e) {
      let { text: r, list: n } = e.normalizeExpectedResult(this._valueSchema.expected(e));
      return { text: r && \`an array of \${r}\`, list: n && { title: "an array of the following values", values: [{ list: n }] } };
    }
    validate(e, r) {
      if (!Array.isArray(e)) return false;
      let n = [];
      for (let u of e) {
        let o = r.normalizeValidateResult(this._valueSchema.validate(u, r), u);
        o !== true && n.push(o.value);
      }
      return n.length === 0 ? true : { value: n };
    }
    deprecated(e, r) {
      let n = [];
      for (let u of e) {
        let o = r.normalizeDeprecatedResult(this._valueSchema.deprecated(u, r), u);
        o !== false && n.push(...o.map(({ value: i }) => ({ value: [i] })));
      }
      return n;
    }
    forward(e, r) {
      let n = [];
      for (let u of e) {
        let o = r.normalizeForwardResult(this._valueSchema.forward(u, r), u);
        n.push(...o.map(Sn$1));
      }
      return n;
    }
    redirect(e, r) {
      let n = [], u = [];
      for (let o of e) {
        let i = r.normalizeRedirectResult(this._valueSchema.redirect(o, r), o);
        "remain" in i && n.push(i.remain), u.push(...i.redirect.map(Sn$1));
      }
      return n.length === 0 ? { redirect: u } : { redirect: u, remain: n };
    }
    overlap(e, r) {
      return e.concat(r);
    }
  };
  function Sn$1({ from: t, to: e }) {
    return { from: [t], to: e };
  }
  var mt$1 = class mt extends O$1 {
    expected() {
      return "true or false";
    }
    validate(e) {
      return typeof e == "boolean";
    }
  };
  function kn$1(t, e) {
    let r = /* @__PURE__ */ Object.create(null);
    for (let n of t) {
      let u = n[e];
      if (r[u]) throw new Error(\`Duplicate \${e} \${JSON.stringify(u)}\`);
      r[u] = n;
    }
    return r;
  }
  function In$1(t, e) {
    let r = /* @__PURE__ */ new Map();
    for (let n of t) {
      let u = n[e];
      if (r.has(u)) throw new Error(\`Duplicate \${e} \${JSON.stringify(u)}\`);
      r.set(u, n);
    }
    return r;
  }
  function Rn$1() {
    let t = /* @__PURE__ */ Object.create(null);
    return (e) => {
      let r = JSON.stringify(e);
      return t[r] ? true : (t[r] = true, false);
    };
  }
  function vn$1(t, e) {
    let r = [], n = [];
    for (let u of t) e(u) ? r.push(u) : n.push(u);
    return [r, n];
  }
  function Ln$1(t) {
    return t === Math.floor(t);
  }
  function Mn$1(t, e) {
    if (t === e) return 0;
    let r = typeof t, n = typeof e, u = ["undefined", "object", "boolean", "number", "string"];
    return r !== n ? u.indexOf(r) - u.indexOf(n) : r !== "string" ? Number(t) - Number(e) : t.localeCompare(e);
  }
  function Yn$1(t) {
    return (...e) => {
      let r = t(...e);
      return typeof r == "string" ? new Error(r) : r;
    };
  }
  function $t$1(t) {
    return t === void 0 ? {} : t;
  }
  function zt$1(t) {
    if (typeof t == "string") return { text: t };
    let { text: e, list: r } = t;
    return jo((e || r) !== void 0, "Unexpected \`expected\` result, there should be at least one field."), r ? { text: e, list: { title: r.title, values: r.values.map(zt$1) } } : { text: e };
  }
  function Gt$1(t, e) {
    return t === true ? true : t === false ? { value: e } : t;
  }
  function Kt$1(t, e, r = false) {
    return t === false ? false : t === true ? r ? true : [{ value: e }] : "value" in t ? [t] : t.length === 0 ? false : t;
  }
  function bn$1(t, e) {
    return typeof t == "string" || "key" in t ? { from: e, to: t } : "from" in t ? { from: t.from, to: t.to } : { from: e, to: t.to };
  }
  function dt$1(t, e) {
    return t === void 0 ? [] : Array.isArray(t) ? t.map((r) => bn$1(r, e)) : [bn$1(t, e)];
  }
  function Ht$1(t, e) {
    let r = dt$1(typeof t == "object" && "redirect" in t ? t.redirect : t, e);
    return r.length === 0 ? { remain: e, redirect: r } : typeof t == "object" && "remain" in t ? { remain: t.remain, redirect: r } : { redirect: r };
  }
  function jo(t, e) {
    if (!t) throw new Error(e);
  }
  var Ft$1 = class Ft extends O$1 {
    constructor(e) {
      super(e), this._choices = In$1(e.choices.map((r) => r && typeof r == "object" ? r : { value: r }), "value");
    }
    expected({ descriptor: e }) {
      let r = Array.from(this._choices.keys()).map((i) => this._choices.get(i)).filter(({ hidden: i }) => !i).map((i) => i.value).sort(Mn$1).map(e.value), n = r.slice(0, -2), u = r.slice(-2);
      return { text: n.concat(u.join(" or ")).join(", "), list: { title: "one of the following values", values: r } };
    }
    validate(e) {
      return this._choices.has(e);
    }
    deprecated(e) {
      let r = this._choices.get(e);
      return r && r.deprecated ? { value: e } : false;
    }
    forward(e) {
      let r = this._choices.get(e);
      return r ? r.forward : void 0;
    }
    redirect(e) {
      let r = this._choices.get(e);
      return r ? r.redirect : void 0;
    }
  };
  var Et$1 = class Et extends O$1 {
    expected() {
      return "a number";
    }
    validate(e, r) {
      return typeof e == "number";
    }
  };
  var Ct$1 = class Ct extends Et$1 {
    expected() {
      return "an integer";
    }
    validate(e, r) {
      return r.normalizeValidateResult(super.validate(e, r), e) === true && Ln$1(e);
    }
  };
  var Ye$1 = class Ye extends O$1 {
    expected() {
      return "a string";
    }
    validate(e) {
      return typeof e == "string";
    }
  };
  var jn$1 = ie, Un$1 = ct$1, Vn$1 = Nn$1, Wn$1 = xn$1;
  var ht$1 = class ht {
    constructor(e, r) {
      let { logger: n = console, loggerPrintWidth: u = 80, descriptor: o = jn$1, unknown: i = Un$1, invalid: D = Vn$1, deprecated: s = Wn$1, missing: a = () => false, required: c = () => false, preprocess: p2 = (m2) => m2, postprocess: l = () => Ae$1 } = r || {};
      this._utils = { descriptor: o, logger: n || { warn: () => {
      } }, loggerPrintWidth: u, schemas: kn$1(e, "name"), normalizeDefaultResult: $t$1, normalizeExpectedResult: zt$1, normalizeDeprecatedResult: Kt$1, normalizeForwardResult: dt$1, normalizeRedirectResult: Ht$1, normalizeValidateResult: Gt$1 }, this._unknownHandler = i, this._invalidHandler = Yn$1(D), this._deprecatedHandler = s, this._identifyMissing = (m2, f) => !(m2 in f) || a(m2, f), this._identifyRequired = c, this._preprocess = p2, this._postprocess = l, this.cleanHistory();
    }
    cleanHistory() {
      this._hasDeprecationWarned = Rn$1();
    }
    normalize(e) {
      let r = {}, u = [this._preprocess(e, this._utils)], o = () => {
        for (; u.length !== 0; ) {
          let i = u.shift(), D = this._applyNormalization(i, r);
          u.push(...D);
        }
      };
      o();
      for (let i of Object.keys(this._utils.schemas)) {
        let D = this._utils.schemas[i];
        if (!(i in r)) {
          let s = $t$1(D.default(this._utils));
          "value" in s && u.push({ [i]: s.value });
        }
      }
      o();
      for (let i of Object.keys(this._utils.schemas)) {
        if (!(i in r)) continue;
        let D = this._utils.schemas[i], s = r[i], a = D.postprocess(s, this._utils);
        a !== Ae$1 && (this._applyValidation(a, i, D), r[i] = a);
      }
      return this._applyPostprocess(r), this._applyRequiredCheck(r), r;
    }
    _applyNormalization(e, r) {
      let n = [], { knownKeys: u, unknownKeys: o } = this._partitionOptionKeys(e);
      for (let i of u) {
        let D = this._utils.schemas[i], s = D.preprocess(e[i], this._utils);
        this._applyValidation(s, i, D);
        let a = ({ from: m2, to: f }) => {
          n.push(typeof f == "string" ? { [f]: m2 } : { [f.key]: f.value });
        }, c = ({ value: m2, redirectTo: f }) => {
          let F2 = Kt$1(D.deprecated(m2, this._utils), s, true);
          if (F2 !== false) if (F2 === true) this._hasDeprecationWarned(i) || this._utils.logger.warn(this._deprecatedHandler(i, f, this._utils));
          else for (let { value: d } of F2) {
            let E2 = { key: i, value: d };
            if (!this._hasDeprecationWarned(E2)) {
              let C2 = typeof f == "string" ? { key: f, value: d } : f;
              this._utils.logger.warn(this._deprecatedHandler(E2, C2, this._utils));
            }
          }
        };
        dt$1(D.forward(s, this._utils), s).forEach(a);
        let l = Ht$1(D.redirect(s, this._utils), s);
        if (l.redirect.forEach(a), "remain" in l) {
          let m2 = l.remain;
          r[i] = i in r ? D.overlap(r[i], m2, this._utils) : m2, c({ value: m2 });
        }
        for (let { from: m2, to: f } of l.redirect) c({ value: m2, redirectTo: f });
      }
      for (let i of o) {
        let D = e[i];
        this._applyUnknownHandler(i, D, r, (s, a) => {
          n.push({ [s]: a });
        });
      }
      return n;
    }
    _applyRequiredCheck(e) {
      for (let r of Object.keys(this._utils.schemas)) if (this._identifyMissing(r, e) && this._identifyRequired(r)) throw this._invalidHandler(r, Dt$1, this._utils);
    }
    _partitionOptionKeys(e) {
      let [r, n] = vn$1(Object.keys(e).filter((u) => !this._identifyMissing(u, e)), (u) => u in this._utils.schemas);
      return { knownKeys: r, unknownKeys: n };
    }
    _applyValidation(e, r, n) {
      let u = Gt$1(n.validate(e, this._utils), e);
      if (u !== true) throw this._invalidHandler(r, u.value, this._utils);
    }
    _applyUnknownHandler(e, r, n, u) {
      let o = this._unknownHandler(e, r, this._utils);
      if (o) for (let i of Object.keys(o)) {
        if (this._identifyMissing(i, o)) continue;
        let D = o[i];
        i in this._utils.schemas ? u(i, D) : n[i] = D;
      }
    }
    _applyPostprocess(e) {
      let r = this._postprocess(e, this._utils);
      if (r !== Ae$1) {
        if (r.delete) for (let n of r.delete) delete e[n];
        if (r.override) {
          let { knownKeys: n, unknownKeys: u } = this._partitionOptionKeys(r.override);
          for (let o of n) {
            let i = r.override[o];
            this._applyValidation(i, o, this._utils.schemas[o]), e[o] = i;
          }
          for (let o of u) {
            let i = r.override[o];
            this._applyUnknownHandler(o, i, e, (D, s) => {
              let a = this._utils.schemas[D];
              this._applyValidation(s, D, a), e[D] = s;
            });
          }
        }
      }
    }
  };
  var Jt$1;
  function Uo$1(t, e, { logger: r = false, isCLI: n = false, passThrough: u = false, FlagSchema: o, descriptor: i } = {}) {
    if (n) {
      if (!o) throw new Error("'FlagSchema' option is required.");
      if (!i) throw new Error("'descriptor' option is required.");
    } else i = ie;
    let D = u ? Array.isArray(u) ? (l, m2) => u.includes(l) ? { [l]: m2 } : void 0 : (l, m2) => ({ [l]: m2 }) : (l, m2, f) => {
      let { _: F2, ...d } = f.schemas;
      return ct$1(l, m2, { ...f, schemas: d });
    }, s = Vo$1(e, { isCLI: n, FlagSchema: o }), a = new ht$1(s, { logger: r, unknown: D, descriptor: i }), c = r !== false;
    c && Jt$1 && (a._hasDeprecationWarned = Jt$1);
    let p2 = a.normalize(t);
    return c && (Jt$1 = a._hasDeprecationWarned), p2;
  }
  function Vo$1(t, { isCLI: e, FlagSchema: r }) {
    let n = [];
    e && n.push(lt$1.create({ name: "_" }));
    for (let u of t) n.push(Wo$1(u, { isCLI: e, optionInfos: t, FlagSchema: r })), u.alias && e && n.push(ft$1.create({ name: u.alias, sourceName: u.name }));
    return n;
  }
  function Wo$1(t, { isCLI: e, optionInfos: r, FlagSchema: n }) {
    let { name: u } = t, o = { name: u }, i, D = {};
    switch (t.type) {
      case "int":
        i = Ct$1, e && (o.preprocess = Number);
        break;
      case "string":
        i = Ye$1;
        break;
      case "choice":
        i = Ft$1, o.choices = t.choices.map((s) => s?.redirect ? { ...s, redirect: { to: { key: t.name, value: s.redirect } } } : s);
        break;
      case "boolean":
        i = mt$1;
        break;
      case "flag":
        i = n, o.flags = r.flatMap((s) => [s.alias, s.description && s.name, s.oppositeDescription && \`no-\${s.name}\`].filter(Boolean));
        break;
      case "path":
        i = Ye$1;
        break;
      default:
        throw new Error(\`Unexpected type \${t.type}\`);
    }
    if (t.exception ? o.validate = (s, a, c) => t.exception(s) || a.validate(s, c) : o.validate = (s, a, c) => s === void 0 || a.validate(s, c), t.redirect && (D.redirect = (s) => s ? { to: typeof t.redirect == "string" ? t.redirect : { key: t.redirect.option, value: t.redirect.value } } : void 0), t.deprecated && (D.deprecated = true), e && !t.array) {
      let s = o.preprocess || ((a) => a);
      o.preprocess = (a, c, p2) => c.preprocess(s(Array.isArray(a) ? y$1(0, a, -1) : a), p2);
    }
    return t.array ? pt$1.create({ ...e ? { preprocess: (s) => Array.isArray(s) ? s : [s] } : {}, ...D, valueSchema: i.create(o) }) : i.create({ ...o, ...D });
  }
  var $n$1 = Uo$1;
  var $o$1 = Array.prototype.findLast ?? function(t) {
    for (let e = this.length - 1; e >= 0; e--) {
      let r = this[e];
      if (t(r, e, this)) return r;
    }
  }, zo$1 = X$1("findLast", function() {
    if (Array.isArray(this)) return $o$1;
  }), qt$1 = zo$1;
  var zn$1 = /* @__PURE__ */ Symbol.for("PRETTIER_IS_FRONT_MATTER"), Xt$1 = [];
  function Go$1(t) {
    return !!t?.[zn$1];
  }
  var pe$1 = Go$1;
  var Gn$1 = /* @__PURE__ */ new Set(["yaml", "toml"]), je$1 = ({ node: t }) => pe$1(t) && Gn$1.has(t.language);
  async function Qt$1(t, e, r, n) {
    let { node: u } = r, { language: o } = u;
    if (!Gn$1.has(o)) return;
    let i = u.value.trim(), D;
    if (i) {
      let s = o === "yaml" ? o : st$1(n, { language: o });
      if (!s) return;
      D = i ? await t(i, { parser: s }) : "";
    } else D = i;
    return Xe$1([u.startDelimiter, u.explicitLanguage ?? "", W, D, D ? W : "", u.endDelimiter]);
  }
  function Ko(t, e) {
    return je$1({ node: t }) && (delete e.end, delete e.raw, delete e.value), e;
  }
  var Zt$1 = Ko;
  function Ho$1({ node: t }) {
    return t.raw;
  }
  var er$1 = Ho$1;
  var Kn$1 = /* @__PURE__ */ new Set(["tokens", "comments", "parent", "enclosingNode", "precedingNode", "followingNode"]), Jo = (t) => Object.keys(t).filter((e) => !Kn$1.has(e));
  function qo$1(t, e) {
    let r = t ? (n) => t(n, Kn$1) : Jo;
    return e ? new Proxy(r, { apply: (n, u, o) => pe$1(o[0]) ? Xt$1 : Reflect.apply(n, u, o) }) : r;
  }
  var tr$1 = qo$1;
  function rr$1(t, e) {
    if (!e) throw new Error("parserName is required.");
    let r = qt$1(0, t, (u) => u.parsers && le$1(u.parsers, e));
    if (r) return r;
    let n = \`Couldn't resolve parser "\${e}".\`;
    throw n += " Plugins must be explicitly added to the standalone bundle.", new Le$1(n);
  }
  function Hn$1(t, e) {
    if (!e) throw new Error("astFormat is required.");
    let r = qt$1(0, t, (u) => u.printers && le$1(u.printers, e));
    if (r) return r;
    let n = \`Couldn't find plugin for AST format "\${e}".\`;
    throw n += " Plugins must be explicitly added to the standalone bundle.", new Le$1(n);
  }
  function Ue$1({ plugins: t, parser: e }) {
    let r = rr$1(t, e);
    return nr$1(r, e);
  }
  function nr$1(t, e) {
    let r = t.parsers[e];
    return typeof r == "function" ? r() : r;
  }
  async function Jn$1(t, e) {
    let r = t.printers[e], n = typeof r == "function" ? await r() : r;
    return Zo(n);
  }
  function Xo(t) {
    let { features: e, getVisitorKeys: r, embed: n, massageAstNode: u, print: o, ...i } = t;
    e = ni$1(e);
    let D = e.experimental_frontMatterSupport;
    r = tr$1(r, D.massageAstNode || D.embed || D.print);
    let s = u;
    u && D.massageAstNode && (s = new Proxy(u, { apply(l, m2, f) {
      return Zt$1(...f), Reflect.apply(l, m2, f);
    } }));
    let a = n;
    if (n) {
      let l;
      a = new Proxy(n, { get(m2, f, F2) {
        return f === "getVisitorKeys" ? (l ?? (l = n.getVisitorKeys ? tr$1(n.getVisitorKeys, D.massageAstNode || D.embed) : r), l) : Reflect.get(m2, f, F2);
      }, apply: (m2, f, F2) => D.embed && je$1(...F2) ? Qt$1 : Reflect.apply(m2, f, F2) });
    }
    let c = o;
    return D.print && (c = new Proxy(o, { apply(l, m2, f) {
      let [F2] = f;
      return pe$1(F2.node) ? er$1(F2) : Reflect.apply(l, m2, f);
    } })), { features: e, getVisitorKeys: r, embed: a, massageAstNode: s, print: c, ...i };
  }
  var Qo = /* @__PURE__ */ new WeakMap();
  function Zo(t) {
    return Fe$1(Qo, t, Xo);
  }
  var ei$1 = ["clean", "embed", "print"], ti$1 = Object.fromEntries(ei$1.map((t) => [t, false]));
  function ri$1(t) {
    return { ...ti$1, ...t };
  }
  function ni$1(t) {
    return { experimental_avoidAstMutation: false, ...t, experimental_frontMatterSupport: ri$1(t?.experimental_frontMatterSupport) };
  }
  var qn$1 = { astFormat: "estree", printer: {}, originalText: void 0, locStart: null, locEnd: null, getVisitorKeys: null };
  async function ui$1(t, e = {}) {
    let r = { ...t };
    if (!r.parser) {
      if (!r.filepath) throw new Me$1("No parser and no file path given, couldn't infer a parser.");
      if (r.parser = st$1(r, { physicalFile: r.filepath }), !r.parser) throw new Me$1(\`No parser could be inferred for file "\${r.filepath}".\`);
    }
    let n = it$1({ plugins: t.plugins, showDeprecated: true }).options, u = { ...qn$1, ...Object.fromEntries(n.filter((p2) => p2.default !== void 0).map((p2) => [p2.name, p2.default])) }, o = rr$1(r.plugins, r.parser), i = await nr$1(o, r.parser);
    r.astFormat = i.astFormat, r.locEnd = i.locEnd, r.locStart = i.locStart;
    let D = o.printers?.[i.astFormat] ? o : Hn$1(r.plugins, i.astFormat), s = await Jn$1(D, i.astFormat);
    r.printer = s, r.getVisitorKeys = s.getVisitorKeys;
    let a = D.defaultOptions ? Object.fromEntries(Object.entries(D.defaultOptions).filter(([, p2]) => p2 !== void 0)) : {}, c = { ...u, ...a };
    for (let [p2, l] of Object.entries(c)) r[p2] ?? (r[p2] = l);
    return r.parser === "json" && (r.trailingComma = "none"), $n$1(r, n, { passThrough: Object.keys(qn$1), ...e });
  }
  var se$1 = ui$1;
  var Xn$1 = /\\r\\n|[\\n\\r\\u2028\\u2029]/;
  function oi$1(t, e, r, n) {
    let u = { column: null, line: -1, ...t.start }, o = { ...u, ...t.end }, { linesAbove: i = 2, linesBelow: D = 3 } = r || {}, s = u.line - n, a = u.column, c = o.line - n, p2 = o.column, l = Math.max(s - (i + 1), 0), m2 = Math.min(e.length, c + D);
    s === -1 && (l = 0), c === -1 && (m2 = e.length);
    let f = c - s, F2 = {};
    if (f) for (let d = 0; d <= f; d++) {
      let E2 = d + s;
      if (a == null) F2[E2] = true;
      else if (d === 0) {
        let C2 = e[E2 - 1].length;
        F2[E2] = [a, C2 - a];
      } else if (d === f) F2[E2] = [0, p2];
      else {
        let C2 = e[E2 - 1].length;
        F2[E2] = [0, C2];
      }
    }
    else if (a === p2) a != null ? F2[s] = [a, 0] : F2[s] = true;
    else {
      let d = a ?? 0, E2 = p2 ?? d;
      F2[s] = [d, E2 - d];
    }
    return { start: l, end: m2, markerLines: F2 };
  }
  function Qn$1(t, e, r = {}, n) {
    let { defs: u, highlight: o } = { defs: { gutter: String, marker: String, message: String, reset: String }, highlight: String }, i = (r.startLine || 1) - 1, D = t.split(Xn$1), { start: s, end: a, markerLines: c } = oi$1(e, D, r, i), p2 = e.start && typeof e.start.column == "number", l = String(a + i).length, f = o(t).split(Xn$1, a).slice(s, a).map((F2, d) => {
      let E2 = s + 1 + d, h = \` \${\` \${E2 + i}\`.slice(-l)} |\`, _ = c[E2], P2 = !c[E2 + 1];
      if (_) {
        let A2 = "";
        if (Array.isArray(_)) {
          let B2 = F2.slice(0, _[0]).replace(/[^\\t]/g, " "), J2 = _[1] || 1;
          A2 = [\`
 \`, u.gutter(h.replace(/\\d/g, " ")), " ", B2, u.marker("^").repeat(J2)].join(""), P2 && r.message && (A2 += " " + u.message(r.message));
        }
        return [u.marker(">"), u.gutter(h), F2.length > 0 ? \` \${F2}\` : "", A2].join("");
      } else return \` \${u.gutter(h)}\${F2.length > 0 ? \` \${F2}\` : ""}\`;
    }).join(\`
\`);
    return r.message && !p2 && (f = \`\${" ".repeat(l + 1)}\${r.message}
\${f}\`), u.reset(f);
  }
  function Zn$1(t, e, r = {}) {
    return Qn$1(t, e, r);
  }
  async function ii$1(t, e) {
    let r = await Ue$1(e), n = r.preprocess ? await r.preprocess(t, e) : t;
    e.originalText = n;
    let u;
    try {
      u = await r.parse(n, e, e);
    } catch (o) {
      si$1(o, t);
    }
    return { text: n, ast: u };
  }
  function si$1(t, e) {
    let { loc: r } = t;
    if (r) {
      let { start: n, end: u } = r;
      n && (n = { line: n.line, column: n.column - 1 }), u && (u = { line: u.line, column: u.column - 1 });
      let o = Zn$1(e, { start: n, end: u }, {});
      t.message += \`
\` + o, t.codeFrame = o;
    }
    throw t;
  }
  var me$1 = ii$1;
  async function eu(t, e, r, n, u) {
    if (r.embeddedLanguageFormatting !== "auto") return;
    let { printer: o } = r, { embed: i } = o;
    if (!i) return;
    if (i.length > 2) throw new Error("printer.embed has too many parameters. The API changed in Prettier v3. Please update your plugin. See https://prettier.io/docs/plugins#optional-embed");
    let { hasPrettierIgnore: D } = o, { getVisitorKeys: s } = i, a = [];
    l();
    let c = t.stack;
    for (let { print: m2, node: f, pathStack: F2 } of a) try {
      t.stack = F2;
      let d = await m2(p2, e, t, r);
      d && u.set(f, d);
    } catch (d) {
      if (globalThis.PRETTIER_DEBUG) throw d;
    }
    t.stack = c;
    function p2(m2, f) {
      return Di$1(m2, f, r, n);
    }
    function l() {
      let { node: m2 } = t;
      if (m2 === null || typeof m2 != "object" || D?.(t)) return;
      for (let F2 of s(m2)) Array.isArray(m2[F2]) ? t.each(l, F2) : t.call(l, F2);
      let f = i(t, r);
      if (f) {
        if (typeof f == "function") {
          a.push({ print: f, node: m2, pathStack: [...t.stack] });
          return;
        }
        u.set(m2, f);
      }
    }
  }
  async function Di$1(t, e, r, n) {
    let u = await se$1({ ...r, ...e, parentParser: r.parser, originalText: t, cursorOffset: void 0, rangeStart: void 0, rangeEnd: void 0 }, { passThrough: true }), { ast: o } = await me$1(t, u), i = await n(o, u);
    return He$1(i);
  }
  function ai$1(t, e, r, n) {
    let { originalText: u, [ue$1]: o, locStart: i, locEnd: D, [/* @__PURE__ */ Symbol.for("printedComments")]: s } = e, { node: a } = t, c = i(a), p2 = D(a);
    for (let m2 of o) i(m2) >= c && D(m2) <= p2 && s.add(m2);
    let { printPrettierIgnored: l } = e.printer;
    return l ? l(t, e, r, n) : u.slice(c, p2);
  }
  var tu = ai$1;
  async function Ve$1(t, e) {
    ({ ast: t } = await ur$1(t, e));
    let r = /* @__PURE__ */ new Map(), n = new en$1(t), o = /* @__PURE__ */ new Map();
    await eu(n, D, e, Ve$1, o);
    let i = await ru(n, e, D, void 0, o);
    if (mn$1(e), e.cursorOffset >= 0) {
      if (e.nodeAfterCursor && !e.nodeBeforeCursor) return [ee$1, i];
      if (e.nodeBeforeCursor && !e.nodeAfterCursor) return [i, ee$1];
    }
    return i;
    function D(a, c) {
      return a === void 0 || a === n ? s(c) : Array.isArray(a) ? n.call(() => s(c), ...a) : n.call(() => s(c), a);
    }
    function s(a) {
      let c = n.node;
      if (c == null) return "";
      let p2 = ge$1(c) && a === void 0;
      if (p2 && r.has(c)) return r.get(c);
      let l = ru(n, e, D, a, o);
      return p2 && r.set(c, l), l;
    }
  }
  function ru(t, e, r, n, u) {
    let { node: o } = t, { printer: i } = e, D;
    switch (i.hasPrettierIgnore?.(t) ? D = tu(t, e, r, n) : u.has(o) ? D = u.get(o) : D = i.print(t, e, r, n), o) {
      case e.cursorNode:
        D = Ee$1(D, (s) => [ee$1, s, ee$1]);
        break;
      case e.nodeBeforeCursor:
        D = Ee$1(D, (s) => [s, ee$1]);
        break;
      case e.nodeAfterCursor:
        D = Ee$1(D, (s) => [ee$1, s]);
        break;
    }
    return i.printComment && rt$1(o.comments) && !i.willPrintOwnComments?.(t, e) && (D = pn$1(t, D, e)), D;
  }
  async function ur$1(t, e) {
    let r = t.comments ?? [];
    e[ue$1] = r, e[/* @__PURE__ */ Symbol.for("printedComments")] = /* @__PURE__ */ new Set(), an$1(t, e);
    let { printer: { preprocess: n } } = e;
    return t = n ? await n(t, e) : t, { ast: t, comments: r };
  }
  function ci$1(t, e) {
    let { cursorOffset: r, locStart: n, locEnd: u, getVisitorKeys: o } = e, i = (m2) => n(m2) <= r && u(m2) >= r, D = t, s = [t];
    for (let m2 of nn$1(t, { getVisitorKeys: o, filter: i })) s.push(m2), D = m2;
    if (un$1(D, { getVisitorKeys: o })) return { cursorNode: D };
    let a, c, p2 = -1, l = Number.POSITIVE_INFINITY;
    for (; s.length > 0 && (a === void 0 || c === void 0); ) {
      D = s.pop();
      let m2 = a !== void 0, f = c !== void 0;
      for (let F2 of ye$1(D, { getVisitorKeys: o })) {
        if (!m2) {
          let d = u(F2);
          d <= r && d > p2 && (a = F2, p2 = d);
        }
        if (!f) {
          let d = n(F2);
          d >= r && d < l && (c = F2, l = d);
        }
      }
    }
    return { nodeBeforeCursor: a, nodeAfterCursor: c };
  }
  var or$1 = ci$1;
  function fi$1(t, e) {
    let { printer: r } = e, n = r.massageAstNode;
    if (!n) return t;
    let { getVisitorKeys: u } = r, { ignoredProperties: o } = n;
    return i(t);
    function i(D, s) {
      if (!ge$1(D)) return D;
      if (Array.isArray(D)) return D.map((l) => i(l, s)).filter(Boolean);
      let a = {}, c = new Set(u(D));
      for (let l in D) !le$1(D, l) || o?.has(l) || (c.has(l) ? a[l] = i(D[l], D) : a[l] = D[l]);
      let p2 = n(D, a, s);
      if (p2 !== null) return p2 ?? a;
    }
  }
  var nu = fi$1;
  var li$1 = Array.prototype.findLastIndex ?? function(t) {
    for (let e = this.length - 1; e >= 0; e--) {
      let r = this[e];
      if (t(r, e, this)) return e;
    }
    return -1;
  }, pi$1 = X$1("findLastIndex", function() {
    if (Array.isArray(this)) return li$1;
  }), uu = pi$1;
  function mi$1(t, e) {
    return e = new Set(e), t.find((r) => su.has(r.type) && e.has(r));
  }
  function ou(t) {
    let e = uu(0, t, (r) => r.type !== "Program" && r.type !== "File");
    return e === -1 ? t : t.slice(0, e + 1);
  }
  function di$1(t, e, { locStart: r, locEnd: n }) {
    let [u, ...o] = t, [i, ...D] = e;
    if (u === i) return [u, i];
    let s = r(u);
    for (let c of ou(D)) if (r(c) >= s) i = c;
    else break;
    let a = n(i);
    for (let c of ou(o)) {
      if (n(c) <= a) u = c;
      else break;
      if (u === i) break;
    }
    return [u, i];
  }
  function ir$1(t, e, r, n, u = [], o, i) {
    let { locStart: D, locEnd: s } = i, a = D(t), c = s(t);
    if (e > c || e < a || o === "rangeEnd" && e === a || o === "rangeStart" && e === c) return;
    let p2 = [t, ...u], l = ot$1(t, p2, { cache: Ut, locStart: D, locEnd: s, getVisitorKeys: r.getVisitorKeys, filter: r.printer.canAttachComment, getChildren: r.printer.getCommentChildNodes });
    for (let m2 of l) {
      let f = ir$1(m2, e, r, n, p2, o, i);
      if (f) return f;
    }
    if (n(t, u[0])) return p2;
  }
  function Fi$1(t, e) {
    return e !== "DeclareExportDeclaration" && t !== "TypeParameterDeclaration" && (t === "Directive" || t === "TypeAlias" || t === "TSExportAssignment" || t.startsWith("Declare") || t.startsWith("TSDeclare") || t.endsWith("Statement") || t.endsWith("Declaration"));
  }
  var su = /* @__PURE__ */ new Set(["JsonRoot", "ObjectExpression", "ArrayExpression", "StringLiteral", "NumericLiteral", "BooleanLiteral", "NullLiteral", "UnaryExpression", "TemplateLiteral"]), Ei$1 = /* @__PURE__ */ new Set(["OperationDefinition", "FragmentDefinition", "VariableDefinition", "TypeExtensionDefinition", "ObjectTypeDefinition", "FieldDefinition", "DirectiveDefinition", "EnumTypeDefinition", "EnumValueDefinition", "InputValueDefinition", "InputObjectTypeDefinition", "SchemaDefinition", "OperationTypeDefinition", "InterfaceTypeDefinition", "UnionTypeDefinition", "ScalarTypeDefinition"]);
  function iu(t, e, r) {
    if (!e) return false;
    switch (t.parser) {
      case "flow":
      case "hermes":
      case "babel":
      case "babel-flow":
      case "babel-ts":
      case "typescript":
      case "acorn":
      case "espree":
      case "meriyah":
      case "oxc":
      case "oxc-ts":
      case "yuku":
      case "yuku-ts":
      case "__babel_estree":
        return Fi$1(e.type, r?.type);
      case "json":
      case "json5":
      case "jsonc":
      case "json-stringify":
        return su.has(e.type);
      case "graphql":
        return Ei$1.has(e.kind);
      case "vue":
        return e.tag !== "root";
    }
    return false;
  }
  function Du(t, e, r) {
    let { rangeStart: n, rangeEnd: u } = e;
    let o = t.slice(n, u).search(/\\S/), i = o === -1;
    if (!i) for (n += o; u > n && !/\\S/.test(t[u - 1]); --u) ;
    let D = e.printer.features?.experimental_locForRangeFormat ?? e, s = ir$1(r, n, e, (f, F2) => iu(e, f, F2), [], "rangeStart", D);
    if (!s) return;
    let a = i ? s : ir$1(r, u, e, (f) => iu(e, f), [], "rangeEnd", D);
    if (!a) return;
    let c, p2;
    if (r.type === "JsonRoot") {
      let f = mi$1(s, a);
      c = f, p2 = f;
    } else [c, p2] = di$1(s, a, e);
    let { locStart: l, locEnd: m2 } = D;
    return [Math.min(l(c), l(p2)), Math.max(m2(c), m2(p2))];
  }
  var lu = "\\uFEFF", au = /* @__PURE__ */ Symbol("cursor");
  async function pu(t, e, r = 0) {
    if (!t || t.trim().length === 0) return { formatted: "", cursorOffset: -1, comments: [] };
    let { ast: n, text: u } = await me$1(t, e);
    e.cursorOffset >= 0 && (e = { ...e, ...or$1(n, e) });
    let o = await Ve$1(n, e);
    r > 0 && (o = Qe$1([W, o], r, e.tabWidth));
    let i = Ce(o, e);
    if (r > 0) {
      let s = i.formatted.trim();
      i.cursorNodeStart !== void 0 && (i.cursorNodeStart -= i.formatted.indexOf(s), i.cursorNodeStart < 0 && (i.cursorNodeStart = 0, i.cursorNodeText = i.cursorNodeText.trimStart()), i.cursorNodeStart + i.cursorNodeText.length > s.length && (i.cursorNodeText = i.cursorNodeText.trimEnd())), i.formatted = s + we$1(e.endOfLine);
    }
    let D = e[ue$1];
    if (e.cursorOffset >= 0) {
      let s, a, c, p2;
      if ((e.cursorNode || e.nodeBeforeCursor || e.nodeAfterCursor) && i.cursorNodeText) if (c = i.cursorNodeStart, p2 = i.cursorNodeText, e.cursorNode) s = e.locStart(e.cursorNode), a = u.slice(s, e.locEnd(e.cursorNode));
      else {
        if (!e.nodeBeforeCursor && !e.nodeAfterCursor) throw new Error("Cursor location must contain at least one of cursorNode, nodeBeforeCursor, nodeAfterCursor");
        s = e.nodeBeforeCursor ? e.locEnd(e.nodeBeforeCursor) : 0;
        let E2 = e.nodeAfterCursor ? e.locStart(e.nodeAfterCursor) : u.length;
        a = u.slice(s, E2);
      }
      else s = 0, a = u, c = 0, p2 = i.formatted;
      let l = e.cursorOffset - s;
      if (a === p2) return { formatted: i.formatted, cursorOffset: c + l, comments: D };
      let m2 = a.split("");
      m2.splice(l, 0, au);
      let f = p2.split(""), F2 = xt$1(m2, f), d = c;
      for (let E2 of F2) if (E2.removed) {
        if (E2.value.includes(au)) break;
      } else d += E2.count;
      return { formatted: i.formatted, cursorOffset: d, comments: D };
    }
    return { formatted: i.formatted, cursorOffset: -1, comments: D };
  }
  async function Ci$1(t, e) {
    let { ast: r, text: n } = await me$1(t, e), [u, o] = Du(n, e, r) ?? [0, 0], i = n.slice(u, o), D = Math.min(u, n.lastIndexOf(\`
\`, u) + 1), s = n.slice(D, u).match(/^\\s*/)[0], a = he$1(s, e.tabWidth), c = await pu(i, { ...e, rangeStart: 0, rangeEnd: Number.POSITIVE_INFINITY, cursorOffset: e.cursorOffset > u && e.cursorOffset <= o ? e.cursorOffset - u : -1, endOfLine: "lf" }, a), p2 = c.formatted.trimEnd(), { cursorOffset: l } = e;
    l > o ? l += p2.length - i.length : c.cursorOffset >= 0 && (l = c.cursorOffset + u);
    let m2 = n.slice(0, u) + p2 + n.slice(o);
    if (e.endOfLine !== "lf") {
      let f = we$1(e.endOfLine);
      l >= 0 && f === \`\\r
\` && (l += Tt$1(m2.slice(0, l), \`
\`)), m2 = ne$1(0, m2, \`
\`, f);
    }
    return { formatted: m2, cursorOffset: l, comments: c.comments };
  }
  function sr$1(t, e, r) {
    return typeof e != "number" || Number.isNaN(e) || e < 0 || e > t.length ? r : e;
  }
  function cu(t, e) {
    let { cursorOffset: r, rangeStart: n, rangeEnd: u } = e;
    return r = sr$1(t, r, -1), n = sr$1(t, n, 0), u = sr$1(t, u, t.length), { ...e, cursorOffset: r, rangeStart: n, rangeEnd: u };
  }
  function mu(t, e) {
    let { cursorOffset: r, rangeStart: n, rangeEnd: u, endOfLine: o } = cu(t, e), i = t.charAt(0) === lu;
    if (i && (t = t.slice(1), r--, n--, u--), o === "auto" && (o = Cr$1(t)), t.includes("\\r")) {
      let D = (s) => Tt$1(t.slice(0, Math.max(s, 0)), \`\\r
\`);
      r -= D(r), n -= D(n), u -= D(u), t = hr$1(t);
    }
    return { hasBOM: i, text: t, options: cu(t, { ...e, cursorOffset: r, rangeStart: n, rangeEnd: u, endOfLine: o }) };
  }
  async function fu(t, e) {
    let r = await Ue$1(e);
    return !r.hasPragma || r.hasPragma(t);
  }
  async function hi$1(t, e) {
    return (await Ue$1(e)).hasIgnorePragma?.(t);
  }
  async function Dr$1(t, e) {
    let { hasBOM: r, text: n, options: u } = mu(t, await se$1(e));
    if (u.rangeStart >= u.rangeEnd && n !== "" || u.requirePragma && !await fu(n, u) || u.checkIgnorePragma && await hi$1(n, u)) return { formatted: t, cursorOffset: e.cursorOffset, comments: [] };
    let o;
    return u.rangeStart > 0 || u.rangeEnd < n.length ? o = await Ci$1(n, u) : (!u.requirePragma && u.insertPragma && u.printer.insertPragma && !await fu(n, u) && (n = u.printer.insertPragma(n)), o = await pu(n, u)), r && (o.formatted = lu + o.formatted, o.cursorOffset >= 0 && o.cursorOffset++), o;
  }
  async function du(t, e, r) {
    let { text: n, options: u } = mu(t, await se$1(e)), o = await me$1(n, u);
    return r && (r.preprocessForPrint && (o.ast = await ur$1(o.ast, u)), r.massage && (o.ast = nu(o.ast, u))), o;
  }
  async function Fu(t, e) {
    e = await se$1(e);
    let r = await Ve$1(t, e);
    return Ce(r, e);
  }
  async function Eu(t, e) {
    let r = Ur$1(t), { formatted: n } = await Dr$1(r, { ...e, parser: "__js_expression" });
    return n;
  }
  async function Cu(t, e) {
    e = await se$1(e);
    let { ast: r } = await me$1(t, e);
    return e.cursorOffset >= 0 && (e = { ...e, ...or$1(r, e) }), Ve$1(r, e);
  }
  async function hu(t, e) {
    return Ce(t, await se$1(e));
  }
  var ar$1 = {};
  yt$1(ar$1, { builders: () => _i$1, printer: () => yi$1, utils: () => Ai$1 });
  var _i$1 = { join: be$1, line: Ze$1, softline: Mr$1, hardline: W, literalline: Je$1, group: wt$1, conditionalGroup: Ir$1, fill: kr$1, lineSuffix: Ie$1, lineSuffixBoundary: Yr$1, cursor: ee$1, breakParent: ae$1, ifBreak: Rr$1, trim: jr$1, indent: oe$1, indentIfBreak: vr, align: De$1, addAlignmentToDoc: Qe$1, markAsRoot: Xe$1, dedentToRoot: Sr, dedent: br$1, hardlineWithoutBreakParent: ke$1, literallineWithoutBreakParent: Ot$1, label: Lr$1, concat: (t) => t }, yi$1 = { printDocToString: Ce }, Ai$1 = { willBreak: xr$1, traverseDoc: Oe$1, findInDoc: Ke$1, mapDoc: Se$1, removeLines: Tr$1, stripTrailingHardline: He$1, replaceEndOfLine: Nr$1, canBreak: wr$1 };
  var gu = "3.9.6";
  var fr$1 = {};
  yt$1(fr$1, { addDanglingComment: () => re$1, addLeadingComment: () => ce$1, addTrailingComment: () => fe$1, getAlignmentSize: () => he$1, getIndentSize: () => _u, getMaxContinuousCount: () => yu, getNextNonSpaceNonCommentCharacter: () => Au, getNextNonSpaceNonCommentCharacterIndex: () => vi$1, getPreferredQuote: () => Tu, getStringWidth: () => Re$1, hasNewline: () => H$1, hasNewlineInRange: () => Nu, hasSpaces: () => wu, isNextLineEmpty: () => Ui$1, isNextLineEmptyAfterIndex: () => gt$1, isPreviousLineEmpty: () => Mi, makeString: () => ji$1, skip: () => _e$1, skipEverythingButNewLine: () => ut$1, skipInlineComment: () => Be, skipNewline: () => $$2, skipSpaces: () => j$1, skipToLineEnd: () => nt$1, skipTrailingComment: () => Te$1, skipWhitespace: () => tn$1 });
  function xi$1(t, e) {
    if (e === false) return false;
    if (t.charAt(e) === "/" && t.charAt(e + 1) === "*") {
      for (let r = e + 2; r < t.length; ++r) if (t.charAt(r) === "*" && t.charAt(r + 1) === "/") return r + 2;
    }
    return e;
  }
  var Be = xi$1;
  function Bi$1(t, e) {
    return e === false ? false : t.charAt(e) === "/" && t.charAt(e + 1) === "/" ? ut$1(t, e) : e;
  }
  var Te$1 = Bi$1;
  function Ti$1(t, e) {
    let r = null, n = e;
    for (; n !== r; ) r = n, n = j$1(t, n), n = Be(t, n), n = Te$1(t, n), n = $$2(t, n);
    return n;
  }
  var We$1 = Ti$1;
  function Ni$1(t, e) {
    let r = null, n = e;
    for (; n !== r; ) r = n, n = nt$1(t, n), n = Be(t, n), n = j$1(t, n);
    return n = Te$1(t, n), n = $$2(t, n), n !== false && H$1(t, n);
  }
  var gt$1 = Ni$1;
  function wi$1(t, e) {
    let r = t.lastIndexOf(\`
\`);
    return r === -1 ? 0 : he$1(t.slice(r + 1).match(/^[\\t ]*/)[0], e);
  }
  var _u = wi$1;
  function cr$1(t) {
    if (typeof t != "string") throw new TypeError("Expected a string");
    return t.replace(/[|\\\\{}()[\\]^$+*?.]/g, "\\\\$&").replace(/-/g, "\\\\x2d");
  }
  function Oi$1(t, e) {
    let r = t.matchAll(new RegExp(\`(?:\${cr$1(e)})+\`, "g"));
    return r.reduce || (r = [...r]), r.reduce((n, [u]) => Math.max(n, u.length), 0) / e.length;
  }
  var yu = Oi$1;
  function Pi$1(t, e) {
    let r = We$1(t, e);
    return r === false ? "" : t.charAt(r);
  }
  var Au = Pi$1;
  var xu = Object.freeze({ character: "'", codePoint: 39 }), Bu = Object.freeze({ character: '"', codePoint: 34 }), Si$1 = Object.freeze({ preferred: xu, alternate: Bu }), bi$1 = Object.freeze({ preferred: Bu, alternate: xu });
  function Tu(t, e) {
    let { preferred: r, alternate: n } = e === true || e === "'" ? Si$1 : bi$1, { length: u } = t, o = 0, i = 0;
    for (let D = 0; D < u; D++) {
      let s = t.charCodeAt(D);
      s === r.codePoint ? o++ : s === n.codePoint && i++;
    }
    return (o > i ? n : r).character;
  }
  function ki$1(t, e, r) {
    for (let n = e; n < r; ++n) if (t.charAt(n) === \`
\`) return true;
    return false;
  }
  var Nu = ki$1;
  function Ii$1(t, e, r = {}) {
    return j$1(t, r.backwards ? e - 1 : e, r) !== e;
  }
  var wu = Ii$1;
  function Ri$1(t, e, r) {
    return We$1(t, r(e));
  }
  function vi$1(t, e) {
    return arguments.length === 2 || typeof e == "number" ? We$1(t, e) : Ri$1(...arguments);
  }
  function Li$1(t, e, r) {
    return ve$1(t, r(e));
  }
  function Mi(t, e) {
    return arguments.length === 2 || typeof e == "number" ? ve$1(t, e) : Li$1(...arguments);
  }
  function Yi$1(t, e, r) {
    return gt$1(t, r(e));
  }
  function ji$1(t, e, r) {
    let n = e === '"' ? "'" : '"', o = ne$1(0, t, /\\\\(.)|(["'])/gs, (i, D, s) => D === n ? D : s === e ? "\\\\" + s : s || (r && /^[^\\n\\r"'0-7\\\\bfnrt-vx\\u2028\\u2029]$/.test(D) ? D : "\\\\" + D));
    return e + o + e;
  }
  function Ui$1(t, e) {
    return arguments.length === 2 || typeof e == "number" ? gt$1(t, e) : Yi$1(...arguments);
  }
  function de$1(t, e = 1) {
    return async (...r) => {
      let n = r[e] ?? {}, u = n.plugins ?? [];
      return r[e] = { ...n, plugins: Array.isArray(u) ? u : Object.values(u) }, await t(...r);
    };
  }
  var Ou = de$1(Dr$1);
  async function Pu(t, e) {
    let { formatted: r } = await Ou(t, { ...e, cursorOffset: -1 });
    return r;
  }
  async function Vi$1(t, e) {
    return await Pu(t, e) === t;
  }
  var Wi$1 = de$1(it$1, 0), $i$1 = { parse: de$1(du), formatAST: de$1(Fu), formatDoc: de$1(Eu), printToDoc: de$1(Cu), printDocToString: de$1(hu) };
  var Nr = Object.defineProperty;
  var Dr = (e) => {
    throw TypeError(e);
  };
  var es = (e, t, r) => t in e ? Nr(e, t, { enumerable: true, configurable: true, writable: true, value: r }) : e[t] = r;
  var Ir = (e, t) => {
    for (var r in t) Nr(e, r, { get: t[r], enumerable: true });
  };
  var Wt = (e, t, r) => es(e, typeof t != "symbol" ? t + "" : t, r), ts = (e, t, r) => t.has(e) || Dr("Cannot " + r);
  var qe = (e, t, r) => (ts(e, t, "read from private field"), r ? r.call(e) : t.get(e)), Rr = (e, t, r) => t.has(e) ? Dr("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r);
  var Zi = {};
  Ir(Zi, { languages: () => Ui, options: () => zi, parsers: () => Pr, printers: () => $o });
  var ke = (e, t) => (r, n, ...i) => r | 1 && n == null ? void 0 : (t.call(n) ?? n[e]).apply(n, i);
  var rs = String.prototype.replaceAll ?? function(e, t) {
    return e.global ? this.replace(e, t) : this.split(e).join(t);
  }, ns = ke("replaceAll", function() {
    if (typeof this == "string") return rs;
  }), T = ns;
  function is(e) {
    return this[e < 0 ? this.length + e : e];
  }
  var ss = ke("at", function() {
    if (Array.isArray(this) || typeof this == "string") return is;
  }), I = ss;
  var as = () => {
  }, He = as;
  var Fe = "string", Ve = "array", ot = "cursor", be = "indent", we = "align", lt = "trim", Te = "group", ye = "fill", Ee = "if-break", xe = "indent-if-break", ct = "line-suffix", ut = "line-suffix-boundary", z = "line", pt = "label", Le = "break-parent", ht = /* @__PURE__ */ new Set([ot, be, we, lt, Te, ye, Ee, xe, ct, ut, z, pt, Le]);
  function mt(e, t, r) {
    if (!e.has(t)) {
      let n = r(t);
      e.set(t, n);
    }
    return e.get(t);
  }
  function os(e) {
    if (typeof e == "string") return Fe;
    if (Array.isArray(e)) return Ve;
    if (!e) return;
    let { type: t } = e;
    if (ht.has(t)) return t;
  }
  var ft = os;
  var ls = (e) => new Intl.ListFormat("en-US", { type: "disjunction" }).format(e);
  function cs(e) {
    let t = e === null ? "null" : typeof e;
    if (t !== "string" && t !== "object") return \`Unexpected doc '\${t}', 
Expected it to be 'string' or 'object'.\`;
    if (ft(e)) throw new Error("doc is valid.");
    let r = Object.prototype.toString.call(e);
    if (r !== "[object Object]") return \`Unexpected doc '\${r}'.\`;
    let n = ls([...ht].map((i) => \`'\${i}'\`));
    return \`Unexpected doc.type '\${e.type}'.
Expected it to be \${n}.\`;
  }
  var zt = class extends Error {
    name = "InvalidDocError";
    constructor(t) {
      super(cs(t)), this.doc = t;
    }
  }, Or = zt;
  function Gt(e, t) {
    if (typeof e == "string") return t(e);
    let r = /* @__PURE__ */ new Map();
    return n(e);
    function n(s) {
      return mt(r, s, i);
    }
    function i(s) {
      switch (ft(s)) {
        case Ve:
          return t(s.map(n));
        case ye:
          return t({ ...s, parts: s.parts.map(n) });
        case Ee:
          return t({ ...s, breakContents: n(s.breakContents), flatContents: n(s.flatContents) });
        case Te: {
          let { expandedStates: a, contents: o } = s;
          return a ? (a = a.map(n), o = a[0]) : o = n(o), t({ ...s, contents: o, expandedStates: a });
        }
        case we:
        case be:
        case xe:
        case pt:
        case ct:
          return t({ ...s, contents: n(s.contents) });
        case Fe:
        case ot:
        case lt:
        case ut:
        case z:
        case Le:
          return t(s);
        default:
          throw new Or(s);
      }
    }
  }
  function L(e, t = Mr) {
    return Gt(e, (r) => typeof r == "string" ? R(t, r.split(\`
\`)) : r);
  }
  var dt = He;
  function A(e) {
    return { type: be, contents: e };
  }
  function us(e, t) {
    return { type: we, contents: t, n: e };
  }
  function Hr(e) {
    return us(Number.NEGATIVE_INFINITY, e);
  }
  var G = { type: Le };
  function gt(e) {
    return { type: ye, parts: e };
  }
  function C(e, t = {}) {
    return dt(t.expandedStates), { type: Te, id: t.id, contents: e, break: !!t.shouldBreak, expandedStates: t.expandedStates };
  }
  function $$1(e, t = "", r = {}) {
    return { type: Ee, breakContents: e, flatContents: t, groupId: r.groupId };
  }
  function Fr(e, t) {
    return { type: xe, contents: e, groupId: t.groupId, negate: t.negate };
  }
  function R(e, t) {
    let r = [];
    for (let n = 0; n < t.length; n++) n !== 0 && r.push(e), r.push(t[n]);
    return r;
  }
  var S = { type: z }, y = { type: z, soft: true }, ps = { type: z, hard: true }, k = [ps, G], hs = { type: z, hard: true, literal: true }, Mr = [hs, G];
  var Vr = Object.freeze({ character: "'", codePoint: 39 }), Ur = Object.freeze({ character: '"', codePoint: 34 }), fs = Object.freeze({ preferred: Ur, alternate: Vr });
  function Wr(e, t) {
    let { preferred: r, alternate: n } = fs, { length: i } = e, s = 0, a = 0;
    for (let o = 0; o < i; o++) {
      let l = e.charCodeAt(o);
      l === r.codePoint ? s++ : l === n.codePoint && a++;
    }
    return (s > a ? n : r).character;
  }
  function $t(e) {
    if (typeof e != "string") throw new TypeError("Expected a string");
    return e.replace(/[|\\\\{}()[\\]^$+*?.]/g, "\\\\$&").replace(/-/g, "\\\\x2d");
  }
  var jt = class {
    #e;
    constructor(t) {
      this.#e = new Set(t);
    }
    getLeadingWhitespaceCount(t) {
      let r = this.#e, n = 0;
      for (let i = 0; i < t.length && r.has(t.charAt(i)); i++) n++;
      return n;
    }
    getTrailingWhitespaceCount(t) {
      let r = this.#e, n = 0;
      for (let i = t.length - 1; i >= 0 && r.has(t.charAt(i)); i--) n++;
      return n;
    }
    getLeadingWhitespace(t) {
      let r = this.getLeadingWhitespaceCount(t);
      return t.slice(0, r);
    }
    getTrailingWhitespace(t) {
      let r = this.getTrailingWhitespaceCount(t);
      return t.slice(t.length - r);
    }
    hasLeadingWhitespace(t) {
      return this.#e.has(t.charAt(0));
    }
    hasTrailingWhitespace(t) {
      return this.#e.has(I(0, t, -1));
    }
    trimStart(t) {
      let r = this.getLeadingWhitespaceCount(t);
      return t.slice(r);
    }
    trimEnd(t) {
      let r = this.getTrailingWhitespaceCount(t);
      return t.slice(0, t.length - r);
    }
    trim(t) {
      return this.trimEnd(this.trimStart(t));
    }
    split(t, r = false) {
      let n = \`[\${$t([...this.#e].join(""))}]+\`, i = new RegExp(r ? \`(\${n})\` : n);
      return t.split(i);
    }
    hasWhitespaceCharacter(t) {
      let r = this.#e;
      return Array.prototype.some.call(t, (n) => r.has(n));
    }
    hasNonWhitespaceCharacter(t) {
      let r = this.#e;
      return Array.prototype.some.call(t, (n) => !r.has(n));
    }
    isWhitespaceOnly(t) {
      let r = this.#e;
      return Array.prototype.every.call(t, (n) => r.has(n));
    }
    #t(t) {
      let r = Number.POSITIVE_INFINITY;
      for (let n of t.split(\`
\`)) {
        if (n.length === 0) continue;
        let i = this.getLeadingWhitespaceCount(n);
        if (i === 0) return 0;
        n.length !== i && i < r && (r = i);
      }
      return r === Number.POSITIVE_INFINITY ? 0 : r;
    }
    dedentString(t) {
      let r = this.#t(t);
      return r === 0 ? t : t.split(\`
\`).map((n) => n.slice(r)).join(\`
\`);
    }
  }, zr = jt;
  var ds = ["	", \`
\`, "\\f", "\\r", " "], gs = new zr(ds), P = gs;
  var Yt = class extends Error {
    name = "UnexpectedNodeError";
    constructor(t, r, n = "type") {
      super(\`Unexpected \${r} node \${n}: \${JSON.stringify(t[n])}.\`), this.node = t;
    }
  }, Gr = Yt;
  function j(e, t = true) {
    return [A([y, e]), t ? y : ""];
  }
  function q(e, t) {
    let r = e.type === "NGRoot" ? e.node.type === "NGMicrosyntax" && e.node.body.length === 1 && e.node.body[0].type === "NGMicrosyntaxExpression" ? e.node.body[0].expression : e.node : e.type === "JsExpressionRoot" ? e.node : e;
    return r && (r.type === "ObjectExpression" || r.type === "ArrayExpression" || (t.parser === "__vue_expression" || t.parser === "__vue_ts_expression" || t.parser === "__ng_binding" || t.parser === "__ng_directive") && (r.type === "TemplateLiteral" || r.type === "StringLiteral"));
  }
  async function E(e, t, r, n) {
    r = { __isInHtmlAttribute: true, __embeddedInHtml: true, ...r };
    let i = true;
    n && (r.__onHtmlBindingRoot = (a, o) => {
      i = n(a, o);
    });
    let s = await t(e, r, t);
    return i ? C(s) : j(s);
  }
  function _s(e, t, r, n) {
    let { node: i } = r, s = n.originalText.slice(i.sourceSpan.start.offset, i.sourceSpan.end.offset);
    return /^\\s*$/.test(s) ? "" : E(s, e, { parser: "__ng_directive", __isInHtmlAttribute: false }, q);
  }
  var $r = _s;
  var Ss = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), se = Ss;
  var vs = Array.prototype.toReversed ?? function() {
    return [...this].reverse();
  }, Cs = ke("toReversed", function() {
    if (Array.isArray(this)) return vs;
  }), jr = Cs;
  function ks() {
    let e = globalThis, t = e.process?.platform;
    if (typeof t == "string") return t.startsWith("win");
    let r = e.Deno?.build?.os;
    return typeof r == "string" ? r === "windows" : e.navigator?.platform?.startsWith("Win") ?? false;
  }
  var bs = ks();
  function Yr(e) {
    if (e = e instanceof URL ? e : new URL(e), e.protocol !== "file:") throw new TypeError(\`URL must be a file URL: received "\${e.protocol}"\`);
    return e;
  }
  function ws(e) {
    return e = Yr(e), decodeURIComponent(e.pathname.replace(/%(?![0-9A-Fa-f]{2})/g, "%25"));
  }
  function Ts(e) {
    e = Yr(e);
    let t = decodeURIComponent(e.pathname.replace(/\\//g, "\\\\").replace(/%(?![0-9A-Fa-f]{2})/g, "%25")).replace(/^\\\\*([A-Za-z]:)(\\\\|$)/, "$1\\\\");
    return e.hostname !== "" && (t = \`\\\\\\\\\${e.hostname}\${t}\`), t;
  }
  function Kt(e) {
    return bs ? Ts(e) : ws(e);
  }
  var Kr = (e) => String(e).split(/[/\\\\]/).pop(), Qr = (e) => String(e).startsWith("file:");
  function ys(e) {
    return Array.isArray(e) && e.length > 0;
  }
  var X = ys;
  function Xr(e, t) {
    if (!t) return;
    let r = Kr(t).toLowerCase();
    return e.find(({ filenames: n }) => n?.some((i) => i.toLowerCase() === r)) ?? e.find(({ extensions: n }) => n?.some((i) => r.endsWith(i)));
  }
  function Es(e, t) {
    if (t) return e.find(({ name: r }) => r.toLowerCase() === t) ?? e.find(({ aliases: r }) => r?.includes(t)) ?? e.find(({ extensions: r }) => r?.includes(\`.\${t}\`));
  }
  var xs = void 0;
  function Jr(e, t) {
    if (t) {
      if (Qr(t)) try {
        t = Kt(t);
      } catch {
        return;
      }
      if (typeof t == "string") return e.find(({ isSupported: r }) => r?.({ filepath: t }));
    }
  }
  function Ls(e, t) {
    let r = jr(0, e.plugins).flatMap((i) => i.languages ?? []);
    return (Es(r, t.language) ?? Xr(r, t.physicalFile) ?? Xr(r, t.file) ?? Jr(r, t.physicalFile) ?? Jr(r, t.file) ?? xs?.(r, t.physicalFile))?.parsers[0];
  }
  var _t = Ls;
  var St = /* @__PURE__ */ Symbol.for("PRETTIER_IS_FRONT_MATTER");
  function As(e) {
    return !!e?.[St];
  }
  var ae = As;
  function Ps(e) {
    return T(0, e, /[^\\n]/g, " ");
  }
  var vt = Ps;
  var Ue = 3;
  function Ns(e) {
    let t = e.slice(0, Ue);
    if (t !== "---" && t !== "+++") return;
    let r = e.indexOf(\`
\`, Ue);
    if (r === -1) return;
    let n = e.slice(Ue, r).trim(), i = e.indexOf(\`
\${t}\`, r), s = n;
    if (s || (s = t === "+++" ? "toml" : "yaml"), i === -1 && t === "---" && s === "yaml" && (i = e.indexOf(\`
...\`, r)), i === -1) return;
    let a = i + 1 + Ue, o = e.charAt(a + 1);
    if (!/\\s?/.test(o)) return;
    let l = e.slice(0, a), c;
    return { language: s, explicitLanguage: n || null, value: e.slice(r + 1, i), startDelimiter: t, endDelimiter: l.slice(-Ue), raw: l, start: { line: 1, column: 0, index: 0 }, end: { index: l.length, get line() {
      return c ?? (c = l.split(\`
\`)), c.length;
    }, get column() {
      return c ?? (c = l.split(\`
\`)), I(0, c, -1).length;
    } }, [St]: true };
  }
  function Ds(e) {
    let t = Ns(e);
    return t ? { frontMatter: t, get content() {
      let { raw: r } = t;
      return vt(r) + e.slice(r.length);
    } } : { content: e };
  }
  var Qt = Ds;
  var Zr = "inline", Xt = { area: "none", base: "none", basefont: "none", datalist: "none", head: "none", link: "none", meta: "none", noembed: "none", noframes: "none", param: "block", rp: "none", script: "block", style: "none", template: "inline", title: "none", html: "block", body: "block", address: "block", blockquote: "block", center: "block", dialog: "block", div: "block", figure: "block", figcaption: "block", footer: "block", form: "block", header: "block", hr: "block", legend: "block", listing: "block", main: "block", p: "block", plaintext: "block", pre: "block", search: "block", xmp: "block", slot: "contents", ruby: "ruby", rt: "ruby-text", article: "block", aside: "block", h1: "block", h2: "block", h3: "block", h4: "block", h5: "block", h6: "block", hgroup: "block", nav: "block", section: "block", dir: "block", dd: "block", dl: "block", dt: "block", menu: "block", ol: "block", ul: "block", li: "list-item", table: "table", caption: "table-caption", colgroup: "table-column-group", col: "table-column", thead: "table-header-group", tbody: "table-row-group", tfoot: "table-footer-group", tr: "table-row", td: "table-cell", th: "table-cell", input: "inline-block", button: "inline-block", fieldset: "block", details: "block", summary: "block", marquee: "inline-block", option: "block", optgroup: "block", select: "inline-block", source: "block", track: "block", meter: "inline-block", progress: "inline-block", object: "inline-block", video: "inline-block", audio: "inline-block" }, en = "normal", Jt = { listing: "pre", plaintext: "pre", pre: "pre", xmp: "pre", nobr: "nowrap", table: "initial", textarea: "pre-wrap" };
  function Is(e) {
    return e.kind === "element" && !e.hasExplicitNamespace && !["html", "svg"].includes(e.namespace);
  }
  var oe = Is;
  var Rs = (e) => T(0, e, /^[\\t\\f\\r ]*\\n/g, ""), Zt = (e) => Rs(P.trimEnd(e)), tn = (e) => {
    let t = e, r = P.getLeadingWhitespace(t);
    r && (t = t.slice(r.length));
    let n = P.getTrailingWhitespace(t);
    return n && (t = t.slice(0, -n.length)), { leadingWhitespace: r, trailingWhitespace: n, text: t };
  };
  function Ct(e, t) {
    return !!(e.kind === "ieConditionalComment" && e.lastChild && !e.lastChild.isSelfClosing && !e.lastChild.endSourceSpan || e.kind === "ieConditionalComment" && !e.complete || Y(e) && e.children.some((r) => r.kind !== "text" && r.kind !== "interpolation") || wt(e, t) && !O(e, t) && e.kind !== "interpolation");
  }
  function le(e) {
    return e.kind === "attribute" || !e.parent || !e.prev ? false : Os(e.prev);
  }
  function Os(e) {
    return e.kind === "comment" && e.value.trim() === "prettier-ignore";
  }
  function N(e) {
    return e.kind === "text" || e.kind === "comment";
  }
  function O(e, t) {
    return e.kind === "element" && (e.fullName === "script" || e.fullName === "style" || e.fullName === "svg:style" || e.fullName === "svg:script" || e.fullName === "mj-style" && t.parser === "mjml" || oe(e) && (e.name === "script" || e.name === "style"));
  }
  function rn(e, t) {
    return e.children && !O(e, t);
  }
  function nn(e, t) {
    return O(e, t) || e.kind === "interpolation" || er(e);
  }
  function er(e) {
    return dn(e).startsWith("pre");
  }
  function sn(e, t) {
    let r = n();
    if (r && !e.prev && e.parent?.tagDefinition?.ignoreFirstLf) return e.kind === "interpolation";
    return r;
    function n() {
      return ae(e) || e.kind === "angularControlFlowBlock" ? false : (e.kind === "text" || e.kind === "interpolation") && e.prev && (e.prev.kind === "text" || e.prev.kind === "interpolation") ? true : !e.parent || e.parent.cssDisplay === "none" ? false : Y(e.parent) ? true : !(!e.prev && (e.parent.kind === "root" || Y(e) && e.parent || O(e.parent, t) || Ge(e.parent, t) || !Vs(e.parent.cssDisplay)) || e.prev && !zs(e.prev.cssDisplay));
    }
  }
  function an(e, t) {
    return ae(e) || e.kind === "angularControlFlowBlock" ? false : (e.kind === "text" || e.kind === "interpolation") && e.next && (e.next.kind === "text" || e.next.kind === "interpolation") ? true : !e.parent || e.parent.cssDisplay === "none" ? false : Y(e.parent) ? true : !(!e.next && (e.parent.kind === "root" || Y(e) && e.parent || O(e.parent, t) || Ge(e.parent, t) || !Us(e.parent.cssDisplay)) || e.next && !Ws(e.next.cssDisplay));
  }
  function on(e, t) {
    return Gs(e.cssDisplay) && !O(e, t);
  }
  function We(e) {
    return ae(e) || e.next && e.sourceSpan.end && e.sourceSpan.end.line + 1 < e.next.sourceSpan.start.line;
  }
  function ln(e) {
    return tr(e) || e.kind === "element" && e.children.length > 0 && (["body", "script", "style"].includes(e.name) || e.children.some((t) => Bs(t))) || e.firstChild && e.firstChild === e.lastChild && e.firstChild.kind !== "text" && un(e.firstChild) && (!e.lastChild.isTrailingSpaceSensitive || pn(e.lastChild));
  }
  function tr(e) {
    return e.kind === "element" && e.children.length > 0 && (["html", "head", "ul", "ol", "select"].includes(e.name) || e.cssDisplay.startsWith("table") && e.cssDisplay !== "table-cell");
  }
  function kt(e) {
    return hn(e) || e.prev && Ms(e.prev) || cn(e);
  }
  function Ms(e) {
    return hn(e) || e.kind === "element" && e.fullName === "br" || cn(e);
  }
  function cn(e) {
    return un(e) && pn(e);
  }
  function un(e) {
    return e.hasLeadingSpaces && (e.prev ? e.prev.sourceSpan.end.line < e.sourceSpan.start.line : e.parent.kind === "root" || e.parent.startSourceSpan.end.line < e.sourceSpan.start.line);
  }
  function pn(e) {
    return e.hasTrailingSpaces && (e.next ? e.next.sourceSpan.start.line > e.sourceSpan.end.line : e.parent.kind === "root" || e.parent.endSourceSpan && e.parent.endSourceSpan.start.line > e.sourceSpan.end.line);
  }
  function hn(e) {
    switch (e.kind) {
      case "ieConditionalComment":
      case "comment":
      case "directive":
        return true;
      case "element":
        return ["script", "select"].includes(e.name);
    }
    return false;
  }
  function bt(e) {
    return e.lastChild ? bt(e.lastChild) : e;
  }
  function Bs(e) {
    return e.children?.some((t) => t.kind !== "text");
  }
  function mn(e) {
    if (e) switch (e) {
      case "module":
      case "text/javascript":
      case "text/babel":
      case "text/jsx":
      case "application/javascript":
        return "babel";
      case "application/x-typescript":
        return "typescript";
      case "text/markdown":
        return "markdown";
      case "text/html":
        return "html";
      case "text/x-handlebars-template":
        return "glimmer";
      default:
        if (e.endsWith("json") || e.endsWith("importmap") || e === "speculationrules") return "json";
    }
  }
  function qs(e, t) {
    let { name: r, attrMap: n } = e;
    if (r !== "script" || se(n, "src")) return;
    let { type: i, lang: s } = e.attrMap;
    return !s && !i ? "babel" : _t(t, { language: s }) ?? mn(i);
  }
  function Hs(e, t) {
    if (!wt(e, t)) return;
    let { attrMap: r } = e;
    if (se(r, "src")) return;
    let { type: n, lang: i } = r;
    return _t(t, { language: i }) ?? mn(n);
  }
  function Fs(e, t) {
    if (e.name === "style") {
      let { lang: r } = e.attrMap;
      return r ? _t(t, { language: r }) : "css";
    }
    if (e.name === "mj-style" && t.parser === "mjml") return "css";
  }
  function rr(e, t) {
    return qs(e, t) ?? Fs(e, t) ?? Hs(e, t);
  }
  function ze(e) {
    return e === "block" || e === "list-item" || e.startsWith("table");
  }
  function Vs(e) {
    return !ze(e) && e !== "inline-block";
  }
  function Us(e) {
    return !ze(e) && e !== "inline-block";
  }
  function Ws(e) {
    return !ze(e);
  }
  function zs(e) {
    return !ze(e);
  }
  function Gs(e) {
    return !ze(e) && e !== "inline-block";
  }
  function Y(e) {
    return dn(e).startsWith("pre");
  }
  function $s(e, t) {
    let r = e;
    for (; r; ) {
      if (t(r)) return true;
      r = r.parent;
    }
    return false;
  }
  function fn(e, t) {
    if (ce(e, t)) return "block";
    if (e.prev?.kind === "comment") {
      let n = e.prev.value.match(/^\\s*display:\\s*([a-z]+)\\s*$/);
      if (n) return n[1];
    }
    let r = false;
    if (e.kind === "element" && e.namespace === "svg") if ($s(e, (n) => n.fullName === "svg:foreignObject")) r = true;
    else return e.name === "svg" ? "inline-block" : "block";
    switch (t.htmlWhitespaceSensitivity) {
      case "strict":
        return "inline";
      case "ignore":
        return "block";
      default:
        if (e.kind === "element" && (!e.namespace || r || oe(e)) && se(Xt, e.name)) return Xt[e.name];
    }
    return Zr;
  }
  function dn(e) {
    return e.kind === "element" && (!e.namespace || oe(e)) && se(Jt, e.name) ? Jt[e.name] : en;
  }
  function nr(e) {
    return T(0, T(0, e, "&apos;", "'"), "&quot;", '"');
  }
  function w(e) {
    return nr(e.value);
  }
  var js = /* @__PURE__ */ new Set(["template", "style", "script"]);
  function Ge(e, t) {
    return ce(e, t) && !js.has(e.fullName);
  }
  function ce(e, t) {
    return t.parser === "vue" && e.kind === "element" && e.parent.kind === "root" && e.fullName.toLowerCase() !== "html";
  }
  function wt(e, t) {
    return ce(e, t) && (Ge(e, t) || e.attrMap.lang && e.attrMap.lang !== "html");
  }
  function gn(e) {
    let t = e.fullName;
    return t.charAt(0) === "#" || t === "slot-scope" || t === "v-slot" || t.startsWith("v-slot:");
  }
  function _n(e, t) {
    let r = e.parent;
    if (!ce(r, t)) return false;
    let n = r.fullName, i = e.fullName;
    return n === "script" && i === "setup" || n === "style" && i === "vars";
  }
  function Tt(e, t = e.value) {
    return e.parent.isWhitespaceSensitive ? e.parent.isIndentationSensitive ? L(t) : L(P.dedentString(Zt(t)), k) : R(S, P.split(t));
  }
  function yt(e, t) {
    return ce(e, t) && e.name === "script";
  }
  function Ys(e) {
    let { valueSpan: t, value: r } = e;
    return t.end.offset - t.start.offset === r.length + 2;
  }
  function Et(e, t) {
    if (Ys(e)) return false;
    let { value: r } = e;
    return /^PRETTIER_HTML_PLACEHOLDER_\\d+_\\d+_IN_JS$/.test(r) || t.parser === "lwc" && r.startsWith("{") && r.endsWith("}");
  }
  var Sn = /\\{\\{(.+?)\\}\\}/s, vn = ({ node: { value: e } }) => Sn.test(e);
  async function Cn(e, t, r) {
    let n = w(r.node), i = [];
    for (let [s, a] of n.split(Sn).entries()) if (s % 2 === 0) i.push(L(a));
    else try {
      i.push(C(["{{", A([S, await E(a, e, { parser: "__ng_interpolation", __isInHtmlInterpolation: true })]), S, "}}"]));
    } catch {
      i.push("{{", L(a), "}}");
    }
    return i;
  }
  var ir = (e) => (t, r, n) => E(w(n.node), t, { parser: e }, q), Ks = [{ test(e) {
    let t = e.node.fullName;
    return t.startsWith("(") && t.endsWith(")") || t.startsWith("on-");
  }, print: ir("__ng_action") }, { test(e) {
    let t = e.node.fullName;
    return t.startsWith("[") && t.endsWith("]") || /^bind(?:on)?-/.test(t) || /^ng-(?:if|show|hide|class|style)$/.test(t);
  }, print: ir("__ng_binding") }, { test: (e) => e.node.fullName.startsWith("*"), print: ir("__ng_directive") }, { test: (e) => /^i18n(?:-.+)?$/.test(e.node.fullName), print: Qs }, { test: vn, print: Cn }].map(({ test: e, print: t }) => ({ test: (r, n) => n.parser === "angular" && e(r), print: t }));
  function Qs(e, t, { node: r }) {
    let n = w(r);
    return j(gt(Tt(r, n.trim())), !n.includes("@@"));
  }
  var kn = Ks;
  var bn = ({ node: e }, t) => !t.parentParser && e.fullName === "class" && !e.value.includes("{{"), wn = (e, t, r) => T(0, w(r.node).trim(), /\\s+/g, " ");
  var sr = ["onabort", "onafterprint", "onauxclick", "onbeforeinput", "onbeforematch", "onbeforeprint", "onbeforetoggle", "onbeforeunload", "onblur", "oncancel", "oncanplay", "oncanplaythrough", "onchange", "onclick", "onclose", "oncommand", "oncontextlost", "oncontextmenu", "oncontextrestored", "oncopy", "oncuechange", "oncut", "ondblclick", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "ondurationchange", "onemptied", "onended", "onerror", "onfocus", "onformdata", "onhashchange", "oninput", "oninvalid", "onkeydown", "onkeypress", "onkeyup", "onlanguagechange", "onload", "onloadeddata", "onloadedmetadata", "onloadstart", "onmessage", "onmessageerror", "onmousedown", "onmouseenter", "onmouseleave", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onoffline", "ononline", "onpagehide", "onpagereveal", "onpageshow", "onpageswap", "onpaste", "onpause", "onplay", "onplaying", "onpopstate", "onprogress", "onratechange", "onrejectionhandled", "onreset", "onresize", "onscroll", "onscrollend", "onsecuritypolicyviolation", "onseeked", "onseeking", "onselect", "onslotchange", "onstalled", "onstorage", "onsubmit", "onsuspend", "ontimeupdate", "ontoggle", "onunhandledrejection", "onunload", "onvolumechange", "onwaiting", "onwheel"];
  var Js = new Set(sr), Tn = ({ node: e }, t) => Js.has(e.fullName) && !t.parentParser && !e.value.includes("{{"), yn = (e, t, r) => E(w(r.node), e, { parser: "babel", __isHtmlInlineEventHandler: true }, () => false);
  function Zs(e) {
    let t = [];
    for (let r of e.split(";")) {
      if (r = P.trim(r), !r) continue;
      let [n, ...i] = P.split(r);
      t.push({ name: n, value: i });
    }
    return t;
  }
  var En = Zs;
  var xn = ({ node: e }, t) => e.fullName === "allow" && !t.parentParser && e.parent.fullName === "iframe" && !e.value.includes("{{");
  function Ln(e, t, r) {
    let { node: n } = r, i = En(w(n));
    return i.length === 0 ? [""] : j(i.map(({ name: s, value: a }, o) => [[s, ...a].join(" "), o === i.length - 1 ? $$1(";") : [";", S]]));
  }
  function An(e) {
    return e === "	" || e === \`
\` || e === "\\f" || e === "\\r" || e === " ";
  }
  var ea = /^[ \\t\\n\\r\\u000c]+/, ta = /^[, \\t\\n\\r\\u000c]+/, ra = /^[^ \\t\\n\\r\\u000c]+/, na = /[,]+$/, Pn = /^\\d+$/, ia = /^-?(?:[0-9]+|[0-9]*\\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/;
  function sa(e) {
    let t = e.length, r, n, i, s, a, o = 0, l;
    function c(h) {
      let f, g2 = h.exec(e.substring(o));
      if (g2) return [f] = g2, o += f.length, f;
    }
    let u = [];
    for (; ; ) {
      if (c(ta), o >= t) {
        if (u.length === 0) throw new Error("Must contain one or more image candidate strings.");
        return u;
      }
      l = o, r = c(ra), n = [], r.slice(-1) === "," ? (r = r.replace(na, ""), _()) : d();
    }
    function d() {
      for (c(ea), i = "", s = "in descriptor"; ; ) {
        if (a = e.charAt(o), s === "in descriptor") if (An(a)) i && (n.push(i), i = "", s = "after descriptor");
        else if (a === ",") {
          o += 1, i && n.push(i), _();
          return;
        } else if (a === "(") i += a, s = "in parens";
        else if (a === "") {
          i && n.push(i), _();
          return;
        } else i += a;
        else if (s === "in parens") if (a === ")") i += a, s = "in descriptor";
        else if (a === "") {
          n.push(i), _();
          return;
        } else i += a;
        else if (s === "after descriptor" && !An(a)) if (a === "") {
          _();
          return;
        } else s = "in descriptor", o -= 1;
        o += 1;
      }
    }
    function _() {
      let h = false, f, g2, v2, W2, ie2 = {}, Q2, at2, Ce2, Be2, Ut2;
      for (W2 = 0; W2 < n.length; W2++) Q2 = n[W2], at2 = Q2[Q2.length - 1], Ce2 = Q2.substring(0, Q2.length - 1), Be2 = parseInt(Ce2, 10), Ut2 = parseFloat(Ce2), Pn.test(Ce2) && at2 === "w" ? ((f || g2) && (h = true), Be2 === 0 ? h = true : f = Be2) : ia.test(Ce2) && at2 === "x" ? ((f || g2 || v2) && (h = true), Ut2 < 0 ? h = true : g2 = Ut2) : Pn.test(Ce2) && at2 === "h" ? ((v2 || g2) && (h = true), Be2 === 0 ? h = true : v2 = Be2) : h = true;
      if (!h) ie2.source = { value: r, startOffset: l }, f && (ie2.width = { value: f }), g2 && (ie2.density = { value: g2 }), v2 && (ie2.height = { value: v2 }), u.push(ie2);
      else throw new Error(\`Invalid srcset descriptor found in "\${e}" at "\${Q2}".\`);
    }
  }
  var Nn = sa;
  var Dn = (e) => e.node.fullName === "srcset" && (e.parent.fullName === "img" || e.parent.fullName === "source"), In = { width: "w", height: "h", density: "x" }, aa = Object.keys(In);
  function Rn(e, t, r) {
    let n = w(r.node), i = Nn(n), s = aa.filter((h) => i.some((f) => se(f, h)));
    if (s.length > 1) throw new Error("Mixed descriptor in srcset is not supported");
    let [a] = s, o = In[a], l = i.map((h) => h.source.value), c = Math.max(...l.map((h) => h.length)), u = i.map((h) => h[a] ? String(h[a].value) : ""), d = u.map((h) => {
      let f = h.indexOf(".");
      return f === -1 ? h.length : f;
    }), _ = Math.max(...d);
    return j(R([",", S], l.map((h, f) => {
      let g2 = [h], v2 = u[f];
      if (v2) {
        let W2 = c - h.length + 1, ie2 = _ - d[f], Q2 = " ".repeat(W2 + ie2);
        g2.push($$1(Q2, " "), v2 + o);
      }
      return g2;
    })));
  }
  var On = ({ node: e }, t) => e.fullName === "style" && !t.parentParser && !e.value.includes("{{"), Mn = async (e, t, r) => j(await e(w(r.node), { parser: "css", __isHTMLStyleAttribute: true }));
  var oa = /* @__PURE__ */ new WeakMap();
  function la(e, t) {
    return mt(oa, e.root, (r) => r.children.some((n) => yt(n, t) && ["ts", "typescript"].includes(n.attrMap.lang)));
  }
  var H = la;
  function Bn(e, t, r) {
    let n = w(r.node);
    return E(\`type T<\${n}> = any\`, e, { parser: "babel-ts", __isEmbeddedTypescriptGenericParameters: true }, q);
  }
  function qn(e, t, r, n) {
    let i = w(r.node), s = H(r, n) ? "babel-ts" : "babel";
    return E(\`function _(\${i}) {}\`, e, { parser: s, __isVueBindings: true });
  }
  async function Hn(e, t, r, n) {
    let i = w(r.node), { left: s, operator: a, right: o } = ca(i), l = H(r, n);
    return [C(await E(\`function _(\${s}) {}\`, e, { parser: l ? "babel-ts" : "babel", __isVueForBindingLeft: true })), " ", a, " ", await E(o, e, { parser: l ? "__ts_expression" : "__js_expression" })];
  }
  function ca(e) {
    let t = /(.*?)\\s+(in|of)\\s+(.*)/s, r = e.match(t);
    if (!r) return;
    let n = { for: r[3].trim() };
    if (!n.for) return;
    let i = /,([^,\\]}]*)(?:,([^,\\]}]*))?$/, s = /^\\(|\\)$/g, a = T(0, r[1].trim(), s, ""), o = a.match(i);
    o ? (n.alias = a.replace(i, ""), n.iterator1 = o[1].trim(), o[2] && (n.iterator2 = o[2].trim())) : n.alias = a;
    let l = [n.alias, n.iterator1, n.iterator2];
    if (!l.some((c, u) => !c && (u === 0 || l.slice(u + 1).some(Boolean)))) return { left: l.filter(Boolean).join(","), operator: r[2], right: n.for };
  }
  var ua = [{ test: (e) => e.node.fullName === "v-for", print: Hn }, { test: (e, t) => e.node.fullName === "generic" && yt(e.parent, t), print: Bn }, { test: ({ node: e }, t) => gn(e) || _n(e, t), print: qn }, { test(e) {
    let t = e.node.fullName;
    return t.startsWith("@") || t.startsWith("v-on:");
  }, print: pa }, { test(e) {
    let t = e.node.fullName;
    return t.startsWith(":") || t.startsWith(".") || t.startsWith("v-bind:");
  }, print: ha }, { test: (e) => e.node.fullName.startsWith("v-"), print: Fn }].map(({ test: e, print: t }) => ({ test: (r, n) => n.parser === "vue" && e(r, n), print: t }));
  async function pa(e, t, r, n) {
    try {
      return await Fn(e, t, r, n);
    } catch (a) {
      if (a.cause?.code !== "BABEL_PARSER_SYNTAX_ERROR") throw a;
    }
    let i = w(r.node), s = H(r, n) ? "__vue_ts_event_binding" : "__vue_event_binding";
    return E(i, e, { parser: s }, q);
  }
  function ha(e, t, r, n) {
    let i = w(r.node), s = H(r, n) ? "__vue_ts_expression" : "__vue_expression";
    return E(i, e, { parser: s }, q);
  }
  function Fn(e, t, r, n) {
    let i = w(r.node), s = H(r, n) ? "__ts_expression" : "__js_expression";
    return E(i, e, { parser: s }, q);
  }
  var Vn = ua;
  var ma = [{ test: Dn, print: Rn }, { test: On, print: Mn }, { test: Tn, print: yn }, { test: bn, print: wn }, { test: xn, print: Ln }, ...Vn, ...kn].map(({ test: e, print: t }) => ({ test: e, print: da(t) }));
  function fa(e, t) {
    let { node: r } = e, { value: n } = r;
    if (n) return Et(r, t) ? [r.rawName, "=", n] : ma.find(({ test: i }) => i(e, t))?.print;
  }
  function da(e) {
    return async (t, r, n, i) => {
      let s = await e(t, r, n, i);
      if (s) return s = Gt(s, (a) => typeof a == "string" ? T(0, a, '"', "&quot;") : a), [n.node.rawName, '="', C(s), '"'];
    };
  }
  var Un = fa;
  var F = (e) => e.sourceSpan.start.offset, J = (e) => e.sourceSpan.end.offset;
  function $e(e, t) {
    return [e.isSelfClosing ? "" : ga(e, t), ue(e, t)];
  }
  function ga(e, t) {
    return e.lastChild && K(e.lastChild) ? "" : [_a(e, t), xt(e, t)];
  }
  function ue(e, t) {
    return (e.next ? V(e.next) : he(e.parent)) ? "" : [pe(e, t), M(e, t)];
  }
  function _a(e, t) {
    return he(e) ? pe(e.lastChild, t) : "";
  }
  function M(e, t) {
    return K(e) ? xt(e.parent, t) : je(e) ? Lt(e.next, t) : "";
  }
  function xt(e, t) {
    if (zn(e, t)) return "";
    switch (e.kind) {
      case "ieConditionalComment":
        return "<!";
      case "element":
        if (e.hasHtmComponentClosingTag) return "<//";
      default:
        return \`</\${e.rawName}\`;
    }
  }
  function pe(e, t) {
    if (zn(e, t)) return "";
    switch (e.kind) {
      case "ieConditionalComment":
      case "ieConditionalEndComment":
        return "[endif]-->";
      case "ieConditionalStartComment":
        return "]><!-->";
      case "interpolation":
        return "}}";
      case "angularIcuExpression":
        return "}";
      case "element":
        if (e.isSelfClosing) return "/>";
      default:
        return ">";
    }
  }
  function zn(e, t) {
    return !e.isSelfClosing && !e.endSourceSpan && (le(e) || Ct(e.parent, t));
  }
  function V(e) {
    return e.prev && e.prev.kind !== "docType" && e.kind !== "angularControlFlowBlock" && !N(e.prev) && e.isLeadingSpaceSensitive && !e.hasLeadingSpaces;
  }
  function he(e) {
    return e.lastChild?.isTrailingSpaceSensitive && !e.lastChild.hasTrailingSpaces && !N(bt(e.lastChild)) && !Y(e);
  }
  function K(e) {
    return !e.next && !e.hasTrailingSpaces && e.isTrailingSpaceSensitive && N(bt(e));
  }
  function je(e) {
    return e.next && !N(e.next) && N(e) && e.isTrailingSpaceSensitive && !e.hasTrailingSpaces;
  }
  function Sa(e) {
    let t = e.trim().match(/^prettier-ignore-attribute(?:\\s+(.+))?$/s);
    return t ? t[1] ? t[1].split(/\\s+/) : true : false;
  }
  function Ye(e) {
    return !e.prev && e.isLeadingSpaceSensitive && !e.hasLeadingSpaces;
  }
  function va(e, t, r) {
    let { node: n } = e, { attrs: i = [], startTagComments: s = [] } = n;
    if (i.length === 0 && s.length === 0) return n.isSelfClosing ? " " : "";
    let a = n.prev?.kind === "comment" && Sa(n.prev.value), o = typeof a == "boolean" ? () => a : Array.isArray(a) ? (g2) => a.includes(g2.rawName) : () => false, l = ["attrs", "startTagComments"].filter((g2) => X(n[g2])), c = l.flatMap((g2) => e.map(({ node: v2 }) => ({ loc: F(v2), printed: v2.kind === "attribute" && o(v2) ? L(t.originalText.slice(F(v2), J(v2))) : r() }), g2));
    l.length > 1 && c.sort((g2, v2) => g2.loc - v2.loc);
    let u = n.kind === "element" && n.fullName === "script" && i.length === 1 && i[0].fullName === "src" && n.children.length === 0 && s.length === 0, d = s.some((g2) => g2.type === "single"), h = d || t.singleAttributePerLine && i.length > 1 && !ce(n, t) ? k : S, f = [A([u ? " " : d ? k : S, R(h, c.map(({ printed: g2 }) => g2))])];
    return n.firstChild && Ye(n.firstChild) || n.isSelfClosing && he(n.parent) || u ? f.push(n.isSelfClosing ? " " : "") : f.push(t.bracketSameLine ? n.isSelfClosing ? " " : "" : n.isSelfClosing ? S : y), f;
  }
  function Ca(e) {
    return e.firstChild && Ye(e.firstChild) ? "" : At(e);
  }
  function Ke(e, t, r) {
    let { node: n } = e;
    return [me(n, t), va(e, t, r), n.isSelfClosing ? "" : Ca(n)];
  }
  function me(e, t) {
    return e.prev && je(e.prev) ? "" : [B(e, t), Lt(e, t)];
  }
  function B(e, t) {
    return Ye(e) ? At(e.parent) : V(e) ? pe(e.prev, t) : "";
  }
  var Wn = "<!doctype";
  function Lt(e, t) {
    switch (e.kind) {
      case "ieConditionalComment":
      case "ieConditionalStartComment":
        return \`<!--[if \${e.condition}\`;
      case "ieConditionalEndComment":
        return "<!--<!";
      case "interpolation":
        return "{{";
      case "docType": {
        if (e.value === "html") {
          let { filepath: n } = t;
          if (n && /\\.html?$/.test(n)) return Wn;
        }
        let r = F(e);
        return t.originalText.slice(r, r + Wn.length);
      }
      case "angularIcuExpression":
        return "{";
      case "element":
        if (e.condition) return \`<!--[if \${e.condition}]><!--><\${e.rawName}\`;
      default:
        return \`<\${e.rawName}\`;
    }
  }
  function At(e) {
    switch (e.kind) {
      case "ieConditionalComment":
        return "]>";
      case "element":
        if (e.condition) return "><!--<![endif]-->";
      default:
        return ">";
    }
  }
  function ka(e, t) {
    if (!e.endSourceSpan) return "";
    let r = e.startSourceSpan.end.offset;
    e.firstChild && Ye(e.firstChild) && (r -= At(e).length);
    let n = e.endSourceSpan.start.offset;
    return e.lastChild && K(e.lastChild) ? n += xt(e, t).length : he(e) && (n -= pe(e.lastChild, t).length), t.originalText.slice(r, n);
  }
  var Pt = ka;
  var ba = /* @__PURE__ */ new Set(["if", "else if", "for", "switch", "case"]);
  function wa(e, t) {
    let { node: r } = e;
    switch (r.kind) {
      case "element":
        if (O(r, t) || r.kind === "interpolation") return;
        if (!r.isSelfClosing && wt(r, t)) {
          let n = rr(r, t);
          return n ? async (i, s) => {
            let a = Pt(r, t), o = /^\\s*$/.test(a), l = "";
            return o || (l = await i(Zt(a), { parser: n, __embeddedInHtml: true }), o = l === ""), [B(r, t), C(Ke(e, t, s)), o ? "" : k, l, o ? "" : k, $e(r, t), M(r, t)];
          } : void 0;
        }
        break;
      case "text":
        if (O(r.parent, t)) {
          let n = rr(r.parent, t);
          if (n) return async (i) => {
            let s = n === "markdown" ? P.dedentString(r.value.replace(/^[^\\S\\n]*\\n/, "")) : r.value, a = { parser: n, __embeddedInHtml: true };
            if (t.parser === "html" && n === "babel") {
              let o = "script", { attrMap: l } = r.parent;
              l && (l.type === "module" || (l.type === "text/babel" || l.type === "text/jsx") && l["data-type"] === "module") && (o = "module"), a.__babelSourceType = o;
            }
            return [G, B(r, t), await i(s, a), M(r, t)];
          };
        } else if (r.parent.kind === "interpolation") return async (n) => {
          let i = { __isInHtmlInterpolation: true, __embeddedInHtml: true };
          return t.parser === "angular" ? i.parser = "__ng_interpolation" : t.parser === "vue" ? i.parser = H(e, t) ? "__vue_ts_expression" : "__vue_expression" : i.parser = "__js_expression", [A([S, await n(r.value, i)]), r.parent.next && V(r.parent.next) ? " " : S];
        };
        break;
      case "attribute":
        return Un(e, t);
      case "angularControlFlowBlockParameters":
        return ba.has(e.parent.name) ? $r : void 0;
      case "angularLetDeclarationInitializer":
        return (n) => E(r.value, n, { parser: "__ng_binding", __isInHtmlAttribute: false });
    }
  }
  var Gn = wa;
  var Qe = null;
  function Xe(e) {
    if (Qe !== null && typeof Qe.property) {
      let t = Qe;
      return Qe = Xe.prototype = null, t;
    }
    return Qe = Xe.prototype = e ?? /* @__PURE__ */ Object.create(null), new Xe();
  }
  var Ta = 10;
  for (let e = 0; e <= Ta; e++) Xe();
  function ar(e) {
    return Xe(e);
  }
  function ya(e, t = "type") {
    ar(e);
    function r(n) {
      let i = n[t], s = e[i];
      if (!Array.isArray(s)) throw Object.assign(new Error(\`Missing visitor keys for '\${i}'.\`), { node: n });
      return s;
    }
    return r;
  }
  var $n = ya;
  var Je = [["children"]], jn = { root: Je[0], element: ["attrs", "startTagComments", "children"], ieConditionalComment: Je[0], ieConditionalStartComment: [], ieConditionalEndComment: [], interpolation: Je[0], text: Je[0], docType: [], comment: [], attribute: [], startTagComment: [], cdata: [], angularControlFlowBlock: ["children", "parameters"], angularControlFlowBlockParameters: Je[0], angularControlFlowBlockParameter: [], angularLetDeclaration: ["init"], angularLetDeclarationInitializer: [], angularIcuExpression: ["cases"], angularIcuCase: ["expression"] };
  var Ea = $n(jn, "kind"), Yn = Ea;
  var xa = /* @__PURE__ */ new Set(["sourceSpan", "startSourceSpan", "endSourceSpan", "nameSpan", "valueSpan", "keySpan", "tagDefinition", "tokens", "valueTokens", "switchValueSourceSpan", "expSourceSpan", "valueSourceSpan"]), La = /* @__PURE__ */ new Set(["if", "else if", "for", "switch", "case"]);
  function or(e, t, r) {
    if (e.kind === "text" || e.kind === "comment") return null;
    if (e.kind === "yaml" && delete t.value, e.kind === "attribute") {
      let { fullName: n, value: i } = e;
      n === "style" || n === "class" || n === "srcset" && (r.fullName === "img" || r.fullName === "source") || n === "allow" && r.fullName === "iframe" || n.startsWith("on") || n.startsWith("@") || n.startsWith(":") || n.startsWith(".") || n.startsWith("#") || n.startsWith("v-") || n === "vars" && r.fullName === "style" || (n === "setup" || n === "generic") && r.fullName === "script" || n === "slot-scope" || n.startsWith("(") || n.startsWith("[") || n.startsWith("*") || n.startsWith("bind") || n.startsWith("i18n") || n.startsWith("on-") || n.startsWith("ng-") || i?.includes("{{") ? delete t.value : i && (t.value = T(0, i, /'|&quot;|&apos;/g, '"'));
    }
    if (e.kind === "docType" && (t.value = T(0, e.value.toLowerCase(), /\\s+/g, " ")), e.kind === "angularControlFlowBlock" && e.parameters?.children) for (let n of t.parameters.children) La.has(e.name) ? delete n.expression : n.expression = n.expression.trim();
    e.kind === "angularIcuExpression" && (t.switchValue = e.switchValue.trim()), e.kind === "angularLetDeclarationInitializer" && delete t.value, e.kind === "element" && e.isVoid && !e.isSelfClosing && (t.isSelfClosing = true);
  }
  or.ignoredProperties = xa;
  var Kn = "format";
  var Qn = /^\\s*<!--\\s*@(?:noformat|noprettier)\\s*-->/, Xn = /^\\s*<!--\\s*@(?:format|prettier)\\s*-->/;
  var Jn = (e) => Xn.test(e), Zn = (e) => Qn.test(e), ei = (e) => \`<!-- @\${Kn} -->

\${e}\`;
  var ti = /* @__PURE__ */ new Map([["if", /* @__PURE__ */ new Set(["else if", "else"])], ["else if", /* @__PURE__ */ new Set(["else if", "else"])], ["for", /* @__PURE__ */ new Set(["empty"])], ["defer", /* @__PURE__ */ new Set(["placeholder", "error", "loading"])], ["placeholder", /* @__PURE__ */ new Set(["placeholder", "error", "loading"])], ["error", /* @__PURE__ */ new Set(["placeholder", "error", "loading"])], ["loading", /* @__PURE__ */ new Set(["placeholder", "error", "loading"])]]);
  function ri(e) {
    let t = J(e);
    return e.kind === "element" && !e.endSourceSpan && X(e.children) ? Math.max(t, ri(I(0, e.children, -1))) : t;
  }
  function Ze(e, t, r) {
    let n = e.node;
    if (le(n)) {
      let i = ri(n);
      return [B(n, t), L(P.trimEnd(t.originalText.slice(F(n) + (n.prev && je(n.prev) ? Lt(n).length : 0), i - (n.next && V(n.next) ? pe(n, t).length : 0)))), M(n, t)];
    }
    return r();
  }
  function Nt(e, t) {
    return N(e) && N(t) ? e.isTrailingSpaceSensitive ? e.hasTrailingSpaces ? kt(t) ? k : S : "" : kt(t) ? k : y : je(e) && (le(t) || t.firstChild || t.isSelfClosing || t.kind === "element" && t.attrs.length > 0) || e.kind === "element" && e.isSelfClosing && V(t) ? "" : t.kind === "comment" && t.isLeadingSpaceSensitive && !t.hasLeadingSpaces ? y : !t.isLeadingSpaceSensitive || kt(t) || V(t) && e.lastChild && K(e.lastChild) && e.lastChild.lastChild && K(e.lastChild.lastChild) ? k : t.hasLeadingSpaces ? S : y;
  }
  function Ae(e, t, r) {
    let { node: n } = e;
    if (tr(n)) return [G, ...e.map(() => {
      let s = e.node, a = s.prev ? Nt(s.prev, s) : "";
      return [a ? [a, We(s.prev) ? k : ""] : "", Ze(e, t, r)];
    }, "children")];
    let i = n.children.map(() => /* @__PURE__ */ Symbol(""));
    return e.map(({ node: s, index: a }) => {
      if (N(s)) {
        if (s.prev && N(s.prev)) {
          let h = Nt(s.prev, s);
          if (h) return We(s.prev) ? [k, k, Ze(e, t, r)] : [h, Ze(e, t, r)];
        }
        return Ze(e, t, r);
      }
      let o = [], l = [], c = [], u = [], d = s.prev ? Nt(s.prev, s) : "", _ = s.next ? Nt(s, s.next) : "";
      return d && (We(s.prev) ? o.push(k, k) : d === k ? o.push(k) : N(s.prev) ? l.push(d) : l.push($$1("", y, { groupId: i[a - 1] }))), _ && (We(s) ? N(s.next) && u.push(k, k) : _ === k ? N(s.next) && u.push(k) : c.push(_)), [...o, C([...l, C([Ze(e, t, r), ...c], { id: i[a] })]), ...u];
    }, "children");
  }
  function ni(e, t, r) {
    let { node: n } = e, i = [];
    Da(e) && i.push("} "), i.push("@", n.name);
    let s = Pa(n);
    if (n.parameters && (s || i.push(" "), i.push("(", C(r("parameters")), ")")), s) return i.push(";"), i;
    if (!Na(n)) {
      i.push(" {");
      let a = ii(n);
      n.children.length > 0 ? (n.firstChild.hasLeadingSpaces = true, n.lastChild.hasTrailingSpaces = true, i.push(A([k, Ae(e, t, r)])), a && i.push(k, "}")) : a && i.push("}");
    }
    return C(i, { shouldBreak: true });
  }
  function ii(e) {
    return !(e.next?.kind === "angularControlFlowBlock" && ti.get(e.name)?.has(e.next.name));
  }
  var Aa = (e) => e?.kind === "angularControlFlowBlock" && (e.name === "case" || e.name === "default"), Pa = (e) => e?.kind === "angularControlFlowBlock" && e.name === "default never";
  function Na(e) {
    return Aa(e) && e.endSourceSpan && e.endSourceSpan.start.offset === e.endSourceSpan.end.offset;
  }
  function Da(e) {
    let { previous: t } = e;
    return t?.kind === "angularControlFlowBlock" && !le(t) && !ii(t);
  }
  function si(e, t, r) {
    return [A([y, R([";", S], e.map(r, "children"))]), y];
  }
  function ai(e, t, r) {
    let { node: n } = e;
    return [me(n, t), C([n.switchValue.trim(), ", ", n.type, n.cases.length > 0 ? [",", A([S, R(S, e.map(r, "cases"))])] : "", y]), ue(n, t)];
  }
  function oi(e, t, r) {
    let { node: n } = e;
    return [n.value, " {", C([A([y, e.map(({ node: i, isLast: s }) => {
      let a = [r()];
      return i.kind === "text" && (i.hasLeadingSpaces && a.unshift(S), i.hasTrailingSpaces && !s && a.push(S)), a;
    }, "expression")]), y]), "}"];
  }
  function li(e, t, r) {
    let { node: n } = e;
    if (Ct(n, t)) return [B(n, t), C(Ke(e, t, r)), L(Pt(n, t)), ...$e(n, t), M(n, t)];
    let i = n.children.length === 1 && (n.firstChild.kind === "interpolation" || n.firstChild.kind === "angularIcuExpression") && n.firstChild.isLeadingSpaceSensitive && !n.firstChild.hasLeadingSpaces && n.lastChild.isTrailingSpaceSensitive && !n.lastChild.hasTrailingSpaces, s = /* @__PURE__ */ Symbol("element-attr-group-id"), a = (u) => C([C(Ke(e, t, r), { id: s }), u, $e(n, t)]);
    if (n.children.length === 0) return a(n.hasDanglingSpaces && n.isDanglingSpaceSensitive ? S : "");
    let o = (u) => i ? Fr(u, { groupId: s }) : (O(n, t) || Ge(n, t)) && n.parent.kind === "root" && t.parser === "vue" && !t.vueIndentScriptAndStyle ? u : A(u), l = () => i ? $$1(y, "", { groupId: s }) : n.firstChild.hasLeadingSpaces && n.firstChild.isLeadingSpaceSensitive ? S : n.firstChild.kind === "text" && n.isWhitespaceSensitive && n.isIndentationSensitive ? Hr(y) : y, c = () => (n.next ? V(n.next) : he(n.parent)) ? n.lastChild.hasTrailingSpaces && n.lastChild.isTrailingSpaceSensitive ? " " : "" : Y(n) && K(n.lastChild) ? "" : i ? $$1(y, "", { groupId: s }) : n.lastChild.hasTrailingSpaces && n.lastChild.isTrailingSpaceSensitive ? S : (n.lastChild.kind === "comment" || n.lastChild.kind === "text" && n.isWhitespaceSensitive && n.isIndentationSensitive) && new RegExp(\`\\\\n[\\\\t ]{\${t.tabWidth * (e.ancestors.length - 1)}}$\`).test(n.lastChild.value) ? "" : y;
    return a([ln(n) ? G : "", o([l(), Ae(e, t, r)]), c()]);
  }
  function ci(e) {
    let { node: { value: t, type: r } } = e;
    return r === "single" ? \`//\${t.trimEnd()}\` : ["/*", L(t), "*/"];
  }
  var lr = (function(e) {
    return e[e.RAW_TEXT = 0] = "RAW_TEXT", e[e.ESCAPABLE_RAW_TEXT = 1] = "ESCAPABLE_RAW_TEXT", e[e.PARSABLE_DATA = 2] = "PARSABLE_DATA", e;
  })({});
  function Z(e, t = true) {
    if (e[0] != ":") return [null, e];
    let r = e.indexOf(":", 1);
    if (r === -1) {
      if (t) throw new Error(\`Unsupported format "\${e}" expecting ":namespace:name"\`);
      return [null, e];
    }
    return [e.slice(1, r), e.slice(r + 1)];
  }
  function cr(e) {
    return Z(e)[1] === "ng-container";
  }
  function ur(e) {
    return Z(e)[1] === "ng-content";
  }
  function Pe(e) {
    return e === null ? null : Z(e)[0];
  }
  function fe(e, t) {
    return e ? \`:\${e}:\${t}\` : t;
  }
  var et;
  var Ia = "math";
  var pr = () => /* @__PURE__ */ Object.create(null);
  function Ra() {
    return et || (et = pr(), ee(1, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]), ee(2, void 0, [["*", ["style"]]]), ee(4, void 0, [["*", ["formAction"]], ["area", ["href"]], ["a", ["href", "xlink:href"]], ["form", ["action"]], ["img", ["src"]], ["video", ["src"]]]), ee(4, Ia, [["*", ["href", "xlink:href"]]]), ee(5, void 0, [["base", ["href"]], ["embed", ["src"]], ["frame", ["src"]], ["iframe", ["src"]], ["link", ["href"]], ["object", ["codebase", "data"]]]), ee(4, "svg", [["a", ["href", "xlink:href"]]]), ee(6, "svg", [["animate", ["attributeName", "values", "to", "from"]], ["set", ["to", "attributeName"]], ["animateMotion", ["attributeName"]], ["animateTransform", ["attributeName"]]]), ee(6, void 0, [["unknown", ["attributeName", "values", "to", "from", "sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]], ["iframe", ["sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority", "credentialless"]]]), et);
  }
  function ee(e, t, r) {
    let n = t ?? "";
    for (let [s, a] of r) {
      let o = s.toLowerCase();
      for (let l of a) {
        var i;
        let c = l.toLowerCase(), u = (i = et)[c] ?? (i[c] = pr()), d = u[n] ?? (u[n] = pr());
        d[o] = e;
      }
    }
  }
  function ui(e, t, r) {
    let n = Ra()[t.toLowerCase()];
    if (!n) return 0;
    let i = e.toLowerCase(), s;
    if (r) {
      let a = n[r];
      a && (s = a[i] ?? a["*"]);
    }
    if (s === void 0) {
      let a = n[""];
      a && (s = a[i] ?? a["*"]);
    }
    return s ?? 0;
  }
  var hr = { name: "custom-elements" }, mr = { name: "no-errors-schema" };
  var Oa = /-+([a-z0-9])/g;
  function pi(e) {
    return e.replace(Oa, (...t) => t[1].toUpperCase());
  }
  var hi = class {
  };
  var Ma = "boolean", Ba = "number", qa = "string", Ha = "object";
  function Dt(e) {
    let [t, r] = Z(e.toLowerCase(), false);
    return t === "svg" || t === "math" ? \`:\${t}:\${r}\` : r;
  }
  var Fa = ["[Element]|textContent,%ariaActiveDescendantElement,%ariaAtomic,%ariaAutoComplete,%ariaBusy,%ariaChecked,%ariaColCount,%ariaColIndex,%ariaColIndexText,%ariaColSpan,%ariaControlsElements,%ariaCurrent,%ariaDescribedByElements,%ariaDescription,%ariaDetailsElements,%ariaDisabled,%ariaErrorMessageElements,%ariaExpanded,%ariaFlowToElements,%ariaHasPopup,%ariaHidden,%ariaInvalid,%ariaKeyShortcuts,%ariaLabel,%ariaLabelledByElements,%ariaLevel,%ariaLive,%ariaModal,%ariaMultiLine,%ariaMultiSelectable,%ariaOrientation,%ariaOwnsElements,%ariaPlaceholder,%ariaPosInSet,%ariaPressed,%ariaReadOnly,%ariaRelevant,%ariaRequired,%ariaRoleDescription,%ariaRowCount,%ariaRowIndex,%ariaRowIndexText,%ariaRowSpan,%ariaSelected,%ariaSetSize,%ariaSort,%ariaValueMax,%ariaValueMin,%ariaValueNow,%ariaValueText,%classList,className,elementTiming,id,innerHTML,*beforecopy,*beforecut,*beforepaste,*fullscreenchange,*fullscreenerror,*search,*webkitfullscreenchange,*webkitfullscreenerror,outerHTML,%part,#scrollLeft,#scrollTop,slot,*message,*mozfullscreenchange,*mozfullscreenerror,*mozpointerlockchange,*mozpointerlockerror,*webglcontextcreationerror,*webglcontextlost,*webglcontextrestored", "[HTMLElement]^[Element]|accessKey,autocapitalize,!autofocus,contentEditable,dir,!draggable,enterKeyHint,!hidden,!inert,innerText,inputMode,lang,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,outerText,!spellcheck,%style,#tabIndex,title,!translate,virtualKeyboardPolicy", "abbr,address,article,aside,b,bdi,bdo,cite,content,code,dd,dfn,dt,em,figcaption,figure,footer,header,hgroup,i,kbd,main,mark,nav,noscript,rb,rp,rt,rtc,ruby,s,samp,search,section,small,strong,sub,sup,u,var,wbr^[HTMLElement]|accessKey,autocapitalize,!autofocus,contentEditable,dir,!draggable,enterKeyHint,!hidden,innerText,inputMode,lang,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,outerText,!spellcheck,%style,#tabIndex,title,!translate,virtualKeyboardPolicy", "media^[HTMLElement]|!autoplay,!controls,%controlsList,%crossOrigin,#currentTime,!defaultMuted,#defaultPlaybackRate,!disableRemotePlayback,!loop,!muted,*encrypted,*waitingforkey,#playbackRate,preload,!preservesPitch,src,%srcObject,#volume", ":svg:^[HTMLElement]|!autofocus,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contextmenu,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,%style,#tabIndex", ":svg:graphics^:svg:|", ":svg:animation^:svg:|*begin,*end,*repeat", ":svg:geometry^:svg:|", ":svg:componentTransferFunction^:svg:|", ":svg:gradient^:svg:|", ":svg:textContent^:svg:graphics|", ":svg:textPositioning^:svg:textContent|", "a^[HTMLElement]|charset,coords,download,hash,host,hostname,href,hreflang,name,password,pathname,ping,port,protocol,referrerPolicy,rel,%relList,rev,search,shape,target,text,type,username", "area^[HTMLElement]|alt,coords,download,hash,host,hostname,href,!noHref,password,pathname,ping,port,protocol,referrerPolicy,rel,%relList,search,shape,target,username", "audio^media|", "br^[HTMLElement]|clear", "base^[HTMLElement]|href,target", "body^[HTMLElement]|aLink,background,bgColor,link,*afterprint,*beforeprint,*beforeunload,*blur,*error,*focus,*hashchange,*languagechange,*load,*message,*messageerror,*offline,*online,*pagehide,*pageshow,*popstate,*rejectionhandled,*resize,*scroll,*storage,*unhandledrejection,*unload,text,vLink", "button^[HTMLElement]|!disabled,formAction,formEnctype,formMethod,!formNoValidate,formTarget,name,type,value", "canvas^[HTMLElement]|#height,#width", "content^[HTMLElement]|select", "dl^[HTMLElement]|!compact", "data^[HTMLElement]|value", "datalist^[HTMLElement]|", "details^[HTMLElement]|!open", "dialog^[HTMLElement]|!open,returnValue", "dir^[HTMLElement]|!compact", "div^[HTMLElement]|align", "embed^[HTMLElement]|align,height,name,src,type,width", "fieldset^[HTMLElement]|!disabled,name", "font^[HTMLElement]|color,face,size", "form^[HTMLElement]|acceptCharset,action,autocomplete,encoding,enctype,method,name,!noValidate,target", "frame^[HTMLElement]|frameBorder,longDesc,marginHeight,marginWidth,name,!noResize,scrolling,src", "frameset^[HTMLElement]|cols,*afterprint,*beforeprint,*beforeunload,*blur,*error,*focus,*hashchange,*languagechange,*load,*message,*messageerror,*offline,*online,*pagehide,*pageshow,*popstate,*rejectionhandled,*resize,*scroll,*storage,*unhandledrejection,*unload,rows", "geolocation^[HTMLElement]|accuracymode,!autolocate,*location,*promptaction,*promptdismiss,*validationstatuschange,!watch", "hr^[HTMLElement]|align,color,!noShade,size,width", "head^[HTMLElement]|", "h1,h2,h3,h4,h5,h6^[HTMLElement]|align", "html^[HTMLElement]|version", "iframe^[HTMLElement]|align,allow,!allowFullscreen,!allowPaymentRequest,csp,!credentialless,frameBorder,height,loading,longDesc,marginHeight,marginWidth,name,referrerPolicy,%sandbox,scrolling,src,srcdoc,width", "img^[HTMLElement]|align,alt,border,%crossOrigin,decoding,#height,#hspace,!isMap,loading,longDesc,lowsrc,name,referrerPolicy,sizes,src,srcset,useMap,#vspace,#width", "input^[HTMLElement]|accept,align,alt,autocomplete,!checked,!defaultChecked,defaultValue,dirName,!disabled,%files,formAction,formEnctype,formMethod,!formNoValidate,formTarget,#height,!incremental,!indeterminate,max,#maxLength,min,#minLength,!multiple,name,pattern,placeholder,!readOnly,!required,selectionDirection,#selectionEnd,#selectionStart,#size,src,step,type,useMap,value,%valueAsDate,#valueAsNumber,#width", "li^[HTMLElement]|type,#value", "label^[HTMLElement]|htmlFor", "legend^[HTMLElement]|align", "link^[HTMLElement]|as,charset,%crossOrigin,!disabled,href,hreflang,imageSizes,imageSrcset,integrity,media,referrerPolicy,rel,%relList,rev,%sizes,target,type", "map^[HTMLElement]|name", "marquee^[HTMLElement]|behavior,bgColor,direction,height,#hspace,#loop,#scrollAmount,#scrollDelay,!trueSpeed,#vspace,width", "menu^[HTMLElement]|!compact", "meta^[HTMLElement]|content,httpEquiv,media,name,scheme", "meter^[HTMLElement]|#high,#low,#max,#min,#optimum,#value", "ins,del^[HTMLElement]|cite,dateTime", "ol^[HTMLElement]|!compact,!reversed,#start,type", "object^[HTMLElement]|align,archive,border,code,codeBase,codeType,data,!declare,height,#hspace,name,standby,type,useMap,#vspace,width", "optgroup^[HTMLElement]|!disabled,label", "option^[HTMLElement]|!defaultSelected,!disabled,label,!selected,text,value", "output^[HTMLElement]|defaultValue,%htmlFor,name,value", "p^[HTMLElement]|align", "param^[HTMLElement]|name,type,value,valueType", "picture^[HTMLElement]|", "pre^[HTMLElement]|#width", "progress^[HTMLElement]|#max,#value", "q,blockquote,cite^[HTMLElement]|", "script^[HTMLElement]|!async,charset,%crossOrigin,!defer,event,htmlFor,integrity,!noModule,%referrerPolicy,src,text,type", "select^[HTMLElement]|autocomplete,!disabled,#length,!multiple,name,!required,#selectedIndex,#size,value", "selectedcontent^[HTMLElement]|", "slot^[HTMLElement]|name", "source^[HTMLElement]|#height,media,sizes,src,srcset,type,#width", "span^[HTMLElement]|", "style^[HTMLElement]|!disabled,media,type", "search^[HTMLELement]|", "caption^[HTMLElement]|align", "th,td^[HTMLElement]|abbr,align,axis,bgColor,ch,chOff,#colSpan,headers,height,!noWrap,#rowSpan,scope,vAlign,width", "col,colgroup^[HTMLElement]|align,ch,chOff,#span,vAlign,width", "table^[HTMLElement]|align,bgColor,border,%caption,cellPadding,cellSpacing,frame,rules,summary,%tFoot,%tHead,width", "tr^[HTMLElement]|align,bgColor,ch,chOff,vAlign", "tfoot,thead,tbody^[HTMLElement]|align,ch,chOff,vAlign", "template^[HTMLElement]|", "textarea^[HTMLElement]|autocomplete,#cols,defaultValue,dirName,!disabled,#maxLength,#minLength,name,placeholder,!readOnly,!required,#rows,selectionDirection,#selectionEnd,#selectionStart,value,wrap", "time^[HTMLElement]|dateTime", "title^[HTMLElement]|text", "track^[HTMLElement]|!default,kind,label,src,srclang", "ul^[HTMLElement]|!compact,type", "unknown^[HTMLElement]|", "video^media|!disablePictureInPicture,#height,*enterpictureinpicture,*leavepictureinpicture,!playsInline,poster,#width", ":svg:a^:svg:graphics|", ":svg:animate^:svg:animation|", ":svg:animateMotion^:svg:animation|", ":svg:animateTransform^:svg:animation|", ":svg:circle^:svg:geometry|", ":svg:clipPath^:svg:graphics|", ":svg:defs^:svg:graphics|", ":svg:desc^:svg:|", ":svg:discard^:svg:|", ":svg:ellipse^:svg:geometry|", ":svg:feBlend^:svg:|", ":svg:feColorMatrix^:svg:|", ":svg:feComponentTransfer^:svg:|", ":svg:feComposite^:svg:|", ":svg:feConvolveMatrix^:svg:|", ":svg:feDiffuseLighting^:svg:|", ":svg:feDisplacementMap^:svg:|", ":svg:feDistantLight^:svg:|", ":svg:feDropShadow^:svg:|", ":svg:feFlood^:svg:|", ":svg:feFuncA^:svg:componentTransferFunction|", ":svg:feFuncB^:svg:componentTransferFunction|", ":svg:feFuncG^:svg:componentTransferFunction|", ":svg:feFuncR^:svg:componentTransferFunction|", ":svg:feGaussianBlur^:svg:|", ":svg:feImage^:svg:|", ":svg:feMerge^:svg:|", ":svg:feMergeNode^:svg:|", ":svg:feMorphology^:svg:|", ":svg:feOffset^:svg:|", ":svg:fePointLight^:svg:|", ":svg:feSpecularLighting^:svg:|", ":svg:feSpotLight^:svg:|", ":svg:feTile^:svg:|", ":svg:feTurbulence^:svg:|", ":svg:filter^:svg:|", ":svg:foreignObject^:svg:graphics|", ":svg:g^:svg:graphics|", ":svg:image^:svg:graphics|decoding", ":svg:line^:svg:geometry|", ":svg:linearGradient^:svg:gradient|", ":svg:mpath^:svg:|", ":svg:marker^:svg:|", ":svg:mask^:svg:|", ":svg:metadata^:svg:|", ":svg:path^:svg:geometry|", ":svg:pattern^:svg:|", ":svg:polygon^:svg:geometry|", ":svg:polyline^:svg:geometry|", ":svg:radialGradient^:svg:gradient|", ":svg:rect^:svg:geometry|", ":svg:svg^:svg:graphics|#currentScale,#zoomAndPan", ":svg:script^:svg:|type", ":svg:set^:svg:animation|", ":svg:stop^:svg:|", ":svg:style^:svg:|!disabled,media,title,type", ":svg:switch^:svg:graphics|", ":svg:symbol^:svg:|", ":svg:tspan^:svg:textPositioning|", ":svg:text^:svg:textPositioning|", ":svg:textPath^:svg:textContent|", ":svg:title^:svg:|", ":svg:use^:svg:graphics|", ":svg:view^:svg:|#zoomAndPan", "data^[HTMLElement]|value", "keygen^[HTMLElement]|!autofocus,challenge,!disabled,form,keytype,name", "menuitem^[HTMLElement]|type,label,icon,!disabled,!checked,radiogroup,!default", "summary^[HTMLElement]|", "time^[HTMLElement]|dateTime", ":svg:cursor^:svg:|", ":math:^[HTMLElement]|!autofocus,nonce,*abort,*animationend,*animationiteration,*animationstart,*auxclick,*beforeinput,*beforematch,*beforetoggle,*beforexrselect,*blur,*cancel,*canplay,*canplaythrough,*change,*click,*close,*contentvisibilityautostatechange,*contextlost,*contextmenu,*contextrestored,*copy,*cuechange,*cut,*dblclick,*drag,*dragend,*dragenter,*dragleave,*dragover,*dragstart,*drop,*durationchange,*emptied,*ended,*error,*focus,*formdata,*gotpointercapture,*input,*invalid,*keydown,*keypress,*keyup,*load,*loadeddata,*loadedmetadata,*loadstart,*lostpointercapture,*mousedown,*mouseenter,*mouseleave,*mousemove,*mouseout,*mouseover,*mouseup,*mousewheel,*paste,*pause,*play,*playing,*pointercancel,*pointerdown,*pointerenter,*pointerleave,*pointermove,*pointerout,*pointerover,*pointerrawupdate,*pointerup,*progress,*ratechange,*reset,*resize,*scroll,*scrollend,*securitypolicyviolation,*seeked,*seeking,*select,*selectionchange,*selectstart,*slotchange,*stalled,*submit,*suspend,*timeupdate,*toggle,*transitioncancel,*transitionend,*transitionrun,*transitionstart,*volumechange,*waiting,*webkitanimationend,*webkitanimationiteration,*webkitanimationstart,*webkittransitionend,*wheel,%style,#tabIndex", ":math:math^:math:|", ":math:maction^:math:|", ":math:menclose^:math:|", ":math:merror^:math:|", ":math:mfenced^:math:|", ":math:mfrac^:math:|", ":math:mi^:math:|", ":math:mmultiscripts^:math:|", ":math:mn^:math:|", ":math:mo^:math:|", ":math:mover^:math:|", ":math:mpadded^:math:|", ":math:mphantom^:math:|", ":math:mroot^:math:|", ":math:mrow^:math:|", ":math:ms^:math:|", ":math:mspace^:math:|", ":math:msqrt^:math:|", ":math:mstyle^:math:|", ":math:msub^:math:|", ":math:msubsup^:math:|", ":math:msup^:math:|", ":math:mtable^:math:|", ":math:mtd^:math:|", ":math:mtext^:math:|", ":math:mtr^:math:|", ":math:munder^:math:|", ":math:munderover^:math:|", ":math:semantics^:math:|"], mi = new Map(Object.entries({ class: "className", for: "htmlFor", formaction: "formAction", innerHtml: "innerHTML", readonly: "readOnly", tabindex: "tabIndex", "aria-activedescendant": "ariaActiveDescendantElement", "aria-atomic": "ariaAtomic", "aria-autocomplete": "ariaAutoComplete", "aria-busy": "ariaBusy", "aria-checked": "ariaChecked", "aria-colcount": "ariaColCount", "aria-colindex": "ariaColIndex", "aria-colindextext": "ariaColIndexText", "aria-colspan": "ariaColSpan", "aria-controls": "ariaControlsElements", "aria-current": "ariaCurrent", "aria-describedby": "ariaDescribedByElements", "aria-description": "ariaDescription", "aria-details": "ariaDetailsElements", "aria-disabled": "ariaDisabled", "aria-errormessage": "ariaErrorMessageElements", "aria-expanded": "ariaExpanded", "aria-flowto": "ariaFlowToElements", "aria-haspopup": "ariaHasPopup", "aria-hidden": "ariaHidden", "aria-invalid": "ariaInvalid", "aria-keyshortcuts": "ariaKeyShortcuts", "aria-label": "ariaLabel", "aria-labelledby": "ariaLabelledByElements", "aria-level": "ariaLevel", "aria-live": "ariaLive", "aria-modal": "ariaModal", "aria-multiline": "ariaMultiLine", "aria-multiselectable": "ariaMultiSelectable", "aria-orientation": "ariaOrientation", "aria-owns": "ariaOwnsElements", "aria-placeholder": "ariaPlaceholder", "aria-posinset": "ariaPosInSet", "aria-pressed": "ariaPressed", "aria-readonly": "ariaReadOnly", "aria-required": "ariaRequired", "aria-roledescription": "ariaRoleDescription", "aria-rowcount": "ariaRowCount", "aria-rowindex": "ariaRowIndex", "aria-rowindextext": "ariaRowIndexText", "aria-rowspan": "ariaRowSpan", "aria-selected": "ariaSelected", "aria-setsize": "ariaSetSize", "aria-sort": "ariaSort", "aria-valuemax": "ariaValueMax", "aria-valuemin": "ariaValueMin", "aria-valuenow": "ariaValueNow", "aria-valuetext": "ariaValueText" })), Va = Array.from(mi).reduce((e, [t, r]) => (e.set(t, r), e), /* @__PURE__ */ new Map()), fi = class extends hi {
    _schema = /* @__PURE__ */ new Map();
    _eventSchema = /* @__PURE__ */ new Map();
    constructor() {
      super(), Fa.forEach((e) => {
        let t = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), [n, i] = e.split("|"), s = i.split(","), [a, o] = n.split("^");
        a.split(",").forEach((c) => {
          this._schema.set(c.toLowerCase(), t), this._eventSchema.set(c.toLowerCase(), r);
        });
        let l = o && this._schema.get(o.toLowerCase());
        if (l) {
          for (let [c, u] of l) t.set(c, u);
          for (let c of this._eventSchema.get(o.toLowerCase())) r.add(c);
        }
        s.forEach((c) => {
          if (c.length > 0) switch (c[0]) {
            case "*":
              r.add(c.substring(1));
              break;
            case "!":
              t.set(c.substring(1), Ma);
              break;
            case "#":
              t.set(c.substring(1), Ba);
              break;
            case "%":
              t.set(c.substring(1), Ha);
              break;
            default:
              t.set(c, qa);
          }
        });
      });
    }
    hasProperty(e, t, r) {
      if (r.some((i) => i.name === mr.name)) return true;
      let n = Dt(e);
      if (n.includes("-")) {
        if (cr(n) || ur(n)) return false;
        if (r.some((i) => i.name === hr.name)) return true;
      }
      return (this._schema.get(n) || this._schema.get("unknown")).has(t);
    }
    hasElement(e, t) {
      if (t.some((n) => n.name === mr.name)) return true;
      let r = Dt(e);
      return r.includes("-") && (cr(r) || ur(r) || t.some((n) => n.name === hr.name)) ? true : this._schema.has(r);
    }
    securityContext(e, t, r) {
      r && (t = this.getMappedPropName(t));
      let [n, i] = Z(e, false);
      return ui(i, t, n);
    }
    getMappedPropName(e) {
      return mi.get(e) ?? e;
    }
    getDefaultComponentElementName() {
      return "ng-component";
    }
    validateProperty(e) {
      return e.toLowerCase().startsWith("on") ? { error: true, msg: \`Binding to event property '\${e}' is disallowed for security reasons, please use (\${e.slice(2)})=...
If '\${e}' is a directive input, make sure the directive is imported by the current module.\` } : { error: false };
    }
    validateAttribute(e) {
      return e.toLowerCase().startsWith("on") ? { error: true, msg: \`Binding to event attribute '\${e}' is disallowed for security reasons, please use (\${e.slice(2)})=...\` } : { error: false };
    }
    allKnownElementNames() {
      return Array.from(this._schema.keys());
    }
    allKnownAttributesOfElement(e) {
      let t = Dt(e), r = this._schema.get(t) || this._schema.get("unknown");
      return Array.from(r.keys()).map((n) => Va.get(n) ?? n);
    }
    allKnownEventsOfElement(e) {
      let t = Dt(e);
      return Array.from(this._eventSchema.get(t) ?? []);
    }
    normalizeAnimationStyleProperty(e) {
      return pi(e);
    }
    normalizeAnimationStyleValue(e, t, r) {
      let n = "", i = r.toString().trim(), s = null;
      if (Ua(e) && r !== 0 && r !== "0") if (typeof r == "number") n = "px";
      else {
        let a = r.match(/^[+-]?[\\d\\.]+([a-z]*)$/);
        a && a[1].length == 0 && (s = \`Please provide a CSS unit value for \${t}:\${r}\`);
      }
      return { error: s, value: i + n };
    }
  };
  function Ua(e) {
    switch (e) {
      case "width":
      case "height":
      case "minWidth":
      case "minHeight":
      case "maxWidth":
      case "maxHeight":
      case "left":
      case "top":
      case "bottom":
      case "right":
      case "fontSize":
      case "outlineWidth":
      case "outlineOffset":
      case "paddingTop":
      case "paddingLeft":
      case "paddingBottom":
      case "paddingRight":
      case "marginTop":
      case "marginLeft":
      case "marginBottom":
      case "marginRight":
      case "borderRadius":
      case "borderWidth":
      case "borderTopWidth":
      case "borderLeftWidth":
      case "borderRightWidth":
      case "borderBottomWidth":
      case "textIndent":
        return true;
      default:
        return false;
    }
  }
  var m = class {
    closedByChildren = {};
    contentType;
    closedByParent = false;
    implicitNamespacePrefix;
    isVoid;
    ignoreFirstLf;
    canSelfClose;
    preventNamespaceInheritance;
    constructor({ closedByChildren: e, implicitNamespacePrefix: t, contentType: r = 2, closedByParent: n = false, isVoid: i = false, ignoreFirstLf: s = false, preventNamespaceInheritance: a = false, canSelfClose: o = false } = {}) {
      e && e.length > 0 && e.forEach((l) => this.closedByChildren[l] = true), this.isVoid = i, this.closedByParent = n || i, this.implicitNamespacePrefix = t || null, this.contentType = r, this.ignoreFirstLf = s, this.preventNamespaceInheritance = a, this.canSelfClose = o ?? i;
    }
    isClosedByChild(e) {
      return this.isVoid || e.toLowerCase() in this.closedByChildren;
    }
    getContentType(e) {
      return typeof this.contentType == "object" ? (e === void 0 ? void 0 : this.contentType[e]) ?? this.contentType.default : this.contentType;
    }
  }, di, tt;
  function Ne(e) {
    return tt || (di = new m({ canSelfClose: true }), tt = Object.assign(/* @__PURE__ */ Object.create(null), { base: new m({ isVoid: true }), meta: new m({ isVoid: true }), area: new m({ isVoid: true }), embed: new m({ isVoid: true }), link: new m({ isVoid: true }), img: new m({ isVoid: true }), input: new m({ isVoid: true }), param: new m({ isVoid: true }), hr: new m({ isVoid: true }), br: new m({ isVoid: true }), source: new m({ isVoid: true }), track: new m({ isVoid: true }), wbr: new m({ isVoid: true }), p: new m({ closedByChildren: ["address", "article", "aside", "blockquote", "div", "dl", "fieldset", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "main", "nav", "ol", "p", "pre", "section", "table", "ul"], closedByParent: true }), thead: new m({ closedByChildren: ["tbody", "tfoot"] }), tbody: new m({ closedByChildren: ["tbody", "tfoot"], closedByParent: true }), tfoot: new m({ closedByChildren: ["tbody"], closedByParent: true }), tr: new m({ closedByChildren: ["tr"], closedByParent: true }), td: new m({ closedByChildren: ["td", "th"], closedByParent: true }), th: new m({ closedByChildren: ["td", "th"], closedByParent: true }), col: new m({ isVoid: true }), svg: new m({ implicitNamespacePrefix: "svg" }), foreignObject: new m({ implicitNamespacePrefix: "svg", preventNamespaceInheritance: true }), math: new m({ implicitNamespacePrefix: "math" }), li: new m({ closedByChildren: ["li"], closedByParent: true }), dt: new m({ closedByChildren: ["dt", "dd"] }), dd: new m({ closedByChildren: ["dt", "dd"], closedByParent: true }), rb: new m({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: true }), rt: new m({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: true }), rtc: new m({ closedByChildren: ["rb", "rtc", "rp"], closedByParent: true }), rp: new m({ closedByChildren: ["rb", "rt", "rtc", "rp"], closedByParent: true }), optgroup: new m({ closedByChildren: ["optgroup"], closedByParent: true }), option: new m({ closedByChildren: ["option", "optgroup"], closedByParent: true }), pre: new m({ ignoreFirstLf: true }), listing: new m({ ignoreFirstLf: true }), style: new m({ contentType: 0 }), script: new m({ contentType: 0 }), title: new m({ contentType: { default: 1, svg: 2 } }), textarea: new m({ contentType: 1, ignoreFirstLf: true }) }), new fi().allKnownElementNames().forEach((t) => {
      !tt[t] && Pe(t) === null && (tt[t] = new m({ canSelfClose: false }));
    })), tt[e] ?? di;
  }
  var De = class gi {
    file;
    offset;
    line;
    col;
    constructor(t, r, n, i) {
      this.file = t, this.offset = r, this.line = n, this.col = i;
    }
    toString() {
      return this.offset != null ? \`\${this.file.url}@\${this.line}:\${this.col}\` : this.file.url;
    }
    moveBy(t) {
      let r = this.file.content, n = r.length, i = this.offset, s = this.line, a = this.col;
      for (; i > 0 && t < 0; ) if (i--, t++, r.charCodeAt(i) == 10) {
        s--;
        let o = r.substring(0, i - 1).lastIndexOf(\`
\`);
        a = o > 0 ? i - o : i;
      } else a--;
      for (; i < n && t > 0; ) {
        let o = r.charCodeAt(i);
        i++, t--, o == 10 ? (s++, a = 0) : a++;
      }
      return new gi(this.file, i, s, a);
    }
    getContext(t, r) {
      let n = this.file.content, i = this.offset;
      if (i != null) {
        i > n.length - 1 && (i = n.length - 1);
        let s = i, a = 0, o = 0;
        for (; a < t && i > 0 && (i--, a++, !(n[i] == \`
\` && ++o == r)); ) ;
        for (a = 0, o = 0; a < t && s < n.length - 1 && (s++, a++, !(n[s] == \`
\` && ++o == r)); ) ;
        return { before: n.substring(i, this.offset), after: n.substring(this.offset, s + 1) };
      }
      return null;
    }
  }, rt = class {
    content;
    url;
    constructor(e, t) {
      this.content = e, this.url = t;
    }
  }, p = class {
    start;
    end;
    fullStart;
    details;
    constructor(e, t, r = e, n = null) {
      this.start = e, this.end = t, this.fullStart = r, this.details = n;
    }
    toString() {
      return this.start.file.content.substring(this.start.offset, this.end.offset);
    }
  }, Wa = (function(e) {
    return e[e.WARNING = 0] = "WARNING", e[e.ERROR = 1] = "ERROR", e;
  })({}), te = class extends Error {
    span;
    msg;
    level;
    relatedError;
    constructor(e, t, r = 1, n) {
      super(t), this.span = e, this.msg = t, this.level = r, this.relatedError = n, Object.setPrototypeOf(this, new.target.prototype);
    }
    contextualMessage() {
      let e = this.span.start.getContext(100, 3);
      return e ? \`\${this.msg} ("\${e.before}[\${Wa[this.level]} ->]\${e.after}")\` : this.msg;
    }
    toString() {
      let e = this.span.details ? \`, \${this.span.details}\` : "";
      return \`\${this.contextualMessage()}: \${this.span.start}\${e}\`;
    }
  };
  var de = class {
    sourceSpan;
    i18n;
    constructor(e, t) {
      this.sourceSpan = e, this.i18n = t;
    }
  }, _i = class extends de {
    value;
    tokens;
    constructor(e, t, r, n) {
      super(t, n), this.value = e, this.tokens = r;
    }
    visit(e, t) {
      return e.visitText(this, t);
    }
    kind = "text";
  }, Si = class extends de {
    value;
    tokens;
    constructor(e, t, r, n) {
      super(t, n), this.value = e, this.tokens = r;
    }
    visit(e, t) {
      return e.visitCdata(this, t);
    }
    kind = "cdata";
  }, vi = class extends de {
    switchValue;
    type;
    cases;
    switchValueSourceSpan;
    constructor(e, t, r, n, i, s) {
      super(n, s), this.switchValue = e, this.type = t, this.cases = r, this.switchValueSourceSpan = i;
    }
    visit(e, t) {
      return e.visitExpansion(this, t);
    }
    kind = "expansion";
  }, Ci = class {
    value;
    expression;
    sourceSpan;
    valueSourceSpan;
    expSourceSpan;
    constructor(e, t, r, n, i) {
      this.value = e, this.expression = t, this.sourceSpan = r, this.valueSourceSpan = n, this.expSourceSpan = i;
    }
    visit(e, t) {
      return e.visitExpansionCase(this, t);
    }
    kind = "expansionCase";
  }, ki = class extends de {
    name;
    value;
    keySpan;
    valueSpan;
    valueTokens;
    constructor(e, t, r, n, i, s, a) {
      super(r, a), this.name = e, this.value = t, this.keySpan = n, this.valueSpan = i, this.valueTokens = s;
    }
    visit(e, t) {
      return e.visitAttribute(this, t);
    }
    kind = "attribute";
    get nameSpan() {
      return this.keySpan;
    }
  }, bi = class {
    value;
    type;
    sourceSpan;
    constructor(e, t, r) {
      this.value = e, this.type = t, this.sourceSpan = r;
    }
    visit(e, t) {
      return e.visitStartTagComment ? e.visitStartTagComment(this, t) : void 0;
    }
    kind = "startTagComment";
  }, re = class extends de {
    name;
    attrs;
    directives;
    children;
    isSelfClosing;
    startSourceSpan;
    endSourceSpan;
    nameSpan;
    isVoid;
    comments;
    constructor(e, t, r, n, i, s, a, o = null, l = null, c, u, d = []) {
      super(s, u), this.name = e, this.attrs = t, this.directives = r, this.children = n, this.isSelfClosing = i, this.startSourceSpan = a, this.endSourceSpan = o, this.nameSpan = l, this.isVoid = c, this.comments = d;
    }
    visit(e, t) {
      return e.visitElement(this, t);
    }
    kind = "element";
  }, wi = class {
    value;
    sourceSpan;
    constructor(e, t) {
      this.value = e, this.sourceSpan = t;
    }
    visit(e, t) {
      return e.visitComment(this, t);
    }
    kind = "comment";
  }, Ti = class {
    value;
    sourceSpan;
    constructor(e, t) {
      this.value = e, this.sourceSpan = t;
    }
    visit(e, t) {
      return e.visitDocType(this, t);
    }
    kind = "docType";
  }, ge = class extends de {
    name;
    parameters;
    children;
    nameSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, r, n, i, s, a = null, o) {
      super(n, o), this.name = e, this.parameters = t, this.children = r, this.nameSpan = i, this.startSourceSpan = s, this.endSourceSpan = a;
    }
    visit(e, t) {
      return e.visitBlock(this, t);
    }
    kind = "block";
  }, U = class extends de {
    componentName;
    tagName;
    fullName;
    attrs;
    directives;
    children;
    isSelfClosing;
    startSourceSpan;
    endSourceSpan;
    comments;
    constructor(e, t, r, n, i, s, a, o, l, c = null, u, d = []) {
      super(o, u), this.componentName = e, this.tagName = t, this.fullName = r, this.attrs = n, this.directives = i, this.children = s, this.isSelfClosing = a, this.startSourceSpan = l, this.endSourceSpan = c, this.comments = d;
    }
    visit(e, t) {
      return e.visitComponent(this, t);
    }
    kind = "component";
  }, yi = class {
    name;
    attrs;
    sourceSpan;
    startSourceSpan;
    endSourceSpan;
    constructor(e, t, r, n, i = null) {
      this.name = e, this.attrs = t, this.sourceSpan = r, this.startSourceSpan = n, this.endSourceSpan = i;
    }
    visit(e, t) {
      return e.visitDirective(this, t);
    }
    kind = "directive";
  }, fr = class {
    expression;
    sourceSpan;
    constructor(e, t) {
      this.expression = e, this.sourceSpan = t;
    }
    visit(e, t) {
      return e.visitBlockParameter(this, t);
    }
    kind = "blockParameter";
    startSourceSpan = null;
    endSourceSpan = null;
  }, dr = class {
    name;
    value;
    sourceSpan;
    nameSpan;
    valueSpan;
    constructor(e, t, r, n, i) {
      this.name = e, this.value = t, this.sourceSpan = r, this.nameSpan = n, this.valueSpan = i;
    }
    visit(e, t) {
      return e.visitLetDeclaration(this, t);
    }
    kind = "letDeclaration";
    startSourceSpan = null;
    endSourceSpan = null;
  };
  function It(e, t, r = null) {
    let n = [], i = e.visit ? (s) => e.visit(s, r) || s.visit(e, r) : (s) => s.visit(e, r);
    return t.forEach((s) => {
      let a = i(s);
      a && n.push(a);
    }), n;
  }
  var gr = class {
    constructor() {
    }
    visitElement(e, t) {
      this.visitChildren(t, (r) => {
        r(e.attrs), r(e.directives), r(e.comments), r(e.children);
      });
    }
    visitAttribute(e, t) {
    }
    visitStartTagComment(e, t) {
    }
    visitText(e, t) {
    }
    visitCdata(e, t) {
    }
    visitComment(e, t) {
    }
    visitDocType(e, t) {
    }
    visitExpansion(e, t) {
      return this.visitChildren(t, (r) => {
        r(e.cases);
      });
    }
    visitExpansionCase(e, t) {
    }
    visitBlock(e, t) {
      this.visitChildren(t, (r) => {
        r(e.parameters), r(e.children);
      });
    }
    visitBlockParameter(e, t) {
    }
    visitLetDeclaration(e, t) {
    }
    visitComponent(e, t) {
      this.visitChildren(t, (r) => {
        r(e.attrs), r(e.comments), r(e.children);
      });
    }
    visitDirective(e, t) {
      this.visitChildren(t, (r) => {
        r(e.attrs);
      });
    }
    visitChildren(e, t) {
      let r = [], n = this;
      function i(s) {
        s && r.push(It(n, s, e));
      }
      return t(i), Array.prototype.concat.apply([], r);
    }
  };
  function nt(e) {
    return e >= 9 && e <= 32 || e == 160;
  }
  function Ie(e) {
    return 48 <= e && e <= 57;
  }
  function Re(e) {
    return e >= 97 && e <= 122 || e >= 65 && e <= 90;
  }
  function Ei(e) {
    return e >= 97 && e <= 102 || e >= 65 && e <= 70 || Ie(e);
  }
  function Oe(e) {
    return e === 10 || e === 13;
  }
  function _r(e) {
    return 48 <= e && e <= 55;
  }
  function Rt(e) {
    return e === 39 || e === 34 || e === 96;
  }
  var _e = { AElig: "Æ", AMP: "&", amp: "&", Aacute: "Á", Abreve: "Ă", Acirc: "Â", Acy: "А", Afr: "𝔄", Agrave: "À", Alpha: "Α", Amacr: "Ā", And: "⩓", Aogon: "Ą", Aopf: "𝔸", ApplyFunction: "⁡", af: "⁡", Aring: "Å", angst: "Å", Ascr: "𝒜", Assign: "≔", colone: "≔", coloneq: "≔", Atilde: "Ã", Auml: "Ä", Backslash: "∖", setminus: "∖", setmn: "∖", smallsetminus: "∖", ssetmn: "∖", Barv: "⫧", Barwed: "⌆", doublebarwedge: "⌆", Bcy: "Б", Because: "∵", becaus: "∵", because: "∵", Bernoullis: "ℬ", Bscr: "ℬ", bernou: "ℬ", Beta: "Β", Bfr: "𝔅", Bopf: "𝔹", Breve: "˘", breve: "˘", Bumpeq: "≎", HumpDownHump: "≎", bump: "≎", CHcy: "Ч", COPY: "©", copy: "©", Cacute: "Ć", Cap: "⋒", CapitalDifferentialD: "ⅅ", DD: "ⅅ", Cayleys: "ℭ", Cfr: "ℭ", Ccaron: "Č", Ccedil: "Ç", Ccirc: "Ĉ", Cconint: "∰", Cdot: "Ċ", Cedilla: "¸", cedil: "¸", CenterDot: "·", centerdot: "·", middot: "·", Chi: "Χ", CircleDot: "⊙", odot: "⊙", CircleMinus: "⊖", ominus: "⊖", CirclePlus: "⊕", oplus: "⊕", CircleTimes: "⊗", otimes: "⊗", ClockwiseContourIntegral: "∲", cwconint: "∲", CloseCurlyDoubleQuote: "”", rdquo: "”", rdquor: "”", CloseCurlyQuote: "’", rsquo: "’", rsquor: "’", Colon: "∷", Proportion: "∷", Colone: "⩴", Congruent: "≡", equiv: "≡", Conint: "∯", DoubleContourIntegral: "∯", ContourIntegral: "∮", conint: "∮", oint: "∮", Copf: "ℂ", complexes: "ℂ", Coproduct: "∐", coprod: "∐", CounterClockwiseContourIntegral: "∳", awconint: "∳", Cross: "⨯", Cscr: "𝒞", Cup: "⋓", CupCap: "≍", asympeq: "≍", DDotrahd: "⤑", DJcy: "Ђ", DScy: "Ѕ", DZcy: "Џ", Dagger: "‡", ddagger: "‡", Darr: "↡", Dashv: "⫤", DoubleLeftTee: "⫤", Dcaron: "Ď", Dcy: "Д", Del: "∇", nabla: "∇", Delta: "Δ", Dfr: "𝔇", DiacriticalAcute: "´", acute: "´", DiacriticalDot: "˙", dot: "˙", DiacriticalDoubleAcute: "˝", dblac: "˝", DiacriticalGrave: "\`", grave: "\`", DiacriticalTilde: "˜", tilde: "˜", Diamond: "⋄", diam: "⋄", diamond: "⋄", DifferentialD: "ⅆ", dd: "ⅆ", Dopf: "𝔻", Dot: "¨", DoubleDot: "¨", die: "¨", uml: "¨", DotDot: "⃜", DotEqual: "≐", doteq: "≐", esdot: "≐", DoubleDownArrow: "⇓", Downarrow: "⇓", dArr: "⇓", DoubleLeftArrow: "⇐", Leftarrow: "⇐", lArr: "⇐", DoubleLeftRightArrow: "⇔", Leftrightarrow: "⇔", hArr: "⇔", iff: "⇔", DoubleLongLeftArrow: "⟸", Longleftarrow: "⟸", xlArr: "⟸", DoubleLongLeftRightArrow: "⟺", Longleftrightarrow: "⟺", xhArr: "⟺", DoubleLongRightArrow: "⟹", Longrightarrow: "⟹", xrArr: "⟹", DoubleRightArrow: "⇒", Implies: "⇒", Rightarrow: "⇒", rArr: "⇒", DoubleRightTee: "⊨", vDash: "⊨", DoubleUpArrow: "⇑", Uparrow: "⇑", uArr: "⇑", DoubleUpDownArrow: "⇕", Updownarrow: "⇕", vArr: "⇕", DoubleVerticalBar: "∥", par: "∥", parallel: "∥", shortparallel: "∥", spar: "∥", DownArrow: "↓", ShortDownArrow: "↓", darr: "↓", downarrow: "↓", DownArrowBar: "⤓", DownArrowUpArrow: "⇵", duarr: "⇵", DownBreve: "̑", DownLeftRightVector: "⥐", DownLeftTeeVector: "⥞", DownLeftVector: "↽", leftharpoondown: "↽", lhard: "↽", DownLeftVectorBar: "⥖", DownRightTeeVector: "⥟", DownRightVector: "⇁", rhard: "⇁", rightharpoondown: "⇁", DownRightVectorBar: "⥗", DownTee: "⊤", top: "⊤", DownTeeArrow: "↧", mapstodown: "↧", Dscr: "𝒟", Dstrok: "Đ", ENG: "Ŋ", ETH: "Ð", Eacute: "É", Ecaron: "Ě", Ecirc: "Ê", Ecy: "Э", Edot: "Ė", Efr: "𝔈", Egrave: "È", Element: "∈", in: "∈", isin: "∈", isinv: "∈", Emacr: "Ē", EmptySmallSquare: "◻", EmptyVerySmallSquare: "▫", Eogon: "Ę", Eopf: "𝔼", Epsilon: "Ε", Equal: "⩵", EqualTilde: "≂", eqsim: "≂", esim: "≂", Equilibrium: "⇌", rightleftharpoons: "⇌", rlhar: "⇌", Escr: "ℰ", expectation: "ℰ", Esim: "⩳", Eta: "Η", Euml: "Ë", Exists: "∃", exist: "∃", ExponentialE: "ⅇ", ee: "ⅇ", exponentiale: "ⅇ", Fcy: "Ф", Ffr: "𝔉", FilledSmallSquare: "◼", FilledVerySmallSquare: "▪", blacksquare: "▪", squarf: "▪", squf: "▪", Fopf: "𝔽", ForAll: "∀", forall: "∀", Fouriertrf: "ℱ", Fscr: "ℱ", GJcy: "Ѓ", GT: ">", gt: ">", Gamma: "Γ", Gammad: "Ϝ", Gbreve: "Ğ", Gcedil: "Ģ", Gcirc: "Ĝ", Gcy: "Г", Gdot: "Ġ", Gfr: "𝔊", Gg: "⋙", ggg: "⋙", Gopf: "𝔾", GreaterEqual: "≥", ge: "≥", geq: "≥", GreaterEqualLess: "⋛", gel: "⋛", gtreqless: "⋛", GreaterFullEqual: "≧", gE: "≧", geqq: "≧", GreaterGreater: "⪢", GreaterLess: "≷", gl: "≷", gtrless: "≷", GreaterSlantEqual: "⩾", geqslant: "⩾", ges: "⩾", GreaterTilde: "≳", gsim: "≳", gtrsim: "≳", Gscr: "𝒢", Gt: "≫", NestedGreaterGreater: "≫", gg: "≫", HARDcy: "Ъ", Hacek: "ˇ", caron: "ˇ", Hat: "^", Hcirc: "Ĥ", Hfr: "ℌ", Poincareplane: "ℌ", HilbertSpace: "ℋ", Hscr: "ℋ", hamilt: "ℋ", Hopf: "ℍ", quaternions: "ℍ", HorizontalLine: "─", boxh: "─", Hstrok: "Ħ", HumpEqual: "≏", bumpe: "≏", bumpeq: "≏", IEcy: "Е", IJlig: "Ĳ", IOcy: "Ё", Iacute: "Í", Icirc: "Î", Icy: "И", Idot: "İ", Ifr: "ℑ", Im: "ℑ", image: "ℑ", imagpart: "ℑ", Igrave: "Ì", Imacr: "Ī", ImaginaryI: "ⅈ", ii: "ⅈ", Int: "∬", Integral: "∫", int: "∫", Intersection: "⋂", bigcap: "⋂", xcap: "⋂", InvisibleComma: "⁣", ic: "⁣", InvisibleTimes: "⁢", it: "⁢", Iogon: "Į", Iopf: "𝕀", Iota: "Ι", Iscr: "ℐ", imagline: "ℐ", Itilde: "Ĩ", Iukcy: "І", Iuml: "Ï", Jcirc: "Ĵ", Jcy: "Й", Jfr: "𝔍", Jopf: "𝕁", Jscr: "𝒥", Jsercy: "Ј", Jukcy: "Є", KHcy: "Х", KJcy: "Ќ", Kappa: "Κ", Kcedil: "Ķ", Kcy: "К", Kfr: "𝔎", Kopf: "𝕂", Kscr: "𝒦", LJcy: "Љ", LT: "<", lt: "<", Lacute: "Ĺ", Lambda: "Λ", Lang: "⟪", Laplacetrf: "ℒ", Lscr: "ℒ", lagran: "ℒ", Larr: "↞", twoheadleftarrow: "↞", Lcaron: "Ľ", Lcedil: "Ļ", Lcy: "Л", LeftAngleBracket: "⟨", lang: "⟨", langle: "⟨", LeftArrow: "←", ShortLeftArrow: "←", larr: "←", leftarrow: "←", slarr: "←", LeftArrowBar: "⇤", larrb: "⇤", LeftArrowRightArrow: "⇆", leftrightarrows: "⇆", lrarr: "⇆", LeftCeiling: "⌈", lceil: "⌈", LeftDoubleBracket: "⟦", lobrk: "⟦", LeftDownTeeVector: "⥡", LeftDownVector: "⇃", dharl: "⇃", downharpoonleft: "⇃", LeftDownVectorBar: "⥙", LeftFloor: "⌊", lfloor: "⌊", LeftRightArrow: "↔", harr: "↔", leftrightarrow: "↔", LeftRightVector: "⥎", LeftTee: "⊣", dashv: "⊣", LeftTeeArrow: "↤", mapstoleft: "↤", LeftTeeVector: "⥚", LeftTriangle: "⊲", vartriangleleft: "⊲", vltri: "⊲", LeftTriangleBar: "⧏", LeftTriangleEqual: "⊴", ltrie: "⊴", trianglelefteq: "⊴", LeftUpDownVector: "⥑", LeftUpTeeVector: "⥠", LeftUpVector: "↿", uharl: "↿", upharpoonleft: "↿", LeftUpVectorBar: "⥘", LeftVector: "↼", leftharpoonup: "↼", lharu: "↼", LeftVectorBar: "⥒", LessEqualGreater: "⋚", leg: "⋚", lesseqgtr: "⋚", LessFullEqual: "≦", lE: "≦", leqq: "≦", LessGreater: "≶", lessgtr: "≶", lg: "≶", LessLess: "⪡", LessSlantEqual: "⩽", leqslant: "⩽", les: "⩽", LessTilde: "≲", lesssim: "≲", lsim: "≲", Lfr: "𝔏", Ll: "⋘", Lleftarrow: "⇚", lAarr: "⇚", Lmidot: "Ŀ", LongLeftArrow: "⟵", longleftarrow: "⟵", xlarr: "⟵", LongLeftRightArrow: "⟷", longleftrightarrow: "⟷", xharr: "⟷", LongRightArrow: "⟶", longrightarrow: "⟶", xrarr: "⟶", Lopf: "𝕃", LowerLeftArrow: "↙", swarr: "↙", swarrow: "↙", LowerRightArrow: "↘", searr: "↘", searrow: "↘", Lsh: "↰", lsh: "↰", Lstrok: "Ł", Lt: "≪", NestedLessLess: "≪", ll: "≪", Map: "⤅", Mcy: "М", MediumSpace: " ", Mellintrf: "ℳ", Mscr: "ℳ", phmmat: "ℳ", Mfr: "𝔐", MinusPlus: "∓", mnplus: "∓", mp: "∓", Mopf: "𝕄", Mu: "Μ", NJcy: "Њ", Nacute: "Ń", Ncaron: "Ň", Ncedil: "Ņ", Ncy: "Н", NegativeMediumSpace: "​", NegativeThickSpace: "​", NegativeThinSpace: "​", NegativeVeryThinSpace: "​", ZeroWidthSpace: "​", NewLine: \`
\`, Nfr: "𝔑", NoBreak: "⁠", NonBreakingSpace: " ", nbsp: " ", Nopf: "ℕ", naturals: "ℕ", Not: "⫬", NotCongruent: "≢", nequiv: "≢", NotCupCap: "≭", NotDoubleVerticalBar: "∦", npar: "∦", nparallel: "∦", nshortparallel: "∦", nspar: "∦", NotElement: "∉", notin: "∉", notinva: "∉", NotEqual: "≠", ne: "≠", NotEqualTilde: "≂̸", nesim: "≂̸", NotExists: "∄", nexist: "∄", nexists: "∄", NotGreater: "≯", ngt: "≯", ngtr: "≯", NotGreaterEqual: "≱", nge: "≱", ngeq: "≱", NotGreaterFullEqual: "≧̸", ngE: "≧̸", ngeqq: "≧̸", NotGreaterGreater: "≫̸", nGtv: "≫̸", NotGreaterLess: "≹", ntgl: "≹", NotGreaterSlantEqual: "⩾̸", ngeqslant: "⩾̸", nges: "⩾̸", NotGreaterTilde: "≵", ngsim: "≵", NotHumpDownHump: "≎̸", nbump: "≎̸", NotHumpEqual: "≏̸", nbumpe: "≏̸", NotLeftTriangle: "⋪", nltri: "⋪", ntriangleleft: "⋪", NotLeftTriangleBar: "⧏̸", NotLeftTriangleEqual: "⋬", nltrie: "⋬", ntrianglelefteq: "⋬", NotLess: "≮", nless: "≮", nlt: "≮", NotLessEqual: "≰", nle: "≰", nleq: "≰", NotLessGreater: "≸", ntlg: "≸", NotLessLess: "≪̸", nLtv: "≪̸", NotLessSlantEqual: "⩽̸", nleqslant: "⩽̸", nles: "⩽̸", NotLessTilde: "≴", nlsim: "≴", NotNestedGreaterGreater: "⪢̸", NotNestedLessLess: "⪡̸", NotPrecedes: "⊀", npr: "⊀", nprec: "⊀", NotPrecedesEqual: "⪯̸", npre: "⪯̸", npreceq: "⪯̸", NotPrecedesSlantEqual: "⋠", nprcue: "⋠", NotReverseElement: "∌", notni: "∌", notniva: "∌", NotRightTriangle: "⋫", nrtri: "⋫", ntriangleright: "⋫", NotRightTriangleBar: "⧐̸", NotRightTriangleEqual: "⋭", nrtrie: "⋭", ntrianglerighteq: "⋭", NotSquareSubset: "⊏̸", NotSquareSubsetEqual: "⋢", nsqsube: "⋢", NotSquareSuperset: "⊐̸", NotSquareSupersetEqual: "⋣", nsqsupe: "⋣", NotSubset: "⊂⃒", nsubset: "⊂⃒", vnsub: "⊂⃒", NotSubsetEqual: "⊈", nsube: "⊈", nsubseteq: "⊈", NotSucceeds: "⊁", nsc: "⊁", nsucc: "⊁", NotSucceedsEqual: "⪰̸", nsce: "⪰̸", nsucceq: "⪰̸", NotSucceedsSlantEqual: "⋡", nsccue: "⋡", NotSucceedsTilde: "≿̸", NotSuperset: "⊃⃒", nsupset: "⊃⃒", vnsup: "⊃⃒", NotSupersetEqual: "⊉", nsupe: "⊉", nsupseteq: "⊉", NotTilde: "≁", nsim: "≁", NotTildeEqual: "≄", nsime: "≄", nsimeq: "≄", NotTildeFullEqual: "≇", ncong: "≇", NotTildeTilde: "≉", nap: "≉", napprox: "≉", NotVerticalBar: "∤", nmid: "∤", nshortmid: "∤", nsmid: "∤", Nscr: "𝒩", Ntilde: "Ñ", Nu: "Ν", OElig: "Œ", Oacute: "Ó", Ocirc: "Ô", Ocy: "О", Odblac: "Ő", Ofr: "𝔒", Ograve: "Ò", Omacr: "Ō", Omega: "Ω", ohm: "Ω", Omicron: "Ο", Oopf: "𝕆", OpenCurlyDoubleQuote: "“", ldquo: "“", OpenCurlyQuote: "‘", lsquo: "‘", Or: "⩔", Oscr: "𝒪", Oslash: "Ø", Otilde: "Õ", Otimes: "⨷", Ouml: "Ö", OverBar: "‾", oline: "‾", OverBrace: "⏞", OverBracket: "⎴", tbrk: "⎴", OverParenthesis: "⏜", PartialD: "∂", part: "∂", Pcy: "П", Pfr: "𝔓", Phi: "Φ", Pi: "Π", PlusMinus: "±", plusmn: "±", pm: "±", Popf: "ℙ", primes: "ℙ", Pr: "⪻", Precedes: "≺", pr: "≺", prec: "≺", PrecedesEqual: "⪯", pre: "⪯", preceq: "⪯", PrecedesSlantEqual: "≼", prcue: "≼", preccurlyeq: "≼", PrecedesTilde: "≾", precsim: "≾", prsim: "≾", Prime: "″", Product: "∏", prod: "∏", Proportional: "∝", prop: "∝", propto: "∝", varpropto: "∝", vprop: "∝", Pscr: "𝒫", Psi: "Ψ", QUOT: '"', quot: '"', Qfr: "𝔔", Qopf: "ℚ", rationals: "ℚ", Qscr: "𝒬", RBarr: "⤐", drbkarow: "⤐", REG: "®", circledR: "®", reg: "®", Racute: "Ŕ", Rang: "⟫", Rarr: "↠", twoheadrightarrow: "↠", Rarrtl: "⤖", Rcaron: "Ř", Rcedil: "Ŗ", Rcy: "Р", Re: "ℜ", Rfr: "ℜ", real: "ℜ", realpart: "ℜ", ReverseElement: "∋", SuchThat: "∋", ni: "∋", niv: "∋", ReverseEquilibrium: "⇋", leftrightharpoons: "⇋", lrhar: "⇋", ReverseUpEquilibrium: "⥯", duhar: "⥯", Rho: "Ρ", RightAngleBracket: "⟩", rang: "⟩", rangle: "⟩", RightArrow: "→", ShortRightArrow: "→", rarr: "→", rightarrow: "→", srarr: "→", RightArrowBar: "⇥", rarrb: "⇥", RightArrowLeftArrow: "⇄", rightleftarrows: "⇄", rlarr: "⇄", RightCeiling: "⌉", rceil: "⌉", RightDoubleBracket: "⟧", robrk: "⟧", RightDownTeeVector: "⥝", RightDownVector: "⇂", dharr: "⇂", downharpoonright: "⇂", RightDownVectorBar: "⥕", RightFloor: "⌋", rfloor: "⌋", RightTee: "⊢", vdash: "⊢", RightTeeArrow: "↦", map: "↦", mapsto: "↦", RightTeeVector: "⥛", RightTriangle: "⊳", vartriangleright: "⊳", vrtri: "⊳", RightTriangleBar: "⧐", RightTriangleEqual: "⊵", rtrie: "⊵", trianglerighteq: "⊵", RightUpDownVector: "⥏", RightUpTeeVector: "⥜", RightUpVector: "↾", uharr: "↾", upharpoonright: "↾", RightUpVectorBar: "⥔", RightVector: "⇀", rharu: "⇀", rightharpoonup: "⇀", RightVectorBar: "⥓", Ropf: "ℝ", reals: "ℝ", RoundImplies: "⥰", Rrightarrow: "⇛", rAarr: "⇛", Rscr: "ℛ", realine: "ℛ", Rsh: "↱", rsh: "↱", RuleDelayed: "⧴", SHCHcy: "Щ", SHcy: "Ш", SOFTcy: "Ь", Sacute: "Ś", Sc: "⪼", Scaron: "Š", Scedil: "Ş", Scirc: "Ŝ", Scy: "С", Sfr: "𝔖", ShortUpArrow: "↑", UpArrow: "↑", uarr: "↑", uparrow: "↑", Sigma: "Σ", SmallCircle: "∘", compfn: "∘", Sopf: "𝕊", Sqrt: "√", radic: "√", Square: "□", squ: "□", square: "□", SquareIntersection: "⊓", sqcap: "⊓", SquareSubset: "⊏", sqsub: "⊏", sqsubset: "⊏", SquareSubsetEqual: "⊑", sqsube: "⊑", sqsubseteq: "⊑", SquareSuperset: "⊐", sqsup: "⊐", sqsupset: "⊐", SquareSupersetEqual: "⊒", sqsupe: "⊒", sqsupseteq: "⊒", SquareUnion: "⊔", sqcup: "⊔", Sscr: "𝒮", Star: "⋆", sstarf: "⋆", Sub: "⋐", Subset: "⋐", SubsetEqual: "⊆", sube: "⊆", subseteq: "⊆", Succeeds: "≻", sc: "≻", succ: "≻", SucceedsEqual: "⪰", sce: "⪰", succeq: "⪰", SucceedsSlantEqual: "≽", sccue: "≽", succcurlyeq: "≽", SucceedsTilde: "≿", scsim: "≿", succsim: "≿", Sum: "∑", sum: "∑", Sup: "⋑", Supset: "⋑", Superset: "⊃", sup: "⊃", supset: "⊃", SupersetEqual: "⊇", supe: "⊇", supseteq: "⊇", THORN: "Þ", TRADE: "™", trade: "™", TSHcy: "Ћ", TScy: "Ц", Tab: "	", Tau: "Τ", Tcaron: "Ť", Tcedil: "Ţ", Tcy: "Т", Tfr: "𝔗", Therefore: "∴", there4: "∴", therefore: "∴", Theta: "Θ", ThickSpace: "  ", ThinSpace: " ", thinsp: " ", Tilde: "∼", sim: "∼", thicksim: "∼", thksim: "∼", TildeEqual: "≃", sime: "≃", simeq: "≃", TildeFullEqual: "≅", cong: "≅", TildeTilde: "≈", ap: "≈", approx: "≈", asymp: "≈", thickapprox: "≈", thkap: "≈", Topf: "𝕋", TripleDot: "⃛", tdot: "⃛", Tscr: "𝒯", Tstrok: "Ŧ", Uacute: "Ú", Uarr: "↟", Uarrocir: "⥉", Ubrcy: "Ў", Ubreve: "Ŭ", Ucirc: "Û", Ucy: "У", Udblac: "Ű", Ufr: "𝔘", Ugrave: "Ù", Umacr: "Ū", UnderBar: "_", lowbar: "_", UnderBrace: "⏟", UnderBracket: "⎵", bbrk: "⎵", UnderParenthesis: "⏝", Union: "⋃", bigcup: "⋃", xcup: "⋃", UnionPlus: "⊎", uplus: "⊎", Uogon: "Ų", Uopf: "𝕌", UpArrowBar: "⤒", UpArrowDownArrow: "⇅", udarr: "⇅", UpDownArrow: "↕", updownarrow: "↕", varr: "↕", UpEquilibrium: "⥮", udhar: "⥮", UpTee: "⊥", bot: "⊥", bottom: "⊥", perp: "⊥", UpTeeArrow: "↥", mapstoup: "↥", UpperLeftArrow: "↖", nwarr: "↖", nwarrow: "↖", UpperRightArrow: "↗", nearr: "↗", nearrow: "↗", Upsi: "ϒ", upsih: "ϒ", Upsilon: "Υ", Uring: "Ů", Uscr: "𝒰", Utilde: "Ũ", Uuml: "Ü", VDash: "⊫", Vbar: "⫫", Vcy: "В", Vdash: "⊩", Vdashl: "⫦", Vee: "⋁", bigvee: "⋁", xvee: "⋁", Verbar: "‖", Vert: "‖", VerticalBar: "∣", mid: "∣", shortmid: "∣", smid: "∣", VerticalLine: "|", verbar: "|", vert: "|", VerticalSeparator: "❘", VerticalTilde: "≀", wr: "≀", wreath: "≀", VeryThinSpace: " ", hairsp: " ", Vfr: "𝔙", Vopf: "𝕍", Vscr: "𝒱", Vvdash: "⊪", Wcirc: "Ŵ", Wedge: "⋀", bigwedge: "⋀", xwedge: "⋀", Wfr: "𝔚", Wopf: "𝕎", Wscr: "𝒲", Xfr: "𝔛", Xi: "Ξ", Xopf: "𝕏", Xscr: "𝒳", YAcy: "Я", YIcy: "Ї", YUcy: "Ю", Yacute: "Ý", Ycirc: "Ŷ", Ycy: "Ы", Yfr: "𝔜", Yopf: "𝕐", Yscr: "𝒴", Yuml: "Ÿ", ZHcy: "Ж", Zacute: "Ź", Zcaron: "Ž", Zcy: "З", Zdot: "Ż", Zeta: "Ζ", Zfr: "ℨ", zeetrf: "ℨ", Zopf: "ℤ", integers: "ℤ", Zscr: "𝒵", aacute: "á", abreve: "ă", ac: "∾", mstpos: "∾", acE: "∾̳", acd: "∿", acirc: "â", acy: "а", aelig: "æ", afr: "𝔞", agrave: "à", alefsym: "ℵ", aleph: "ℵ", alpha: "α", amacr: "ā", amalg: "⨿", and: "∧", wedge: "∧", andand: "⩕", andd: "⩜", andslope: "⩘", andv: "⩚", ang: "∠", angle: "∠", ange: "⦤", angmsd: "∡", measuredangle: "∡", angmsdaa: "⦨", angmsdab: "⦩", angmsdac: "⦪", angmsdad: "⦫", angmsdae: "⦬", angmsdaf: "⦭", angmsdag: "⦮", angmsdah: "⦯", angrt: "∟", angrtvb: "⊾", angrtvbd: "⦝", angsph: "∢", angzarr: "⍼", aogon: "ą", aopf: "𝕒", apE: "⩰", apacir: "⩯", ape: "≊", approxeq: "≊", apid: "≋", apos: "'", aring: "å", ascr: "𝒶", ast: "*", midast: "*", atilde: "ã", auml: "ä", awint: "⨑", bNot: "⫭", backcong: "≌", bcong: "≌", backepsilon: "϶", bepsi: "϶", backprime: "‵", bprime: "‵", backsim: "∽", bsim: "∽", backsimeq: "⋍", bsime: "⋍", barvee: "⊽", barwed: "⌅", barwedge: "⌅", bbrktbrk: "⎶", bcy: "б", bdquo: "„", ldquor: "„", bemptyv: "⦰", beta: "β", beth: "ℶ", between: "≬", twixt: "≬", bfr: "𝔟", bigcirc: "◯", xcirc: "◯", bigodot: "⨀", xodot: "⨀", bigoplus: "⨁", xoplus: "⨁", bigotimes: "⨂", xotime: "⨂", bigsqcup: "⨆", xsqcup: "⨆", bigstar: "★", starf: "★", bigtriangledown: "▽", xdtri: "▽", bigtriangleup: "△", xutri: "△", biguplus: "⨄", xuplus: "⨄", bkarow: "⤍", rbarr: "⤍", blacklozenge: "⧫", lozf: "⧫", blacktriangle: "▴", utrif: "▴", blacktriangledown: "▾", dtrif: "▾", blacktriangleleft: "◂", ltrif: "◂", blacktriangleright: "▸", rtrif: "▸", blank: "␣", blk12: "▒", blk14: "░", blk34: "▓", block: "█", bne: "=⃥", bnequiv: "≡⃥", bnot: "⌐", bopf: "𝕓", bowtie: "⋈", boxDL: "╗", boxDR: "╔", boxDl: "╖", boxDr: "╓", boxH: "═", boxHD: "╦", boxHU: "╩", boxHd: "╤", boxHu: "╧", boxUL: "╝", boxUR: "╚", boxUl: "╜", boxUr: "╙", boxV: "║", boxVH: "╬", boxVL: "╣", boxVR: "╠", boxVh: "╫", boxVl: "╢", boxVr: "╟", boxbox: "⧉", boxdL: "╕", boxdR: "╒", boxdl: "┐", boxdr: "┌", boxhD: "╥", boxhU: "╨", boxhd: "┬", boxhu: "┴", boxminus: "⊟", minusb: "⊟", boxplus: "⊞", plusb: "⊞", boxtimes: "⊠", timesb: "⊠", boxuL: "╛", boxuR: "╘", boxul: "┘", boxur: "└", boxv: "│", boxvH: "╪", boxvL: "╡", boxvR: "╞", boxvh: "┼", boxvl: "┤", boxvr: "├", brvbar: "¦", bscr: "𝒷", bsemi: "⁏", bsol: "\\\\", bsolb: "⧅", bsolhsub: "⟈", bull: "•", bullet: "•", bumpE: "⪮", cacute: "ć", cap: "∩", capand: "⩄", capbrcup: "⩉", capcap: "⩋", capcup: "⩇", capdot: "⩀", caps: "∩︀", caret: "⁁", ccaps: "⩍", ccaron: "č", ccedil: "ç", ccirc: "ĉ", ccups: "⩌", ccupssm: "⩐", cdot: "ċ", cemptyv: "⦲", cent: "¢", cfr: "𝔠", chcy: "ч", check: "✓", checkmark: "✓", chi: "χ", cir: "○", cirE: "⧃", circ: "ˆ", circeq: "≗", cire: "≗", circlearrowleft: "↺", olarr: "↺", circlearrowright: "↻", orarr: "↻", circledS: "Ⓢ", oS: "Ⓢ", circledast: "⊛", oast: "⊛", circledcirc: "⊚", ocir: "⊚", circleddash: "⊝", odash: "⊝", cirfnint: "⨐", cirmid: "⫯", cirscir: "⧂", clubs: "♣", clubsuit: "♣", colon: ":", comma: ",", commat: "@", comp: "∁", complement: "∁", congdot: "⩭", copf: "𝕔", copysr: "℗", crarr: "↵", cross: "✗", cscr: "𝒸", csub: "⫏", csube: "⫑", csup: "⫐", csupe: "⫒", ctdot: "⋯", cudarrl: "⤸", cudarrr: "⤵", cuepr: "⋞", curlyeqprec: "⋞", cuesc: "⋟", curlyeqsucc: "⋟", cularr: "↶", curvearrowleft: "↶", cularrp: "⤽", cup: "∪", cupbrcap: "⩈", cupcap: "⩆", cupcup: "⩊", cupdot: "⊍", cupor: "⩅", cups: "∪︀", curarr: "↷", curvearrowright: "↷", curarrm: "⤼", curlyvee: "⋎", cuvee: "⋎", curlywedge: "⋏", cuwed: "⋏", curren: "¤", cwint: "∱", cylcty: "⌭", dHar: "⥥", dagger: "†", daleth: "ℸ", dash: "‐", hyphen: "‐", dbkarow: "⤏", rBarr: "⤏", dcaron: "ď", dcy: "д", ddarr: "⇊", downdownarrows: "⇊", ddotseq: "⩷", eDDot: "⩷", deg: "°", delta: "δ", demptyv: "⦱", dfisht: "⥿", dfr: "𝔡", diamondsuit: "♦", diams: "♦", digamma: "ϝ", gammad: "ϝ", disin: "⋲", div: "÷", divide: "÷", divideontimes: "⋇", divonx: "⋇", djcy: "ђ", dlcorn: "⌞", llcorner: "⌞", dlcrop: "⌍", dollar: "$", dopf: "𝕕", doteqdot: "≑", eDot: "≑", dotminus: "∸", minusd: "∸", dotplus: "∔", plusdo: "∔", dotsquare: "⊡", sdotb: "⊡", drcorn: "⌟", lrcorner: "⌟", drcrop: "⌌", dscr: "𝒹", dscy: "ѕ", dsol: "⧶", dstrok: "đ", dtdot: "⋱", dtri: "▿", triangledown: "▿", dwangle: "⦦", dzcy: "џ", dzigrarr: "⟿", eacute: "é", easter: "⩮", ecaron: "ě", ecir: "≖", eqcirc: "≖", ecirc: "ê", ecolon: "≕", eqcolon: "≕", ecy: "э", edot: "ė", efDot: "≒", fallingdotseq: "≒", efr: "𝔢", eg: "⪚", egrave: "è", egs: "⪖", eqslantgtr: "⪖", egsdot: "⪘", el: "⪙", elinters: "⏧", ell: "ℓ", els: "⪕", eqslantless: "⪕", elsdot: "⪗", emacr: "ē", empty: "∅", emptyset: "∅", emptyv: "∅", varnothing: "∅", emsp13: " ", emsp14: " ", emsp: " ", eng: "ŋ", ensp: " ", eogon: "ę", eopf: "𝕖", epar: "⋕", eparsl: "⧣", eplus: "⩱", epsi: "ε", epsilon: "ε", epsiv: "ϵ", straightepsilon: "ϵ", varepsilon: "ϵ", equals: "=", equest: "≟", questeq: "≟", equivDD: "⩸", eqvparsl: "⧥", erDot: "≓", risingdotseq: "≓", erarr: "⥱", escr: "ℯ", eta: "η", eth: "ð", euml: "ë", euro: "€", excl: "!", fcy: "ф", female: "♀", ffilig: "ﬃ", fflig: "ﬀ", ffllig: "ﬄ", ffr: "𝔣", filig: "ﬁ", fjlig: "fj", flat: "♭", fllig: "ﬂ", fltns: "▱", fnof: "ƒ", fopf: "𝕗", fork: "⋔", pitchfork: "⋔", forkv: "⫙", fpartint: "⨍", frac12: "½", half: "½", frac13: "⅓", frac14: "¼", frac15: "⅕", frac16: "⅙", frac18: "⅛", frac23: "⅔", frac25: "⅖", frac34: "¾", frac35: "⅗", frac38: "⅜", frac45: "⅘", frac56: "⅚", frac58: "⅝", frac78: "⅞", frasl: "⁄", frown: "⌢", sfrown: "⌢", fscr: "𝒻", gEl: "⪌", gtreqqless: "⪌", gacute: "ǵ", gamma: "γ", gap: "⪆", gtrapprox: "⪆", gbreve: "ğ", gcirc: "ĝ", gcy: "г", gdot: "ġ", gescc: "⪩", gesdot: "⪀", gesdoto: "⪂", gesdotol: "⪄", gesl: "⋛︀", gesles: "⪔", gfr: "𝔤", gimel: "ℷ", gjcy: "ѓ", glE: "⪒", gla: "⪥", glj: "⪤", gnE: "≩", gneqq: "≩", gnap: "⪊", gnapprox: "⪊", gne: "⪈", gneq: "⪈", gnsim: "⋧", gopf: "𝕘", gscr: "ℊ", gsime: "⪎", gsiml: "⪐", gtcc: "⪧", gtcir: "⩺", gtdot: "⋗", gtrdot: "⋗", gtlPar: "⦕", gtquest: "⩼", gtrarr: "⥸", gvertneqq: "≩︀", gvnE: "≩︀", hardcy: "ъ", harrcir: "⥈", harrw: "↭", leftrightsquigarrow: "↭", hbar: "ℏ", hslash: "ℏ", planck: "ℏ", plankv: "ℏ", hcirc: "ĥ", hearts: "♥", heartsuit: "♥", hellip: "…", mldr: "…", hercon: "⊹", hfr: "𝔥", hksearow: "⤥", searhk: "⤥", hkswarow: "⤦", swarhk: "⤦", hoarr: "⇿", homtht: "∻", hookleftarrow: "↩", larrhk: "↩", hookrightarrow: "↪", rarrhk: "↪", hopf: "𝕙", horbar: "―", hscr: "𝒽", hstrok: "ħ", hybull: "⁃", iacute: "í", icirc: "î", icy: "и", iecy: "е", iexcl: "¡", ifr: "𝔦", igrave: "ì", iiiint: "⨌", qint: "⨌", iiint: "∭", tint: "∭", iinfin: "⧜", iiota: "℩", ijlig: "ĳ", imacr: "ī", imath: "ı", inodot: "ı", imof: "⊷", imped: "Ƶ", incare: "℅", infin: "∞", infintie: "⧝", intcal: "⊺", intercal: "⊺", intlarhk: "⨗", intprod: "⨼", iprod: "⨼", iocy: "ё", iogon: "į", iopf: "𝕚", iota: "ι", iquest: "¿", iscr: "𝒾", isinE: "⋹", isindot: "⋵", isins: "⋴", isinsv: "⋳", itilde: "ĩ", iukcy: "і", iuml: "ï", jcirc: "ĵ", jcy: "й", jfr: "𝔧", jmath: "ȷ", jopf: "𝕛", jscr: "𝒿", jsercy: "ј", jukcy: "є", kappa: "κ", kappav: "ϰ", varkappa: "ϰ", kcedil: "ķ", kcy: "к", kfr: "𝔨", kgreen: "ĸ", khcy: "х", kjcy: "ќ", kopf: "𝕜", kscr: "𝓀", lAtail: "⤛", lBarr: "⤎", lEg: "⪋", lesseqqgtr: "⪋", lHar: "⥢", lacute: "ĺ", laemptyv: "⦴", lambda: "λ", langd: "⦑", lap: "⪅", lessapprox: "⪅", laquo: "«", larrbfs: "⤟", larrfs: "⤝", larrlp: "↫", looparrowleft: "↫", larrpl: "⤹", larrsim: "⥳", larrtl: "↢", leftarrowtail: "↢", lat: "⪫", latail: "⤙", late: "⪭", lates: "⪭︀", lbarr: "⤌", lbbrk: "❲", lbrace: "{", lcub: "{", lbrack: "[", lsqb: "[", lbrke: "⦋", lbrksld: "⦏", lbrkslu: "⦍", lcaron: "ľ", lcedil: "ļ", lcy: "л", ldca: "⤶", ldrdhar: "⥧", ldrushar: "⥋", ldsh: "↲", le: "≤", leq: "≤", leftleftarrows: "⇇", llarr: "⇇", leftthreetimes: "⋋", lthree: "⋋", lescc: "⪨", lesdot: "⩿", lesdoto: "⪁", lesdotor: "⪃", lesg: "⋚︀", lesges: "⪓", lessdot: "⋖", ltdot: "⋖", lfisht: "⥼", lfr: "𝔩", lgE: "⪑", lharul: "⥪", lhblk: "▄", ljcy: "љ", llhard: "⥫", lltri: "◺", lmidot: "ŀ", lmoust: "⎰", lmoustache: "⎰", lnE: "≨", lneqq: "≨", lnap: "⪉", lnapprox: "⪉", lne: "⪇", lneq: "⪇", lnsim: "⋦", loang: "⟬", loarr: "⇽", longmapsto: "⟼", xmap: "⟼", looparrowright: "↬", rarrlp: "↬", lopar: "⦅", lopf: "𝕝", loplus: "⨭", lotimes: "⨴", lowast: "∗", loz: "◊", lozenge: "◊", lpar: "(", lparlt: "⦓", lrhard: "⥭", lrm: "‎", lrtri: "⊿", lsaquo: "‹", lscr: "𝓁", lsime: "⪍", lsimg: "⪏", lsquor: "‚", sbquo: "‚", lstrok: "ł", ltcc: "⪦", ltcir: "⩹", ltimes: "⋉", ltlarr: "⥶", ltquest: "⩻", ltrPar: "⦖", ltri: "◃", triangleleft: "◃", lurdshar: "⥊", luruhar: "⥦", lvertneqq: "≨︀", lvnE: "≨︀", mDDot: "∺", macr: "¯", strns: "¯", male: "♂", malt: "✠", maltese: "✠", marker: "▮", mcomma: "⨩", mcy: "м", mdash: "—", mfr: "𝔪", mho: "℧", micro: "µ", midcir: "⫰", minus: "−", minusdu: "⨪", mlcp: "⫛", models: "⊧", mopf: "𝕞", mscr: "𝓂", mu: "μ", multimap: "⊸", mumap: "⊸", nGg: "⋙̸", nGt: "≫⃒", nLeftarrow: "⇍", nlArr: "⇍", nLeftrightarrow: "⇎", nhArr: "⇎", nLl: "⋘̸", nLt: "≪⃒", nRightarrow: "⇏", nrArr: "⇏", nVDash: "⊯", nVdash: "⊮", nacute: "ń", nang: "∠⃒", napE: "⩰̸", napid: "≋̸", napos: "ŉ", natur: "♮", natural: "♮", ncap: "⩃", ncaron: "ň", ncedil: "ņ", ncongdot: "⩭̸", ncup: "⩂", ncy: "н", ndash: "–", neArr: "⇗", nearhk: "⤤", nedot: "≐̸", nesear: "⤨", toea: "⤨", nfr: "𝔫", nharr: "↮", nleftrightarrow: "↮", nhpar: "⫲", nis: "⋼", nisd: "⋺", njcy: "њ", nlE: "≦̸", nleqq: "≦̸", nlarr: "↚", nleftarrow: "↚", nldr: "‥", nopf: "𝕟", not: "¬", notinE: "⋹̸", notindot: "⋵̸", notinvb: "⋷", notinvc: "⋶", notnivb: "⋾", notnivc: "⋽", nparsl: "⫽⃥", npart: "∂̸", npolint: "⨔", nrarr: "↛", nrightarrow: "↛", nrarrc: "⤳̸", nrarrw: "↝̸", nscr: "𝓃", nsub: "⊄", nsubE: "⫅̸", nsubseteqq: "⫅̸", nsup: "⊅", nsupE: "⫆̸", nsupseteqq: "⫆̸", ntilde: "ñ", nu: "ν", num: "#", numero: "№", numsp: " ", nvDash: "⊭", nvHarr: "⤄", nvap: "≍⃒", nvdash: "⊬", nvge: "≥⃒", nvgt: ">⃒", nvinfin: "⧞", nvlArr: "⤂", nvle: "≤⃒", nvlt: "<⃒", nvltrie: "⊴⃒", nvrArr: "⤃", nvrtrie: "⊵⃒", nvsim: "∼⃒", nwArr: "⇖", nwarhk: "⤣", nwnear: "⤧", oacute: "ó", ocirc: "ô", ocy: "о", odblac: "ő", odiv: "⨸", odsold: "⦼", oelig: "œ", ofcir: "⦿", ofr: "𝔬", ogon: "˛", ograve: "ò", ogt: "⧁", ohbar: "⦵", olcir: "⦾", olcross: "⦻", olt: "⧀", omacr: "ō", omega: "ω", omicron: "ο", omid: "⦶", oopf: "𝕠", opar: "⦷", operp: "⦹", or: "∨", vee: "∨", ord: "⩝", order: "ℴ", orderof: "ℴ", oscr: "ℴ", ordf: "ª", ordm: "º", origof: "⊶", oror: "⩖", orslope: "⩗", orv: "⩛", oslash: "ø", osol: "⊘", otilde: "õ", otimesas: "⨶", ouml: "ö", ovbar: "⌽", para: "¶", parsim: "⫳", parsl: "⫽", pcy: "п", percnt: "%", period: ".", permil: "‰", pertenk: "‱", pfr: "𝔭", phi: "φ", phiv: "ϕ", straightphi: "ϕ", varphi: "ϕ", phone: "☎", pi: "π", piv: "ϖ", varpi: "ϖ", planckh: "ℎ", plus: "+", plusacir: "⨣", pluscir: "⨢", plusdu: "⨥", pluse: "⩲", plussim: "⨦", plustwo: "⨧", pointint: "⨕", popf: "𝕡", pound: "£", prE: "⪳", prap: "⪷", precapprox: "⪷", precnapprox: "⪹", prnap: "⪹", precneqq: "⪵", prnE: "⪵", precnsim: "⋨", prnsim: "⋨", prime: "′", profalar: "⌮", profline: "⌒", profsurf: "⌓", prurel: "⊰", pscr: "𝓅", psi: "ψ", puncsp: " ", qfr: "𝔮", qopf: "𝕢", qprime: "⁗", qscr: "𝓆", quatint: "⨖", quest: "?", rAtail: "⤜", rHar: "⥤", race: "∽̱", racute: "ŕ", raemptyv: "⦳", rangd: "⦒", range: "⦥", raquo: "»", rarrap: "⥵", rarrbfs: "⤠", rarrc: "⤳", rarrfs: "⤞", rarrpl: "⥅", rarrsim: "⥴", rarrtl: "↣", rightarrowtail: "↣", rarrw: "↝", rightsquigarrow: "↝", ratail: "⤚", ratio: "∶", rbbrk: "❳", rbrace: "}", rcub: "}", rbrack: "]", rsqb: "]", rbrke: "⦌", rbrksld: "⦎", rbrkslu: "⦐", rcaron: "ř", rcedil: "ŗ", rcy: "р", rdca: "⤷", rdldhar: "⥩", rdsh: "↳", rect: "▭", rfisht: "⥽", rfr: "𝔯", rharul: "⥬", rho: "ρ", rhov: "ϱ", varrho: "ϱ", rightrightarrows: "⇉", rrarr: "⇉", rightthreetimes: "⋌", rthree: "⋌", ring: "˚", rlm: "‏", rmoust: "⎱", rmoustache: "⎱", rnmid: "⫮", roang: "⟭", roarr: "⇾", ropar: "⦆", ropf: "𝕣", roplus: "⨮", rotimes: "⨵", rpar: ")", rpargt: "⦔", rppolint: "⨒", rsaquo: "›", rscr: "𝓇", rtimes: "⋊", rtri: "▹", triangleright: "▹", rtriltri: "⧎", ruluhar: "⥨", rx: "℞", sacute: "ś", scE: "⪴", scap: "⪸", succapprox: "⪸", scaron: "š", scedil: "ş", scirc: "ŝ", scnE: "⪶", succneqq: "⪶", scnap: "⪺", succnapprox: "⪺", scnsim: "⋩", succnsim: "⋩", scpolint: "⨓", scy: "с", sdot: "⋅", sdote: "⩦", seArr: "⇘", sect: "§", semi: ";", seswar: "⤩", tosa: "⤩", sext: "✶", sfr: "𝔰", sharp: "♯", shchcy: "щ", shcy: "ш", shy: "­", sigma: "σ", sigmaf: "ς", sigmav: "ς", varsigma: "ς", simdot: "⩪", simg: "⪞", simgE: "⪠", siml: "⪝", simlE: "⪟", simne: "≆", simplus: "⨤", simrarr: "⥲", smashp: "⨳", smeparsl: "⧤", smile: "⌣", ssmile: "⌣", smt: "⪪", smte: "⪬", smtes: "⪬︀", softcy: "ь", sol: "/", solb: "⧄", solbar: "⌿", sopf: "𝕤", spades: "♠", spadesuit: "♠", sqcaps: "⊓︀", sqcups: "⊔︀", sscr: "𝓈", star: "☆", sub: "⊂", subset: "⊂", subE: "⫅", subseteqq: "⫅", subdot: "⪽", subedot: "⫃", submult: "⫁", subnE: "⫋", subsetneqq: "⫋", subne: "⊊", subsetneq: "⊊", subplus: "⪿", subrarr: "⥹", subsim: "⫇", subsub: "⫕", subsup: "⫓", sung: "♪", sup1: "¹", sup2: "²", sup3: "³", supE: "⫆", supseteqq: "⫆", supdot: "⪾", supdsub: "⫘", supedot: "⫄", suphsol: "⟉", suphsub: "⫗", suplarr: "⥻", supmult: "⫂", supnE: "⫌", supsetneqq: "⫌", supne: "⊋", supsetneq: "⊋", supplus: "⫀", supsim: "⫈", supsub: "⫔", supsup: "⫖", swArr: "⇙", swnwar: "⤪", szlig: "ß", target: "⌖", tau: "τ", tcaron: "ť", tcedil: "ţ", tcy: "т", telrec: "⌕", tfr: "𝔱", theta: "θ", thetasym: "ϑ", thetav: "ϑ", vartheta: "ϑ", thorn: "þ", times: "×", timesbar: "⨱", timesd: "⨰", topbot: "⌶", topcir: "⫱", topf: "𝕥", topfork: "⫚", tprime: "‴", triangle: "▵", utri: "▵", triangleq: "≜", trie: "≜", tridot: "◬", triminus: "⨺", triplus: "⨹", trisb: "⧍", tritime: "⨻", trpezium: "⏢", tscr: "𝓉", tscy: "ц", tshcy: "ћ", tstrok: "ŧ", uHar: "⥣", uacute: "ú", ubrcy: "ў", ubreve: "ŭ", ucirc: "û", ucy: "у", udblac: "ű", ufisht: "⥾", ufr: "𝔲", ugrave: "ù", uhblk: "▀", ulcorn: "⌜", ulcorner: "⌜", ulcrop: "⌏", ultri: "◸", umacr: "ū", uogon: "ų", uopf: "𝕦", upsi: "υ", upsilon: "υ", upuparrows: "⇈", uuarr: "⇈", urcorn: "⌝", urcorner: "⌝", urcrop: "⌎", uring: "ů", urtri: "◹", uscr: "𝓊", utdot: "⋰", utilde: "ũ", uuml: "ü", uwangle: "⦧", vBar: "⫨", vBarv: "⫩", vangrt: "⦜", varsubsetneq: "⊊︀", vsubne: "⊊︀", varsubsetneqq: "⫋︀", vsubnE: "⫋︀", varsupsetneq: "⊋︀", vsupne: "⊋︀", varsupsetneqq: "⫌︀", vsupnE: "⫌︀", vcy: "в", veebar: "⊻", veeeq: "≚", vellip: "⋮", vfr: "𝔳", vopf: "𝕧", vscr: "𝓋", vzigzag: "⦚", wcirc: "ŵ", wedbar: "⩟", wedgeq: "≙", weierp: "℘", wp: "℘", wfr: "𝔴", wopf: "𝕨", wscr: "𝓌", xfr: "𝔵", xi: "ξ", xnis: "⋻", xopf: "𝕩", xscr: "𝓍", yacute: "ý", yacy: "я", ycirc: "ŷ", ycy: "ы", yen: "¥", yfr: "𝔶", yicy: "ї", yopf: "𝕪", yscr: "𝓎", yucy: "ю", yuml: "ÿ", zacute: "ź", zcaron: "ž", zcy: "з", zdot: "ż", zeta: "ζ", zfr: "𝔷", zhcy: "ж", zigrarr: "⇝", zopf: "𝕫", zscr: "𝓏", zwj: "‍", zwnj: "‌" };
  _e.ngsp = "";
  var za = class {
    tokens;
    errors;
    nonNormalizedIcuExpressions;
    constructor(e, t, r) {
      this.tokens = e, this.errors = t, this.nonNormalizedIcuExpressions = r;
    }
  };
  function Di(e, t, r, n = {}) {
    let i = new Qa(new rt(e, t), r, n);
    return i.tokenize(), new za(no(i.tokens), i.errors, i.nonNormalizedIcuExpressions);
  }
  var Ga = /\\r\\n?/g;
  function Se(e) {
    return \`Unexpected character "\${e === 0 ? "EOF" : String.fromCharCode(e)}"\`;
  }
  function xi(e) {
    return \`Unknown entity "\${e}" - use the "&#<decimal>;" or  "&#x<hex>;" syntax\`;
  }
  function $a(e, t) {
    return \`Unable to parse entity "\${t}" - \${e} character reference entities must end with ";"\`;
  }
  var ja = ["@if", "@else", "@for", "@switch", "@case", "@default", "@empty", "@defer", "@placeholder", "@loading", "@error", "@content"], it = { start: "{{", end: "}}" }, Ya = /^default[^\\S\\r\\n]+never/, Ka = /^else[^\\S\\r\\n]+if/, Qa = class {
    _getTagContentType;
    _cursor;
    _tokenizeIcu;
    _leadingTriviaCodePoints;
    _canSelfClose;
    _allowHtmComponentClosingTags;
    _allowStartTagComments;
    _currentTokenStart = null;
    _currentTokenType = null;
    _expansionCaseStack = [];
    _openDirectiveCount = 0;
    _inInterpolation = false;
    _preserveLineEndings;
    _i18nNormalizeLineEndingsInICUs;
    _fullNameStack = [];
    _tokenizeBlocks;
    _tokenizeLet;
    _selectorlessEnabled;
    tokens = [];
    errors = [];
    nonNormalizedIcuExpressions = [];
    constructor(e, t, r) {
      this._getTagContentType = t, this._tokenizeIcu = r.tokenizeExpansionForms || false, this._leadingTriviaCodePoints = r.leadingTriviaChars && r.leadingTriviaChars.map((i) => i.codePointAt(0) || 0), this._canSelfClose = r.canSelfClose || false, this._allowHtmComponentClosingTags = r.allowHtmComponentClosingTags || false, this._allowStartTagComments = r.allowStartTagComments ?? true;
      let n = r.range || { endPos: e.content.length, startPos: 0, startLine: 0, startCol: 0 };
      this._cursor = r.escapedString ? new io(e, n) : new Ii(e, n), this._preserveLineEndings = r.preserveLineEndings || false, this._i18nNormalizeLineEndingsInICUs = r.i18nNormalizeLineEndingsInICUs || false, this._tokenizeBlocks = r.tokenizeBlocks ?? true, this._tokenizeLet = r.tokenizeLet ?? true, this._selectorlessEnabled = r.selectorlessEnabled ?? false;
      try {
        this._cursor.init();
      } catch (i) {
        this.handleError(i);
      }
    }
    _processCarriageReturns(e) {
      return this._preserveLineEndings ? e : e.replace(Ga, \`
\`);
    }
    tokenize() {
      for (; this._cursor.peek() !== 0; ) {
        let e = this._cursor.clone();
        try {
          if (this._attemptCharCode(60)) if (this._attemptCharCode(33)) this._attemptStr("[CDATA[") ? this._consumeCdata(e) : this._attemptStr("--") ? this._consumeComment(e) : this._attemptStrCaseInsensitive("doctype") ? this._consumeDocType(e) : this._consumeBogusComment(e);
          else if (this._attemptCharCode(47)) this._consumeTagClose(e);
          else {
            let t = this._cursor.clone();
            this._attemptCharCode(63) ? (this._cursor = t, this._consumeBogusComment(e)) : this._consumeTagOpen(e);
          }
          else this._tokenizeLet && this._cursor.peek() === 64 && !this._inInterpolation && this._isLetStart() ? this._consumeLetDeclaration(e) : this._tokenizeBlocks && this._isBlockStart() ? this._consumeBlockStart(e) : this._tokenizeBlocks && !this._inInterpolation && !this._isInExpansionCase() && !this._isInExpansionForm() && this._attemptCharCode(125) ? this._consumeBlockEnd(e) : this._tokenizeIcu && this._tokenizeExpansionForm() || this._consumeWithInterpolation(5, 8, () => this._isTextEnd(), () => this._isTagStart());
        } catch (t) {
          this.handleError(t);
        }
      }
      this._beginToken(43), this._endToken([]);
    }
    _getBlockName() {
      let e = false, t = this._cursor.clone();
      this._attemptCharCodeUntilFn((n) => nt(n) ? !e : ro(n) ? (e = true, false) : true);
      let r = this._cursor.getChars(t).trim();
      return Ka.test(r) ? r = "else if" : Ya.test(r) && (r = "default never"), r;
    }
    _consumeBlockStart(e) {
      this._requireCharCode(64), this._beginToken(26, e);
      let t = this._endToken([this._getBlockName()]);
      if (this._cursor.peek() === 40) if (this._cursor.advance(), this._consumeBlockParameters(), this._attemptCharCodeUntilFn(b), this._attemptCharCode(41)) this._attemptCharCodeUntilFn(b);
      else {
        t.type = 30;
        return;
      }
      if (t.parts[0] === "default never" && this._attemptCharCode(59)) {
        this._beginToken(27), this._endToken([]), this._beginToken(28), this._endToken([]);
        return;
      }
      this._attemptCharCode(123) ? (this._beginToken(27), this._endToken([])) : this._isBlockStart() && (t.parts[0] === "case" || t.parts[0] === "default") ? (this._beginToken(27), this._endToken([]), this._beginToken(28), this._endToken([])) : t.type = 30;
    }
    _consumeBlockEnd(e) {
      this._beginToken(28, e), this._endToken([]);
    }
    _consumeBlockParameters() {
      for (this._attemptCharCodeUntilFn(Ai); this._cursor.peek() !== 41 && this._cursor.peek() !== 0; ) {
        this._beginToken(29);
        let e = this._cursor.clone(), t = null, r = 0;
        for (; this._cursor.peek() !== 59 && this._cursor.peek() !== 0 || t !== null; ) {
          let n = this._cursor.peek();
          if (n === 92) this._cursor.advance();
          else if (n === t) t = null;
          else if (t === null && Rt(n)) t = n;
          else if (n === 40 && t === null) r++;
          else if (n === 41 && t === null) {
            if (r === 0) break;
            r > 0 && r--;
          }
          this._cursor.advance();
        }
        this._endToken([this._cursor.getChars(e)]), this._attemptCharCodeUntilFn(Ai);
      }
    }
    _consumeLetDeclaration(e) {
      if (this._requireStr("@let"), this._beginToken(31, e), nt(this._cursor.peek())) this._attemptCharCodeUntilFn(b);
      else {
        let r = this._endToken([this._cursor.getChars(e)]);
        r.type = 34;
        return;
      }
      let t = this._endToken([this._getLetDeclarationName()]);
      if (this._attemptCharCodeUntilFn(b), !this._attemptCharCode(61)) {
        t.type = 34;
        return;
      }
      this._attemptCharCodeUntilFn((r) => b(r) && !Oe(r)), this._consumeLetDeclarationValue(), this._cursor.peek() === 59 ? (this._beginToken(33), this._cursor.advance(), this._endToken([])) : (t.type = 34, t.sourceSpan = this._cursor.getSpan(e));
    }
    _getLetDeclarationName() {
      let e = this._cursor.clone(), t = false;
      return this._attemptCharCodeUntilFn((r) => Re(r) || r === 36 || r === 95 || t && Ie(r) ? (t = true, false) : true), this._cursor.getChars(e).trim();
    }
    _consumeLetDeclarationValue() {
      let e = this._cursor.clone();
      for (this._beginToken(32, e); this._cursor.peek() !== 0; ) {
        let t = this._cursor.peek();
        if (t === 59) break;
        Rt(t) && (this._cursor.advance(), this._attemptCharCodeUntilFn((r) => r === 92 ? (this._cursor.advance(), false) : r === t)), this._cursor.advance();
      }
      this._endToken([this._cursor.getChars(e)]);
    }
    _tokenizeExpansionForm() {
      if (this.isExpansionFormStart()) return this._consumeExpansionFormStart(), true;
      if (eo(this._cursor.peek()) && this._isInExpansionForm()) return this._consumeExpansionCaseStart(), true;
      if (this._cursor.peek() === 125) {
        if (this._isInExpansionCase()) return this._consumeExpansionCaseEnd(), true;
        if (this._isInExpansionForm()) return this._consumeExpansionFormEnd(), true;
      }
      return false;
    }
    _beginToken(e, t = this._cursor.clone()) {
      this._currentTokenStart = t, this._currentTokenType = e;
    }
    _endToken(e, t) {
      if (this._currentTokenStart === null) throw new te(this._cursor.getSpan(t), "Programming error - attempted to end a token when there was no start to the token");
      if (this._currentTokenType === null) throw new te(this._cursor.getSpan(this._currentTokenStart), "Programming error - attempted to end a token which has no token type");
      let r = { type: this._currentTokenType, parts: e, sourceSpan: (t ?? this._cursor).getSpan(this._currentTokenStart, this._leadingTriviaCodePoints) };
      return this.tokens.push(r), this._currentTokenStart = null, this._currentTokenType = null, r;
    }
    _createError(e, t) {
      this._isInExpansionForm() && (e += \` (Do you have an unescaped "{" in your template? Use "{{ '{' }}") to escape it.)\`);
      let r = new te(t, e);
      return this._currentTokenStart = null, this._currentTokenType = null, r;
    }
    handleError(e) {
      if (e instanceof Cr && (e = this._createError(e.msg, this._cursor.getSpan(e.cursor))), e instanceof te) this.errors.push(e);
      else throw e;
    }
    _attemptCharCode(e) {
      return this._cursor.peek() === e ? (this._cursor.advance(), true) : false;
    }
    _attemptCharCodeCaseInsensitive(e) {
      return to(this._cursor.peek(), e) ? (this._cursor.advance(), true) : false;
    }
    _requireCharCode(e) {
      let t = this._cursor.clone();
      if (!this._attemptCharCode(e)) throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(t));
    }
    _attemptStr(e) {
      let t = e.length;
      if (this._cursor.charsLeft() < t) return false;
      let r = this._cursor.clone();
      for (let n = 0; n < t; n++) if (!this._attemptCharCode(e.charCodeAt(n))) return this._cursor = r, false;
      return true;
    }
    _attemptStrCaseInsensitive(e) {
      for (let t = 0; t < e.length; t++) if (!this._attemptCharCodeCaseInsensitive(e.charCodeAt(t))) return false;
      return true;
    }
    _requireStr(e) {
      let t = this._cursor.clone();
      if (!this._attemptStr(e)) throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(t));
    }
    _requireStrCaseInsensitive(e) {
      let t = this._cursor.clone();
      if (!this._attemptStrCaseInsensitive(e)) throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(t));
    }
    _attemptCharCodeUntilFn(e) {
      for (; !e(this._cursor.peek()); ) this._cursor.advance();
    }
    _requireCharCodeUntilFn(e, t) {
      let r = this._cursor.clone();
      if (this._attemptCharCodeUntilFn(e), this._cursor.diff(r) < t) throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(r));
    }
    _attemptUntilChar(e) {
      for (; this._cursor.peek() !== e; ) this._cursor.advance();
    }
    _readChar() {
      let e = String.fromCodePoint(this._cursor.peek());
      return this._cursor.advance(), e;
    }
    _peekStr(e) {
      let t = e.length;
      if (this._cursor.charsLeft() < t) return false;
      let r = this._cursor.clone();
      for (let n = 0; n < t; n++) {
        if (r.peek() !== e.charCodeAt(n)) return false;
        r.advance();
      }
      return true;
    }
    _isBlockStart() {
      return this._cursor.peek() === 64 && ja.some((e) => this._peekStr(e));
    }
    _isLetStart() {
      return this._cursor.peek() === 64 && this._peekStr("@let");
    }
    _consumeEntity(e) {
      this._beginToken(9);
      let t = this._cursor.clone();
      if (this._cursor.advance(), this._attemptCharCode(35)) {
        let r = this._attemptCharCode(120) || this._attemptCharCode(88), n = this._cursor.clone();
        if (this._attemptCharCodeUntilFn(Ja), this._cursor.peek() != 59) {
          this._cursor.advance();
          let s = r ? "hexadecimal" : "decimal";
          throw this._createError($a(s, this._cursor.getChars(t)), this._cursor.getSpan());
        }
        let i = this._cursor.getChars(n);
        this._cursor.advance();
        try {
          let s = parseInt(i, r ? 16 : 10);
          this._endToken([String.fromCodePoint(s), this._cursor.getChars(t)]);
        } catch {
          throw this._createError(xi(this._cursor.getChars(t)), this._cursor.getSpan());
        }
      } else {
        let r = this._cursor.clone();
        if (this._attemptCharCodeUntilFn(Za), this._cursor.peek() != 59) this._beginToken(e, t), this._cursor = r, this._endToken(["&"]);
        else {
          let n = this._cursor.getChars(r);
          this._cursor.advance();
          let i = _e.hasOwnProperty(n) && _e[n];
          if (!i) throw this._createError(xi(n), this._cursor.getSpan(t));
          this._endToken([i, \`&\${n};\`]);
        }
      }
    }
    _consumeRawText(e, t) {
      this._beginToken(e ? 6 : 7);
      let r = [];
      for (; ; ) {
        let n = this._cursor.clone(), i = t();
        if (this._cursor = n, i) break;
        e && this._cursor.peek() === 38 ? (this._endToken([this._processCarriageReturns(r.join(""))]), r.length = 0, this._consumeEntity(6), this._beginToken(6)) : r.push(this._readChar());
      }
      this._endToken([this._processCarriageReturns(r.join(""))]);
    }
    _consumeComment(e) {
      this._beginToken(10, e), this._endToken([]), this._consumeRawText(false, () => this._attemptStr("-->")), this._beginToken(11), this._requireStr("-->"), this._endToken([]);
    }
    _consumeBogusComment(e) {
      this._beginToken(10, e), this._endToken([]), this._consumeRawText(false, () => this._cursor.peek() === 62), this._beginToken(11), this._cursor.advance(), this._endToken([]);
    }
    _consumeCdata(e) {
      this._beginToken(13, e), this._endToken([]), this._consumeRawText(false, () => this._attemptStr("]]>")), this._beginToken(14), this._requireStr("]]>"), this._endToken([]);
    }
    _consumeDocType(e) {
      this._beginToken(19, e), this._endToken([]), this._consumeRawText(false, () => this._cursor.peek() === 62), this._beginToken(20), this._cursor.advance(), this._endToken([]);
    }
    _consumePrefixAndName(e) {
      let t = this._cursor.clone(), r = "";
      for (; this._cursor.peek() !== 58 && !Xa(this._cursor.peek()); ) this._cursor.advance();
      let n;
      this._cursor.peek() === 58 ? (r = this._cursor.getChars(t), this._cursor.advance(), n = this._cursor.clone()) : n = t, this._requireCharCodeUntilFn(e, r === "" ? 0 : 1);
      let i = this._cursor.getChars(n);
      return [r, i];
    }
    _consumeSingleLineComment(e) {
      let t = this._cursor.clone();
      this._attemptCharCodeUntilFn((i) => Oe(i) || i === 0);
      let r = this._cursor.clone(), n = r.getChars(t);
      this._beginToken(12, e), this._endToken([n, "single"], r), this._attemptCharCodeUntilFn(b);
    }
    _consumeMultiLineComment(e) {
      let t = this._cursor.clone();
      this._attemptCharCodeUntilFn((s) => {
        if (s === 0) return true;
        if (s === 42) {
          let a = this._cursor.clone();
          return a.advance(), a.peek() === 47;
        }
        return false;
      });
      let r = this._cursor.clone(), n = r.getChars(t), i = r;
      this._attemptStr("*/") && (i = this._cursor.clone(), this._attemptCharCodeUntilFn(b)), this._beginToken(12, e), this._endToken([n, "multi"], i);
    }
    _consumeTagOpen(e) {
      let t, r, n, i, s = [];
      try {
        if (this._selectorlessEnabled && Ot(this._cursor.peek())) i = this._consumeComponentOpenStart(e), [n, r, t] = i.parts, r && (n += \`:\${r}\`), t && (n += \`:\${t}\`), this._attemptCharCodeUntilFn(b);
        else {
          if (!Re(this._cursor.peek())) throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(e));
          i = this._consumeTagOpenStart(e), r = i.parts[0], t = n = i.parts[1], this._attemptCharCodeUntilFn(b);
        }
        for (; ; ) {
          if (this._allowStartTagComments) {
            let o = this._cursor.clone();
            if (this._attemptStr("//")) {
              this._consumeSingleLineComment(o);
              continue;
            }
            if (this._attemptStr("/*")) {
              this._consumeMultiLineComment(o);
              continue;
            }
          }
          if (Ni(this._cursor.peek())) break;
          if (this._selectorlessEnabled && this._cursor.peek() === 64) {
            let o = this._cursor.clone(), l = o.clone();
            l.advance(), Ot(l.peek()) && this._consumeDirective(o, l);
          } else {
            let o = this._consumeAttribute();
            s.push(o);
          }
        }
        i.type === 35 ? this._consumeComponentOpenEnd() : this._consumeTagOpenEnd();
      } catch (o) {
        if (o instanceof te) {
          i ? i.type = i.type === 35 ? 39 : 4 : (this._beginToken(5, e), this._endToken(["<"]));
          return;
        }
        throw o;
      }
      if (this._canSelfClose && this.tokens[this.tokens.length - 1].type === 2) return;
      let a = this._getTagContentType(t, r, this._fullNameStack.length > 0, s);
      this._handleFullNameStackForTagOpen(r, t), a === 0 ? this._consumeRawTextWithTagClose(r, i, n, false) : a === 1 && this._consumeRawTextWithTagClose(r, i, n, true);
    }
    _consumeRawTextWithTagClose(e, t, r, n) {
      this._consumeRawText(n, () => !this._attemptCharCode(60) || !this._attemptCharCode(47) || (this._attemptCharCodeUntilFn(b), !this._attemptStrCaseInsensitive(e && t.type !== 35 ? \`\${e}:\${r}\` : r)) ? false : (this._attemptCharCodeUntilFn(b), this._attemptCharCode(62))), this._beginToken(t.type === 35 ? 38 : 3), this._requireCharCodeUntilFn((i) => i === 62, 3), this._cursor.advance(), this._endToken(t.parts), this._handleFullNameStackForTagClose(e, r);
    }
    _consumeTagOpenStart(e) {
      this._beginToken(0, e);
      let t = this._consumePrefixAndName(ve);
      return this._endToken(t);
    }
    _consumeComponentOpenStart(e) {
      this._beginToken(35, e);
      let t = this._consumeComponentName();
      return this._endToken(t);
    }
    _consumeComponentName() {
      let e = this._cursor.clone();
      for (; Pi(this._cursor.peek()); ) this._cursor.advance();
      let t = this._cursor.getChars(e), r = "", n = "";
      return this._cursor.peek() === 58 && (this._cursor.advance(), [r, n] = this._consumePrefixAndName(ve)), [t, r, n];
    }
    _consumeAttribute() {
      let [e, t] = this._consumeAttributeName(), r;
      return this._attemptCharCodeUntilFn(b), this._attemptCharCode(61) && (this._attemptCharCodeUntilFn(b), r = this._consumeAttributeValue()), this._attemptCharCodeUntilFn(b), { prefix: e, name: t, value: r };
    }
    _consumeAttributeName() {
      let e = this._cursor.peek();
      if (e === 39 || e === 34) throw this._createError(Se(e), this._cursor.getSpan());
      this._beginToken(15);
      let t;
      if (this._openDirectiveCount > 0) {
        let n = 0;
        t = (i) => {
          if (this._openDirectiveCount > 0) {
            if (i === 40) n++;
            else if (i === 41) {
              if (n === 0) return true;
              n--;
            }
          }
          return ve(i);
        };
      } else if (e === 91) {
        let n = 0;
        t = (i) => (i === 91 ? n++ : i === 93 && n--, n <= 0 ? ve(i) : Oe(i));
      } else t = ve;
      let r = this._consumePrefixAndName(t);
      return this._endToken(r), r;
    }
    _consumeAttributeValue() {
      let e;
      if (this._cursor.peek() === 39 || this._cursor.peek() === 34) {
        let t = this._cursor.peek();
        this._consumeQuote(t);
        let r = () => this._cursor.peek() === t;
        e = this._consumeWithInterpolation(17, 18, r, r), this._consumeQuote(t);
      } else {
        let t = () => ve(this._cursor.peek());
        e = this._consumeWithInterpolation(17, 18, t, t);
      }
      return e;
    }
    _consumeQuote(e) {
      this._beginToken(16), this._requireCharCode(e), this._endToken([String.fromCodePoint(e)]);
    }
    _consumeTagOpenEnd() {
      let e = this._attemptCharCode(47) ? 2 : 1;
      this._beginToken(e), this._requireCharCode(62), this._endToken([]);
    }
    _consumeComponentOpenEnd() {
      let e = this._attemptCharCode(47) ? 37 : 36;
      this._beginToken(e), this._requireCharCode(62), this._endToken([]);
    }
    _consumeTagClose(e) {
      if (this._selectorlessEnabled) {
        let t = e.clone();
        for (; t.peek() !== 62 && !Ot(t.peek()); ) t.advance();
        if (Ot(t.peek())) {
          this._beginToken(38, e);
          let r = this._consumeComponentName();
          this._attemptCharCodeUntilFn(b), this._requireCharCode(62), this._endToken(r);
          return;
        }
      }
      if (this._beginToken(3, e), this._attemptCharCodeUntilFn(b), this._allowHtmComponentClosingTags && this._attemptCharCode(47)) this._attemptCharCodeUntilFn(b), this._requireCharCode(62), this._endToken([]);
      else {
        let [t, r] = this._consumePrefixAndName(ve);
        this._attemptCharCodeUntilFn(b), this._requireCharCode(62), this._endToken([t, r]), this._handleFullNameStackForTagClose(t, r);
      }
    }
    _consumeExpansionFormStart() {
      this._beginToken(21), this._requireCharCode(123), this._endToken([]), this._expansionCaseStack.push(21), this._beginToken(7);
      let e = this._readUntil(44), t = this._processCarriageReturns(e);
      if (this._i18nNormalizeLineEndingsInICUs) this._endToken([t]);
      else {
        let n = this._endToken([e]);
        t !== e && this.nonNormalizedIcuExpressions.push(n);
      }
      this._requireCharCode(44), this._attemptCharCodeUntilFn(b), this._beginToken(7);
      let r = this._readUntil(44);
      this._endToken([r]), this._requireCharCode(44), this._attemptCharCodeUntilFn(b);
    }
    _consumeExpansionCaseStart() {
      this._beginToken(22);
      let e = this._readUntil(123).trim();
      this._endToken([e]), this._attemptCharCodeUntilFn(b), this._beginToken(23), this._requireCharCode(123), this._endToken([]), this._attemptCharCodeUntilFn(b), this._expansionCaseStack.push(23);
    }
    _consumeExpansionCaseEnd() {
      this._beginToken(24), this._requireCharCode(125), this._endToken([]), this._attemptCharCodeUntilFn(b), this._expansionCaseStack.pop();
    }
    _consumeExpansionFormEnd() {
      this._beginToken(25), this._requireCharCode(125), this._endToken([]), this._expansionCaseStack.pop();
    }
    _consumeWithInterpolation(e, t, r, n) {
      this._beginToken(e);
      let i = [];
      for (; !r(); ) {
        let a = this._cursor.clone();
        this._attemptStr(it.start) ? (this._endToken([this._processCarriageReturns(i.join(""))], a), i.length = 0, this._consumeInterpolation(t, a, n), this._beginToken(e)) : this._cursor.peek() === 38 ? (this._endToken([this._processCarriageReturns(i.join(""))]), i.length = 0, this._consumeEntity(e), this._beginToken(e)) : i.push(this._readChar());
      }
      this._inInterpolation = false;
      let s = this._processCarriageReturns(i.join(""));
      return this._endToken([s]), s;
    }
    _consumeInterpolation(e, t, r) {
      let n = [];
      this._beginToken(e, t), n.push(it.start);
      let i = this._cursor.clone(), s = null, a = false;
      for (; this._cursor.peek() !== 0 && (r === null || !r()); ) {
        let o = this._cursor.clone();
        if (this._isTagStart()) {
          this._cursor = o, n.push(this._getProcessedChars(i, o)), this._endToken(n);
          return;
        }
        if (s === null) if (this._attemptStr(it.end)) {
          n.push(this._getProcessedChars(i, o)), n.push(it.end), this._endToken(n);
          return;
        } else this._attemptStr("//") && (a = true);
        let l = this._cursor.peek();
        this._cursor.advance(), l === 92 ? this._cursor.advance() : l === s ? s = null : !a && s === null && Rt(l) && (s = l);
      }
      n.push(this._getProcessedChars(i, this._cursor)), this._endToken(n);
    }
    _consumeDirective(e, t) {
      for (this._requireCharCode(64), this._cursor.advance(); Pi(this._cursor.peek()); ) this._cursor.advance();
      this._beginToken(40, e);
      let r = this._cursor.getChars(t);
      if (this._endToken([r]), this._attemptCharCodeUntilFn(b), this._cursor.peek() === 40) {
        for (this._openDirectiveCount++, this._beginToken(41), this._cursor.advance(), this._endToken([]), this._attemptCharCodeUntilFn(b); !Ni(this._cursor.peek()) && this._cursor.peek() !== 41; ) this._consumeAttribute();
        if (this._attemptCharCodeUntilFn(b), this._openDirectiveCount--, this._cursor.peek() !== 41) {
          if (this._cursor.peek() === 62 || this._cursor.peek() === 47) return;
          throw this._createError(Se(this._cursor.peek()), this._cursor.getSpan(e));
        }
        this._beginToken(42), this._cursor.advance(), this._endToken([]), this._attemptCharCodeUntilFn(b);
      }
    }
    _getProcessedChars(e, t) {
      return this._processCarriageReturns(t.getChars(e));
    }
    _isTextEnd() {
      return !!(this._isTagStart() || this._cursor.peek() === 0 || this._tokenizeIcu && !this._inInterpolation && (this.isExpansionFormStart() || this._cursor.peek() === 125 && this._isInExpansionCase()) || this._tokenizeBlocks && !this._inInterpolation && !this._isInExpansion() && (this._isBlockStart() || this._isLetStart() || this._cursor.peek() === 125));
    }
    _isTagStart() {
      if (this._cursor.peek() === 60) {
        let e = this._cursor.clone();
        e.advance();
        let t = e.peek();
        if (97 <= t && t <= 122 || 65 <= t && t <= 90 || t === 47 || t === 33) return true;
      }
      return false;
    }
    _readUntil(e) {
      let t = this._cursor.clone();
      return this._attemptUntilChar(e), this._cursor.getChars(t);
    }
    _isInExpansion() {
      return this._isInExpansionCase() || this._isInExpansionForm();
    }
    _isInExpansionCase() {
      return this._expansionCaseStack.length > 0 && this._expansionCaseStack[this._expansionCaseStack.length - 1] === 23;
    }
    _isInExpansionForm() {
      return this._expansionCaseStack.length > 0 && this._expansionCaseStack[this._expansionCaseStack.length - 1] === 21;
    }
    isExpansionFormStart() {
      if (this._cursor.peek() !== 123) return false;
      let e = this._cursor.clone(), t = this._attemptStr(it.start);
      return this._cursor = e, !t;
    }
    _handleFullNameStackForTagOpen(e, t) {
      let r = fe(e, t);
      (this._fullNameStack.length === 0 || this._fullNameStack[this._fullNameStack.length - 1] === r) && this._fullNameStack.push(r);
    }
    _handleFullNameStackForTagClose(e, t) {
      let r = fe(e, t);
      this._fullNameStack.length !== 0 && this._fullNameStack[this._fullNameStack.length - 1] === r && this._fullNameStack.pop();
    }
  };
  function b(e) {
    return !nt(e) || e === 0;
  }
  function ve(e) {
    return nt(e) || e === 62 || e === 60 || e === 47 || e === 39 || e === 34 || e === 61 || e === 0;
  }
  function Xa(e) {
    return (e < 97 || 122 < e) && (e < 65 || 90 < e) && (e < 48 || e > 57);
  }
  function Ja(e) {
    return e === 59 || e === 0 || !Ei(e);
  }
  function Za(e) {
    return e === 59 || e === 0 || !(Re(e) || Ie(e));
  }
  function eo(e) {
    return e !== 125;
  }
  function to(e, t) {
    return Li(e) === Li(t);
  }
  function Li(e) {
    return e >= 97 && e <= 122 ? e - 97 + 65 : e;
  }
  function ro(e) {
    return Re(e) || Ie(e) || e === 95;
  }
  function Ai(e) {
    return e !== 59 && b(e);
  }
  function Ot(e) {
    return e === 95 || e >= 65 && e <= 90;
  }
  function Pi(e) {
    return Re(e) || Ie(e) || e === 95;
  }
  function Ni(e) {
    return e === 47 || e === 62 || e === 60 || e === 0;
  }
  function no(e) {
    let t = [], r;
    for (let n = 0; n < e.length; n++) {
      let i = e[n];
      r && r.type === 5 && i.type === 5 || r && r.type === 17 && i.type === 17 ? (r.parts[0] += i.parts[0], r.sourceSpan.end = i.sourceSpan.end) : (r = i, t.push(r));
    }
    return t;
  }
  var Ii = class Sr2 {
    state;
    file;
    input;
    end;
    constructor(t, r) {
      if (t instanceof Sr2) {
        this.file = t.file, this.input = t.input, this.end = t.end;
        let n = t.state;
        this.state = { peek: n.peek, offset: n.offset, line: n.line, column: n.column };
      } else {
        if (!r) throw new Error("Programming error: the range argument must be provided with a file argument.");
        this.file = t, this.input = t.content, this.end = r.endPos, this.state = { peek: -1, offset: r.startPos, line: r.startLine, column: r.startCol };
      }
    }
    clone() {
      return new Sr2(this);
    }
    peek() {
      return this.state.peek;
    }
    charsLeft() {
      return this.end - this.state.offset;
    }
    diff(t) {
      return this.state.offset - t.state.offset;
    }
    advance() {
      this.advanceState(this.state);
    }
    init() {
      this.updatePeek(this.state);
    }
    getSpan(t, r) {
      t = t || this;
      let n = t;
      if (r) for (; this.diff(t) > 0 && r.indexOf(t.peek()) !== -1; ) n === t && (t = t.clone()), t.advance();
      let i = this.locationFromCursor(t);
      return new p(i, this.locationFromCursor(this), n !== t ? this.locationFromCursor(n) : i);
    }
    getChars(t) {
      return this.input.substring(t.state.offset, this.state.offset);
    }
    charAt(t) {
      return this.input.charCodeAt(t);
    }
    advanceState(t) {
      if (t.offset >= this.end) throw this.state = t, new Cr('Unexpected character "EOF"', this);
      let r = this.charAt(t.offset);
      r === 10 ? (t.line++, t.column = 0) : Oe(r) || t.column++, t.offset++, this.updatePeek(t);
    }
    updatePeek(t) {
      t.peek = t.offset >= this.end ? 0 : this.charAt(t.offset);
    }
    locationFromCursor(t) {
      return new De(t.file, t.state.offset, t.state.line, t.state.column);
    }
  }, io = class vr2 extends Ii {
    internalState;
    constructor(t, r) {
      t instanceof vr2 ? (super(t), this.internalState = { ...t.internalState }) : (super(t, r), this.internalState = this.state);
    }
    advance() {
      this.state = this.internalState, super.advance(), this.processEscapeSequence();
    }
    init() {
      super.init(), this.processEscapeSequence();
    }
    clone() {
      return new vr2(this);
    }
    getChars(t) {
      let r = t.clone(), n = "";
      for (; r.internalState.offset < this.internalState.offset; ) n += String.fromCodePoint(r.peek()), r.advance();
      return n;
    }
    processEscapeSequence() {
      let t = () => this.internalState.peek;
      if (t() === 92) if (this.internalState = { ...this.state }, this.advanceState(this.internalState), t() === 110) this.state.peek = 10;
      else if (t() === 114) this.state.peek = 13;
      else if (t() === 118) this.state.peek = 11;
      else if (t() === 116) this.state.peek = 9;
      else if (t() === 98) this.state.peek = 8;
      else if (t() === 102) this.state.peek = 12;
      else if (t() === 117) if (this.advanceState(this.internalState), t() === 123) {
        this.advanceState(this.internalState);
        let r = this.clone(), n = 0;
        for (; t() !== 125; ) this.advanceState(this.internalState), n++;
        this.state.peek = this.decodeHexDigits(r, n);
      } else {
        let r = this.clone();
        this.advanceState(this.internalState), this.advanceState(this.internalState), this.advanceState(this.internalState), this.state.peek = this.decodeHexDigits(r, 4);
      }
      else if (t() === 120) {
        this.advanceState(this.internalState);
        let r = this.clone();
        this.advanceState(this.internalState), this.state.peek = this.decodeHexDigits(r, 2);
      } else if (_r(t())) {
        let r = "", n = 0, i = this.clone();
        for (; _r(t()) && n < 3; ) i = this.clone(), r += String.fromCodePoint(t()), this.advanceState(this.internalState), n++;
        this.state.peek = parseInt(r, 8), this.internalState = i.internalState;
      } else Oe(this.internalState.peek) ? (this.advanceState(this.internalState), this.state = this.internalState) : this.state.peek = this.internalState.peek;
    }
    decodeHexDigits(t, r) {
      let n = this.input.slice(t.internalState.offset, t.internalState.offset + r), i = parseInt(n, 16);
      if (isNaN(i)) throw t.state = t.internalState, new Cr("Invalid hexadecimal escape sequence", t);
      return i;
    }
  }, Cr = class extends Error {
    msg;
    cursor;
    constructor(e, t) {
      super(e), this.msg = e, this.cursor = t, Object.setPrototypeOf(this, new.target.prototype);
    }
  };
  var x = class Mi2 extends te {
    elementName;
    static create(t, r, n) {
      return new Mi2(t, r, n);
    }
    constructor(t, r, n) {
      super(r, n), this.elementName = t;
    }
  }, so = class {
    rootNodes;
    errors;
    constructor(e, t) {
      this.rootNodes = e, this.errors = t;
    }
  }, Bi = class {
    getTagDefinition;
    constructor(e) {
      this.getTagDefinition = e;
    }
    parse(e, t, r, n = false, i) {
      let s = (h) => (f, ...g2) => h(f.toLowerCase(), ...g2), a = n ? this.getTagDefinition : s(this.getTagDefinition), o = (h) => a(h).getContentType(), l = n ? i : s(i), c = Di(e, t, i ? (h, f, g2, v2) => {
        let W2 = l(h, f, g2, v2);
        return W2 !== void 0 ? W2 : o(h);
      } : o, r), u = r && r.canSelfClose || false, d = r && r.allowHtmComponentClosingTags || false, _ = new ao(c.tokens, a, u, d, n);
      return _.build(), new so(_.rootNodes, [...c.errors, ..._.errors]);
    }
  }, ao = class qi {
    tokens;
    tagDefinitionResolver;
    canSelfClose;
    allowHtmComponentClosingTags;
    isTagNameCaseSensitive;
    _index = -1;
    _peek;
    _containerStack = [];
    rootNodes = [];
    errors = [];
    constructor(t, r, n, i, s) {
      this.tokens = t, this.tagDefinitionResolver = r, this.canSelfClose = n, this.allowHtmComponentClosingTags = i, this.isTagNameCaseSensitive = s, this._advance();
    }
    build() {
      for (; this._peek.type !== 43; ) this._peek.type === 0 || this._peek.type === 4 ? this._consumeElementStartTag(this._advance()) : this._peek.type === 3 ? (this._closeVoidElement(), this._consumeElementEndTag(this._advance())) : this._peek.type === 13 ? (this._closeVoidElement(), this._consumeCdata(this._advance())) : this._peek.type === 10 ? (this._closeVoidElement(), this._consumeComment(this._advance())) : this._peek.type === 5 || this._peek.type === 7 || this._peek.type === 6 ? (this._closeVoidElement(), this._consumeText(this._advance())) : this._peek.type === 21 ? this._consumeExpansion(this._advance()) : this._peek.type === 26 ? (this._closeVoidElement(), this._consumeBlockOpen(this._advance())) : this._peek.type === 28 ? (this._closeVoidElement(), this._consumeBlockClose(this._advance())) : this._peek.type === 30 ? (this._closeVoidElement(), this._consumeIncompleteBlock(this._advance())) : this._peek.type === 31 ? (this._closeVoidElement(), this._consumeLet(this._advance())) : this._peek.type === 19 ? this._consumeDocType(this._advance()) : this._peek.type === 34 ? (this._closeVoidElement(), this._consumeIncompleteLet(this._advance())) : this._peek.type === 35 || this._peek.type === 39 ? this._consumeComponentStartTag(this._advance()) : this._peek.type === 38 ? this._consumeComponentEndTag(this._advance()) : this._advance();
      for (let t of this._containerStack) t instanceof ge && this.errors.push(x.create(t.name, t.sourceSpan, \`Unclosed block "\${t.name}"\`));
    }
    _advance() {
      let t = this._peek;
      return this._index < this.tokens.length - 1 && this._index++, this._peek = this.tokens[this._index], t;
    }
    _advanceIf(t) {
      return this._peek.type === t ? this._advance() : null;
    }
    _consumeCdata(t) {
      let r = this._advance(), n = this._getText(r), i = this._advanceIf(14);
      this._addToParent(new Si(n, new p(t.sourceSpan.start, (i || r).sourceSpan.end), [r]));
    }
    _consumeComment(t) {
      let r = this._advanceIf(7), n = this._advanceIf(11), i = r != null ? r.parts[0].trim() : null, s = n == null ? t.sourceSpan : new p(t.sourceSpan.start, n.sourceSpan.end, t.sourceSpan.fullStart);
      this._addToParent(new wi(i, s));
    }
    _consumeDocType(t) {
      let r = this._advanceIf(7), n = this._advanceIf(20), i = r != null ? r.parts[0].trim() : null, s = new p(t.sourceSpan.start, (n || r || t).sourceSpan.end);
      this._addToParent(new Ti(i, s));
    }
    _consumeExpansion(t) {
      let r = this._advance(), n = this._advance(), i = [];
      for (; this._peek.type === 22; ) {
        let a = this._parseExpansionCase();
        if (!a) return;
        i.push(a);
      }
      if (this._peek.type !== 25) {
        this.errors.push(x.create(null, this._peek.sourceSpan, "Invalid ICU message. Missing '}'."));
        return;
      }
      let s = new p(t.sourceSpan.start, this._peek.sourceSpan.end, t.sourceSpan.fullStart);
      this._addToParent(new vi(r.parts[0], n.parts[0], i, s, r.sourceSpan)), this._advance();
    }
    _parseExpansionCase() {
      let t = this._advance();
      if (this._peek.type !== 23) return this.errors.push(x.create(null, this._peek.sourceSpan, "Invalid ICU message. Missing '{'.")), null;
      let r = this._advance(), n = this._collectExpansionExpTokens(r);
      if (!n) return null;
      let i = this._advance();
      n.push({ type: 43, parts: [], sourceSpan: i.sourceSpan });
      let s = new qi(n, this.tagDefinitionResolver, this.canSelfClose, this.allowHtmComponentClosingTags, this.isTagNameCaseSensitive);
      if (s.build(), s.errors.length > 0) return this.errors = this.errors.concat(s.errors), null;
      let a = new p(t.sourceSpan.start, i.sourceSpan.end, t.sourceSpan.fullStart), o = new p(r.sourceSpan.start, i.sourceSpan.end, r.sourceSpan.fullStart);
      return new Ci(t.parts[0], s.rootNodes, a, t.sourceSpan, o);
    }
    _collectExpansionExpTokens(t) {
      let r = [], n = [23];
      for (; ; ) {
        if ((this._peek.type === 21 || this._peek.type === 23) && n.push(this._peek.type), this._peek.type === 24) if (Ri(n, 23)) {
          if (n.pop(), n.length === 0) return r;
        } else return this.errors.push(x.create(null, t.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        if (this._peek.type === 25) if (Ri(n, 21)) n.pop();
        else return this.errors.push(x.create(null, t.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        if (this._peek.type === 43) return this.errors.push(x.create(null, t.sourceSpan, "Invalid ICU message. Missing '}'.")), null;
        r.push(this._advance());
      }
    }
    _getText(t) {
      let r = t.parts[0];
      if (r.length > 0 && r[0] == \`
\`) {
        var n;
        let i = this._getClosestElementLikeParent();
        i != null && i.children.length == 0 && (!((n = this._getTagDefinition(i)) === null || n === void 0) && n.ignoreFirstLf) && (r = r.substring(1));
      }
      return r;
    }
    _consumeText(t) {
      let r = [t], n = t.sourceSpan, i = t.parts[0];
      if (i.length > 0 && i[0] === \`
\`) {
        var s;
        let a = this._getContainer();
        a != null && a.children.length === 0 && (!((s = this._getTagDefinition(a)) === null || s === void 0) && s.ignoreFirstLf) && (i = i.substring(1), r[0] = { type: t.type, sourceSpan: t.sourceSpan, parts: [i] });
      }
      for (; this._peek.type === 8 || this._peek.type === 5 || this._peek.type === 9; ) t = this._advance(), r.push(t), t.type === 8 ? i += t.parts.join("").replace(/&([^;]+);/g, Oi) : t.type === 9 ? i += t.parts[0] : i += t.parts.join("");
      if (i.length > 0) {
        let a = t.sourceSpan;
        this._addToParent(new _i(i, new p(n.start, a.end, n.fullStart, n.details), r));
      }
    }
    _closeVoidElement() {
      var t;
      let r = this._getContainer();
      r !== null && (!((t = this._getTagDefinition(r)) === null || t === void 0) && t.isVoid) && this._containerStack.pop();
    }
    _consumeElementStartTag(t) {
      var r;
      let n = [], i = [], s = [];
      this._consumeAttributesAndDirectives(n, i, s);
      let a = this._getElementFullName(t, this._getClosestElementLikeParent()), o = this._getTagDefinition(a), l = false;
      if (this._peek.type === 2) {
        this._advance(), l = true;
        let v2 = this._getTagDefinition(a);
        this.canSelfClose || v2?.canSelfClose || Pe(a) !== null || v2?.isVoid || this.errors.push(x.create(a, t.sourceSpan, \`Only void, custom and foreign elements can be self closed "\${t.parts[1]}"\`));
      } else this._peek.type === 1 && (this._advance(), l = false);
      let c = this._peek.sourceSpan.fullStart, u = new p(t.sourceSpan.start, c, t.sourceSpan.fullStart), d = new p(t.sourceSpan.start, c, t.sourceSpan.fullStart), _ = new p(t.sourceSpan.start.moveBy(1), t.sourceSpan.end), h = new re(a, n, i, [], l, u, d, void 0, _, o?.isVoid ?? false, void 0, s), f = this._getContainer(), g2 = f !== null && !!(!((r = this._getTagDefinition(f)) === null || r === void 0) && r.isClosedByChild(h.name));
      this._pushContainer(h, g2), l ? this._popContainer(a, re, u) : t.type === 4 && (this._popContainer(a, re, null), this.errors.push(x.create(a, u, \`Opening tag "\${a}" not terminated.\`)));
    }
    _consumeComponentStartTag(t) {
      var r;
      let n = t.parts[0], i = [], s = [], a = [];
      this._consumeAttributesAndDirectives(i, s, a);
      let o = this._getClosestElementLikeParent(), l = this._getComponentTagName(t, o), c = this._getComponentFullName(t, o), u = this._peek.type === 37;
      this._advance();
      let d = this._peek.sourceSpan.fullStart, _ = new p(t.sourceSpan.start, d, t.sourceSpan.fullStart), h = new U(n, l, c, i, s, [], u, _, new p(t.sourceSpan.start, d, t.sourceSpan.fullStart), void 0, void 0, a), f = this._getContainer(), g2 = f !== null && h.tagName !== null && !!(!((r = this._getTagDefinition(f)) === null || r === void 0) && r.isClosedByChild(h.tagName));
      this._pushContainer(h, g2), u ? this._popContainer(c, U, _) : t.type === 39 && (this._popContainer(c, U, null), this.errors.push(x.create(c, _, \`Opening tag "\${c}" not terminated.\`)));
    }
    _consumeAttributesAndDirectives(t, r, n) {
      for (; this._peek.type === 15 || this._peek.type === 40 || this._peek.type === 12; ) if (this._peek.type === 40) r.push(this._consumeDirective(this._peek));
      else if (this._peek.type === 15) t.push(this._consumeAttr(this._advance()));
      else {
        let i = this._advance();
        n.push(new bi(i.parts[0], i.parts[1], i.sourceSpan));
      }
    }
    _consumeComponentEndTag(t) {
      let r = this._getComponentFullName(t, this._getClosestElementLikeParent());
      if (!this._popContainer(r, U, t.sourceSpan)) {
        let n = this._containerStack[this._containerStack.length - 1], i;
        n instanceof U && n.componentName === t.parts[0] ? i = \`, did you mean "\${n.fullName}"?\` : i = ". It may happen when the tag has already been closed by another tag.";
        let s = \`Unexpected closing tag "\${r}"\${i}\`;
        this.errors.push(x.create(r, t.sourceSpan, s));
      }
    }
    _getTagDefinition(t) {
      return typeof t == "string" ? this.tagDefinitionResolver(t) : t instanceof re ? this.tagDefinitionResolver(t.name) : t instanceof U && t.tagName !== null ? this.tagDefinitionResolver(t.tagName) : null;
    }
    _pushContainer(t, r) {
      r && this._containerStack.pop(), this._addToParent(t), this._containerStack.push(t);
    }
    _consumeElementEndTag(t) {
      var r;
      let n = this.allowHtmComponentClosingTags && t.parts.length === 0 ? null : this._getElementFullName(t, this._getClosestElementLikeParent());
      if (n && (!((r = this._getTagDefinition(n)) === null || r === void 0) && r.isVoid)) this.errors.push(x.create(n, t.sourceSpan, \`Void elements do not have end tags "\${t.parts[1]}"\`));
      else if (!this._popContainer(n, re, t.sourceSpan)) {
        let i = \`Unexpected closing tag "\${n}". It may happen when the tag has already been closed by another tag. For more info see https://www.w3.org/TR/html5/syntax.html#closing-elements-that-have-implied-end-tags\`;
        this.errors.push(x.create(n, t.sourceSpan, i));
      }
    }
    _popContainer(t, r, n) {
      let i = false;
      for (let a = this._containerStack.length - 1; a >= 0; a--) {
        var s;
        let o = this._containerStack[a], l = o instanceof U ? o.fullName : o.name;
        if (Pe(l) ? l === t : (l === t || t === null) && o instanceof r) return o.endSourceSpan = n, o.sourceSpan.end = n !== null ? n.end : o.sourceSpan.end, this._containerStack.splice(a, this._containerStack.length - a), !i;
        (o instanceof ge || !(!((s = this._getTagDefinition(o)) === null || s === void 0) && s.closedByParent)) && (i = true);
      }
      return false;
    }
    _consumeAttr(t) {
      let r = fe(t.parts[0], t.parts[1]), n = t.sourceSpan.end, i;
      this._peek.type === 16 && (i = this._advance());
      let s = "", a = [], o, l;
      if (this._peek.type === 17) for (o = this._peek.sourceSpan, l = this._peek.sourceSpan.end; this._peek.type === 17 || this._peek.type === 18 || this._peek.type === 9; ) {
        let u = this._advance();
        a.push(u), u.type === 18 ? s += u.parts.join("").replace(/&([^;]+);/g, Oi) : u.type === 9 ? s += u.parts[0] : s += u.parts.join(""), l = n = u.sourceSpan.end;
      }
      this._peek.type === 16 && (l = n = this._advance().sourceSpan.end);
      let c = o && l && new p(i?.sourceSpan.start ?? o.start, l, i?.sourceSpan.fullStart ?? o.fullStart);
      return new ki(r, s, new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), t.sourceSpan, c, a.length > 0 ? a : void 0, void 0);
    }
    _consumeDirective(t) {
      let r = [], n = t.sourceSpan.end, i = null;
      if (this._advance(), this._peek.type === 41) {
        for (n = this._peek.sourceSpan.end, this._advance(); this._peek.type === 15; ) r.push(this._consumeAttr(this._advance()));
        this._peek.type === 42 ? (i = this._peek.sourceSpan, this._advance()) : this.errors.push(x.create(null, t.sourceSpan, "Unterminated directive definition"));
      }
      let s = new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), a = new p(s.start, i === null ? t.sourceSpan.end : i.end, s.fullStart);
      return new yi(t.parts[0], r, a, s, i);
    }
    _consumeBlockOpen(t) {
      let r = [];
      for (; this._peek.type === 29; ) {
        let o = this._advance();
        r.push(new fr(o.parts[0], o.sourceSpan));
      }
      this._peek.type === 27 && this._advance();
      let n = this._peek.sourceSpan.fullStart, i = new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), s = new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), a = new ge(t.parts[0], r, [], i, t.sourceSpan, s);
      this._pushContainer(a, false);
    }
    _consumeBlockClose(t) {
      let r = this._containerStack.length, n = this._containerStack[r - 1];
      if (!this._popContainer(null, ge, t.sourceSpan)) {
        if (this._containerStack.length < r) {
          let i = n instanceof U ? n.fullName : n.name;
          this.errors.push(x.create(null, t.sourceSpan, \`Unexpected closing block. The block may have been closed earlier. Did you forget to close the <\${i}> element? If you meant to write the \\\`}\\\` character, you should use the "&#125;" HTML entity instead.\`));
          return;
        }
        this.errors.push(x.create(null, t.sourceSpan, 'Unexpected closing block. The block may have been closed earlier. If you meant to write the \`}\` character, you should use the "&#125;" HTML entity instead.'));
      }
    }
    _consumeIncompleteBlock(t) {
      let r = [];
      for (; this._peek.type === 29; ) {
        let o = this._advance();
        r.push(new fr(o.parts[0], o.sourceSpan));
      }
      let n = this._peek.sourceSpan.fullStart, i = new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), s = new p(t.sourceSpan.start, n, t.sourceSpan.fullStart), a = new ge(t.parts[0], r, [], i, t.sourceSpan, s);
      this._pushContainer(a, false), this._popContainer(null, ge, null), this.errors.push(x.create(t.parts[0], i, \`Incomplete block "\${t.parts[0]}". If you meant to write the @ character, you should use the "&#64;" HTML entity instead.\`));
    }
    _consumeLet(t) {
      let r = t.parts[0], n, i;
      if (this._peek.type !== 32) {
        this.errors.push(x.create(t.parts[0], t.sourceSpan, \`Invalid @let declaration "\${r}". Declaration must have a value.\`));
        return;
      } else n = this._advance();
      if (this._peek.type !== 33) {
        this.errors.push(x.create(t.parts[0], t.sourceSpan, \`Unterminated @let declaration "\${r}". Declaration must be terminated with a semicolon.\`));
        return;
      } else i = this._advance();
      let s = i.sourceSpan.end, a = new p(t.sourceSpan.start, s, t.sourceSpan.fullStart), o = t.sourceSpan.toString().lastIndexOf(r), l = new p(t.sourceSpan.start.moveBy(o), t.sourceSpan.end), c = new dr(r, n.parts[0], a, l, n.sourceSpan);
      this._addToParent(c);
    }
    _consumeIncompleteLet(t) {
      let r = t.parts[0] ?? "", n = r ? \` "\${r}"\` : "";
      if (r.length > 0) {
        let i = t.sourceSpan.toString().lastIndexOf(r), s = new p(t.sourceSpan.start.moveBy(i), t.sourceSpan.end), a = new p(t.sourceSpan.start, t.sourceSpan.start.moveBy(0)), o = new dr(r, "", t.sourceSpan, s, a);
        this._addToParent(o);
      }
      this.errors.push(x.create(t.parts[0], t.sourceSpan, \`Incomplete @let declaration\${n}. @let declarations must be written as \\\`@let <name> = <value>;\\\`\`));
    }
    _getContainer() {
      return this._containerStack.length > 0 ? this._containerStack[this._containerStack.length - 1] : null;
    }
    _getClosestElementLikeParent() {
      for (let t = this._containerStack.length - 1; t > -1; t--) {
        let r = this._containerStack[t];
        if (r instanceof re || r instanceof U) return r;
      }
      return null;
    }
    _addToParent(t) {
      let r = this._getContainer();
      r === null ? this.rootNodes.push(t) : r.children.push(t);
    }
    _getElementFullName(t, r) {
      return fe(this._getPrefix(t, r), t.parts[1]);
    }
    _getComponentFullName(t, r) {
      let n = t.parts[0], i = this._getComponentTagName(t, r);
      return i === null ? n : i.startsWith(":") ? n + i : \`\${n}:\${i}\`;
    }
    _getComponentTagName(t, r) {
      let n = this._getPrefix(t, r), i = t.parts[2];
      return !n && !i ? null : !n && i ? i : fe(n, i || "ng-component");
    }
    _getPrefix(t, r) {
      var n;
      let i, s;
      if (t.type === 35 || t.type === 39 || t.type === 38 ? (i = t.parts[1], s = t.parts[2]) : (i = t.parts[0], s = t.parts[1]), i = i || ((n = this._getTagDefinition(s)) === null || n === void 0 ? void 0 : n.implicitNamespacePrefix) || "", !i && r) {
        let a = r instanceof re ? r.name : r.tagName;
        if (a !== null) {
          let o = Z(a)[1], l = this._getTagDefinition(o);
          l !== null && !l.preventNamespaceInheritance && (i = Pe(a));
        }
      }
      return i;
    }
  };
  function Ri(e, t) {
    return e.length > 0 && e[e.length - 1] === t;
  }
  function Oi(e, t) {
    return _e[t] !== void 0 ? _e[t] || e : /^#x[a-f0-9]+$/i.test(t) ? String.fromCodePoint(parseInt(t.slice(2), 16)) : /^#\\d+$/.test(t) ? String.fromCodePoint(parseInt(t.slice(1), 10)) : e;
  }
  var Hi = class extends Bi {
    constructor() {
      super(Ne);
    }
    parse(e, t, r, n = false, i) {
      return super.parse(e, t, r, n, i);
    }
  };
  var kr;
  function Mt(e, t = {}) {
    let { canSelfClose: r = false, allowHtmComponentClosingTags: n = false, allowStartTagComments: i = false, isTagNameCaseSensitive: s = false, getTagContentType: a, tokenizeAngularBlocks: o = false, tokenizeAngularLetDeclaration: l = false, enableAngularSelectorlessSyntax: c = false } = t;
    return kr ?? (kr = new Hi()), kr.parse(e, "angular-html-parser", { tokenizeExpansionForms: o, canSelfClose: r, allowHtmComponentClosingTags: n, allowStartTagComments: i, tokenizeBlocks: o, tokenizeLet: l, selectorlessEnabled: c }, s, a);
  }
  var oo = [co, uo, ho, fo, go, vo, _o, So, Co, mo];
  function lo(e, t) {
    for (let r of oo) r(e, t);
    return e;
  }
  function co(e) {
    e.walk((t) => {
      if (t.kind === "element" && t.tagDefinition.ignoreFirstLf && t.children.length > 0 && t.children[0].kind === "text" && t.children[0].value[0] === \`
\`) {
        let r = t.children[0];
        r.value.length === 1 ? t.removeChild(r) : r.value = r.value.slice(1);
      }
    });
  }
  function uo(e) {
    let t = (r) => r.kind === "element" && r.prev?.kind === "ieConditionalStartComment" && r.prev.sourceSpan.end.offset === r.startSourceSpan.start.offset && r.firstChild?.kind === "ieConditionalEndComment" && r.firstChild.sourceSpan.start.offset === r.startSourceSpan.end.offset;
    e.walk((r) => {
      if (r.children) for (let n = 0; n < r.children.length; n++) {
        let i = r.children[n];
        if (!t(i)) continue;
        let s = i.prev, a = i.firstChild;
        r.removeChild(s), n--;
        let o = new p(s.sourceSpan.start, a.sourceSpan.end), l = new p(o.start, i.sourceSpan.end);
        i.condition = s.condition, i.sourceSpan = l, i.startSourceSpan = o, i.removeChild(a);
      }
    });
  }
  function po(e, t, r) {
    e.walk((n) => {
      if (n.children) for (let i = 0; i < n.children.length; i++) {
        let s = n.children[i];
        if (s.kind !== "text" && !t(s)) continue;
        s.kind !== "text" && (s.kind = "text", s.value = r(s));
        let a = s.prev;
        !a || a.kind !== "text" || (a.value += s.value, a.sourceSpan = new p(a.sourceSpan.start, s.sourceSpan.end), n.removeChild(s), i--);
      }
    });
  }
  function ho(e) {
    return po(e, (t) => t.kind === "cdata", (t) => \`<![CDATA[\${t.value}]]>\`);
  }
  function mo(e) {
    let t = (r) => r.kind === "element" && r.attrs.length === 0 && !X(r.startTagComments) && r.children.length === 1 && r.firstChild.kind === "text" && !P.hasWhitespaceCharacter(r.children[0].value) && !r.firstChild.hasLeadingSpaces && !r.firstChild.hasTrailingSpaces && r.isLeadingSpaceSensitive && !r.hasLeadingSpaces && r.isTrailingSpaceSensitive && !r.hasTrailingSpaces && r.prev?.kind === "text" && r.next?.kind === "text";
    e.walk((r) => {
      if (r.children) for (let n = 0; n < r.children.length; n++) {
        let i = r.children[n];
        if (!t(i)) continue;
        let s = i.prev, a = i.next;
        s.value += \`<\${i.rawName}>\` + i.firstChild.value + \`</\${i.rawName}>\` + a.value, s.sourceSpan = new p(s.sourceSpan.start, a.sourceSpan.end), s.isTrailingSpaceSensitive = a.isTrailingSpaceSensitive, s.hasTrailingSpaces = a.hasTrailingSpaces, r.removeChild(i), n--, r.removeChild(a);
      }
    });
  }
  function fo(e, t) {
    if (t.parser === "html") return;
    let r = /\\{\\{(.+?)\\}\\}/s;
    e.walk((n) => {
      if (rn(n, t)) for (let i of n.children) {
        if (i.kind !== "text") continue;
        let s = i.sourceSpan.start, a, o = i.value.split(r);
        for (let l = 0; l < o.length; l++, s = a) {
          let c = o[l];
          if (l % 2 === 0) {
            a = s.moveBy(c.length), c.length > 0 && n.insertChildBefore(i, { kind: "text", value: c, sourceSpan: new p(s, a) });
            continue;
          }
          a = s.moveBy(c.length + 4), n.insertChildBefore(i, { kind: "interpolation", sourceSpan: new p(s, a), children: c.length === 0 ? [] : [{ kind: "text", value: c, sourceSpan: new p(s.moveBy(2), a.moveBy(-2)) }] });
        }
        n.removeChild(i);
      }
    });
  }
  function go(e, t) {
    e.walk((r) => {
      let n = r.$children;
      if (!n) return;
      if (n.length === 0 || n.length === 1 && n[0].kind === "text" && P.trim(n[0].value).length === 0) {
        r.hasDanglingSpaces = n.length > 0, r.$children = [];
        return;
      }
      let i = nn(r, t), s = er(r);
      if (!i) for (let a = 0; a < n.length; a++) {
        let o = n[a];
        if (o.kind !== "text") continue;
        let { leadingWhitespace: l, text: c, trailingWhitespace: u } = tn(o.value), d = o.prev, _ = o.next;
        c ? (o.value = c, o.sourceSpan = new p(o.sourceSpan.start.moveBy(l.length), o.sourceSpan.end.moveBy(-u.length)), l && (d && (d.hasTrailingSpaces = true), o.hasLeadingSpaces = true), u && (o.hasTrailingSpaces = true, _ && (_.hasLeadingSpaces = true))) : (r.removeChild(o), a--, (l || u) && (d && (d.hasTrailingSpaces = true), _ && (_.hasLeadingSpaces = true)));
      }
      r.isWhitespaceSensitive = i, r.isIndentationSensitive = s;
    });
  }
  function _o(e) {
    e.walk((t) => {
      t.isSelfClosing = !t.children || t.kind === "element" && (t.tagDefinition.isVoid || t.endSourceSpan && t.startSourceSpan.start === t.endSourceSpan.start && t.startSourceSpan.end === t.endSourceSpan.end);
    });
  }
  function So(e, t) {
    e.walk((r) => {
      r.kind === "element" && (r.hasHtmComponentClosingTag = r.endSourceSpan && /^<\\s*\\/\\s*\\/\\s*>$/.test(t.originalText.slice(r.endSourceSpan.start.offset, r.endSourceSpan.end.offset)));
    });
  }
  function vo(e, t) {
    e.walk((r) => {
      r.cssDisplay = fn(r, t);
    });
  }
  function Co(e, t) {
    e.walk((r) => {
      let { children: n } = r;
      if (n) {
        if (n.length === 0) {
          r.isDanglingSpaceSensitive = on(r, t);
          return;
        }
        for (let i of n) i.isLeadingSpaceSensitive = sn(i, t), i.isTrailingSpaceSensitive = an(i, t);
        for (let i = 0; i < n.length; i++) {
          let s = n[i];
          s.isLeadingSpaceSensitive = (i === 0 || s.prev.isTrailingSpaceSensitive) && s.isLeadingSpaceSensitive, s.isTrailingSpaceSensitive = (i === n.length - 1 || s.next.isLeadingSpaceSensitive) && s.isTrailingSpaceSensitive;
        }
      }
    });
  }
  var Fi = lo;
  function ko(e, t, r) {
    let { node: n } = e;
    switch (n.kind) {
      case "root":
        return t.__onHtmlRoot && t.__onHtmlRoot(n), [C(Ae(e, t, r)), k];
      case "element":
      case "ieConditionalComment":
        return li(e, t, r);
      case "angularControlFlowBlock":
        return ni(e, t, r);
      case "angularControlFlowBlockParameters":
        return si(e, t, r);
      case "angularControlFlowBlockParameter":
        return P.trim(n.expression);
      case "angularLetDeclaration":
        return C(["@let ", C([n.id, " =", C(A([S, r("init")]))]), ";"]);
      case "angularLetDeclarationInitializer":
        return n.value;
      case "angularIcuExpression":
        return ai(e, t, r);
      case "angularIcuCase":
        return oi(e, t, r);
      case "ieConditionalStartComment":
      case "ieConditionalEndComment":
        return [me(n), ue(n)];
      case "interpolation":
        return [me(n, t), ...e.map(r, "children"), ue(n, t)];
      case "text": {
        if (n.parent.kind === "interpolation") {
          let o = /\\n[^\\S\\n]*$/, l = o.test(n.value), c = l ? n.value.replace(o, "") : n.value;
          return [L(c), l ? k : ""];
        }
        let i = B(n, t), s = Tt(n), a = M(n, t);
        return s[0] = [i, s[0]], s.push([s.pop(), a]), gt(s);
      }
      case "docType":
        return [C([me(n, t), " ", T(0, n.value.replace(/^html\\b/i, "html"), /\\s+/g, " ")]), ue(n, t)];
      case "comment":
        return [B(n, t), L(t.originalText.slice(F(n), J(n))), M(n, t)];
      case "attribute": {
        if (n.value === null) return n.rawName;
        let i = nr(n.value), s = Et(n, t) ? "" : Wr(i);
        return [n.rawName, "=", s, L(s === '"' ? T(0, i, '"', "&quot;") : T(0, i, "'", "&apos;")), s];
      }
      case "startTagComment":
        return ci(e);
      default:
        throw new Gr(n, "HTML");
    }
  }
  var bo = { features: { experimental_frontMatterSupport: { massageAstNode: true, embed: true, print: true } }, preprocess: Fi, print: ko, insertPragma: ei, massageAstNode: or, embed: Gn, getVisitorKeys: Yn }, Vi = bo;
  var Ui = [{ name: "Angular", type: "markup", aceMode: "html", extensions: [".component.html"], tmScope: "text.html.basic", aliases: ["xhtml"], codemirrorMode: "htmlmixed", codemirrorMimeType: "text/html", parsers: ["angular"], vscodeLanguageIds: ["html"], filenames: [], linguistLanguageId: 146 }, { name: "HTML", type: "markup", aceMode: "html", extensions: [".html", ".hta", ".htm", ".html.hl", ".inc", ".xht", ".xhtml"], tmScope: "text.html.basic", aliases: ["xhtml"], codemirrorMode: "htmlmixed", codemirrorMimeType: "text/html", parsers: ["html"], vscodeLanguageIds: ["html"], linguistLanguageId: 146 }, { name: "Lightning Web Components", type: "markup", aceMode: "html", extensions: [], tmScope: "text.html.basic", aliases: ["LWC", "lwc"], codemirrorMode: "htmlmixed", codemirrorMimeType: "text/html", parsers: ["lwc"], vscodeLanguageIds: ["html"], filenames: [], linguistLanguageId: 146 }, { name: "MJML", type: "markup", aceMode: "html", extensions: [".mjml"], tmScope: "text.mjml.basic", aliases: ["MJML", "mjml"], codemirrorMode: "htmlmixed", codemirrorMimeType: "text/html", parsers: ["mjml"], filenames: [], vscodeLanguageIds: ["mjml"], linguistLanguageId: 146 }, { name: "Vue", type: "markup", aceMode: "vue", extensions: [".vue"], tmScope: "text.html.vue", codemirrorMode: "vue", codemirrorMimeType: "text/x-vue", parsers: ["vue"], vscodeLanguageIds: ["vue"], linguistLanguageId: 391 }];
  var br = { bracketSameLine: { category: "Common", type: "boolean", default: false, description: "Put > of opening tags on the last line instead of on a new line." }, singleAttributePerLine: { category: "Common", type: "boolean", default: false, description: "Enforce single attribute per line in HTML, Vue and JSX." } };
  var Wi = "HTML", wo = { bracketSameLine: br.bracketSameLine, htmlWhitespaceSensitivity: { category: Wi, type: "choice", default: "css", description: "How to handle whitespaces in HTML.", choices: [{ value: "css", description: "Respect the default value of CSS display property." }, { value: "strict", description: "Whitespaces are considered sensitive." }, { value: "ignore", description: "Whitespaces are considered insensitive." }] }, singleAttributePerLine: br.singleAttributePerLine, vueIndentScriptAndStyle: { category: Wi, type: "boolean", default: false, description: "Indent script and style tags in Vue files." } }, zi = wo;
  var Pr = {};
  Ir(Pr, { angular: () => Wo, html: () => Fo, lwc: () => Go, mjml: () => Uo, vue: () => zo });
  function To(e, t) {
    let r = new SyntaxError(e + " (" + t.loc.start.line + ":" + t.loc.start.column + ")");
    return Object.assign(r, t);
  }
  var Gi = To;
  var yo = { canSelfClose: true, normalizeTagName: false, normalizeAttributeName: false, allowHtmComponentClosingTags: false, allowStartTagComments: false, isTagNameCaseSensitive: false, shouldParseFrontMatter: true };
  function Bt(e) {
    return { ...yo, ...e };
  }
  function wr(e) {
    let { canSelfClose: t, allowHtmComponentClosingTags: r, allowStartTagComments: n, isTagNameCaseSensitive: i, shouldParseAsRawText: s, tokenizeAngularBlocks: a, tokenizeAngularLetDeclaration: o } = e;
    return { canSelfClose: t, allowHtmComponentClosingTags: r, allowStartTagComments: n, isTagNameCaseSensitive: i, getTagContentType: s ? (...l) => s(...l) ? lr.RAW_TEXT : void 0 : void 0, tokenizeAngularBlocks: a, tokenizeAngularLetDeclaration: o };
  }
  var qt = /* @__PURE__ */ new Map([["*", /* @__PURE__ */ new Set(["accesskey", "autocapitalize", "autocorrect", "autofocus", "class", "contenteditable", "dir", "draggable", "enterkeyhint", "exportparts", "hidden", "id", "inert", "inputmode", "is", "itemid", "itemprop", "itemref", "itemscope", "itemtype", "lang", "nonce", "part", "popover", "slot", "spellcheck", "style", "tabindex", "title", "translate", "writingsuggestions"])], ["a", /* @__PURE__ */ new Set(["charset", "coords", "download", "href", "hreflang", "name", "ping", "referrerpolicy", "rel", "rev", "shape", "target", "type"])], ["applet", /* @__PURE__ */ new Set(["align", "alt", "archive", "code", "codebase", "height", "hspace", "name", "object", "vspace", "width"])], ["area", /* @__PURE__ */ new Set(["alt", "coords", "download", "href", "hreflang", "nohref", "ping", "referrerpolicy", "rel", "shape", "target", "type"])], ["audio", /* @__PURE__ */ new Set(["autoplay", "controls", "crossorigin", "loop", "muted", "preload", "src"])], ["base", /* @__PURE__ */ new Set(["href", "target"])], ["basefont", /* @__PURE__ */ new Set(["color", "face", "size"])], ["blockquote", /* @__PURE__ */ new Set(["cite"])], ["body", /* @__PURE__ */ new Set(["alink", "background", "bgcolor", "link", "text", "vlink"])], ["br", /* @__PURE__ */ new Set(["clear"])], ["button", /* @__PURE__ */ new Set(["command", "commandfor", "disabled", "form", "formaction", "formenctype", "formmethod", "formnovalidate", "formtarget", "name", "popovertarget", "popovertargetaction", "type", "value"])], ["canvas", /* @__PURE__ */ new Set(["height", "width"])], ["caption", /* @__PURE__ */ new Set(["align"])], ["col", /* @__PURE__ */ new Set(["align", "char", "charoff", "span", "valign", "width"])], ["colgroup", /* @__PURE__ */ new Set(["align", "char", "charoff", "span", "valign", "width"])], ["data", /* @__PURE__ */ new Set(["value"])], ["del", /* @__PURE__ */ new Set(["cite", "datetime"])], ["details", /* @__PURE__ */ new Set(["name", "open"])], ["dialog", /* @__PURE__ */ new Set(["closedby", "open"])], ["dir", /* @__PURE__ */ new Set(["compact"])], ["div", /* @__PURE__ */ new Set(["align"])], ["dl", /* @__PURE__ */ new Set(["compact"])], ["embed", /* @__PURE__ */ new Set(["height", "src", "type", "width"])], ["fieldset", /* @__PURE__ */ new Set(["disabled", "form", "name"])], ["font", /* @__PURE__ */ new Set(["color", "face", "size"])], ["form", /* @__PURE__ */ new Set(["accept", "accept-charset", "action", "autocomplete", "enctype", "method", "name", "novalidate", "target"])], ["frame", /* @__PURE__ */ new Set(["frameborder", "longdesc", "marginheight", "marginwidth", "name", "noresize", "scrolling", "src"])], ["frameset", /* @__PURE__ */ new Set(["cols", "rows"])], ["h1", /* @__PURE__ */ new Set(["align"])], ["h2", /* @__PURE__ */ new Set(["align"])], ["h3", /* @__PURE__ */ new Set(["align"])], ["h4", /* @__PURE__ */ new Set(["align"])], ["h5", /* @__PURE__ */ new Set(["align"])], ["h6", /* @__PURE__ */ new Set(["align"])], ["head", /* @__PURE__ */ new Set(["profile"])], ["hr", /* @__PURE__ */ new Set(["align", "noshade", "size", "width"])], ["html", /* @__PURE__ */ new Set(["manifest", "version"])], ["iframe", /* @__PURE__ */ new Set(["align", "allow", "allowfullscreen", "allowpaymentrequest", "allowusermedia", "frameborder", "height", "loading", "longdesc", "marginheight", "marginwidth", "name", "referrerpolicy", "sandbox", "scrolling", "src", "srcdoc", "width"])], ["img", /* @__PURE__ */ new Set(["align", "alt", "border", "crossorigin", "decoding", "fetchpriority", "height", "hspace", "ismap", "loading", "longdesc", "name", "referrerpolicy", "sizes", "src", "srcset", "usemap", "vspace", "width"])], ["input", /* @__PURE__ */ new Set(["accept", "align", "alpha", "alt", "autocomplete", "checked", "colorspace", "dirname", "disabled", "form", "formaction", "formenctype", "formmethod", "formnovalidate", "formtarget", "height", "ismap", "list", "max", "maxlength", "min", "minlength", "multiple", "name", "pattern", "placeholder", "popovertarget", "popovertargetaction", "readonly", "required", "size", "src", "step", "type", "usemap", "value", "width"])], ["ins", /* @__PURE__ */ new Set(["cite", "datetime"])], ["isindex", /* @__PURE__ */ new Set(["prompt"])], ["label", /* @__PURE__ */ new Set(["for", "form"])], ["legend", /* @__PURE__ */ new Set(["align"])], ["li", /* @__PURE__ */ new Set(["type", "value"])], ["link", /* @__PURE__ */ new Set(["as", "blocking", "charset", "color", "crossorigin", "disabled", "fetchpriority", "href", "hreflang", "imagesizes", "imagesrcset", "integrity", "media", "referrerpolicy", "rel", "rev", "sizes", "target", "type"])], ["map", /* @__PURE__ */ new Set(["name"])], ["menu", /* @__PURE__ */ new Set(["compact"])], ["meta", /* @__PURE__ */ new Set(["charset", "content", "http-equiv", "media", "name", "scheme"])], ["meter", /* @__PURE__ */ new Set(["high", "low", "max", "min", "optimum", "value"])], ["object", /* @__PURE__ */ new Set(["align", "archive", "border", "classid", "codebase", "codetype", "data", "declare", "form", "height", "hspace", "name", "standby", "type", "typemustmatch", "usemap", "vspace", "width"])], ["ol", /* @__PURE__ */ new Set(["compact", "reversed", "start", "type"])], ["optgroup", /* @__PURE__ */ new Set(["disabled", "label"])], ["option", /* @__PURE__ */ new Set(["disabled", "label", "selected", "value"])], ["output", /* @__PURE__ */ new Set(["for", "form", "name"])], ["p", /* @__PURE__ */ new Set(["align"])], ["param", /* @__PURE__ */ new Set(["name", "type", "value", "valuetype"])], ["pre", /* @__PURE__ */ new Set(["width"])], ["progress", /* @__PURE__ */ new Set(["max", "value"])], ["q", /* @__PURE__ */ new Set(["cite"])], ["script", /* @__PURE__ */ new Set(["async", "blocking", "charset", "crossorigin", "defer", "fetchpriority", "integrity", "language", "nomodule", "referrerpolicy", "src", "type"])], ["select", /* @__PURE__ */ new Set(["autocomplete", "disabled", "form", "multiple", "name", "required", "size"])], ["slot", /* @__PURE__ */ new Set(["name"])], ["source", /* @__PURE__ */ new Set(["height", "media", "sizes", "src", "srcset", "type", "width"])], ["style", /* @__PURE__ */ new Set(["blocking", "media", "type"])], ["table", /* @__PURE__ */ new Set(["align", "bgcolor", "border", "cellpadding", "cellspacing", "frame", "rules", "summary", "width"])], ["tbody", /* @__PURE__ */ new Set(["align", "char", "charoff", "valign"])], ["td", /* @__PURE__ */ new Set(["abbr", "align", "axis", "bgcolor", "char", "charoff", "colspan", "headers", "height", "nowrap", "rowspan", "scope", "valign", "width"])], ["template", /* @__PURE__ */ new Set(["shadowrootclonable", "shadowrootcustomelementregistry", "shadowrootdelegatesfocus", "shadowrootmode", "shadowrootserializable"])], ["textarea", /* @__PURE__ */ new Set(["autocomplete", "cols", "dirname", "disabled", "form", "maxlength", "minlength", "name", "placeholder", "readonly", "required", "rows", "wrap"])], ["tfoot", /* @__PURE__ */ new Set(["align", "char", "charoff", "valign"])], ["th", /* @__PURE__ */ new Set(["abbr", "align", "axis", "bgcolor", "char", "charoff", "colspan", "headers", "height", "nowrap", "rowspan", "scope", "valign", "width"])], ["thead", /* @__PURE__ */ new Set(["align", "char", "charoff", "valign"])], ["time", /* @__PURE__ */ new Set(["datetime"])], ["tr", /* @__PURE__ */ new Set(["align", "bgcolor", "char", "charoff", "valign"])], ["track", /* @__PURE__ */ new Set(["default", "kind", "label", "src", "srclang"])], ["ul", /* @__PURE__ */ new Set(["compact", "type"])], ["video", /* @__PURE__ */ new Set(["autoplay", "controls", "crossorigin", "height", "loop", "muted", "playsinline", "poster", "preload", "src", "width"])]]);
  var $i = /* @__PURE__ */ new Set(["a", "abbr", "acronym", "address", "applet", "area", "article", "aside", "audio", "b", "base", "basefont", "bdi", "bdo", "bgsound", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "command", "content", "data", "datalist", "dd", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "em", "embed", "fencedframe", "fieldset", "figcaption", "figure", "font", "footer", "form", "frame", "frameset", "geolocation", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "image", "img", "input", "ins", "isindex", "kbd", "keygen", "label", "legend", "li", "link", "listing", "main", "map", "mark", "marquee", "math", "menu", "menuitem", "meta", "meter", "multicol", "nav", "nextid", "nobr", "noembed", "noframes", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "picture", "plaintext", "pre", "progress", "q", "rb", "rbc", "rp", "rt", "rtc", "ruby", "s", "samp", "script", "search", "section", "select", "selectedcontent", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "svg", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "tt", "u", "ul", "var", "video", "wbr", "xmp"]);
  var Ht = { attrs: true, children: true, cases: true, expression: true }, ji = /* @__PURE__ */ new Set(["parent"]), ne, Tr, yr, Me = class Me2 {
    constructor(t = {}) {
      Rr(this, ne);
      Wt(this, "kind");
      Wt(this, "parent");
      for (let r of /* @__PURE__ */ new Set([...ji, ...Object.keys(t)])) this.setProperty(r, t[r]);
      if (ae(t)) for (let r of Object.getOwnPropertySymbols(t)) this.setProperty(r, t[r]);
    }
    setProperty(t, r) {
      if (this[t] !== r) {
        if (t in Ht && (r = r.map((n) => this.createChild(n))), !ji.has(t)) {
          this[t] = r;
          return;
        }
        Object.defineProperty(this, t, { value: r, enumerable: false, configurable: true });
      }
    }
    map(t) {
      let r;
      for (let n in Ht) {
        let i = this[n];
        if (i) {
          let s = Eo(i, (a) => a.map(t));
          r !== i && (r ?? (r = new Me2({ parent: this.parent })), r.setProperty(n, s));
        }
      }
      if (r) for (let n in this) n in Ht || (r[n] = this[n]);
      return t(r || this);
    }
    walk(t) {
      for (let r in Ht) {
        let n = this[r];
        if (n) for (let i = 0; i < n.length; i++) n[i].walk(t);
      }
      t(this);
    }
    createChild(t) {
      let r = t instanceof Me2 ? t.clone() : new Me2(t);
      return r.setProperty("parent", this), r;
    }
    insertChildBefore(t, r) {
      let n = this.$children;
      n.splice(n.indexOf(t), 0, this.createChild(r));
    }
    removeChild(t) {
      let r = this.$children;
      r.splice(r.indexOf(t), 1);
    }
    replaceChild(t, r) {
      let n = this.$children;
      n[n.indexOf(t)] = this.createChild(r);
    }
    clone() {
      return new Me2(this);
    }
    get $children() {
      return this[qe(this, ne, Tr)];
    }
    set $children(t) {
      this[qe(this, ne, Tr)] = t;
    }
    get firstChild() {
      return this.$children?.[0];
    }
    get lastChild() {
      return I(1, this.$children, -1);
    }
    get prev() {
      let t = qe(this, ne, yr);
      return t[t.indexOf(this) - 1];
    }
    get next() {
      let t = qe(this, ne, yr);
      return t[t.indexOf(this) + 1];
    }
    get rawName() {
      return this.hasExplicitNamespace ? this.fullName : this.name;
    }
    get fullName() {
      return this.namespace ? this.namespace + ":" + this.name : this.name;
    }
    get attrMap() {
      return Object.fromEntries(this.attrs.map((t) => [t.fullName, t.value]));
    }
  };
  ne = /* @__PURE__ */ new WeakSet(), Tr = function() {
    return this.kind === "angularIcuCase" ? "expression" : this.kind === "angularIcuExpression" ? "cases" : "children";
  }, yr = function() {
    return this.parent?.$children ?? [];
  };
  var Ft = Me;
  function Eo(e, t) {
    let r = e.map(t);
    return r.some((n, i) => n !== e[i]) ? r : e;
  }
  var xo = [{ regex: /^(?<openingTagSuffix>\\[if(?<condition>[^\\]]*)\\]>)(?<data>.*?)<!\\s*\\[endif\\]$/s, parse: Lo }, { regex: /^\\[if(?<condition>[^\\]]*)\\]><!$/, parse: Ao }, { regex: /^<!\\s*\\[endif\\]$/, parse: Po }];
  function Yi(e, t) {
    if (e.value) for (let { regex: r, parse: n } of xo) {
      let i = e.value.match(r);
      if (i) return n(e, i, t);
    }
    return null;
  }
  function Lo(e, t, r) {
    let { openingTagSuffix: n, condition: i, data: s } = t.groups, a = 4 + n.length, o = e.sourceSpan.start.moveBy(a), l = o.moveBy(s.length), [c, u] = (() => {
      try {
        return [true, r(s, o).children];
      } catch {
        return [false, [{ kind: "text", value: s, sourceSpan: new p(o, l) }]];
      }
    })();
    return { kind: "ieConditionalComment", complete: c, children: u, condition: T(0, i.trim(), /\\s+/g, " "), sourceSpan: e.sourceSpan, startSourceSpan: new p(e.sourceSpan.start, o), endSourceSpan: new p(l, e.sourceSpan.end) };
  }
  function Ao(e, t) {
    let { condition: r } = t.groups;
    return { kind: "ieConditionalStartComment", condition: T(0, r.trim(), /\\s+/g, " "), sourceSpan: e.sourceSpan };
  }
  function Po(e) {
    return { kind: "ieConditionalEndComment", sourceSpan: e.sourceSpan };
  }
  var Er = class extends gr {
    visitExpansionCase(t, r) {
      r.parseOptions.name === "angular" && this.visitChildren(r, (n) => {
        n(t.expression);
      });
    }
    visit(t, { parseOptions: r }) {
      Ro(t), Oo(t, r), Bo(t, r), Mo(t);
    }
  };
  function Xi(e, t, r, n) {
    let i = r.name === "angular";
    It(new Er(), e.children, { parseOptions: r }), t && e.children.unshift(t);
    let s = new Ft(e);
    return s.walk((a) => {
      if (a.kind === "comment") {
        let o = Yi(a, n);
        o && a.parent.replaceChild(a, o);
      } else i && a.kind === "element" && a.comments && (a.startTagComments = a.comments, delete a.comments);
      i && (No(a), Do(a), Io(a));
    }), s;
  }
  function No(e) {
    if (e.kind === "block") {
      if (e.name = T(0, e.name.toLowerCase(), /\\s+/g, " ").trim(), e.kind = "angularControlFlowBlock", !X(e.parameters)) {
        delete e.parameters;
        return;
      }
      for (let t of e.parameters) t.kind = "angularControlFlowBlockParameter";
      e.parameters = { kind: "angularControlFlowBlockParameters", children: e.parameters, sourceSpan: new p(e.parameters[0].sourceSpan.start, I(0, e.parameters, -1).sourceSpan.end) };
    }
  }
  function Do(e) {
    e.kind === "letDeclaration" && (e.kind = "angularLetDeclaration", e.id = e.name, e.init = { kind: "angularLetDeclarationInitializer", sourceSpan: new p(e.valueSpan.start, e.valueSpan.end), value: e.value }, delete e.name, delete e.value);
  }
  function Io(e) {
    e.kind === "expansion" && (e.kind = "angularIcuExpression"), e.kind === "expansionCase" && (e.kind = "angularIcuCase");
  }
  function Ki(e, t) {
    let r = e.toLowerCase();
    return t(r) ? r : e;
  }
  function Qi(e) {
    let t = e.name.startsWith(":") ? e.name.slice(1).split(":", 1)[0] : null, r = e.nameSpan.toString(), n = t !== null && r.startsWith(\`\${t}:\`), i = n ? r.slice(t.length + 1) : r;
    e.name = i, e.namespace = t, e.hasExplicitNamespace = n;
  }
  function Ro(e) {
    switch (e.kind) {
      case "element":
        Qi(e);
        for (let t of e.attrs) Qi(t), t.valueSpan ? (t.value = t.valueSpan.toString(), /["']/.test(t.value[0]) && (t.value = t.value.slice(1, -1))) : t.value = null;
        break;
      case "comment":
        e.value = e.sourceSpan.toString().slice(4, -3);
        break;
      case "text":
        e.value = e.sourceSpan.toString();
        break;
    }
  }
  function Oo(e, t) {
    if (e.kind === "element") {
      let r = Ne(t.isTagNameCaseSensitive ? e.name : e.name.toLowerCase());
      !e.namespace || e.namespace === r.implicitNamespacePrefix || oe(e) ? e.tagDefinition = r : e.tagDefinition = Ne("");
    }
  }
  function Mo(e) {
    e.sourceSpan && e.endSourceSpan && (e.sourceSpan = new p(e.sourceSpan.start, e.endSourceSpan.end));
  }
  function Bo(e, t) {
    if (e.kind === "element" && (t.normalizeTagName && (!e.namespace || e.namespace === e.tagDefinition.implicitNamespacePrefix || oe(e)) && (e.name = Ki(e.name, (r) => $i.has(r))), t.normalizeAttributeName)) for (let r of e.attrs) r.namespace || (r.name = Ki(r.name, (n) => qt.has(e.name) && (qt.get("*").has(n) || qt.get(e.name).has(n))));
  }
  function Lr(e, t) {
    let { rootNodes: r, errors: n } = Mt(e, wr(t));
    return n.length > 0 && xr(n[0]), { parseOptions: t, rootNodes: r };
  }
  function Ji(e, t) {
    let r = wr(t), { rootNodes: n, errors: i } = Mt(e, r);
    if (n.some((c) => c.kind === "docType" && c.value === "html" || c.kind === "element" && c.name.toLowerCase() === "html")) return Lr(e, Vt);
    let a, o = () => a ?? (a = Mt(e, { ...r, getTagContentType: void 0 })), l = (c) => {
      let { offset: u } = c.startSourceSpan.start;
      return o().rootNodes.find((d) => d.kind === "element" && d.startSourceSpan.start.offset === u) ?? c;
    };
    for (let [c, u] of n.entries()) if (u.kind === "element") {
      if (u.isVoid) i = o().errors, n[c] = l(u);
      else if (qo(u)) {
        let { endSourceSpan: d, startSourceSpan: _ } = u, h = o().errors.find((f) => f.span.start.offset > _.start.offset && f.span.start.offset < d.end.offset);
        h && xr(h), n[c] = l(u);
      }
    }
    return i.length > 0 && xr(i[0]), { parseOptions: t, rootNodes: n };
  }
  function qo(e) {
    if (e.kind !== "element" || e.name !== "template") return false;
    let t = e.attrs.find((r) => r.name === "lang")?.value;
    return !t || t === "html";
  }
  function xr(e) {
    let { msg: t, span: { start: r, end: n } } = e;
    throw Gi(t, { loc: { start: { line: r.line + 1, column: r.col + 1 }, end: { line: n.line + 1, column: n.col + 1 } }, cause: e });
  }
  function Ho(e, t, r, n, i, s) {
    let { offset: a } = n, o = vt(t.slice(0, a)) + r, l = Ar(o, e, { ...i, shouldParseFrontMatter: false }, s);
    l.sourceSpan = new p(n, I(0, l.children, -1).sourceSpan.end);
    let c = l.children[0];
    return c.length === a ? l.children.shift() : (c.sourceSpan = new p(c.sourceSpan.start.moveBy(a), c.sourceSpan.end), c.value = c.value.slice(a)), l;
  }
  function Ar(e, t, r, n = {}) {
    let { frontMatter: i, content: s } = r.shouldParseFrontMatter ? Qt(e) : { content: e }, a = new rt(e, n.filepath), o = new De(a, 0, 0, 0), l = o.moveBy(e.length), { parseOptions: c, rootNodes: u } = t(s, r), d = { kind: "root", sourceSpan: new p(o, l), children: u }, _;
    if (i) {
      let [f, g2] = [i.start, i.end].map((v2) => new De(a, v2.index, v2.line - 1, v2.column));
      _ = { ...i, kind: "frontMatter", sourceSpan: new p(f, g2) };
    }
    return Xi(d, _, c, (f, g2) => Ho(t, e, f, g2, c, n));
  }
  var Vt = Bt({ name: "html", normalizeTagName: true, normalizeAttributeName: true, allowHtmComponentClosingTags: true });
  function st(e) {
    let t = Bt(e), r = t.name === "vue" ? Ji : Lr;
    return { parse: (n, i) => Ar(n, r, t, i), hasPragma: Jn, hasIgnorePragma: Zn, astFormat: "html", locStart: F, locEnd: J };
  }
  var Fo = st(Vt), Vo = /* @__PURE__ */ new Set(["mj-style", "mj-raw"]), Uo = st({ ...Vt, name: "mjml", shouldParseAsRawText: (e) => Vo.has(e) }), Wo = st({ name: "angular", tokenizeAngularBlocks: true, tokenizeAngularLetDeclaration: true, allowStartTagComments: true }), zo = st({ name: "vue", isTagNameCaseSensitive: true, shouldParseAsRawText(e, t, r, n) {
    return e.toLowerCase() !== "html" && !r && (e !== "template" || n.some(({ name: i, value: s }) => i === "lang" && s !== "html" && s !== "" && s !== void 0));
  } }), Go = st({ name: "lwc", canSelfClose: false });
  var $o = { html: Vi };
  function keepTagClosingBracketsInline(source) {
    let result = "";
    let inTag = false;
    let quote;
    let rawTextTag;
    let tagStart = -1;
    for (let index = 0; index < source.length; index += 1) {
      const character = source[index];
      if (!inTag) {
        if (rawTextTag !== void 0) {
          if (!beginsRawTextClosingTag(source, index, rawTextTag)) {
            result += character;
            continue;
          }
          inTag = true;
          tagStart = index;
          result += character;
          continue;
        }
        if (source.startsWith("<!--", index)) {
          const end = source.indexOf("-->", index + 4);
          if (end === -1) {
            result += source.slice(index);
            break;
          }
          result += source.slice(index, end + 3);
          index = end + 2;
          continue;
        }
        result += character;
        if (character === "<" && beginsHtmlTag(source[index + 1])) {
          inTag = true;
          tagStart = index;
        }
        continue;
      }
      if (quote !== void 0) {
        result += character;
        if (character === quote) quote = void 0;
        continue;
      }
      if (character === '"' || character === "'") {
        quote = character;
        result += character;
        continue;
      }
      if (character === ">") {
        const tag = source.slice(tagStart, index + 1);
        inTag = false;
        result += character;
        if (/^<script(?:\\s|>)/iu.test(tag)) rawTextTag = "script";
        else if (/^<style(?:\\s|>)/iu.test(tag)) rawTextTag = "style";
        else if (rawTextTag !== void 0 && new RegExp(\`^<\\\\/\${rawTextTag}(?:\\\\s|>)\`, "iu").test(tag)) {
          rawTextTag = void 0;
        }
        continue;
      }
      if (character === "\\n" || character === "\\r") {
        let next = index + 1;
        if (character === "\\r" && source[next] === "\\n") next += 1;
        while (source[next] === " " || source[next] === "	") next += 1;
        if (source[next] === ">") {
          index = next - 1;
          continue;
        }
      }
      result += character;
    }
    return result;
  }
  function beginsHtmlTag(character) {
    return character !== void 0 && /[!/?A-Za-z]/u.test(character);
  }
  function beginsRawTextClosingTag(source, index, tagName) {
    const candidate = source.slice(index, index + tagName.length + 3);
    return new RegExp(\`^<\\\\/\${tagName}(?:\\\\s|>)\`, "iu").test(candidate);
  }
  const UNDEFINED_CODE_POINTS = /* @__PURE__ */ new Set([
    65534,
    65535,
    131070,
    131071,
    196606,
    196607,
    262142,
    262143,
    327678,
    327679,
    393214,
    393215,
    458750,
    458751,
    524286,
    524287,
    589822,
    589823,
    655358,
    655359,
    720894,
    720895,
    786430,
    786431,
    851966,
    851967,
    917502,
    917503,
    983038,
    983039,
    1048574,
    1048575,
    1114110,
    1114111
  ]);
  const REPLACEMENT_CHARACTER = "�";
  var CODE_POINTS;
  (function(CODE_POINTS2) {
    CODE_POINTS2[CODE_POINTS2["EOF"] = -1] = "EOF";
    CODE_POINTS2[CODE_POINTS2["NULL"] = 0] = "NULL";
    CODE_POINTS2[CODE_POINTS2["TABULATION"] = 9] = "TABULATION";
    CODE_POINTS2[CODE_POINTS2["CARRIAGE_RETURN"] = 13] = "CARRIAGE_RETURN";
    CODE_POINTS2[CODE_POINTS2["LINE_FEED"] = 10] = "LINE_FEED";
    CODE_POINTS2[CODE_POINTS2["FORM_FEED"] = 12] = "FORM_FEED";
    CODE_POINTS2[CODE_POINTS2["SPACE"] = 32] = "SPACE";
    CODE_POINTS2[CODE_POINTS2["EXCLAMATION_MARK"] = 33] = "EXCLAMATION_MARK";
    CODE_POINTS2[CODE_POINTS2["QUOTATION_MARK"] = 34] = "QUOTATION_MARK";
    CODE_POINTS2[CODE_POINTS2["AMPERSAND"] = 38] = "AMPERSAND";
    CODE_POINTS2[CODE_POINTS2["APOSTROPHE"] = 39] = "APOSTROPHE";
    CODE_POINTS2[CODE_POINTS2["HYPHEN_MINUS"] = 45] = "HYPHEN_MINUS";
    CODE_POINTS2[CODE_POINTS2["SOLIDUS"] = 47] = "SOLIDUS";
    CODE_POINTS2[CODE_POINTS2["DIGIT_0"] = 48] = "DIGIT_0";
    CODE_POINTS2[CODE_POINTS2["DIGIT_9"] = 57] = "DIGIT_9";
    CODE_POINTS2[CODE_POINTS2["SEMICOLON"] = 59] = "SEMICOLON";
    CODE_POINTS2[CODE_POINTS2["LESS_THAN_SIGN"] = 60] = "LESS_THAN_SIGN";
    CODE_POINTS2[CODE_POINTS2["EQUALS_SIGN"] = 61] = "EQUALS_SIGN";
    CODE_POINTS2[CODE_POINTS2["GREATER_THAN_SIGN"] = 62] = "GREATER_THAN_SIGN";
    CODE_POINTS2[CODE_POINTS2["QUESTION_MARK"] = 63] = "QUESTION_MARK";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_A"] = 65] = "LATIN_CAPITAL_A";
    CODE_POINTS2[CODE_POINTS2["LATIN_CAPITAL_Z"] = 90] = "LATIN_CAPITAL_Z";
    CODE_POINTS2[CODE_POINTS2["RIGHT_SQUARE_BRACKET"] = 93] = "RIGHT_SQUARE_BRACKET";
    CODE_POINTS2[CODE_POINTS2["GRAVE_ACCENT"] = 96] = "GRAVE_ACCENT";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_A"] = 97] = "LATIN_SMALL_A";
    CODE_POINTS2[CODE_POINTS2["LATIN_SMALL_Z"] = 122] = "LATIN_SMALL_Z";
  })(CODE_POINTS || (CODE_POINTS = {}));
  const SEQUENCES = {
    DASH_DASH: "--",
    CDATA_START: "[CDATA[",
    DOCTYPE: "doctype",
    SCRIPT: "script",
    PUBLIC: "public",
    SYSTEM: "system"
  };
  function isSurrogate(cp) {
    return cp >= 55296 && cp <= 57343;
  }
  function isSurrogatePair(cp) {
    return cp >= 56320 && cp <= 57343;
  }
  function getSurrogatePairCodePoint(cp1, cp2) {
    return (cp1 - 55296) * 1024 + 9216 + cp2;
  }
  function isControlCodePoint(cp) {
    return cp !== 32 && cp !== 10 && cp !== 13 && cp !== 9 && cp !== 12 && cp >= 1 && cp <= 31 || cp >= 127 && cp <= 159;
  }
  function isUndefinedCodePoint(cp) {
    return cp >= 64976 && cp <= 65007 || UNDEFINED_CODE_POINTS.has(cp);
  }
  var ERR;
  (function(ERR2) {
    ERR2["controlCharacterInInputStream"] = "control-character-in-input-stream";
    ERR2["noncharacterInInputStream"] = "noncharacter-in-input-stream";
    ERR2["surrogateInInputStream"] = "surrogate-in-input-stream";
    ERR2["nonVoidHtmlElementStartTagWithTrailingSolidus"] = "non-void-html-element-start-tag-with-trailing-solidus";
    ERR2["endTagWithAttributes"] = "end-tag-with-attributes";
    ERR2["endTagWithTrailingSolidus"] = "end-tag-with-trailing-solidus";
    ERR2["unexpectedSolidusInTag"] = "unexpected-solidus-in-tag";
    ERR2["unexpectedNullCharacter"] = "unexpected-null-character";
    ERR2["unexpectedQuestionMarkInsteadOfTagName"] = "unexpected-question-mark-instead-of-tag-name";
    ERR2["invalidFirstCharacterOfTagName"] = "invalid-first-character-of-tag-name";
    ERR2["unexpectedEqualsSignBeforeAttributeName"] = "unexpected-equals-sign-before-attribute-name";
    ERR2["missingEndTagName"] = "missing-end-tag-name";
    ERR2["unexpectedCharacterInAttributeName"] = "unexpected-character-in-attribute-name";
    ERR2["unknownNamedCharacterReference"] = "unknown-named-character-reference";
    ERR2["missingSemicolonAfterCharacterReference"] = "missing-semicolon-after-character-reference";
    ERR2["unexpectedCharacterAfterDoctypeSystemIdentifier"] = "unexpected-character-after-doctype-system-identifier";
    ERR2["unexpectedCharacterInUnquotedAttributeValue"] = "unexpected-character-in-unquoted-attribute-value";
    ERR2["eofBeforeTagName"] = "eof-before-tag-name";
    ERR2["eofInTag"] = "eof-in-tag";
    ERR2["missingAttributeValue"] = "missing-attribute-value";
    ERR2["missingWhitespaceBetweenAttributes"] = "missing-whitespace-between-attributes";
    ERR2["missingWhitespaceAfterDoctypePublicKeyword"] = "missing-whitespace-after-doctype-public-keyword";
    ERR2["missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers"] = "missing-whitespace-between-doctype-public-and-system-identifiers";
    ERR2["missingWhitespaceAfterDoctypeSystemKeyword"] = "missing-whitespace-after-doctype-system-keyword";
    ERR2["missingQuoteBeforeDoctypePublicIdentifier"] = "missing-quote-before-doctype-public-identifier";
    ERR2["missingQuoteBeforeDoctypeSystemIdentifier"] = "missing-quote-before-doctype-system-identifier";
    ERR2["missingDoctypePublicIdentifier"] = "missing-doctype-public-identifier";
    ERR2["missingDoctypeSystemIdentifier"] = "missing-doctype-system-identifier";
    ERR2["abruptDoctypePublicIdentifier"] = "abrupt-doctype-public-identifier";
    ERR2["abruptDoctypeSystemIdentifier"] = "abrupt-doctype-system-identifier";
    ERR2["cdataInHtmlContent"] = "cdata-in-html-content";
    ERR2["incorrectlyOpenedComment"] = "incorrectly-opened-comment";
    ERR2["eofInScriptHtmlCommentLikeText"] = "eof-in-script-html-comment-like-text";
    ERR2["eofInDoctype"] = "eof-in-doctype";
    ERR2["nestedComment"] = "nested-comment";
    ERR2["abruptClosingOfEmptyComment"] = "abrupt-closing-of-empty-comment";
    ERR2["eofInComment"] = "eof-in-comment";
    ERR2["incorrectlyClosedComment"] = "incorrectly-closed-comment";
    ERR2["eofInCdata"] = "eof-in-cdata";
    ERR2["absenceOfDigitsInNumericCharacterReference"] = "absence-of-digits-in-numeric-character-reference";
    ERR2["nullCharacterReference"] = "null-character-reference";
    ERR2["surrogateCharacterReference"] = "surrogate-character-reference";
    ERR2["characterReferenceOutsideUnicodeRange"] = "character-reference-outside-unicode-range";
    ERR2["controlCharacterReference"] = "control-character-reference";
    ERR2["noncharacterCharacterReference"] = "noncharacter-character-reference";
    ERR2["missingWhitespaceBeforeDoctypeName"] = "missing-whitespace-before-doctype-name";
    ERR2["missingDoctypeName"] = "missing-doctype-name";
    ERR2["invalidCharacterSequenceAfterDoctypeName"] = "invalid-character-sequence-after-doctype-name";
    ERR2["duplicateAttribute"] = "duplicate-attribute";
    ERR2["nonConformingDoctype"] = "non-conforming-doctype";
    ERR2["missingDoctype"] = "missing-doctype";
    ERR2["misplacedDoctype"] = "misplaced-doctype";
    ERR2["endTagWithoutMatchingOpenElement"] = "end-tag-without-matching-open-element";
    ERR2["closingOfElementWithOpenChildElements"] = "closing-of-element-with-open-child-elements";
    ERR2["disallowedContentInNoscriptInHead"] = "disallowed-content-in-noscript-in-head";
    ERR2["openElementsLeftAfterEof"] = "open-elements-left-after-eof";
    ERR2["abandonedHeadElementChild"] = "abandoned-head-element-child";
    ERR2["misplacedStartTagForHeadElement"] = "misplaced-start-tag-for-head-element";
    ERR2["nestedNoscriptInHead"] = "nested-noscript-in-head";
    ERR2["eofInElementThatCanContainOnlyText"] = "eof-in-element-that-can-contain-only-text";
  })(ERR || (ERR = {}));
  const DEFAULT_BUFFER_WATERLINE = 1 << 16;
  class Preprocessor {
    constructor(handler) {
      this.handler = handler;
      this.html = "";
      this.pos = -1;
      this.lastGapPos = -2;
      this.gapStack = [];
      this.skipNextNewLine = false;
      this.lastChunkWritten = false;
      this.endOfChunkHit = false;
      this.bufferWaterline = DEFAULT_BUFFER_WATERLINE;
      this.isEol = false;
      this.lineStartPos = 0;
      this.droppedBufferSize = 0;
      this.line = 1;
      this.lastErrOffset = -1;
    }
    /** The column on the current line. If we just saw a gap (eg. a surrogate pair), return the index before. */
    get col() {
      return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
    }
    get offset() {
      return this.droppedBufferSize + this.pos;
    }
    getError(code, cpOffset) {
      const { line, col, offset } = this;
      const startCol = col + cpOffset;
      const startOffset = offset + cpOffset;
      return {
        code,
        startLine: line,
        endLine: line,
        startCol,
        endCol: startCol,
        startOffset,
        endOffset: startOffset
      };
    }
    _err(code) {
      if (this.handler.onParseError && this.lastErrOffset !== this.offset) {
        this.lastErrOffset = this.offset;
        this.handler.onParseError(this.getError(code, 0));
      }
    }
    _addGap() {
      this.gapStack.push(this.lastGapPos);
      this.lastGapPos = this.pos;
    }
    _processSurrogate(cp) {
      if (this.pos !== this.html.length - 1) {
        const nextCp = this.html.charCodeAt(this.pos + 1);
        if (isSurrogatePair(nextCp)) {
          this.pos++;
          this._addGap();
          return getSurrogatePairCodePoint(cp, nextCp);
        }
      } else if (!this.lastChunkWritten) {
        this.endOfChunkHit = true;
        return CODE_POINTS.EOF;
      }
      this._err(ERR.surrogateInInputStream);
      return cp;
    }
    willDropParsedChunk() {
      return this.pos > this.bufferWaterline;
    }
    dropParsedChunk() {
      if (this.willDropParsedChunk()) {
        this.html = this.html.substring(this.pos);
        this.lineStartPos -= this.pos;
        this.droppedBufferSize += this.pos;
        this.pos = 0;
        this.lastGapPos = -2;
        this.gapStack.length = 0;
      }
    }
    write(chunk, isLastChunk) {
      if (this.html.length > 0) {
        this.html += chunk;
      } else {
        this.html = chunk;
      }
      this.endOfChunkHit = false;
      this.lastChunkWritten = isLastChunk;
    }
    insertHtmlAtCurrentPos(chunk) {
      this.html = this.html.substring(0, this.pos + 1) + chunk + this.html.substring(this.pos + 1);
      this.endOfChunkHit = false;
    }
    startsWith(pattern, caseSensitive) {
      if (this.pos + pattern.length > this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return false;
      }
      if (caseSensitive) {
        return this.html.startsWith(pattern, this.pos);
      }
      for (let i = 0; i < pattern.length; i++) {
        const cp = this.html.charCodeAt(this.pos + i) | 32;
        if (cp !== pattern.charCodeAt(i)) {
          return false;
        }
      }
      return true;
    }
    peek(offset) {
      const pos = this.pos + offset;
      if (pos >= this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return CODE_POINTS.EOF;
      }
      const code = this.html.charCodeAt(pos);
      return code === CODE_POINTS.CARRIAGE_RETURN ? CODE_POINTS.LINE_FEED : code;
    }
    advance() {
      this.pos++;
      if (this.isEol) {
        this.isEol = false;
        this.line++;
        this.lineStartPos = this.pos;
      }
      if (this.pos >= this.html.length) {
        this.endOfChunkHit = !this.lastChunkWritten;
        return CODE_POINTS.EOF;
      }
      let cp = this.html.charCodeAt(this.pos);
      if (cp === CODE_POINTS.CARRIAGE_RETURN) {
        this.isEol = true;
        this.skipNextNewLine = true;
        return CODE_POINTS.LINE_FEED;
      }
      if (cp === CODE_POINTS.LINE_FEED) {
        this.isEol = true;
        if (this.skipNextNewLine) {
          this.line--;
          this.skipNextNewLine = false;
          this._addGap();
          return this.advance();
        }
      }
      this.skipNextNewLine = false;
      if (isSurrogate(cp)) {
        cp = this._processSurrogate(cp);
      }
      const isCommonValidRange = this.handler.onParseError === null || cp > 31 && cp < 127 || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.CARRIAGE_RETURN || cp > 159 && cp < 64976;
      if (!isCommonValidRange) {
        this._checkForProblematicCharacters(cp);
      }
      return cp;
    }
    _checkForProblematicCharacters(cp) {
      if (isControlCodePoint(cp)) {
        this._err(ERR.controlCharacterInInputStream);
      } else if (isUndefinedCodePoint(cp)) {
        this._err(ERR.noncharacterInInputStream);
      }
    }
    retreat(count) {
      this.pos -= count;
      while (this.pos < this.lastGapPos) {
        this.lastGapPos = this.gapStack.pop();
        this.pos--;
      }
      this.isEol = false;
    }
  }
  var TokenType;
  (function(TokenType2) {
    TokenType2[TokenType2["CHARACTER"] = 0] = "CHARACTER";
    TokenType2[TokenType2["NULL_CHARACTER"] = 1] = "NULL_CHARACTER";
    TokenType2[TokenType2["WHITESPACE_CHARACTER"] = 2] = "WHITESPACE_CHARACTER";
    TokenType2[TokenType2["START_TAG"] = 3] = "START_TAG";
    TokenType2[TokenType2["END_TAG"] = 4] = "END_TAG";
    TokenType2[TokenType2["COMMENT"] = 5] = "COMMENT";
    TokenType2[TokenType2["DOCTYPE"] = 6] = "DOCTYPE";
    TokenType2[TokenType2["EOF"] = 7] = "EOF";
    TokenType2[TokenType2["HIBERNATION"] = 8] = "HIBERNATION";
  })(TokenType || (TokenType = {}));
  function getTokenAttr(token, attrName) {
    for (let i = token.attrs.length - 1; i >= 0; i--) {
      if (token.attrs[i].name === attrName) {
        return token.attrs[i].value;
      }
    }
    return null;
  }
  const decodeMap = /* @__PURE__ */ new Map([
    [0, 65533],
    // C1 Unicode control character reference replacements
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376]
  ]);
  function replaceCodePoint(codePoint) {
    if (codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111) {
      return 65533;
    }
    return decodeMap.get(codePoint) ?? codePoint;
  }
  function decodeBase64(input) {
    const binary = atob(input);
    const evenLength = binary.length & -2;
    const out = new Uint16Array(evenLength / 2);
    for (let index = 0, outIndex = 0; index < evenLength; index += 2) {
      const lo2 = binary.charCodeAt(index);
      const hi2 = binary.charCodeAt(index + 1);
      out[outIndex++] = lo2 | hi2 << 8;
    }
    return out;
  }
  const htmlDecodeTree = /* @__PURE__ */ decodeBase64("QR08ALkAAgH6AYsDNQR2BO0EPgXZBQEGLAbdBxMISQrvCmQLfQurDKQNLw4fD4YPpA+6D/IPAAAAAAAAAAAAAAAAKhBMEY8TmxUWF2EYLBkxGuAa3RsJHDscWR8YIC8jSCSIJcMl6ie3Ku8rEC0CLjoupS7kLgAIRU1hYmNmZ2xtbm9wcnN0dVQAWgBeAGUAaQBzAHcAfgCBAIQAhwCSAJoAoACsALMAbABpAGcAO4DGAMZAUAA7gCYAJkBjAHUAdABlADuAwQDBQHIiZXZlAAJhAAFpeW0AcgByAGMAO4DCAMJAEGRyAADgNdgE3XIAYQB2AGUAO4DAAMBA8CFoYZFj4SFjcgBhZAAAoFMqAAFncIsAjgBvAG4ABGFmAADgNdg43fAlbHlGdW5jdGlvbgCgYSBpAG4AZwA7gMUAxUAAAWNzpACoAHIAAOA12Jzc6SFnbgCgVCJpAGwAZABlADuAwwDDQG0AbAA7gMQAxEAABGFjZWZvcnN1xQDYANoA7QDxAPYA+QD8AAABY3LJAM8AayNzbGFzaAAAoBYidgHTANUAAKDnKmUAZAAAoAYjeQARZIABY3J0AOAA5QDrAGEidXNlAACgNSLuI291bGxpcwCgLCFhAJJjcgAA4DXYBd1wAGYAAOA12Dnd5SF2ZdhiYwDyAOoAbSJwZXEAAKBOIgAHSE9hY2RlZmhpbG9yc3UXARoBHwE6AVIBVQFiAWQBZgGCAakB6QHtAfIBYwB5ACdkUABZADuAqQCpQIABY3B5ACUBKAE1AfUhdGUGYWmg0iJ0KGFsRGlmZmVyZW50aWFsRAAAoEUhbCJleXMAAKAtIQACYWVpb0EBRAFKAU0B8iFvbgxhZABpAGwAO4DHAMdAcgBjAAhhbiJpbnQAAKAwIm8AdAAKYQABZG5ZAV0BaSJsbGEAuGB0I2VyRG90ALdg8gA5AWkAp2NyImNsZQAAAkRNUFRwAXQBeQF9AW8AdAAAoJkiaSJudXMAAKCWIuwhdXMAoJUiaSJtZXMAAKCXIm8AAAFjc4cBlAFrKndpc2VDb250b3VySW50ZWdyYWwAAKAyImUjQ3VybHkAAAFEUZwBpAFvJXVibGVRdW90ZQAAoB0gdSJvdGUAAKAZIAACbG5wdbABtgHNAdgBbwBuAGWgNyIAoHQqgAFnaXQAvAHBAcUB8iJ1ZW50AKBhIm4AdAAAoC8i7yV1ckludGVncmFsAKAuIgABZnLRAdMBAKACIe8iZHVjdACgECJuLnRlckNsb2Nrd2lzZUNvbnRvdXJJbnRlZ3JhbAAAoDMi7yFzcwCgLypjAHIAAOA12J7ccABDoNMiYQBwAACgTSKABURKU1phY2VmaW9zAAsCEgIVAhgCGwIsAjQCOQI9AnMCfwNvoEUh9CJyYWhkAKARKWMAeQACZGMAeQAFZGMAeQAPZIABZ3JzACECJQIoAuchZXIAoCEgcgAAoKEhaAB2AACg5CoAAWF5MAIzAvIhb24OYRRkbAB0oAciYQCUY3IAAOA12AfdAAFhZkECawIAAWNtRQJnAvIjaXRpY2FsAAJBREdUUAJUAl8CYwJjInV0ZQC0YG8AdAFZAloC2WJiJGxlQWN1dGUA3WJyImF2ZQBgYGkibGRlANxi7yFuZACgxCJmJWVyZW50aWFsRAAAoEYhcAR9AgAAAAAAAIECjgIAABoDZgAA4DXYO91EoagAhQKJAm8AdAAAoNwgcSJ1YWwAAKBQIuIhbGUAA0NETFJVVpkCqAK1Au8C/wIRA28AbgB0AG8AdQByAEkAbgB0AGUAZwByAGEA7ADEAW8AdAKvAgAAAACwAqhgbiNBcnJvdwAAoNMhAAFlb7kC0AJmAHQAgAFBUlQAwQLGAs0CciJyb3cAAKDQIekkZ2h0QXJyb3cAoNQhZQDlACsCbgBnAAABTFLWAugC5SFmdAABQVLcAuECciJyb3cAAKD4J+kkZ2h0QXJyb3cAoPon6SRnaHRBcnJvdwCg+SdpImdodAAAAUFU9gL7AnIicm93AACg0iFlAGUAAKCoInAAQQIGAwAAAAALA3Iicm93AACg0SFvJHduQXJyb3cAAKDVIWUlcnRpY2FsQmFyAACgJSJuAAADQUJMUlRhJAM2AzoDWgNxA3oDciJyb3cAAKGTIUJVLAMwA2EAcgAAoBMpcCNBcnJvdwAAoPUhciJldmUAEWPlIWZ00gJDAwAASwMAAFIDaSVnaHRWZWN0b3IAAKBQKWUkZVZlY3RvcgAAoF4p5SJjdG9yQqC9IWEAcgAAoFYpaSJnaHQA1AFiAwAAaQNlJGVWZWN0b3IAAKBfKeUiY3RvckKgwSFhAHIAAKBXKWUAZQBBoKQiciJyb3cAAKCnIXIAcgBvAPcAtAIAAWN0gwOHA3IAAOA12J/c8iFvaxBhAAhOVGFjZGZnbG1vcHFzdHV4owOlA6kDsAO/A8IDxgPNA9ID8gP9AwEEFAQeBCAEJQRHAEphSAA7gNAA0EBjAHUAdABlADuAyQDJQIABYWl5ALYDuQO+A/Ihb24aYXIAYwA7gMoAykAtZG8AdAAWYXIAAOA12AjdcgBhAHYAZQA7gMgAyEDlIm1lbnQAoAgiAAFhcNYD2QNjAHIAEmF0AHkAUwLhAwAAAADpA20lYWxsU3F1YXJlAACg+yVlJ3J5U21hbGxTcXVhcmUAAKCrJQABZ3D2A/kDbwBuABhhZgAA4DXYPN3zImlsb26VY3UAAAFhaQYEDgRsAFSgdSppImxkZQAAoEIi7CNpYnJpdW0AoMwhAAFjaRgEGwRyAACgMCFtAACgcyphAJdjbQBsADuAywDLQAABaXApBC0E8yF0cwCgAyLvJG5lbnRpYWxFAKBHIYACY2Zpb3MAPQQ/BEMEXQRyBHkAJGRyAADgNdgJ3WwibGVkAFMCTAQAAAAAVARtJWFsbFNxdWFyZQAAoPwlZSdyeVNtYWxsU3F1YXJlAACgqiVwA2UEAABpBAAAAABtBGYAAOA12D3dwSFsbACgACLyI2llcnRyZgCgMSFjAPIAcQQABkpUYWJjZGZnb3JzdIgEiwSOBJMElwSkBKcEqwStBLIE5QTqBGMAeQADZDuAPgA+QO0hbWFkoJMD3GNyImV2ZQAeYYABZWl5AJ0EoASjBOQhaWwiYXIAYwAcYRNkbwB0ACBhcgAA4DXYCt0AoNkicABmAADgNdg+3eUiYXRlcgADRUZHTFNUvwTIBM8E1QTZBOAEcSJ1YWwATKBlIuUhc3MAoNsidSRsbEVxdWFsAACgZyJyI2VhdGVyAACgoirlIXNzAKB3IuwkYW50RXF1YWwAoH4qaSJsZGUAAKBzImMAcgAA4DXYotwAoGsiAARBYWNmaW9zdfkE/QQFBQgFCwUTBSIFKwVSIkRjeQAqZAABY3QBBQQFZQBrAMdiXmDpIXJjJGFyAACgDCFsJWJlcnRTcGFjZQAAoAsh8AEYBQAAGwVmAACgDSHpJXpvbnRhbExpbmUAoAAlAAFjdCYFKAXyABIF8iFvayZhbQBwAEQBMQU5BW8AdwBuAEgAdQBtAPAAAAFxInVhbAAAoE8iAAdFSk9hY2RmZ21ub3N0dVMFVgVZBVwFYwVtBXAFcwV6BZAFtgXFBckFzQVjAHkAFWTsIWlnMmFjAHkAAWRjAHUAdABlADuAzQDNQAABaXlnBWwFcgBjADuAzgDOQBhkbwB0ADBhcgAAoBEhcgBhAHYAZQA7gMwAzEAAoREhYXB/BYsFAAFjZ4MFhQVyACphaSNuYXJ5SQAAoEghbABpAGUA8wD6AvQBlQUAAKUFZaAsIgABZ3KaBZ4F8iFhbACgKyLzI2VjdGlvbgCgwiJpI3NpYmxlAAABQ1SsBbEFbyJtbWEAAKBjIGkibWVzAACgYiCAAWdwdAC8Bb8FwwVvAG4ALmFmAADgNdhA3WEAmWNjAHIAAKAQIWkibGRlAChh6wHSBQAA1QVjAHkABmRsADuAzwDPQIACY2Zvc3UA4QXpBe0F8gX9BQABaXnlBegFcgBjADRhGWRyAADgNdgN3XAAZgAA4DXYQd3jAfcFAAD7BXIAAOA12KXc8iFjeQhk6yFjeQRkgANISmFjZm9zAAwGDwYSBhUGHQYhBiYGYwB5ACVkYwB5AAxk8CFwYZpjAAFleRkGHAbkIWlsNmEaZHIAAOA12A7dcABmAADgNdhC3WMAcgAA4DXYptyABUpUYWNlZmxtb3N0AD0GQAZDBl4GawZkB2gHcAd0B80H2gdjAHkACWQ7gDwAPECAAmNtbnByAEwGTwZSBlUGWwb1IXRlOWHiIWRhm2NnAACg6ifsI2FjZXRyZgCgEiFyAACgniGAAWFleQBkBmcGagbyIW9uPWHkIWlsO2EbZAABZnNvBjQHdAAABUFDREZSVFVWYXKABp4GpAbGBssG3AYDByEHwQIqBwABbnKEBowGZyVsZUJyYWNrZXQAAKDoJ/Ihb3cAoZAhQlKTBpcGYQByAACg5CHpJGdodEFycm93AKDGIWUjaWxpbmcAAKAII28A9QGqBgAAsgZiJWxlQnJhY2tldAAAoOYnbgDUAbcGAAC+BmUkZVZlY3RvcgAAoGEp5SJjdG9yQqDDIWEAcgAAoFkpbCJvb3IAAKAKI2kiZ2h0AAABQVbSBtcGciJyb3cAAKCUIeUiY3RvcgCgTikAAWVy4AbwBmUAAKGjIkFW5gbrBnIicm93AACgpCHlImN0b3IAoFopaSNhbmdsZQBCorIi+wYAAAAA/wZhAHIAAKDPKXEidWFsAACgtCJwAIABRFRWAAoHEQcYB+8kd25WZWN0b3IAoFEpZSRlVmVjdG9yAACgYCnlImN0b3JCoL8hYQByAACgWCnlImN0b3JCoLwhYQByAACgUilpAGcAaAB0AGEAcgByAG8A9wDMAnMAAANFRkdMU1Q/B0cHTgdUB1gHXwfxJXVhbEdyZWF0ZXIAoNoidSRsbEVxdWFsAACgZiJyI2VhdGVyAACgdiLlIXNzAKChKuwkYW50RXF1YWwAoH0qaSJsZGUAAKByInIAAOA12A/dZaDYIuYjdGFycm93AKDaIWkiZG90AD9hgAFucHcAege1B7kHZwAAAkxSbHKCB5QHmwerB+UhZnQAAUFSiAeNB3Iicm93AACg9SfpJGdodEFycm93AKD3J+kkZ2h0QXJyb3cAoPYn5SFmdAABYXLcAqEHaQBnAGgAdABhAHIAcgBvAPcA5wJpAGcAaAB0AGEAcgByAG8A9wDuAmYAAOA12EPdZQByAAABTFK/B8YHZSRmdEFycm93AACgmSHpJGdodEFycm93AKCYIYABY2h0ANMH1QfXB/IAWgYAoLAh8iFva0FhAKBqIgAEYWNlZmlvc3XpB+wH7gf/BwMICQgOCBEIcAAAoAUpeQAcZAABZGzyB/kHaSR1bVNwYWNlAACgXyBsI2ludHJmAACgMyFyAADgNdgQ3e4jdXNQbHVzAKATInAAZgAA4DXYRN1jAPIA/gecY4AESmFjZWZvc3R1ACEIJAgoCDUIgQiFCDsKQApHCmMAeQAKZGMidXRlAENhgAFhZXkALggxCDQI8iFvbkdh5CFpbEVhHWSAAWdzdwA7CGEIfQjhInRpdmWAAU1UVgBECEwIWQhlJWRpdW1TcGFjZQAAoAsgaABpAAABY25SCFMIawBTAHAAYQBjAOUASwhlAHIAeQBUAGgAaQDuAFQI9CFlZAABR0xnCHUIcgBlAGEAdABlAHIARwByAGUAYQB0AGUA8gDrBGUAcwBzAEwAZQBzAPMA2wdMImluZQAKYHIAAOA12BHdAAJCbnB0jAiRCJkInAhyImVhawAAoGAgwiZyZWFraW5nU3BhY2WgYGYAAKAVIUOq7CqzCMIIzQgAAOcIGwkAAAAAAAAtCQAAbwkAAIcJAACdCcAJGQoAADQKAAFvdbYIvAjuI2dydWVudACgYiJwIkNhcAAAoG0ibyh1YmxlVmVydGljYWxCYXIAAKAmIoABbHF4ANII1wjhCOUibWVudACgCSL1IWFsVKBgImkibGRlAADgQiI4A2kic3RzAACgBCJyI2VhdGVyAACjbyJFRkdMU1T1CPoIAgkJCQ0JFQlxInVhbAAAoHEidSRsbEVxdWFsAADgZyI4A3IjZWF0ZXIAAOBrIjgD5SFzcwCgeSLsJGFudEVxdWFsAOB+KjgDaSJsZGUAAKB1IvUhbXBEASAJJwnvI3duSHVtcADgTiI4A3EidWFsAADgTyI4A2UAAAFmczEJRgn0JFRyaWFuZ2xlQqLqIj0JAAAAAEIJYQByAADgzyk4A3EidWFsAACg7CJzAICibiJFR0xTVABRCVYJXAlhCWkJcSJ1YWwAAKBwInIjZWF0ZXIAAKB4IuUhc3MA4GoiOAPsJGFudEVxdWFsAOB9KjgDaSJsZGUAAKB0IuUic3RlZAABR0x1CX8J8iZlYXRlckdyZWF0ZXIA4KIqOAPlI3NzTGVzcwDgoSo4A/IjZWNlZGVzAKGAIkVTjwmVCXEidWFsAADgryo4A+wkYW50RXF1YWwAoOAiAAFlaaAJqQl2JmVyc2VFbGVtZW50AACgDCLnJWh0VHJpYW5nbGVCousitgkAAAAAuwlhAHIAAODQKTgDcSJ1YWwAAKDtIgABcXXDCeAJdSNhcmVTdQAAAWJwywnVCfMhZXRF4I8iOANxInVhbAAAoOIi5SJyc2V0ReCQIjgDcSJ1YWwAAKDjIoABYmNwAOYJ8AkNCvMhZXRF4IIi0iBxInVhbAAAoIgi4yJlZWRzgKGBIkVTVAD6CQAKBwpxInVhbAAA4LAqOAPsJGFudEVxdWFsAKDhImkibGRlAADgfyI4A+UicnNldEXggyLSIHEidWFsAACgiSJpImxkZQCAoUEiRUZUACIKJwouCnEidWFsAACgRCJ1JGxsRXF1YWwAAKBHImkibGRlAACgSSJlJXJ0aWNhbEJhcgAAoCQiYwByAADgNdip3GkAbABkAGUAO4DRANFAnWMAB0VhY2RmZ21vcHJzdHV2XgphCmgKcgp2CnoKgQqRCpYKqwqtCrsKyArNCuwhaWdSYWMAdQB0AGUAO4DTANNAAAFpeWwKcQpyAGMAO4DUANRAHmRiImxhYwBQYXIAAOA12BLdcgBhAHYAZQA7gNIA0kCAAWFlaQCHCooKjQpjAHIATGFnAGEAqWNjInJvbgCfY3AAZgAA4DXYRt3lI25DdXJseQABRFGeCqYKbyV1YmxlUXVvdGUAAKAcIHUib3RlAACgGCAAoFQqAAFjbLEKtQpyAADgNdiq3GEAcwBoADuA2ADYQGkAbAHACsUKZABlADuA1QDVQGUAcwAAoDcqbQBsADuA1gDWQGUAcgAAAUJQ0wrmCgABYXLXCtoKcgAAoD4gYQBjAAABZWvgCuIKAKDeI2UAdAAAoLQjYSVyZW50aGVzaXMAAKDcI4AEYWNmaGlsb3JzAP0KAwsFCwkLCwsMCxELIwtaC3IjdGlhbEQAAKACInkAH2RyAADgNdgT3WkApmOgY/Ujc01pbnVzsWAAAWlwFQsgC24AYwBhAHIAZQBwAGwAYQBuAOUACgVmAACgGSGAobsqZWlvACoLRQtJC+MiZWRlc4CheiJFU1QANAs5C0ALcSJ1YWwAAKCvKuwkYW50RXF1YWwAoHwiaSJsZGUAAKB+Im0AZQAAoDMgAAFkcE0LUQv1IWN0AKAPIm8jcnRpb24AYaA3ImwAAKAdIgABY2leC2ILcgAA4DXYq9yoYwACVWZvc2oLbwtzC3cLTwBUADuAIgAiQHIAAOA12BTdcABmAACgGiFjAHIAAOA12KzcAAZCRWFjZWZoaW9yc3WPC5MLlwupC7YL2AvbC90LhQyTDJoMowzhIXJyAKAQKUcAO4CuAK5AgAFjbnIAnQugC6ML9SF0ZVRhZwAAoOsncgB0oKAhbAAAoBYpgAFhZXkArwuyC7UL8iFvblhh5CFpbFZhIGR2oBwhZSJyc2UAAAFFVb8LzwsAAWxxwwvIC+UibWVudACgCyL1JGlsaWJyaXVtAKDLIXAmRXF1aWxpYnJpdW0AAKBvKXIAAKAcIW8AoWPnIWh0AARBQ0RGVFVWYewLCgwQDDIMNwxeDHwM9gIAAW5y8Av4C2clbGVCcmFja2V0AACg6SfyIW93AKGSIUJM/wsDDGEAcgAAoOUhZSRmdEFycm93AACgxCFlI2lsaW5nAACgCSNvAPUBFgwAAB4MYiVsZUJyYWNrZXQAAKDnJ24A1AEjDAAAKgxlJGVWZWN0b3IAAKBdKeUiY3RvckKgwiFhAHIAAKBVKWwib29yAACgCyMAAWVyOwxLDGUAAKGiIkFWQQxGDHIicm93AACgpiHlImN0b3IAoFspaSNhbmdsZQBCorMiVgwAAAAAWgxhAHIAAKDQKXEidWFsAACgtSJwAIABRFRWAGUMbAxzDO8kd25WZWN0b3IAoE8pZSRlVmVjdG9yAACgXCnlImN0b3JCoL4hYQByAACgVCnlImN0b3JCoMAhYQByAACgUykAAXB1iQyMDGYAAKAdIe4kZEltcGxpZXMAoHAp6SRnaHRhcnJvdwCg2yEAAWNongyhDHIAAKAbIQCgsSHsJGVEZWxheWVkAKD0KYAGSE9hY2ZoaW1vcXN0dQC/DMgMzAzQDOIM5gwKDQ0NFA0ZDU8NVA1YDQABQ2PDDMYMyCFjeSlkeQAoZEYiVGN5ACxkYyJ1dGUAWmEAorwqYWVpedgM2wzeDOEM8iFvbmBh5CFpbF5hcgBjAFxhIWRyAADgNdgW3e8hcnQAAkRMUlXvDPYM/QwEDW8kd25BcnJvdwAAoJMhZSRmdEFycm93AACgkCHpJGdodEFycm93AKCSIXAjQXJyb3cAAKCRIechbWGjY+EkbGxDaXJjbGUAoBgicABmAADgNdhK3XICHw0AAAAAIg10AACgGiLhIXJlgKGhJUlTVQAqDTINSg3uJXRlcnNlY3Rpb24AoJMidQAAAWJwNw1ADfMhZXRFoI8icSJ1YWwAAKCRIuUicnNldEWgkCJxInVhbAAAoJIibiJpb24AAKCUImMAcgAA4DXYrtxhAHIAAKDGIgACYmNtcF8Nag2ODZANc6DQImUAdABFoNAicSJ1YWwAAKCGIgABY2huDYkNZSJlZHMAgKF7IkVTVAB4DX0NhA1xInVhbAAAoLAq7CRhbnRFcXVhbACgfSJpImxkZQAAoH8iVABoAGEA9ADHCwCgESIAodEiZXOVDZ8NciJzZXQARaCDInEidWFsAACghyJlAHQAAKDRIoAFSFJTYWNmaGlvcnMAtQ27Db8NyA3ODdsN3w3+DRgOHQ4jDk8AUgBOADuA3gDeQMEhREUAoCIhAAFIY8MNxg1jAHkAC2R5ACZkAAFidcwNzQ0JYKRjgAFhZXkA1A3XDdoN8iFvbmRh5CFpbGJhImRyAADgNdgX3QABZWnjDe4N8gHoDQAA7Q3lImZvcmUAoDQiYQCYYwABY27yDfkNayNTcGFjZQAA4F8gCiDTInBhY2UAoAkg7CFkZYChPCJFRlQABw4MDhMOcSJ1YWwAAKBDInUkbGxFcXVhbAAAoEUiaSJsZGUAAKBIInAAZgAA4DXYS93pI3BsZURvdACg2yAAAWN0Jw4rDnIAAOA12K/c8iFva2Zh4QpFDlYOYA5qDgAAbg5yDgAAAAAAAAAAAAB5DnwOqA6zDgAADg8RDxYPGg8AAWNySA5ODnUAdABlADuA2gDaQHIAb6CfIeMhaXIAoEkpcgDjAVsOAABdDnkADmR2AGUAbGEAAWl5Yw5oDnIAYwA7gNsA20AjZGIibGFjAHBhcgAA4DXYGN1yAGEAdgBlADuA2QDZQOEhY3JqYQABZGl/Dp8OZQByAAABQlCFDpcOAAFhcokOiw5yAF9gYQBjAAABZWuRDpMOAKDfI2UAdAAAoLUjYSVyZW50aGVzaXMAAKDdI28AbgBQoMMi7CF1cwCgjiIAAWdwqw6uDm8AbgByYWYAAOA12EzdAARBREVUYWRwc78O0g7ZDuEOBQPqDvMOBw9yInJvdwDCoZEhyA4AAMwOYQByAACgEilvJHduQXJyb3cAAKDFIW8kd25BcnJvdwAAoJUhcSV1aWxpYnJpdW0AAKBuKWUAZQBBoKUiciJyb3cAAKClIW8AdwBuAGEAcgByAG8A9wAQA2UAcgAAAUxS+Q4AD2UkZnRBcnJvdwAAoJYh6SRnaHRBcnJvdwCglyFpAGyg0gNvAG4ApWPpIW5nbmFjAHIAAOA12LDcaSJsZGUAaGFtAGwAO4DcANxAgAREYmNkZWZvc3YALQ8xDzUPNw89D3IPdg97D4AP4SFzaACgqyJhAHIAAKDrKnkAEmThIXNobKCpIgCg5ioAAWVyQQ9DDwCgwSKAAWJ0eQBJD00Paw9hAHIAAKAWIGmgFiDjIWFsAAJCTFNUWA9cD18PZg9hAHIAAKAjIukhbmV8YGUkcGFyYXRvcgAAoFgnaSJsZGUAAKBAItQkaGluU3BhY2UAoAogcgAA4DXYGd1wAGYAAOA12E3dYwByAADgNdix3GQiYXNoAACgqiKAAmNlZm9zAI4PkQ+VD5kPng/pIXJjdGHkIWdlAKDAInIAAOA12BrdcABmAADgNdhO3WMAcgAA4DXYstwAAmZpb3OqD64Prw+0D3IAAOA12BvdnmNwAGYAAOA12E/dYwByAADgNdiz3IAEQUlVYWNmb3N1AMgPyw/OD9EP2A/gD+QP6Q/uD2MAeQAvZGMAeQAHZGMAeQAuZGMAdQB0AGUAO4DdAN1AAAFpedwP3w9yAGMAdmErZHIAAOA12BzdcABmAADgNdhQ3WMAcgAA4DXYtNxtAGwAeGEABEhhY2RlZm9z/g8BEAUQDRAQEB0QIBAkEGMAeQAWZGMidXRlAHlhAAFheQkQDBDyIW9ufWEXZG8AdAB7YfIBFRAAABwQbwBXAGkAZAB0AOgAVAhhAJZjcgAAoCghcABmAACgJCFjAHIAAOA12LXc4QtCEEkQTRAAAGcQbRByEAAAAAAAAAAAeRCKEJcQ8hD9EAAAGxEhETIROREAAD4RYwB1AHQAZQA7gOEA4UByImV2ZQADYYCiPiJFZGl1eQBWEFkQWxBgEGUQAOA+IjMDAKA/InIAYwA7gOIA4kB0AGUAO4C0ALRAMGRsAGkAZwA7gOYA5kByoGEgAOA12B7dcgBhAHYAZQA7gOAA4EAAAWVwfBCGEAABZnCAEIQQ8yF5bQCgNSHoAIMQaABhALFjAAFhcI0QWwAAAWNskRCTEHIAAWFnAACgPypkApwQAAAAALEQAKInImFkc3ajEKcQqRCuEG4AZAAAoFUqAKBcKmwib3BlAACgWCoAoFoqAKMgImVsbXJzersQvRDAEN0Q5RDtEACgpCllAACgICJzAGQAYaAhImEEzhDQENIQ1BDWENgQ2hDcEACgqCkAoKkpAKCqKQCgqykAoKwpAKCtKQCgrikAoK8pdAB2oB8iYgBkoL4iAKCdKQABcHTpEOwQaAAAoCIixWDhIXJyAKB8IwABZ3D1EPgQbwBuAAVhZgAA4DXYUt0Ao0giRWFlaW9wBxEJEQ0RDxESERQRAKBwKuMhaXIAoG8qAKBKImQAAKBLInMAJ2DyIW94ZaBIIvEADhFpAG4AZwA7gOUA5UCAAWN0eQAmESoRKxFyAADgNdi23CpgbQBwAGWgSCLxAPgBaQBsAGQAZQA7gOMA40BtAGwAO4DkAORAAAFjaUERRxFvAG4AaQBuAPQA6AFuAHQAAKARKgAITmFiY2RlZmlrbG5vcHJzdWQRaBGXEZ8RpxGrEdIR1hErEjASexKKEn0RThNbE3oTbwB0AACg7SoAAWNybBGJEWsAAAJjZXBzdBF4EX0RghHvIW5nAKBMInAjc2lsb24A9mNyImltZQAAoDUgaQBtAGWgPSJxAACgzSJ2AY0RkRFlAGUAAKC9ImUAZABnoAUjZQAAoAUjcgBrAHSgtSPiIXJrAKC2IwABb3mjEaYRbgDnAHcRMWTxIXVvAKAeIIACY21wcnQAtBG5Eb4RwRHFEeEhdXPloDUi5ABwInR5dgAAoLApcwDpAH0RbgBvAPUA6gCAAWFodwDLEcwRzhGyYwCgNiHlIWVuAKBsInIAAOA12B/dZwCAA2Nvc3R1dncA4xHyEQUSEhIhEiYSKRKAAWFpdQDpEesR7xHwAKMFcgBjAACg7yVwAACgwyKAAWRwdAD4EfwRABJvAHQAAKAAKuwhdXMAoAEqaSJtZXMAAKACKnECCxIAAAAADxLjIXVwAKAGKmEAcgAAoAUm8iNpYW5nbGUAAWR1GhIeEu8hd24AoL0lcAAAoLMlcCJsdXMAAKAEKmUA5QBCD+UAkg9hInJvdwAAoA0pgAFha28ANhJoEncSAAFjbjoSZRJrAIABbHN0AEESRxJNEm8jemVuZ2UAAKDrKXEAdQBhAHIA5QBcBPIjaWFuZ2xlgKG0JWRscgBYElwSYBLvIXduAKC+JeUhZnQAoMIlaSJnaHQAAKC4JWsAAKAjJLEBbRIAAHUSsgFxEgAAcxIAoJIlAKCRJTQAAKCTJWMAawAAoIglAAFlb38ShxJx4D0A5SD1IWl2AOBhIuUgdAAAoBAjAAJwdHd4kRKVEpsSnxJmAADgNdhT3XSgpSJvAG0AAKClIvQhaWUAoMgiAAZESFVWYmRobXB0dXayEsES0RLgEvcS+xIKExoTHxMjEygTNxMAAkxSbHK5ErsSvRK/EgCgVyUAoFQlAKBWJQCgUyUAolAlRFVkdckSyxLNEs8SAKBmJQCgaSUAoGQlAKBnJQACTFJsctgS2hLcEt4SAKBdJQCgWiUAoFwlAKBZJQCjUSVITFJobHLrEu0S7xLxEvMS9RIAoGwlAKBjJQCgYCUAoGslAKBiJQCgXyVvAHgAAKDJKQACTFJscgITBBMGEwgTAKBVJQCgUiUAoBAlAKAMJQCiACVEVWR1EhMUExYTGBMAoGUlAKBoJQCgLCUAoDQlaSJudXMAAKCfIuwhdXMAoJ4iaSJtZXMAAKCgIgACTFJsci8TMRMzEzUTAKBbJQCgWCUAoBglAKAUJQCjAiVITFJobHJCE0QTRhNIE0oTTBMAoGolAKBhJQCgXiUAoDwlAKAkJQCgHCUAAWV2UhNVE3YA5QD5AGIAYQByADuApgCmQAACY2Vpb2ITZhNqE24TcgAA4DXYt9xtAGkAAKBPIG0A5aA9IogRbAAAoVwAYmh0E3YTAKDFKfMhdWIAoMgnbAF+E4QTbABloCIgdAAAoCIgcAAAoU4iRWWJE4sTAKCuKvGgTyI8BeEMqRMAAN8TABQDFB8UAAAjFDQUAAAAAIUUAAAAAI0UAAAAANcU4xT3FPsUAACIFQAAlhWAAWNwcgCuE7ET1RP1IXRlB2GAoikiYWJjZHMAuxO/E8QTzhPSE24AZAAAoEQqciJjdXAAAKBJKgABYXXIE8sTcAAAoEsqcAAAoEcqbwB0AACgQCoA4CkiAP4AAWVv2RPcE3QAAKBBIO4ABAUAAmFlaXXlE+8T9RP4E/AB6hMAAO0TcwAAoE0qbwBuAA1hZABpAGwAO4DnAOdAcgBjAAlhcABzAHOgTCptAACgUCpvAHQAC2GAAWRtbgAIFA0UEhRpAGwAO4C4ALhAcCJ0eXYAAKCyKXQAAIGiADtlGBQZFKJAcgBkAG8A9ABiAXIAAOA12CDdgAFjZWkAKBQqFDIUeQBHZGMAawBtoBMn4SFyawCgEyfHY3IAAKPLJUVjZWZtcz8UQRRHFHcUfBSAFACgwykAocYCZWxGFEkUcQAAoFciZQBhAlAUAAAAAGAUciJyb3cAAAFsclYUWhTlIWZ0AKC6IWkiZ2h0AACguyGAAlJTYWNkAGgUaRRrFG8UcxSuYACgyCRzAHQAAKCbIukhcmMAoJoi4SFzaACgnSJuImludAAAoBAqaQBkAACg7yrjIWlyAKDCKfUhYnN1oGMmaQB0AACgYybsApMUmhS2FAAAwxRvAG4AZaA6APGgVCKrAG0CnxQAAAAAoxRhAHSgLABAYAChASJmbKcUqRTuABMNZQAAAW14rhSyFOUhbnQAoAEiZQDzANIB5wG6FAAAwBRkoEUibwB0AACgbSpuAPQAzAGAAWZyeQDIFMsUzhQA4DXYVN1vAOQA1wEAgakAO3MeAdMUcgAAoBchAAFhb9oU3hRyAHIAAKC1IXMAcwAAoBcnAAFjdeYU6hRyAADgNdi43AABYnDuFPIUZaDPKgCg0SploNAqAKDSKuQhb3QAoO8igANkZWxwcnZ3AAYVEBUbFSEVRBVlFYQV4SFycgABbHIMFQ4VAKA4KQCgNSlwAhYVAAAAABkVcgAAoN4iYwAAoN8i4SFycnCgtiEAoD0pgKIqImJjZG9zACsVMBU6FT4VQRVyImNhcAAAoEgqAAFhdTQVNxVwAACgRipwAACgSipvAHQAAKCNInIAAKBFKgDgKiIA/gACYWxydksVURVuFXMVcgByAG2gtyEAoDwpeQCAAWV2dwBYFWUVaRVxAHACXxUAAAAAYxVyAGUA4wAXFXUA4wAZFWUAZQAAoM4iZSJkZ2UAAKDPImUAbgA7gKQApEBlI2Fycm93AAABbHJ7FX8V5SFmdACgtiFpImdodAAAoLchZQDkAG0VAAFjaYsVkRVvAG4AaQBuAPQAkwFuAHQAAKAxImwiY3R5AACgLSOACUFIYWJjZGVmaGlqbG9yc3R1d3oAuBW7Fb8V1RXgFegV+RUKFhUWHxZUFlcWZRbFFtsW7xb7FgUXChdyAPIAtAJhAHIAAKBlKQACZ2xyc8YVyhXOFdAV5yFlcgCgICDlIXRoAKA4IfIA9QxoAHagECAAoKMiawHZFd4VYSJyb3cAAKAPKWEA4wBfAgABYXnkFecV8iFvbg9hNGQAoUYhYW/tFfQVAAFnciEC8RVyAACgyiF0InNlcQAAoHcqgAFnbG0A/xUCFgUWO4CwALBAdABhALRjcCJ0eXYAAKCxKQABaXIOFhIW8yFodACgfykA4DXYId1hAHIAAAFschsWHRYAoMMhAKDCIYACYWVnc3YAKBauAjYWOhY+Fm0AAKHEIm9zLhY0Fm4AZABzoMQi9SFpdACgZiZhIm1tYQDdY2kAbgAAoPIiAKH3AGlvQxZRFmQAZQAAgfcAO29KFksW90BuI3RpbWVzAACgxyJuAPgAUBZjAHkAUmRjAG8CXhYAAAAAYhZyAG4AAKAeI28AcAAAoA0jgAJscHR1dwBuFnEWdRaSFp4W7CFhciRgZgAA4DXYVd0AotkCZW1wc30WhBaJFo0WcQBkoFAibwB0AACgUSJpIm51cwAAoDgi7CF1cwCgFCLxInVhcmUAoKEiYgBsAGUAYgBhAHIAdwBlAGQAZwDlANcAbgCAAWFkaAClFqoWtBZyAHIAbwD3APUMbwB3AG4AYQByAHIAbwB3APMA8xVhI3Jwb29uAAABbHK8FsAWZQBmAPQAHBZpAGcAaAD0AB4WYgHJFs8WawBhAHIAbwD3AJILbwLUFgAAAADYFnIAbgAAoB8jbwBwAACgDCOAAWNvdADhFukW7BYAAXJ55RboFgDgNdi53FVkbAAAoPYp8iFvaxFhAAFkcvMW9xZvAHQAAKDxImkA5qC/JVsSAAFhaP8WAhdyAPIANQNhAPIA1wvhIm5nbGUAoKYpAAFjaQ4XEBd5AF9k5yJyYXJyAKD/JwAJRGFjZGVmZ2xtbm9wcXJzdHV4MRc4F0YXWxcyBF4XaRd5F40XrBe0F78X2RcVGCEYLRg1GEAYAAFEbzUXgRZvAPQA+BUAAWNzPBdCF3UAdABlADuA6QDpQPQhZXIAoG4qAAJhaW95TRdQF1YXWhfyIW9uG2FyAGOgViI7gOoA6kDsIW9uAKBVIk1kbwB0ABdhAAFEcmIXZhdvAHQAAKBSIgDgNdgi3XKhmipuF3QXYQB2AGUAO4DoAOhAZKCWKm8AdAAAoJgqgKGZKmlscwCAF4UXhxfuInRlcnMAoOcjAKATIWSglSpvAHQAAKCXKoABYXBzAJMXlheiF2MAcgATYXQAeQBzogUinxcAAAAAoRdlAHQAAKAFInAAMaADIDMBqRerFwCgBCAAoAUgAAFnc7AXsRdLYXAAAKACIAABZ3C4F7sXbwBuABlhZgAA4DXYVt2AAWFscwDFF8sXzxdyAHOg1SJsAACg4yl1AHMAAKBxKmkAAKG1A2x21RfYF28AbgC1Y/VjAAJjc3V24BfoF/0XEBgAAWlv5BdWF3IAYwAAoFYiaQLuFwAAAADwF+0ADQThIW50AAFnbPUX+Rd0AHIAAKCWKuUhc3MAoJUqgAFhZWkAAxgGGAoYbABzAD1gcwB0AACgXyJ2AESgYSJEAACgeCrwImFyc2wAoOUpAAFEYRkYHRhvAHQAAKBTInIAcgAAoHEpgAFjZGkAJxgqGO0XcgAAoC8hbwD0AIwCAAFhaDEYMhi3YzuA8ADwQAABbXI5GD0YbAA7gOsA60BvAACgrCCAAWNpcABGGEgYSxhsACFgcwD0ACwEAAFlb08YVxhjAHQAYQB0AGkAbwDuABoEbgBlAG4AdABpAGEAbADlADME4Ql1GAAAgRgAAIMYiBgAAAAAoRilGAAAqhgAALsYvhjRGAAA1xgnGWwAbABpAG4AZwBkAG8AdABzAGUA8QBlF3kARGRtImFsZQAAoEAmgAFpbHIAjRiRGJ0Y7CFpZwCgA/tpApcYAAAAAJoYZwAAoAD7aQBnAACgBPsA4DXYI93sIWlnAKAB++whaWcA4GYAagCAAWFsdACvGLIYthh0AACgbSZpAGcAAKAC+24AcwAAoLElbwBmAJJh8AHCGAAAxhhmAADgNdhX3QABYWvJGMwYbADsAGsEdqDUIgCg2SphI3J0aW50AACgDSoAAWFv2hgiGQABY3PeGB8ZsQPnGP0YBRkSGRUZAAAdGbID7xjyGPQY9xj5GAAA+xg7gL0AvUAAoFMhO4C8ALxAAKBVIQCgWSEAoFshswEBGQAAAxkAoFQhAKBWIbQCCxkOGQAAAAAQGTuAvgC+QACgVyEAoFwhNQAAoFghtgEZGQAAGxkAoFohAKBdITgAAKBeIWwAAKBEIHcAbgAAoCIjYwByAADgNdi73IAIRWFiY2RlZmdpamxub3JzdHYARhlKGVoZXhlmGWkZkhmWGZkZnRmgGa0ZxhnLGc8Z4BkjGmygZyIAoIwqgAFjbXAAUBlTGVgZ9SF0ZfVhbQBhAOSgswM6FgCghipyImV2ZQAfYQABaXliGWUZcgBjAB1hM2RvAHQAIWGAoWUibHFzAMYEcBl6GfGhZSLOBAAAdhlsAGEAbgD0AN8EgKF+KmNkbACBGYQZjBljAACgqSpvAHQAb6CAKmyggioAoIQqZeDbIgD+cwAAoJQqcgAA4DXYJN3noGsirATtIWVsAKA3IWMAeQBTZIChdyJFYWoApxmpGasZAKCSKgCgpSoAoKQqAAJFYWVztBm2Gb0ZwhkAoGkicABwoIoq8iFveACgiipxoIgq8aCIKrUZaQBtAACg5yJwAGYAAOA12FjdYQB2AOUAYwIAAWNp0xnWGXIAAKAKIW0AAKFzImVs3BneGQCgjioAoJAqAIM+ADtjZGxxco0E6xn0GfgZ/BkBGgABY2nvGfEZAKCnKnIAAKB6Km8AdAAAoNci0CFhcgCglSl1ImVzdAAAoHwqgAJhZGVscwAKGvQZFhrVBCAa8AEPGgAAFBpwAHIAbwD4AFkZcgAAoHgpcQAAAWxxxAQbGmwAZQBzAPMASRlpAO0A5AQAAWVuJxouGnIjdG5lcXEAAOBpIgD+xQAsGgAFQWFiY2Vma29zeUAaQxpmGmoabRqDGocalhrCGtMacgDyAMwCAAJpbG1yShpOGlAaVBpyAHMA8ABxD2YAvWBpAGwA9AASBQABZHJYGlsaYwB5AEpkAKGUIWN3YBpkGmkAcgAAoEgpAKCtIWEAcgAAoA8h6SFyYyVhgAFhbHIAcxp7Gn8a8iF0c3WgZSZpAHQAAKBlJuwhaXAAoCYg4yFvbgCguSJyAADgNdgl3XMAAAFld4wakRphInJvdwAAoCUpYSJyb3cAAKAmKYACYW1vcHIAnxqjGqcauhq+GnIAcgAAoP8h9CFodACgOyJrAAABbHKsGrMaZSRmdGFycm93AACgqSHpJGdodGFycm93AKCqIWYAAOA12Fnd4iFhcgCgFSCAAWNsdADIGswa0BpyAADgNdi93GEAcwDoAGka8iFvaydhAAFicNca2xr1IWxsAKBDIOghZW4AoBAg4Qr2GgAA/RoAAAgbExsaGwAAIRs7GwAAAAA+G2IbmRuVG6sbAACyG80b0htjAHUAdABlADuA7QDtQAChYyBpeQEbBhtyAGMAO4DuAO5AOGQAAWN4CxsNG3kANWRjAGwAO4ChAKFAAAFmcssCFhsA4DXYJt1yAGEAdgBlADuA7ADsQIChSCFpbm8AJxsyGzYbAAFpbisbLxtuAHQAAKAMKnQAAKAtIuYhaW4AoNwpdABhAACgKSHsIWlnM2GAAWFvcABDG1sbXhuAAWNndABJG0sbWRtyACthgAFlbHAAcQVRG1UbaQBuAOUAyAVhAHIA9AByBWgAMWFmAACgtyJlAGQAtWEAoggiY2ZvdGkbbRt1G3kb4SFyZQCgBSFpAG4AdKAeImkAZQAAoN0pZABvAPQAWxsAoisiY2VscIEbhRuPG5QbYQBsAACguiIAAWdyiRuNG2UAcgDzACMQ4wCCG2EicmhrAACgFyryIW9kAKA8KgACY2dwdJ8boRukG6gbeQBRZG8AbgAvYWYAAOA12FrdYQC5Y3UAZQBzAHQAO4C/AL9AAAFjabUbuRtyAADgNdi+3G4AAKIIIkVkc3bCG8QbyBvQAwCg+SJvAHQAAKD1Inag9CIAoPMiaaBiIOwhZGUpYesB1hsAANkbYwB5AFZkbAA7gO8A70AAA2NmbW9zdeYb7hvyG/Ub+hsFHAABaXnqG+0bcgBjADVhOWRyAADgNdgn3eEhdGg3YnAAZgAA4DXYW93jAf8bAAADHHIAAOA12L/c8iFjeVhk6yFjeVRkAARhY2ZnaGpvcxUcGhwiHCYcKhwtHDAcNRzwIXBhdqC6A/BjAAFleR4cIRzkIWlsN2E6ZHIAAOA12CjdciJlZW4AOGFjAHkARWRjAHkAXGRwAGYAAOA12FzdYwByAADgNdjA3IALQUJFSGFiY2RlZmdoamxtbm9wcnN0dXYAXhxtHHEcdRx5HN8cBx0dHTwd3B3tHfEdAR4EHh0eLB5FHrwewx7hHgkfPR9LH4ABYXJ0AGQcZxxpHHIA8gBvB/IAxQLhIWlsAKAbKeEhcnIAoA4pZ6BmIgCgiyphAHIAAKBiKWMJjRwAAJAcAACVHAAAAAAAAAAAAACZHJwcAACmHKgcrRwAANIc9SF0ZTph7SJwdHl2AKC0KXIAYQDuAFoG4iFkYbtjZwAAoegnZGyhHKMcAKCRKeUAiwYAoIUqdQBvADuAqwCrQHIAgKOQIWJmaGxwc3QAuhy/HMIcxBzHHMoczhxmoOQhcwAAoB8pcwAAoB0p6wCyGnAAAKCrIWwAAKA5KWkAbQAAoHMpbAAAoKIhAKGrKmFl1hzaHGkAbAAAoBkpc6CtKgDgrSoA/oABYWJyAOUc6RztHHIAcgAAoAwpcgBrAACgcicAAWFr8Rz4HGMAAAFla/Yc9xx7YFtgAAFlc/wc/hwAoIspbAAAAWR1Ax0FHQCgjykAoI0pAAJhZXV5Dh0RHRodHB3yIW9uPmEAAWRpFR0YHWkAbAA8YewAowbiAPccO2QAAmNxcnMkHScdLB05HWEAAKA2KXUAbwDyoBwgqhEAAWR1MB00HeghYXIAoGcpcyJoYXIAAKBLKWgAAKCyIQCiZCJmZ3FzRB1FB5Qdnh10AIACYWhscnQATh1WHWUdbB2NHXIicm93AHSgkCFhAOkAzxxhI3Jwb29uAAABZHVeHWId7yF3bgCgvSFwAACgvCHlJGZ0YXJyb3dzAKDHIWkiZ2h0AIABYWhzAHUdex2DHXIicm93APOglCGdBmEAcgBwAG8AbwBuAPMAzgtxAHUAaQBnAGEAcgByAG8A9wBlGugkcmVldGltZXMAoMsi8aFkIk0HAACaHWwAYQBuAPQAXgcAon0qY2Rnc6YdqR2xHbcdYwAAoKgqbwB0AG+gfypyoIEqAKCDKmXg2iIA/nMAAKCTKoACYWRlZ3MAwB3GHcod1h3ZHXAAcAByAG8A+ACmHG8AdAAAoNYicQAAAWdxzx3SHXQA8gBGB2cAdADyAHQcdADyAFMHaQDtAGMHgAFpbHIA4h3mHeod8yFodACgfClvAG8A8gDKBgDgNdgp3UWgdiIAoJEqYQH1Hf4dcgAAAWR1YB35HWygvCEAoGopbABrAACghCVjAHkAWWQAomoiYWNodAweDx4VHhkecgDyAGsdbwByAG4AZQDyAGAW4SFyZACgaylyAGkAAKD6JQABaW8hHiQe5CFvdEBh9SFzdGGgsCPjIWhlAKCwIwACRWFlczMeNR48HkEeAKBoInAAcKCJKvIhb3gAoIkqcaCHKvGghyo0HmkAbQAAoOYiAARhYm5vcHR3elIeXB5fHoUelh6mHqsetB4AAW5yVh5ZHmcAAKDsJ3IAAKD9IXIA6wCwBmcAgAFsbXIAZh52Hnse5SFmdAABYXKIB2weaQBnAGgAdABhAHIAcgBvAPcAkwfhInBzdG8AoPwnaQBnAGgAdABhAHIAcgBvAPcAmgdwI2Fycm93AAABbHKNHpEeZQBmAPQAxhxpImdodAAAoKwhgAFhZmwAnB6fHqIecgAAoIUpAOA12F3ddQBzAACgLSppIm1lcwAAoDQqYQGvHrMecwB0AACgFyLhAIoOZaHKJbkeRhLuIWdlAKDKJWEAcgBsoCgAdAAAoJMpgAJhY2htdADMHs8e1R7bHt0ecgDyAJ0GbwByAG4AZQDyANYWYQByAGSgyyEAoG0pAKAOIHIAaQAAoL8iAANhY2hpcXTrHu8e1QfzHv0eBh/xIXVvAKA5IHIAAOA12MHcbQDloXIi+h4AAPweAKCNKgCgjyoAAWJ19xwBH28AcqAYIACgGiDyIW9rQmEAhDwAO2NkaGlscXJCBhcfxh0gHyQfKB8sHzEfAAFjaRsfHR8AoKYqcgAAoHkqcgBlAOUAkx3tIWVzAKDJIuEhcnIAoHYpdSJlc3QAAKB7KgABUGk1HzkfYQByAACglillocMlAgdfEnIAAAFkdUIfRx9zImhhcgAAoEop6CFhcgCgZikAAWVuTx9WH3IjdG5lcXEAAOBoIgD+xQBUHwAHRGFjZGVmaGlsbm9wc3VuH3Ifoh+rH68ftx+7H74f5h/uH/MfBwj/HwsgxCFvdACgOiIAAmNscHJ5H30fiR+eH3IAO4CvAK9AAAFldIEfgx8AoEImZaAgJ3MAZQAAoCAnc6CmIXQAbwCAoaYhZGx1AJQfmB+cH28AdwDuAHkDZQBmAPQA6gbwAOkO6yFlcgCgriUAAW95ph+qH+0hbWEAoCkqPGThIXNoAKAUIOElc3VyZWRhbmdsZQCgISJyAADgNdgq3W8AAKAnIYABY2RuAMQfyR/bH3IAbwA7gLUAtUBhoiMi0B8AANMf1x9zAPQAKxFpAHIAAKDwKm8AdAA7gLcAt0B1AHMA4qESIh4TAADjH3WgOCIAoCoqYwHqH+0fcAAAoNsq8gB+GnAAbAB1APMACAgAAWRw9x/7H+UhbHMAoKciZgAA4DXYXt0AAWN0AyAHIHIAAOA12MLc8CFvcwCgPiJsobwDECAVIPQiaW1hcACguCJhAPAAEyAADEdMUlZhYmNkZWZnaGlqbG1vcHJzdHV2dzwgRyBmIG0geSCqILgg2iDeIBEhFSEyIUMhTSFQIZwhnyHSIQAiIyKLIrEivyIUIwABZ3RAIEMgAODZIjgD9uBrItIgBwmAAWVsdABNIF8gYiBmAHQAAAFhclMgWCByInJvdwAAoM0h6SRnaHRhcnJvdwCgziEA4NgiOAP24Goi0iBfCekkZ2h0YXJyb3cAoM8hAAFEZHEgdSDhIXNoAKCvIuEhc2gAoK4igAJiY25wdACCIIYgiSCNIKIgbABhAACgByL1IXRlRGFnAADgICLSIACiSSJFaW9wlSCYIJwgniAA4HAqOANkAADgSyI4A3MASWFyAG8A+AAyCnUAcgBhoG4mbADzoG4mmwjzAa8gAACzIHAAO4CgAKBAbQBwAOXgTiI4AyoJgAJhZW91eQDBIMogzSDWINkg8AHGIAAAyCAAoEMqbwBuAEhh5CFpbEZhbgBnAGSgRyJvAHQAAOBtKjgDcAAAoEIqPWThIXNoAKATIACjYCJBYWRxc3jpIO0g+SD+IAIhDCFyAHIAAKDXIXIAAAFocvIg9SBrAACgJClvoJch9wAGD28AdAAA4FAiOAN1AGkA9gC7CAABZWkGIQohYQByAACgKCntAN8I6SFzdPOgBCLlCHIAAOA12CvdAAJFZXN0/wgcISshLiHxoXEiIiEAABMJ8aFxIgAJAAAnIWwAYQBuAPQAEwlpAO0AGQlyoG8iAKBvIoABQWFwADghOyE/IXIA8gBeIHIAcgAAoK4hYQByAACg8ipzogsiSiEAAAAAxwtkoPwiAKD6ImMAeQBaZIADQUVhZGVzdABcIV8hYiFmIWkhkyGWIXIA8gBXIADgZiI4A3IAcgAAoJohcgAAoCUggKFwImZxcwBwIYQhjiF0AAABYXJ1IXohcgByAG8A9wBlIWkAZwBoAHQAYQByAHIAbwD3AD4h8aFwImAhAACKIWwAYQBuAPQAZwlz4H0qOAMAoG4iaQDtAG0JcqBuImkA5aDqIkUJaQDkADoKAAFwdKMhpyFmAADgNdhf3YCBrAA7aW4AriGvIcchrEBuAIChCSJFZHYAtyG6Ib8hAOD5IjgDbwB0AADg9SI4A+EB1gjEIcYhAKD3IgCg9iJpAHagDCLhAagJzyHRIQCg/iIAoP0igAFhb3IA2CHsIfEhcgCAoSYiYXN0AOAh5SHpIWwAbABlAOwAywhsAADg/SrlIADgAiI4A2wiaW50AACgFCrjoYAi9yEAAPohdQDlAJsJY+CvKjgDZaCAIvEAkwkAAkFhaXQHIgoiFyIeInIA8gBsIHIAcgAAoZshY3cRIhQiAOAzKTgDAOCdITgDZyRodGFycm93AACgmyFyAGkA5aDrIr4JgANjaGltcHF1AC8iPCJHIpwhTSJQIloigKGBImNlcgA2Iv0JOSJ1AOUABgoA4DXYw9zvIXJ0bQKdIQAAAABEImEAcgDhAOEhbQBloEEi8aBEIiYKYQDyAMsIcwB1AAABYnBWIlgi5QDUCeUA3wmAAWJjcABgInMieCKAoYQiRWVzAGci7glqIgDgxSo4A2UAdABl4IIi0iBxAPGgiCJoImMAZaCBIvEA/gmAoYUiRWVzAH8iFgqCIgDgxio4A2UAdABl4IMi0iBxAPGgiSKAIgACZ2lscpIilCKaIpwi7AAMCWwAZABlADuA8QDxQOcAWwlpI2FuZ2xlAAABbHKkIqoi5SFmdGWg6iLxAEUJaSJnaHQAZaDrIvEAvgltoL0DAKEjAGVzuCK8InIAbwAAoBYhcAAAoAcggARESGFkZ2lscnMAziLSItYi2iLeIugi7SICIw8j4SFzaACgrSLhIXJyAKAEKXAAAOBNItIg4SFzaACgrCIAAWV04iLlIgDgZSLSIADgPgDSIG4iZmluAACg3imAAUFldADzIvci+iJyAHIAAKACKQDgZCLSIHLgPADSIGkAZQAA4LQi0iAAAUF0BiMKI3IAcgAAoAMp8iFpZQDgtSLSIGkAbQAA4Dwi0iCAAUFhbgAaIx4jKiNyAHIAAKDWIXIAAAFociMjJiNrAACgIylvoJYh9wD/DuUhYXIAoCcpUxJqFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVCMAAF4jaSN/I4IjjSOeI8AUAAAAAKYjwCMAANoj3yMAAO8jHiQvJD8kRCQAAWNzVyNsFHUAdABlADuA8wDzQAABaXlhI2cjcgBjoJoiO4D0APRAPmSAAmFiaW9zAHEjdCN3I3EBeiNzAOgAdhTsIWFjUWF2AACgOCrvIWxkAKC8KewhaWdTYQABY3KFI4kjaQByAACgvykA4DXYLN1vA5QjAAAAAJYjAACcI24A22JhAHYAZQA7gPIA8kAAoMEpAAFibaEjjAphAHIAAKC1KQACYWNpdKwjryO6I70jcgDyAFkUAAFpcrMjtiNyAACgvinvIXNzAKC7KW4A5QDZCgCgwCmAAWFlaQDFI8gjyyNjAHIATWFnAGEAyWOAAWNkbgDRI9Qj1iPyIW9uv2MAoLYpdQDzAHgBcABmAADgNdhg3YABYWVsAOQj5yPrI3IAAKC3KXIAcAAAoLkpdQDzAHwBAKMoImFkaW9zdvkj/CMPJBMkFiQbJHIA8gBeFIChXSplZm0AAyQJJAwkcgBvoDQhZgAAoDQhO4CqAKpAO4C6ALpA5yFvZgCgtiJyAACgVipsIm9wZQAAoFcqAKBbKoABY2xvACMkJSQrJPIACCRhAHMAaAA7gPgA+EBsAACgmCJpAGwBMyQ4JGQAZQA7gPUA9UBlAHMAYaCXInMAAKA2Km0AbAA7gPYA9kDiIWFyAKA9I+EKXiQAAHokAAB8JJQkAACYJKkkAAAAALUkEQsAAPAkAAAAAAQleiUAAIMlcgCAoSUiYXN0AGUkbyQBCwCBtgA7bGokayS2QGwAZQDsABgDaQJ1JAAAAAB4JG0AAKDzKgCg/Sp5AD9kcgCAAmNpbXB0AIUkiCSLJJkSjyRuAHQAJWBvAGQALmBpAGwAAKAwIOUhbmsAoDEgcgAA4DXYLd2AAWltbwCdJKAkpCR2oMYD1WNtAGEA9AD+B24AZQAAoA4m9KHAA64kAAC0JGMjaGZvcmsAAKDUItZjAAFhdbgkxCRuAAABY2u9JMIkawBooA8hAKAOIfYAaRpzAACkKwBhYmNkZW1zdNMkIRPXJNsk4STjJOck6yTjIWlyAKAjKmkAcgAAoCIqAAFvdYsW3yQAoCUqAKByKm4AO4CxALFAaQBtAACgJip3AG8AAKAnKoABaXB1APUk+iT+JO4idGludACgFSpmAADgNdhh3W4AZAA7gKMAo0CApHoiRWFjZWlub3N1ABMlFSUYJRslTCVRJVklSSV1JQCgsypwAACgtyp1AOUAPwtjoK8qgKJ6ImFjZW5zACclLSU0JTYlSSVwAHAAcgBvAPgAFyV1AHIAbAB5AGUA8QA/C/EAOAuAAWFlcwA8JUElRSXwInByb3gAoLkqcQBxAACgtSppAG0AAKDoImkA7QBEC20AZQDzoDIgIguAAUVhcwBDJVclRSXwAEAlgAFkZnAATwtfJXElgAFhbHMAZSVpJW0l7CFhcgCgLiPpIW5lAKASI/UhcmYAoBMjdKAdIu8AWQvyIWVsAKCwIgABY2l9JYElcgAA4DXYxdzIY24iY3NwAACgCCAAA2Zpb3BzdZElKxuVJZolnyWkJXIAAOA12C7dcABmAADgNdhi3XIiaW1lAACgVyBjAHIAAOA12MbcgAFhZW8AqiW6JcAldAAAAWVpryW2JXIAbgBpAG8AbgDzABkFbgB0AACgFipzAHQAZaA/APEACRj0AG0LgApBQkhhYmNkZWZoaWxtbm9wcnN0dXgA4yXyJfYl+iVpJpAmpia9JtUm5ib4JlonaCdxJ3UnnietJ7EnyCfiJ+cngAFhcnQA6SXsJe4lcgDyAJkM8gD6AuEhaWwAoBwpYQByAPIA3BVhAHIAAKBkKYADY2RlbnFydAAGJhAmEyYYJiYmKyZaJgABZXUKJg0mAOA9IjEDdABlAFVhaQDjACAN7SJwdHl2AKCzKWcAgKHpJ2RlbAAgJiImJCYAoJIpAKClKeUA9wt1AG8AO4C7ALtAcgAApZIhYWJjZmhscHN0dz0mQCZFJkcmSiZMJk4mUSZVJlgmcAAAoHUpZqDlIXMAAKAgKQCgMylzAACgHinrALka8ACVHmwAAKBFKWkAbQAAoHQpbAAAoKMhAKCdIQABYWleJmImaQBsAACgGilvAG6gNiJhAGwA8wB2C4ABYWJyAG8mciZ2JnIA8gAvEnIAawAAoHMnAAFha3omgSZjAAABZWt/JoAmfWBdYAABZXOFJocmAKCMKWwAAAFkdYwmjiYAoI4pAKCQKQACYWV1eZcmmiajJqUm8iFvbllhAAFkaZ4moSZpAGwAV2HsAA8M4gCAJkBkAAJjbHFzrSawJrUmuiZhAACgNylkImhhcgAAoGkpdQBvAPKgHSCjAWgAAKCzIYABYWNnAMMm0iaUC2wAgKEcIWlwcwDLJs4migxuAOUAoAxhAHIA9ADaC3QAAKCtJYABaWxyANsm3ybjJvMhaHQAoH0pbwBvAPIANgwA4DXYL90AAWFv6ib1JnIAAAFkde8m8SYAoMEhbKDAIQCgbCl2oMED8WOAAWducwD+Jk4nUCdoAHQAAANhaGxyc3QKJxInISc1Jz0nRydyInJvdwB0oJIhYQDpAFYmYSNycG9vbgAAAWR1GiceJ28AdwDuAPAmcAAAoMAh5SFmdAABYWgnJy0ncgByAG8AdwDzAAkMYQByAHAAbwBvAG4A8wATBGklZ2h0YXJyb3dzAACgySFxAHUAaQBnAGEAcgByAG8A9wBZJugkcmVldGltZXMAoMwiZwDaYmkAbgBnAGQAbwB0AHMAZQDxABwYgAFhaG0AYCdjJ2YncgDyAAkMYQDyABMEAKAPIG8idXN0AGGgsSPjIWhlAKCxI+0haWQAoO4qAAJhYnB0fCeGJ4knmScAAW5ygCeDJ2cAAKDtJ3IAAKD+IXIA6wAcDIABYWZsAI8nkieVJ3IAAKCGKQDgNdhj3XUAcwAAoC4qaSJtZXMAAKA1KgABYXCiJ6gncgBnoCkAdAAAoJQp7yJsaW50AKASKmEAcgDyADwnAAJhY2hxuCe8J6EMwCfxIXVvAKA6IHIAAOA12MfcAAFidYAmxCdvAPKgGSCoAYABaGlyAM4n0ifWJ3IAZQDlAE0n7SFlcwCgyiJpAIChuSVlZmwAXAxjEt4n9CFyaQCgzinsInVoYXIAoGgpAKAeIWENBSgJKA0oSyhVKIYoAACLKLAoAAAAAOMo5ygAABApJCkxKW0pcSmHKaYpAACYKgAAAACxKmMidXRlAFthcQB1AO8ABR+ApHsiRWFjZWlucHN5ABwoHignKCooLygyKEEoRihJKACgtCrwASMoAAAlKACguCpvAG4AYWF1AOUAgw1koLAqaQBsAF9hcgBjAF1hgAFFYXMAOCg6KD0oAKC2KnAAAKC6KmkAbQAAoOki7yJsaW50AKATKmkA7QCIDUFkbwB0AGKixSKRFgAAAABTKACgZiqAA0FhY21zdHgAYChkKG8ocyh1KHkogihyAHIAAKDYIXIAAAFocmkoayjrAJAab6CYIfcAzAd0ADuApwCnQGkAO2D3IWFyAKApKW0AAAFpbn4ozQBuAHUA8wDOAHQAAKA2J3IA7+A12DDdIxkAAmFjb3mRKJUonSisKHIAcAAAoG8mAAFoeZkonChjAHkASWRIZHIAdABtAqUoAAAAAKgoaQDkAFsPYQByAGEA7ABsJDuArQCtQAABZ22zKLsobQBhAAChwwNmdroouijCY4CjPCJkZWdsbnByAMgozCjPKNMo1yjaKN4obwB0AACgairxoEMiCw5FoJ4qAKCgKkWgnSoAoJ8qZQAAoEYi7CF1cwCgJCrhIXJyAKByKWEAcgDyAPwMAAJhZWl07Sj8KAEpCCkAAWxz8Sj4KGwAcwBlAHQAbQDpAH8oaABwAACgMyrwImFyc2wAoOQpAAFkbFoPBSllAACgIyNloKoqc6CsKgDgrCoA/oABZmxwABUpGCkfKfQhY3lMZGKgLwBhoMQpcgAAoD8jZgAA4DXYZN1hAAABZHIoKRcDZQBzAHWgYCZpAHQAAKBgJoABY3N1ADYpRilhKQABYXU6KUApcABzoJMiAOCTIgD+cABzoJQiAOCUIgD+dQAAAWJwSylWKQChjyJlcz4NUCllAHQAZaCPIvEAPw0AoZAiZXNIDVspZQB0AGWgkCLxAEkNAKGhJWFmZilbBHIAZQFrKVwEAKChJWEAcgDyAAMNAAJjZW10dyl7KX8pgilyAADgNdjI3HQAbQDuAM4AaQDsAAYpYQByAOYAVw0AAWFyiimOKXIA5qAGJhESAAFhbpIpoylpImdodAAAAWVwmSmgKXAAcwBpAGwAbwDuANkXaADpAKAkcwCvYIACYmNtbnAArin8KY4NJSooKgCkgiJFZGVtbnByc7wpvinCKcgpzCnUKdgp3CkAoMUqbwB0AACgvSpkoIYibwB0AACgwyr1IWx0AKDBKgABRWXQKdIpAKDLKgCgiiLsIXVzAKC/KuEhcnIAoHkpgAFlaXUA4inxKfQpdAAAoYIiZW7oKewpcQDxoIYivSllAHEA8aCKItEpbQAAoMcqAAFicPgp+ikAoNUqAKDTKmMAgKJ7ImFjZW5zAAcqDSoUKhYqRihwAHAAcgBvAPgAIyh1AHIAbAB5AGUA8QCDDfEAfA2AAWFlcwAcKiIqPShwAHAAcgBvAPgAPChxAPEAOShnAACgaiYApoMiMTIzRWRlaGxtbnBzPCo/KkIqRSpHKlIqWCpjKmcqaypzKncqO4C5ALlAO4CyALJAO4CzALNAAKDGKgABb3NLKk4qdAAAoL4qdQBiAACg2CpkoIcibwB0AACgxCpzAAABb3VdKmAqbAAAoMknYgAAoNcq4SFycgCgeyn1IWx0AKDCKgABRWVvKnEqAKDMKgCgiyLsIXVzAKDAKoABZWl1AH0qjCqPKnQAAKGDImVugyqHKnEA8aCHIkYqZQBxAPGgiyJwKm0AAKDIKgABYnCTKpUqAKDUKgCg1iqAAUFhbgCdKqEqrCpyAHIAAKDZIXIAAAFocqYqqCrrAJUab6CZIfcAxQf3IWFyAKAqKWwAaQBnADuA3wDfQOELzyrZKtwq6SrsKvEqAAD1KjQrAAAAAAAAAAAAAEwrbCsAAHErvSsAAAAAAADRK3IC1CoAAAAA2CrnIWV0AKAWI8RjcgDrAOUKgAFhZXkA4SrkKucq8iFvbmVh5CFpbGNhQmRvAPQAIg5sInJlYwAAoBUjcgAA4DXYMd0AAmVpa2/7KhIrKCsuK/IBACsAAAkrZQAAATRm6g0EK28AcgDlAOsNYQBzorgDECsAAAAAEit5AG0A0WMAAWNuFislK2sAAAFhcxsrIStwAHAAcgBvAPgAFw5pAG0AAKA8InMA8AD9DQABYXMsKyEr8AAXDnIAbgA7gP4A/kDsATgrOyswG2QA5QBnAmUAcwCAgdcAO2JkAEMrRCtJK9dAYaCgInIAAKAxKgCgMCqAAWVwcwBRK1MraSvhAAkh4qKkIlsrXysAAAAAYytvAHQAAKA2I2kAcgAAoPEqb+A12GXdcgBrAACg2irhAHgociJpbWUAAKA0IIABYWlwAHYreSu3K2QA5QC+DYADYWRlbXBzdACFK6MrmiunK6wrsCuzK24iZ2xlAACitSVkbHFykCuUK5ornCvvIXduAKC/JeUhZnRloMMl8QACBwCgXCJpImdodABloLkl8QBdDG8AdAAAoOwlaSJudXMAAKA6KuwhdXMAoDkqYgAAoM0p6SFtZQCgOyrlInppdW0AoOIjgAFjaHQAwivKK80rAAFyecYrySsA4DXYydxGZGMAeQBbZPIhb2tnYQABaW/UK9creAD0ANERaCJlYWQAAAFsct4r5ytlAGYAdABhAHIAcgBvAPcAXQbpJGdodGFycm93AKCgIQAJQUhhYmNkZmdobG1vcHJzdHV3CiwNLBEsHSwnLDEsQCxLLFIsYix6LIQsjyzLLOgs7Sz/LAotcgDyAAkDYQByAACgYykAAWNyFSwbLHUAdABlADuA+gD6QPIACQ1yAOMBIywAACUseQBeZHYAZQBtYQABaXkrLDAscgBjADuA+wD7QENkgAFhYmgANyw6LD0scgDyANEO7CFhY3FhYQDyAOAOAAFpckQsSCzzIWh0AKB+KQDgNdgy3XIAYQB2AGUAO4D5APlAYQFWLF8scgAAAWxyWixcLACgvyEAoL4hbABrAACggCUAAWN0Zix2LG8CbCwAAAAAcyxyAG4AZaAcI3IAAKAcI28AcAAAoA8jcgBpAACg+CUAAWFsfiyBLGMAcgBrYTuAqACoQAABZ3CILIssbwBuAHNhZgAA4DXYZt0AA2FkaGxzdZksniynLLgsuyzFLHIAcgBvAPcACQ1vAHcAbgBhAHIAcgBvAPcA2A5hI3Jwb29uAAABbHKvLLMsZQBmAPQAWyxpAGcAaAD0AF0sdQDzAKYOaQAAocUDaGzBLMIs0mNvAG4AxWPwI2Fycm93cwCgyCGAAWNpdADRLOEs5CxvAtcsAAAAAN4scgBuAGWgHSNyAACgHSNvAHAAAKAOI24AZwBvYXIAaQAAoPklYwByAADgNdjK3IABZGlyAPMs9yz6LG8AdAAAoPAi7CFkZWlhaQBmoLUlAKC0JQABYW0DLQYtcgDyAMosbAA7gPwA/EDhIm5nbGUAoKcpgAdBQkRhY2RlZmxub3Byc3oAJy0qLTAtNC2bLZ0toS2/LcMtxy3TLdgt3C3gLfwtcgDyABADYQByAHag6CoAoOkqYQBzAOgA/gIAAW5yOC08LechcnQAoJwpgANla25wcnN0AJkpSC1NLVQtXi1iLYItYQBwAHAA4QAaHG8AdABoAGkAbgDnAKEXgAFoaXIAoSmzJFotbwBwAPQAdCVooJUh7wD4JgABaXVmLWotZwBtAOEAuygAAWJwbi14LXMjZXRuZXEAceCKIgD+AODLKgD+cyNldG5lcQBx4IsiAP4A4MwqAP4AAWhyhi2KLWUAdADhABIraSNhbmdsZQAAAWxyki2WLeUhZnQAoLIiaSJnaHQAAKCzInkAMmThIXNoAKCiIoABZWxyAKcttC24LWKiKCKuLQAAAACyLWEAcgAAoLsicQAAoFoi7CFpcACg7iIAAWJ0vC1eD2EA8gBfD3IAAOA12DPddAByAOkAlS1zAHUAAAFicM0t0C0A4IIi0iAA4IMi0iBwAGYAAOA12GfdcgBvAPAAWQt0AHIA6QCaLQABY3XkLegtcgAA4DXYy9wAAWJw7C30LW4AAAFFZXUt8S0A4IoiAP5uAAABRWV/LfktAOCLIgD+6SJnemFnAKCaKYADY2Vmb3BycwANLhAuJS4pLiMuLi40LukhcmN1YQABZGkULiEuAAFiZxguHC5hAHIAAKBfKmUAcaAnIgCgWSLlIXJwAKAYIXIAAOA12DTdcABmAADgNdho3WWgQCJhAHQA6ABqD2MAcgAA4DXYzNzjCuQRUC4AAFQuAABYLmIuAAAAAGMubS5wLnQuAAAAAIguki4AAJouJxIqEnQAcgDpAB0ScgAA4DXYNd0AAUFhWy5eLnIA8gDnAnIA8gCTB75jAAFBYWYuaS5yAPIA4AJyAPIAjAdhAPAAeh5pAHMAAKD7IoABZHB0APgReS6DLgABZmx9LoAuAOA12GnddQDzAP8RaQBtAOUABBIAAUFhiy6OLnIA8gDuAnIA8gCaBwABY3GVLgoScgAA4DXYzdwAAXB0nS6hLmwAdQDzACUScgDpACASAARhY2VmaW9zdbEuvC7ELsguzC7PLtQu2S5jAAABdXm2LrsudABlADuA/QD9QE9kAAFpecAuwy5yAGMAd2FLZG4AO4ClAKVAcgAA4DXYNt1jAHkAV2RwAGYAAOA12GrdYwByAADgNdjO3AABY23dLt8ueQBOZGwAO4D/AP9AAAVhY2RlZmhpb3N38y73Lv8uAi8MLxAvEy8YLx0vIi9jInV0ZQB6YQABYXn7Lv4u8iFvbn5hN2RvAHQAfGEAAWV0Bi8KL3QAcgDmAB8QYQC2Y3IAAOA12DfdYwB5ADZk5yJyYXJyAKDdIXAAZgAA4DXYa91jAHIAAOA12M/cAAFqbiYvKC8AoA0gagAAoAwg");
  var BinTrieFlags;
  (function(BinTrieFlags2) {
    BinTrieFlags2[BinTrieFlags2["VALUE_LENGTH"] = 49152] = "VALUE_LENGTH";
    BinTrieFlags2[BinTrieFlags2["FLAG13"] = 8192] = "FLAG13";
    BinTrieFlags2[BinTrieFlags2["BRANCH_LENGTH"] = 8064] = "BRANCH_LENGTH";
    BinTrieFlags2[BinTrieFlags2["JUMP_TABLE"] = 127] = "JUMP_TABLE";
  })(BinTrieFlags || (BinTrieFlags = {}));
  var CharCodes;
  (function(CharCodes2) {
    CharCodes2[CharCodes2["NUM"] = 35] = "NUM";
    CharCodes2[CharCodes2["SEMI"] = 59] = "SEMI";
    CharCodes2[CharCodes2["EQUALS"] = 61] = "EQUALS";
    CharCodes2[CharCodes2["ZERO"] = 48] = "ZERO";
    CharCodes2[CharCodes2["NINE"] = 57] = "NINE";
    CharCodes2[CharCodes2["LOWER_A"] = 97] = "LOWER_A";
    CharCodes2[CharCodes2["LOWER_F"] = 102] = "LOWER_F";
    CharCodes2[CharCodes2["LOWER_X"] = 120] = "LOWER_X";
    CharCodes2[CharCodes2["LOWER_Z"] = 122] = "LOWER_Z";
    CharCodes2[CharCodes2["UPPER_A"] = 65] = "UPPER_A";
    CharCodes2[CharCodes2["UPPER_F"] = 70] = "UPPER_F";
    CharCodes2[CharCodes2["UPPER_Z"] = 90] = "UPPER_Z";
  })(CharCodes || (CharCodes = {}));
  const TO_LOWER_BIT = 32;
  function isNumber(code) {
    return code >= CharCodes.ZERO && code <= CharCodes.NINE;
  }
  function isHexadecimalCharacter(code) {
    return code >= CharCodes.UPPER_A && code <= CharCodes.UPPER_F || code >= CharCodes.LOWER_A && code <= CharCodes.LOWER_F;
  }
  function isAsciiAlphaNumeric$1(code) {
    return code >= CharCodes.UPPER_A && code <= CharCodes.UPPER_Z || code >= CharCodes.LOWER_A && code <= CharCodes.LOWER_Z || isNumber(code);
  }
  function isEntityInAttributeInvalidEnd(code) {
    return code === CharCodes.EQUALS || isAsciiAlphaNumeric$1(code);
  }
  var EntityDecoderState;
  (function(EntityDecoderState2) {
    EntityDecoderState2[EntityDecoderState2["EntityStart"] = 0] = "EntityStart";
    EntityDecoderState2[EntityDecoderState2["NumericStart"] = 1] = "NumericStart";
    EntityDecoderState2[EntityDecoderState2["NumericDecimal"] = 2] = "NumericDecimal";
    EntityDecoderState2[EntityDecoderState2["NumericHex"] = 3] = "NumericHex";
    EntityDecoderState2[EntityDecoderState2["NamedEntity"] = 4] = "NamedEntity";
  })(EntityDecoderState || (EntityDecoderState = {}));
  var DecodingMode;
  (function(DecodingMode2) {
    DecodingMode2[DecodingMode2["Legacy"] = 0] = "Legacy";
    DecodingMode2[DecodingMode2["Strict"] = 1] = "Strict";
    DecodingMode2[DecodingMode2["Attribute"] = 2] = "Attribute";
  })(DecodingMode || (DecodingMode = {}));
  class EntityDecoder {
    decodeTree;
    emitCodePoint;
    errors;
    constructor(decodeTree, emitCodePoint, errors) {
      this.decodeTree = decodeTree;
      this.emitCodePoint = emitCodePoint;
      this.errors = errors;
    }
    /** The current state of the decoder. */
    state = EntityDecoderState.EntityStart;
    /** Characters that were consumed while parsing an entity. */
    consumed = 1;
    /**
     * The result of the entity.
     *
     * Either the result index of a numeric entity, or the codepoint of a
     * numeric entity.
     */
    result = 0;
    /** The current index in the decode tree. */
    treeIndex = 0;
    /** The number of characters that were consumed in excess. */
    excess = 1;
    /** The mode in which the decoder is operating. */
    decodeMode = DecodingMode.Strict;
    /** The number of characters that have been consumed in the current run. */
    runConsumed = 0;
    /**
     * Resets the instance to make it reusable.
     * @param decodeMode Entity decoding mode to use.
     */
    startEntity(decodeMode) {
      this.decodeMode = decodeMode;
      this.state = EntityDecoderState.EntityStart;
      this.result = 0;
      this.treeIndex = 0;
      this.excess = 1;
      this.consumed = 1;
      this.runConsumed = 0;
    }
    /**
     * Write an entity to the decoder. This can be called multiple times with partial entities.
     * If the entity is incomplete, the decoder will return -1.
     *
     * Mirrors the implementation of \`getDecoder\`, but with the ability to stop decoding if the
     * entity is incomplete, and resume when the next string is written.
     * @param input The string containing the entity (or a continuation of the entity).
     * @param offset The offset at which the entity begins. Should be 0 if this is not the first call.
     * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
     */
    write(input, offset) {
      switch (this.state) {
        case EntityDecoderState.EntityStart: {
          if (input.charCodeAt(offset) === CharCodes.NUM) {
            this.state = EntityDecoderState.NumericStart;
            this.consumed += 1;
            return this.stateNumericStart(input, offset + 1);
          }
          this.state = EntityDecoderState.NamedEntity;
          return this.stateNamedEntity(input, offset);
        }
        case EntityDecoderState.NumericStart: {
          return this.stateNumericStart(input, offset);
        }
        case EntityDecoderState.NumericDecimal: {
          return this.stateNumericDecimal(input, offset);
        }
        case EntityDecoderState.NumericHex: {
          return this.stateNumericHex(input, offset);
        }
        case EntityDecoderState.NamedEntity: {
          return this.stateNamedEntity(input, offset);
        }
      }
    }
    /**
     * Switches between the numeric decimal and hexadecimal states.
     *
     * Equivalent to the \`Numeric character reference state\` in the HTML spec.
     * @param input The string containing the entity (or a continuation of the entity).
     * @param offset The current offset.
     * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
     */
    stateNumericStart(input, offset) {
      if (offset >= input.length) {
        return -1;
      }
      if ((input.charCodeAt(offset) | TO_LOWER_BIT) === CharCodes.LOWER_X) {
        this.state = EntityDecoderState.NumericHex;
        this.consumed += 1;
        return this.stateNumericHex(input, offset + 1);
      }
      this.state = EntityDecoderState.NumericDecimal;
      return this.stateNumericDecimal(input, offset);
    }
    /**
     * Parses a hexadecimal numeric entity.
     *
     * Equivalent to the \`Hexademical character reference state\` in the HTML spec.
     * @param input The string containing the entity (or a continuation of the entity).
     * @param offset The current offset.
     * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
     */
    stateNumericHex(input, offset) {
      while (offset < input.length) {
        const char = input.charCodeAt(offset);
        if (isNumber(char) || isHexadecimalCharacter(char)) {
          const digit = char <= CharCodes.NINE ? char - CharCodes.ZERO : (char | TO_LOWER_BIT) - CharCodes.LOWER_A + 10;
          this.result = this.result * 16 + digit;
          this.consumed++;
          offset++;
        } else {
          return this.emitNumericEntity(char, 3);
        }
      }
      return -1;
    }
    /**
     * Parses a decimal numeric entity.
     *
     * Equivalent to the \`Decimal character reference state\` in the HTML spec.
     * @param input The string containing the entity (or a continuation of the entity).
     * @param offset The current offset.
     * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
     */
    stateNumericDecimal(input, offset) {
      while (offset < input.length) {
        const char = input.charCodeAt(offset);
        if (isNumber(char)) {
          this.result = this.result * 10 + (char - CharCodes.ZERO);
          this.consumed++;
          offset++;
        } else {
          return this.emitNumericEntity(char, 2);
        }
      }
      return -1;
    }
    /**
     * Validate and emit a numeric entity.
     *
     * Implements the logic from the \`Hexademical character reference start
     * state\` and \`Numeric character reference end state\` in the HTML spec.
     * @param lastCp The last code point of the entity. Used to see if the
     *               entity was terminated with a semicolon.
     * @param expectedLength The minimum number of characters that should be
     *                       consumed. Used to validate that at least one digit
     *                       was consumed.
     * @returns The number of characters that were consumed.
     */
    emitNumericEntity(lastCp, expectedLength) {
      if (this.consumed <= expectedLength) {
        this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed);
        return 0;
      }
      if (lastCp === CharCodes.SEMI) {
        this.consumed += 1;
      } else if (this.decodeMode === DecodingMode.Strict) {
        return 0;
      }
      this.emitCodePoint(replaceCodePoint(this.result), this.consumed);
      if (this.errors) {
        if (lastCp !== CharCodes.SEMI) {
          this.errors.missingSemicolonAfterCharacterReference();
        }
        this.errors.validateNumericCharacterReference(this.result);
      }
      return this.consumed;
    }
    /**
     * Parses a named entity.
     *
     * Equivalent to the \`Named character reference state\` in the HTML spec.
     * @param input The string containing the entity (or a continuation of the entity).
     * @param offset The current offset.
     * @returns The number of characters that were consumed, or -1 if the entity is incomplete.
     */
    stateNamedEntity(input, offset) {
      const { decodeTree } = this;
      let current = decodeTree[this.treeIndex];
      let valueLength = (current & BinTrieFlags.VALUE_LENGTH) >> 14;
      while (offset < input.length) {
        if (valueLength === 0 && (current & BinTrieFlags.FLAG13) !== 0) {
          const runLength = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
          if (this.runConsumed === 0) {
            const firstChar = current & BinTrieFlags.JUMP_TABLE;
            if (input.charCodeAt(offset) !== firstChar) {
              return this.result === 0 ? 0 : this.emitNotTerminatedNamedEntity();
            }
            offset++;
            this.excess++;
            this.runConsumed++;
          }
          while (this.runConsumed < runLength) {
            if (offset >= input.length) {
              return -1;
            }
            const charIndexInPacked = this.runConsumed - 1;
            const packedWord = decodeTree[this.treeIndex + 1 + (charIndexInPacked >> 1)];
            const expectedChar = charIndexInPacked % 2 === 0 ? packedWord & 255 : packedWord >> 8 & 255;
            if (input.charCodeAt(offset) !== expectedChar) {
              this.runConsumed = 0;
              return this.result === 0 ? 0 : this.emitNotTerminatedNamedEntity();
            }
            offset++;
            this.excess++;
            this.runConsumed++;
          }
          this.runConsumed = 0;
          this.treeIndex += 1 + (runLength >> 1);
          current = decodeTree[this.treeIndex];
          valueLength = (current & BinTrieFlags.VALUE_LENGTH) >> 14;
        }
        if (offset >= input.length)
          break;
        const char = input.charCodeAt(offset);
        if (char === CharCodes.SEMI && valueLength !== 0 && (current & BinTrieFlags.FLAG13) !== 0) {
          return this.emitNamedEntityData(this.treeIndex, valueLength, this.consumed + this.excess);
        }
        this.treeIndex = determineBranch(decodeTree, current, this.treeIndex + Math.max(1, valueLength), char);
        if (this.treeIndex < 0) {
          return this.result === 0 || // If we are parsing an attribute
          this.decodeMode === DecodingMode.Attribute && // We shouldn't have consumed any characters after the entity,
          (valueLength === 0 || // And there should be no invalid characters.
          isEntityInAttributeInvalidEnd(char)) ? 0 : this.emitNotTerminatedNamedEntity();
        }
        current = decodeTree[this.treeIndex];
        valueLength = (current & BinTrieFlags.VALUE_LENGTH) >> 14;
        if (valueLength !== 0) {
          if (char === CharCodes.SEMI) {
            return this.emitNamedEntityData(this.treeIndex, valueLength, this.consumed + this.excess);
          }
          if (this.decodeMode !== DecodingMode.Strict && (current & BinTrieFlags.FLAG13) === 0) {
            this.result = this.treeIndex;
            this.consumed += this.excess;
            this.excess = 0;
          }
        }
        offset++;
        this.excess++;
      }
      return -1;
    }
    /**
     * Emit a named entity that was not terminated with a semicolon.
     * @returns The number of characters consumed.
     */
    emitNotTerminatedNamedEntity() {
      const { result, decodeTree } = this;
      const valueLength = (decodeTree[result] & BinTrieFlags.VALUE_LENGTH) >> 14;
      this.emitNamedEntityData(result, valueLength, this.consumed);
      this.errors?.missingSemicolonAfterCharacterReference();
      return this.consumed;
    }
    /**
     * Emit a named entity.
     * @param result The index of the entity in the decode tree.
     * @param valueLength The number of bytes in the entity.
     * @param consumed The number of characters consumed.
     * @returns The number of characters consumed.
     */
    emitNamedEntityData(result, valueLength, consumed) {
      const { decodeTree } = this;
      this.emitCodePoint(valueLength === 1 ? decodeTree[result] & ~(BinTrieFlags.VALUE_LENGTH | BinTrieFlags.FLAG13) : decodeTree[result + 1], consumed);
      if (valueLength === 3) {
        this.emitCodePoint(decodeTree[result + 2], consumed);
      }
      return consumed;
    }
    /**
     * Signal to the parser that the end of the input was reached.
     *
     * Remaining data will be emitted and relevant errors will be produced.
     * @returns The number of characters consumed.
     */
    end() {
      switch (this.state) {
        case EntityDecoderState.NamedEntity: {
          return this.result !== 0 && (this.decodeMode !== DecodingMode.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
        }
        // Otherwise, emit a numeric entity if we have one.
        case EntityDecoderState.NumericDecimal: {
          return this.emitNumericEntity(0, 2);
        }
        case EntityDecoderState.NumericHex: {
          return this.emitNumericEntity(0, 3);
        }
        case EntityDecoderState.NumericStart: {
          this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed);
          return 0;
        }
        case EntityDecoderState.EntityStart: {
          return 0;
        }
      }
    }
  }
  function determineBranch(decodeTree, current, nodeIndex, char) {
    const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
    const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
    if (branchCount === 0) {
      return jumpOffset !== 0 && char === jumpOffset ? nodeIndex : -1;
    }
    if (jumpOffset) {
      const value = char - jumpOffset;
      return value < 0 || value >= branchCount ? -1 : decodeTree[nodeIndex + value] - 1;
    }
    const packedKeySlots = branchCount + 1 >> 1;
    let lo2 = 0;
    let hi2 = branchCount - 1;
    while (lo2 <= hi2) {
      const mid = lo2 + hi2 >>> 1;
      const slot = mid >> 1;
      const packed = decodeTree[nodeIndex + slot];
      const midKey = packed >> (mid & 1) * 8 & 255;
      if (midKey < char) {
        lo2 = mid + 1;
      } else if (midKey > char) {
        hi2 = mid - 1;
      } else {
        return decodeTree[nodeIndex + packedKeySlots + mid];
      }
    }
    return -1;
  }
  var NS;
  (function(NS2) {
    NS2["HTML"] = "http://www.w3.org/1999/xhtml";
    NS2["MATHML"] = "http://www.w3.org/1998/Math/MathML";
    NS2["SVG"] = "http://www.w3.org/2000/svg";
    NS2["XLINK"] = "http://www.w3.org/1999/xlink";
    NS2["XML"] = "http://www.w3.org/XML/1998/namespace";
    NS2["XMLNS"] = "http://www.w3.org/2000/xmlns/";
  })(NS || (NS = {}));
  var ATTRS;
  (function(ATTRS2) {
    ATTRS2["TYPE"] = "type";
    ATTRS2["ACTION"] = "action";
    ATTRS2["ENCODING"] = "encoding";
    ATTRS2["PROMPT"] = "prompt";
    ATTRS2["NAME"] = "name";
    ATTRS2["COLOR"] = "color";
    ATTRS2["FACE"] = "face";
    ATTRS2["SIZE"] = "size";
  })(ATTRS || (ATTRS = {}));
  var DOCUMENT_MODE;
  (function(DOCUMENT_MODE2) {
    DOCUMENT_MODE2["NO_QUIRKS"] = "no-quirks";
    DOCUMENT_MODE2["QUIRKS"] = "quirks";
    DOCUMENT_MODE2["LIMITED_QUIRKS"] = "limited-quirks";
  })(DOCUMENT_MODE || (DOCUMENT_MODE = {}));
  var TAG_NAMES;
  (function(TAG_NAMES2) {
    TAG_NAMES2["A"] = "a";
    TAG_NAMES2["ADDRESS"] = "address";
    TAG_NAMES2["ANNOTATION_XML"] = "annotation-xml";
    TAG_NAMES2["APPLET"] = "applet";
    TAG_NAMES2["AREA"] = "area";
    TAG_NAMES2["ARTICLE"] = "article";
    TAG_NAMES2["ASIDE"] = "aside";
    TAG_NAMES2["B"] = "b";
    TAG_NAMES2["BASE"] = "base";
    TAG_NAMES2["BASEFONT"] = "basefont";
    TAG_NAMES2["BGSOUND"] = "bgsound";
    TAG_NAMES2["BIG"] = "big";
    TAG_NAMES2["BLOCKQUOTE"] = "blockquote";
    TAG_NAMES2["BODY"] = "body";
    TAG_NAMES2["BR"] = "br";
    TAG_NAMES2["BUTTON"] = "button";
    TAG_NAMES2["CAPTION"] = "caption";
    TAG_NAMES2["CENTER"] = "center";
    TAG_NAMES2["CODE"] = "code";
    TAG_NAMES2["COL"] = "col";
    TAG_NAMES2["COLGROUP"] = "colgroup";
    TAG_NAMES2["DD"] = "dd";
    TAG_NAMES2["DESC"] = "desc";
    TAG_NAMES2["DETAILS"] = "details";
    TAG_NAMES2["DIALOG"] = "dialog";
    TAG_NAMES2["DIR"] = "dir";
    TAG_NAMES2["DIV"] = "div";
    TAG_NAMES2["DL"] = "dl";
    TAG_NAMES2["DT"] = "dt";
    TAG_NAMES2["EM"] = "em";
    TAG_NAMES2["EMBED"] = "embed";
    TAG_NAMES2["FIELDSET"] = "fieldset";
    TAG_NAMES2["FIGCAPTION"] = "figcaption";
    TAG_NAMES2["FIGURE"] = "figure";
    TAG_NAMES2["FONT"] = "font";
    TAG_NAMES2["FOOTER"] = "footer";
    TAG_NAMES2["FOREIGN_OBJECT"] = "foreignObject";
    TAG_NAMES2["FORM"] = "form";
    TAG_NAMES2["FRAME"] = "frame";
    TAG_NAMES2["FRAMESET"] = "frameset";
    TAG_NAMES2["H1"] = "h1";
    TAG_NAMES2["H2"] = "h2";
    TAG_NAMES2["H3"] = "h3";
    TAG_NAMES2["H4"] = "h4";
    TAG_NAMES2["H5"] = "h5";
    TAG_NAMES2["H6"] = "h6";
    TAG_NAMES2["HEAD"] = "head";
    TAG_NAMES2["HEADER"] = "header";
    TAG_NAMES2["HGROUP"] = "hgroup";
    TAG_NAMES2["HR"] = "hr";
    TAG_NAMES2["HTML"] = "html";
    TAG_NAMES2["I"] = "i";
    TAG_NAMES2["IMG"] = "img";
    TAG_NAMES2["IMAGE"] = "image";
    TAG_NAMES2["INPUT"] = "input";
    TAG_NAMES2["IFRAME"] = "iframe";
    TAG_NAMES2["KEYGEN"] = "keygen";
    TAG_NAMES2["LABEL"] = "label";
    TAG_NAMES2["LI"] = "li";
    TAG_NAMES2["LINK"] = "link";
    TAG_NAMES2["LISTING"] = "listing";
    TAG_NAMES2["MAIN"] = "main";
    TAG_NAMES2["MALIGNMARK"] = "malignmark";
    TAG_NAMES2["MARQUEE"] = "marquee";
    TAG_NAMES2["MATH"] = "math";
    TAG_NAMES2["MENU"] = "menu";
    TAG_NAMES2["META"] = "meta";
    TAG_NAMES2["MGLYPH"] = "mglyph";
    TAG_NAMES2["MI"] = "mi";
    TAG_NAMES2["MO"] = "mo";
    TAG_NAMES2["MN"] = "mn";
    TAG_NAMES2["MS"] = "ms";
    TAG_NAMES2["MTEXT"] = "mtext";
    TAG_NAMES2["NAV"] = "nav";
    TAG_NAMES2["NOBR"] = "nobr";
    TAG_NAMES2["NOFRAMES"] = "noframes";
    TAG_NAMES2["NOEMBED"] = "noembed";
    TAG_NAMES2["NOSCRIPT"] = "noscript";
    TAG_NAMES2["OBJECT"] = "object";
    TAG_NAMES2["OL"] = "ol";
    TAG_NAMES2["OPTGROUP"] = "optgroup";
    TAG_NAMES2["OPTION"] = "option";
    TAG_NAMES2["P"] = "p";
    TAG_NAMES2["PARAM"] = "param";
    TAG_NAMES2["PLAINTEXT"] = "plaintext";
    TAG_NAMES2["PRE"] = "pre";
    TAG_NAMES2["RB"] = "rb";
    TAG_NAMES2["RP"] = "rp";
    TAG_NAMES2["RT"] = "rt";
    TAG_NAMES2["RTC"] = "rtc";
    TAG_NAMES2["RUBY"] = "ruby";
    TAG_NAMES2["S"] = "s";
    TAG_NAMES2["SCRIPT"] = "script";
    TAG_NAMES2["SEARCH"] = "search";
    TAG_NAMES2["SECTION"] = "section";
    TAG_NAMES2["SELECT"] = "select";
    TAG_NAMES2["SOURCE"] = "source";
    TAG_NAMES2["SMALL"] = "small";
    TAG_NAMES2["SPAN"] = "span";
    TAG_NAMES2["STRIKE"] = "strike";
    TAG_NAMES2["STRONG"] = "strong";
    TAG_NAMES2["STYLE"] = "style";
    TAG_NAMES2["SUB"] = "sub";
    TAG_NAMES2["SUMMARY"] = "summary";
    TAG_NAMES2["SUP"] = "sup";
    TAG_NAMES2["TABLE"] = "table";
    TAG_NAMES2["TBODY"] = "tbody";
    TAG_NAMES2["TEMPLATE"] = "template";
    TAG_NAMES2["TEXTAREA"] = "textarea";
    TAG_NAMES2["TFOOT"] = "tfoot";
    TAG_NAMES2["TD"] = "td";
    TAG_NAMES2["TH"] = "th";
    TAG_NAMES2["THEAD"] = "thead";
    TAG_NAMES2["TITLE"] = "title";
    TAG_NAMES2["TR"] = "tr";
    TAG_NAMES2["TRACK"] = "track";
    TAG_NAMES2["TT"] = "tt";
    TAG_NAMES2["U"] = "u";
    TAG_NAMES2["UL"] = "ul";
    TAG_NAMES2["SVG"] = "svg";
    TAG_NAMES2["VAR"] = "var";
    TAG_NAMES2["WBR"] = "wbr";
    TAG_NAMES2["XMP"] = "xmp";
  })(TAG_NAMES || (TAG_NAMES = {}));
  var TAG_ID;
  (function(TAG_ID2) {
    TAG_ID2[TAG_ID2["UNKNOWN"] = 0] = "UNKNOWN";
    TAG_ID2[TAG_ID2["A"] = 1] = "A";
    TAG_ID2[TAG_ID2["ADDRESS"] = 2] = "ADDRESS";
    TAG_ID2[TAG_ID2["ANNOTATION_XML"] = 3] = "ANNOTATION_XML";
    TAG_ID2[TAG_ID2["APPLET"] = 4] = "APPLET";
    TAG_ID2[TAG_ID2["AREA"] = 5] = "AREA";
    TAG_ID2[TAG_ID2["ARTICLE"] = 6] = "ARTICLE";
    TAG_ID2[TAG_ID2["ASIDE"] = 7] = "ASIDE";
    TAG_ID2[TAG_ID2["B"] = 8] = "B";
    TAG_ID2[TAG_ID2["BASE"] = 9] = "BASE";
    TAG_ID2[TAG_ID2["BASEFONT"] = 10] = "BASEFONT";
    TAG_ID2[TAG_ID2["BGSOUND"] = 11] = "BGSOUND";
    TAG_ID2[TAG_ID2["BIG"] = 12] = "BIG";
    TAG_ID2[TAG_ID2["BLOCKQUOTE"] = 13] = "BLOCKQUOTE";
    TAG_ID2[TAG_ID2["BODY"] = 14] = "BODY";
    TAG_ID2[TAG_ID2["BR"] = 15] = "BR";
    TAG_ID2[TAG_ID2["BUTTON"] = 16] = "BUTTON";
    TAG_ID2[TAG_ID2["CAPTION"] = 17] = "CAPTION";
    TAG_ID2[TAG_ID2["CENTER"] = 18] = "CENTER";
    TAG_ID2[TAG_ID2["CODE"] = 19] = "CODE";
    TAG_ID2[TAG_ID2["COL"] = 20] = "COL";
    TAG_ID2[TAG_ID2["COLGROUP"] = 21] = "COLGROUP";
    TAG_ID2[TAG_ID2["DD"] = 22] = "DD";
    TAG_ID2[TAG_ID2["DESC"] = 23] = "DESC";
    TAG_ID2[TAG_ID2["DETAILS"] = 24] = "DETAILS";
    TAG_ID2[TAG_ID2["DIALOG"] = 25] = "DIALOG";
    TAG_ID2[TAG_ID2["DIR"] = 26] = "DIR";
    TAG_ID2[TAG_ID2["DIV"] = 27] = "DIV";
    TAG_ID2[TAG_ID2["DL"] = 28] = "DL";
    TAG_ID2[TAG_ID2["DT"] = 29] = "DT";
    TAG_ID2[TAG_ID2["EM"] = 30] = "EM";
    TAG_ID2[TAG_ID2["EMBED"] = 31] = "EMBED";
    TAG_ID2[TAG_ID2["FIELDSET"] = 32] = "FIELDSET";
    TAG_ID2[TAG_ID2["FIGCAPTION"] = 33] = "FIGCAPTION";
    TAG_ID2[TAG_ID2["FIGURE"] = 34] = "FIGURE";
    TAG_ID2[TAG_ID2["FONT"] = 35] = "FONT";
    TAG_ID2[TAG_ID2["FOOTER"] = 36] = "FOOTER";
    TAG_ID2[TAG_ID2["FOREIGN_OBJECT"] = 37] = "FOREIGN_OBJECT";
    TAG_ID2[TAG_ID2["FORM"] = 38] = "FORM";
    TAG_ID2[TAG_ID2["FRAME"] = 39] = "FRAME";
    TAG_ID2[TAG_ID2["FRAMESET"] = 40] = "FRAMESET";
    TAG_ID2[TAG_ID2["H1"] = 41] = "H1";
    TAG_ID2[TAG_ID2["H2"] = 42] = "H2";
    TAG_ID2[TAG_ID2["H3"] = 43] = "H3";
    TAG_ID2[TAG_ID2["H4"] = 44] = "H4";
    TAG_ID2[TAG_ID2["H5"] = 45] = "H5";
    TAG_ID2[TAG_ID2["H6"] = 46] = "H6";
    TAG_ID2[TAG_ID2["HEAD"] = 47] = "HEAD";
    TAG_ID2[TAG_ID2["HEADER"] = 48] = "HEADER";
    TAG_ID2[TAG_ID2["HGROUP"] = 49] = "HGROUP";
    TAG_ID2[TAG_ID2["HR"] = 50] = "HR";
    TAG_ID2[TAG_ID2["HTML"] = 51] = "HTML";
    TAG_ID2[TAG_ID2["I"] = 52] = "I";
    TAG_ID2[TAG_ID2["IMG"] = 53] = "IMG";
    TAG_ID2[TAG_ID2["IMAGE"] = 54] = "IMAGE";
    TAG_ID2[TAG_ID2["INPUT"] = 55] = "INPUT";
    TAG_ID2[TAG_ID2["IFRAME"] = 56] = "IFRAME";
    TAG_ID2[TAG_ID2["KEYGEN"] = 57] = "KEYGEN";
    TAG_ID2[TAG_ID2["LABEL"] = 58] = "LABEL";
    TAG_ID2[TAG_ID2["LI"] = 59] = "LI";
    TAG_ID2[TAG_ID2["LINK"] = 60] = "LINK";
    TAG_ID2[TAG_ID2["LISTING"] = 61] = "LISTING";
    TAG_ID2[TAG_ID2["MAIN"] = 62] = "MAIN";
    TAG_ID2[TAG_ID2["MALIGNMARK"] = 63] = "MALIGNMARK";
    TAG_ID2[TAG_ID2["MARQUEE"] = 64] = "MARQUEE";
    TAG_ID2[TAG_ID2["MATH"] = 65] = "MATH";
    TAG_ID2[TAG_ID2["MENU"] = 66] = "MENU";
    TAG_ID2[TAG_ID2["META"] = 67] = "META";
    TAG_ID2[TAG_ID2["MGLYPH"] = 68] = "MGLYPH";
    TAG_ID2[TAG_ID2["MI"] = 69] = "MI";
    TAG_ID2[TAG_ID2["MO"] = 70] = "MO";
    TAG_ID2[TAG_ID2["MN"] = 71] = "MN";
    TAG_ID2[TAG_ID2["MS"] = 72] = "MS";
    TAG_ID2[TAG_ID2["MTEXT"] = 73] = "MTEXT";
    TAG_ID2[TAG_ID2["NAV"] = 74] = "NAV";
    TAG_ID2[TAG_ID2["NOBR"] = 75] = "NOBR";
    TAG_ID2[TAG_ID2["NOFRAMES"] = 76] = "NOFRAMES";
    TAG_ID2[TAG_ID2["NOEMBED"] = 77] = "NOEMBED";
    TAG_ID2[TAG_ID2["NOSCRIPT"] = 78] = "NOSCRIPT";
    TAG_ID2[TAG_ID2["OBJECT"] = 79] = "OBJECT";
    TAG_ID2[TAG_ID2["OL"] = 80] = "OL";
    TAG_ID2[TAG_ID2["OPTGROUP"] = 81] = "OPTGROUP";
    TAG_ID2[TAG_ID2["OPTION"] = 82] = "OPTION";
    TAG_ID2[TAG_ID2["P"] = 83] = "P";
    TAG_ID2[TAG_ID2["PARAM"] = 84] = "PARAM";
    TAG_ID2[TAG_ID2["PLAINTEXT"] = 85] = "PLAINTEXT";
    TAG_ID2[TAG_ID2["PRE"] = 86] = "PRE";
    TAG_ID2[TAG_ID2["RB"] = 87] = "RB";
    TAG_ID2[TAG_ID2["RP"] = 88] = "RP";
    TAG_ID2[TAG_ID2["RT"] = 89] = "RT";
    TAG_ID2[TAG_ID2["RTC"] = 90] = "RTC";
    TAG_ID2[TAG_ID2["RUBY"] = 91] = "RUBY";
    TAG_ID2[TAG_ID2["S"] = 92] = "S";
    TAG_ID2[TAG_ID2["SCRIPT"] = 93] = "SCRIPT";
    TAG_ID2[TAG_ID2["SEARCH"] = 94] = "SEARCH";
    TAG_ID2[TAG_ID2["SECTION"] = 95] = "SECTION";
    TAG_ID2[TAG_ID2["SELECT"] = 96] = "SELECT";
    TAG_ID2[TAG_ID2["SOURCE"] = 97] = "SOURCE";
    TAG_ID2[TAG_ID2["SMALL"] = 98] = "SMALL";
    TAG_ID2[TAG_ID2["SPAN"] = 99] = "SPAN";
    TAG_ID2[TAG_ID2["STRIKE"] = 100] = "STRIKE";
    TAG_ID2[TAG_ID2["STRONG"] = 101] = "STRONG";
    TAG_ID2[TAG_ID2["STYLE"] = 102] = "STYLE";
    TAG_ID2[TAG_ID2["SUB"] = 103] = "SUB";
    TAG_ID2[TAG_ID2["SUMMARY"] = 104] = "SUMMARY";
    TAG_ID2[TAG_ID2["SUP"] = 105] = "SUP";
    TAG_ID2[TAG_ID2["TABLE"] = 106] = "TABLE";
    TAG_ID2[TAG_ID2["TBODY"] = 107] = "TBODY";
    TAG_ID2[TAG_ID2["TEMPLATE"] = 108] = "TEMPLATE";
    TAG_ID2[TAG_ID2["TEXTAREA"] = 109] = "TEXTAREA";
    TAG_ID2[TAG_ID2["TFOOT"] = 110] = "TFOOT";
    TAG_ID2[TAG_ID2["TD"] = 111] = "TD";
    TAG_ID2[TAG_ID2["TH"] = 112] = "TH";
    TAG_ID2[TAG_ID2["THEAD"] = 113] = "THEAD";
    TAG_ID2[TAG_ID2["TITLE"] = 114] = "TITLE";
    TAG_ID2[TAG_ID2["TR"] = 115] = "TR";
    TAG_ID2[TAG_ID2["TRACK"] = 116] = "TRACK";
    TAG_ID2[TAG_ID2["TT"] = 117] = "TT";
    TAG_ID2[TAG_ID2["U"] = 118] = "U";
    TAG_ID2[TAG_ID2["UL"] = 119] = "UL";
    TAG_ID2[TAG_ID2["SVG"] = 120] = "SVG";
    TAG_ID2[TAG_ID2["VAR"] = 121] = "VAR";
    TAG_ID2[TAG_ID2["WBR"] = 122] = "WBR";
    TAG_ID2[TAG_ID2["XMP"] = 123] = "XMP";
  })(TAG_ID || (TAG_ID = {}));
  const TAG_NAME_TO_ID = /* @__PURE__ */ new Map([
    [TAG_NAMES.A, TAG_ID.A],
    [TAG_NAMES.ADDRESS, TAG_ID.ADDRESS],
    [TAG_NAMES.ANNOTATION_XML, TAG_ID.ANNOTATION_XML],
    [TAG_NAMES.APPLET, TAG_ID.APPLET],
    [TAG_NAMES.AREA, TAG_ID.AREA],
    [TAG_NAMES.ARTICLE, TAG_ID.ARTICLE],
    [TAG_NAMES.ASIDE, TAG_ID.ASIDE],
    [TAG_NAMES.B, TAG_ID.B],
    [TAG_NAMES.BASE, TAG_ID.BASE],
    [TAG_NAMES.BASEFONT, TAG_ID.BASEFONT],
    [TAG_NAMES.BGSOUND, TAG_ID.BGSOUND],
    [TAG_NAMES.BIG, TAG_ID.BIG],
    [TAG_NAMES.BLOCKQUOTE, TAG_ID.BLOCKQUOTE],
    [TAG_NAMES.BODY, TAG_ID.BODY],
    [TAG_NAMES.BR, TAG_ID.BR],
    [TAG_NAMES.BUTTON, TAG_ID.BUTTON],
    [TAG_NAMES.CAPTION, TAG_ID.CAPTION],
    [TAG_NAMES.CENTER, TAG_ID.CENTER],
    [TAG_NAMES.CODE, TAG_ID.CODE],
    [TAG_NAMES.COL, TAG_ID.COL],
    [TAG_NAMES.COLGROUP, TAG_ID.COLGROUP],
    [TAG_NAMES.DD, TAG_ID.DD],
    [TAG_NAMES.DESC, TAG_ID.DESC],
    [TAG_NAMES.DETAILS, TAG_ID.DETAILS],
    [TAG_NAMES.DIALOG, TAG_ID.DIALOG],
    [TAG_NAMES.DIR, TAG_ID.DIR],
    [TAG_NAMES.DIV, TAG_ID.DIV],
    [TAG_NAMES.DL, TAG_ID.DL],
    [TAG_NAMES.DT, TAG_ID.DT],
    [TAG_NAMES.EM, TAG_ID.EM],
    [TAG_NAMES.EMBED, TAG_ID.EMBED],
    [TAG_NAMES.FIELDSET, TAG_ID.FIELDSET],
    [TAG_NAMES.FIGCAPTION, TAG_ID.FIGCAPTION],
    [TAG_NAMES.FIGURE, TAG_ID.FIGURE],
    [TAG_NAMES.FONT, TAG_ID.FONT],
    [TAG_NAMES.FOOTER, TAG_ID.FOOTER],
    [TAG_NAMES.FOREIGN_OBJECT, TAG_ID.FOREIGN_OBJECT],
    [TAG_NAMES.FORM, TAG_ID.FORM],
    [TAG_NAMES.FRAME, TAG_ID.FRAME],
    [TAG_NAMES.FRAMESET, TAG_ID.FRAMESET],
    [TAG_NAMES.H1, TAG_ID.H1],
    [TAG_NAMES.H2, TAG_ID.H2],
    [TAG_NAMES.H3, TAG_ID.H3],
    [TAG_NAMES.H4, TAG_ID.H4],
    [TAG_NAMES.H5, TAG_ID.H5],
    [TAG_NAMES.H6, TAG_ID.H6],
    [TAG_NAMES.HEAD, TAG_ID.HEAD],
    [TAG_NAMES.HEADER, TAG_ID.HEADER],
    [TAG_NAMES.HGROUP, TAG_ID.HGROUP],
    [TAG_NAMES.HR, TAG_ID.HR],
    [TAG_NAMES.HTML, TAG_ID.HTML],
    [TAG_NAMES.I, TAG_ID.I],
    [TAG_NAMES.IMG, TAG_ID.IMG],
    [TAG_NAMES.IMAGE, TAG_ID.IMAGE],
    [TAG_NAMES.INPUT, TAG_ID.INPUT],
    [TAG_NAMES.IFRAME, TAG_ID.IFRAME],
    [TAG_NAMES.KEYGEN, TAG_ID.KEYGEN],
    [TAG_NAMES.LABEL, TAG_ID.LABEL],
    [TAG_NAMES.LI, TAG_ID.LI],
    [TAG_NAMES.LINK, TAG_ID.LINK],
    [TAG_NAMES.LISTING, TAG_ID.LISTING],
    [TAG_NAMES.MAIN, TAG_ID.MAIN],
    [TAG_NAMES.MALIGNMARK, TAG_ID.MALIGNMARK],
    [TAG_NAMES.MARQUEE, TAG_ID.MARQUEE],
    [TAG_NAMES.MATH, TAG_ID.MATH],
    [TAG_NAMES.MENU, TAG_ID.MENU],
    [TAG_NAMES.META, TAG_ID.META],
    [TAG_NAMES.MGLYPH, TAG_ID.MGLYPH],
    [TAG_NAMES.MI, TAG_ID.MI],
    [TAG_NAMES.MO, TAG_ID.MO],
    [TAG_NAMES.MN, TAG_ID.MN],
    [TAG_NAMES.MS, TAG_ID.MS],
    [TAG_NAMES.MTEXT, TAG_ID.MTEXT],
    [TAG_NAMES.NAV, TAG_ID.NAV],
    [TAG_NAMES.NOBR, TAG_ID.NOBR],
    [TAG_NAMES.NOFRAMES, TAG_ID.NOFRAMES],
    [TAG_NAMES.NOEMBED, TAG_ID.NOEMBED],
    [TAG_NAMES.NOSCRIPT, TAG_ID.NOSCRIPT],
    [TAG_NAMES.OBJECT, TAG_ID.OBJECT],
    [TAG_NAMES.OL, TAG_ID.OL],
    [TAG_NAMES.OPTGROUP, TAG_ID.OPTGROUP],
    [TAG_NAMES.OPTION, TAG_ID.OPTION],
    [TAG_NAMES.P, TAG_ID.P],
    [TAG_NAMES.PARAM, TAG_ID.PARAM],
    [TAG_NAMES.PLAINTEXT, TAG_ID.PLAINTEXT],
    [TAG_NAMES.PRE, TAG_ID.PRE],
    [TAG_NAMES.RB, TAG_ID.RB],
    [TAG_NAMES.RP, TAG_ID.RP],
    [TAG_NAMES.RT, TAG_ID.RT],
    [TAG_NAMES.RTC, TAG_ID.RTC],
    [TAG_NAMES.RUBY, TAG_ID.RUBY],
    [TAG_NAMES.S, TAG_ID.S],
    [TAG_NAMES.SCRIPT, TAG_ID.SCRIPT],
    [TAG_NAMES.SEARCH, TAG_ID.SEARCH],
    [TAG_NAMES.SECTION, TAG_ID.SECTION],
    [TAG_NAMES.SELECT, TAG_ID.SELECT],
    [TAG_NAMES.SOURCE, TAG_ID.SOURCE],
    [TAG_NAMES.SMALL, TAG_ID.SMALL],
    [TAG_NAMES.SPAN, TAG_ID.SPAN],
    [TAG_NAMES.STRIKE, TAG_ID.STRIKE],
    [TAG_NAMES.STRONG, TAG_ID.STRONG],
    [TAG_NAMES.STYLE, TAG_ID.STYLE],
    [TAG_NAMES.SUB, TAG_ID.SUB],
    [TAG_NAMES.SUMMARY, TAG_ID.SUMMARY],
    [TAG_NAMES.SUP, TAG_ID.SUP],
    [TAG_NAMES.TABLE, TAG_ID.TABLE],
    [TAG_NAMES.TBODY, TAG_ID.TBODY],
    [TAG_NAMES.TEMPLATE, TAG_ID.TEMPLATE],
    [TAG_NAMES.TEXTAREA, TAG_ID.TEXTAREA],
    [TAG_NAMES.TFOOT, TAG_ID.TFOOT],
    [TAG_NAMES.TD, TAG_ID.TD],
    [TAG_NAMES.TH, TAG_ID.TH],
    [TAG_NAMES.THEAD, TAG_ID.THEAD],
    [TAG_NAMES.TITLE, TAG_ID.TITLE],
    [TAG_NAMES.TR, TAG_ID.TR],
    [TAG_NAMES.TRACK, TAG_ID.TRACK],
    [TAG_NAMES.TT, TAG_ID.TT],
    [TAG_NAMES.U, TAG_ID.U],
    [TAG_NAMES.UL, TAG_ID.UL],
    [TAG_NAMES.SVG, TAG_ID.SVG],
    [TAG_NAMES.VAR, TAG_ID.VAR],
    [TAG_NAMES.WBR, TAG_ID.WBR],
    [TAG_NAMES.XMP, TAG_ID.XMP]
  ]);
  function getTagID(tagName) {
    var _a2;
    return (_a2 = TAG_NAME_TO_ID.get(tagName)) !== null && _a2 !== void 0 ? _a2 : TAG_ID.UNKNOWN;
  }
  const $ = TAG_ID;
  const SPECIAL_ELEMENTS = {
    [NS.HTML]: /* @__PURE__ */ new Set([
      $.ADDRESS,
      $.APPLET,
      $.AREA,
      $.ARTICLE,
      $.ASIDE,
      $.BASE,
      $.BASEFONT,
      $.BGSOUND,
      $.BLOCKQUOTE,
      $.BODY,
      $.BR,
      $.BUTTON,
      $.CAPTION,
      $.CENTER,
      $.COL,
      $.COLGROUP,
      $.DD,
      $.DETAILS,
      $.DIR,
      $.DIV,
      $.DL,
      $.DT,
      $.EMBED,
      $.FIELDSET,
      $.FIGCAPTION,
      $.FIGURE,
      $.FOOTER,
      $.FORM,
      $.FRAME,
      $.FRAMESET,
      $.H1,
      $.H2,
      $.H3,
      $.H4,
      $.H5,
      $.H6,
      $.HEAD,
      $.HEADER,
      $.HGROUP,
      $.HR,
      $.HTML,
      $.IFRAME,
      $.IMG,
      $.INPUT,
      $.LI,
      $.LINK,
      $.LISTING,
      $.MAIN,
      $.MARQUEE,
      $.MENU,
      $.META,
      $.NAV,
      $.NOEMBED,
      $.NOFRAMES,
      $.NOSCRIPT,
      $.OBJECT,
      $.OL,
      $.P,
      $.PARAM,
      $.PLAINTEXT,
      $.PRE,
      $.SCRIPT,
      $.SECTION,
      $.SELECT,
      $.SOURCE,
      $.STYLE,
      $.SUMMARY,
      $.TABLE,
      $.TBODY,
      $.TD,
      $.TEMPLATE,
      $.TEXTAREA,
      $.TFOOT,
      $.TH,
      $.THEAD,
      $.TITLE,
      $.TR,
      $.TRACK,
      $.UL,
      $.WBR,
      $.XMP
    ]),
    [NS.MATHML]: /* @__PURE__ */ new Set([$.MI, $.MO, $.MN, $.MS, $.MTEXT, $.ANNOTATION_XML]),
    [NS.SVG]: /* @__PURE__ */ new Set([$.TITLE, $.FOREIGN_OBJECT, $.DESC]),
    [NS.XLINK]: /* @__PURE__ */ new Set(),
    [NS.XML]: /* @__PURE__ */ new Set(),
    [NS.XMLNS]: /* @__PURE__ */ new Set()
  };
  const NUMBERED_HEADERS = /* @__PURE__ */ new Set([$.H1, $.H2, $.H3, $.H4, $.H5, $.H6]);
  /* @__PURE__ */ new Set([
    TAG_NAMES.STYLE,
    TAG_NAMES.SCRIPT,
    TAG_NAMES.XMP,
    TAG_NAMES.IFRAME,
    TAG_NAMES.NOEMBED,
    TAG_NAMES.NOFRAMES,
    TAG_NAMES.PLAINTEXT
  ]);
  var State;
  (function(State2) {
    State2[State2["DATA"] = 0] = "DATA";
    State2[State2["RCDATA"] = 1] = "RCDATA";
    State2[State2["RAWTEXT"] = 2] = "RAWTEXT";
    State2[State2["SCRIPT_DATA"] = 3] = "SCRIPT_DATA";
    State2[State2["PLAINTEXT"] = 4] = "PLAINTEXT";
    State2[State2["TAG_OPEN"] = 5] = "TAG_OPEN";
    State2[State2["END_TAG_OPEN"] = 6] = "END_TAG_OPEN";
    State2[State2["TAG_NAME"] = 7] = "TAG_NAME";
    State2[State2["RCDATA_LESS_THAN_SIGN"] = 8] = "RCDATA_LESS_THAN_SIGN";
    State2[State2["RCDATA_END_TAG_OPEN"] = 9] = "RCDATA_END_TAG_OPEN";
    State2[State2["RCDATA_END_TAG_NAME"] = 10] = "RCDATA_END_TAG_NAME";
    State2[State2["RAWTEXT_LESS_THAN_SIGN"] = 11] = "RAWTEXT_LESS_THAN_SIGN";
    State2[State2["RAWTEXT_END_TAG_OPEN"] = 12] = "RAWTEXT_END_TAG_OPEN";
    State2[State2["RAWTEXT_END_TAG_NAME"] = 13] = "RAWTEXT_END_TAG_NAME";
    State2[State2["SCRIPT_DATA_LESS_THAN_SIGN"] = 14] = "SCRIPT_DATA_LESS_THAN_SIGN";
    State2[State2["SCRIPT_DATA_END_TAG_OPEN"] = 15] = "SCRIPT_DATA_END_TAG_OPEN";
    State2[State2["SCRIPT_DATA_END_TAG_NAME"] = 16] = "SCRIPT_DATA_END_TAG_NAME";
    State2[State2["SCRIPT_DATA_ESCAPE_START"] = 17] = "SCRIPT_DATA_ESCAPE_START";
    State2[State2["SCRIPT_DATA_ESCAPE_START_DASH"] = 18] = "SCRIPT_DATA_ESCAPE_START_DASH";
    State2[State2["SCRIPT_DATA_ESCAPED"] = 19] = "SCRIPT_DATA_ESCAPED";
    State2[State2["SCRIPT_DATA_ESCAPED_DASH"] = 20] = "SCRIPT_DATA_ESCAPED_DASH";
    State2[State2["SCRIPT_DATA_ESCAPED_DASH_DASH"] = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH";
    State2[State2["SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN"] = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN";
    State2[State2["SCRIPT_DATA_ESCAPED_END_TAG_OPEN"] = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN";
    State2[State2["SCRIPT_DATA_ESCAPED_END_TAG_NAME"] = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPE_START"] = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPED"] = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPED_DASH"] = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH"] = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN"] = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN";
    State2[State2["SCRIPT_DATA_DOUBLE_ESCAPE_END"] = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END";
    State2[State2["BEFORE_ATTRIBUTE_NAME"] = 31] = "BEFORE_ATTRIBUTE_NAME";
    State2[State2["ATTRIBUTE_NAME"] = 32] = "ATTRIBUTE_NAME";
    State2[State2["AFTER_ATTRIBUTE_NAME"] = 33] = "AFTER_ATTRIBUTE_NAME";
    State2[State2["BEFORE_ATTRIBUTE_VALUE"] = 34] = "BEFORE_ATTRIBUTE_VALUE";
    State2[State2["ATTRIBUTE_VALUE_DOUBLE_QUOTED"] = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED";
    State2[State2["ATTRIBUTE_VALUE_SINGLE_QUOTED"] = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED";
    State2[State2["ATTRIBUTE_VALUE_UNQUOTED"] = 37] = "ATTRIBUTE_VALUE_UNQUOTED";
    State2[State2["AFTER_ATTRIBUTE_VALUE_QUOTED"] = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED";
    State2[State2["SELF_CLOSING_START_TAG"] = 39] = "SELF_CLOSING_START_TAG";
    State2[State2["BOGUS_COMMENT"] = 40] = "BOGUS_COMMENT";
    State2[State2["MARKUP_DECLARATION_OPEN"] = 41] = "MARKUP_DECLARATION_OPEN";
    State2[State2["COMMENT_START"] = 42] = "COMMENT_START";
    State2[State2["COMMENT_START_DASH"] = 43] = "COMMENT_START_DASH";
    State2[State2["COMMENT"] = 44] = "COMMENT";
    State2[State2["COMMENT_LESS_THAN_SIGN"] = 45] = "COMMENT_LESS_THAN_SIGN";
    State2[State2["COMMENT_LESS_THAN_SIGN_BANG"] = 46] = "COMMENT_LESS_THAN_SIGN_BANG";
    State2[State2["COMMENT_LESS_THAN_SIGN_BANG_DASH"] = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH";
    State2[State2["COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH"] = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH";
    State2[State2["COMMENT_END_DASH"] = 49] = "COMMENT_END_DASH";
    State2[State2["COMMENT_END"] = 50] = "COMMENT_END";
    State2[State2["COMMENT_END_BANG"] = 51] = "COMMENT_END_BANG";
    State2[State2["DOCTYPE"] = 52] = "DOCTYPE";
    State2[State2["BEFORE_DOCTYPE_NAME"] = 53] = "BEFORE_DOCTYPE_NAME";
    State2[State2["DOCTYPE_NAME"] = 54] = "DOCTYPE_NAME";
    State2[State2["AFTER_DOCTYPE_NAME"] = 55] = "AFTER_DOCTYPE_NAME";
    State2[State2["AFTER_DOCTYPE_PUBLIC_KEYWORD"] = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD";
    State2[State2["BEFORE_DOCTYPE_PUBLIC_IDENTIFIER"] = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER";
    State2[State2["DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED"] = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED";
    State2[State2["DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED"] = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED";
    State2[State2["AFTER_DOCTYPE_PUBLIC_IDENTIFIER"] = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER";
    State2[State2["BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS"] = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS";
    State2[State2["AFTER_DOCTYPE_SYSTEM_KEYWORD"] = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD";
    State2[State2["BEFORE_DOCTYPE_SYSTEM_IDENTIFIER"] = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER";
    State2[State2["DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED"] = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED";
    State2[State2["DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED"] = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED";
    State2[State2["AFTER_DOCTYPE_SYSTEM_IDENTIFIER"] = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER";
    State2[State2["BOGUS_DOCTYPE"] = 67] = "BOGUS_DOCTYPE";
    State2[State2["CDATA_SECTION"] = 68] = "CDATA_SECTION";
    State2[State2["CDATA_SECTION_BRACKET"] = 69] = "CDATA_SECTION_BRACKET";
    State2[State2["CDATA_SECTION_END"] = 70] = "CDATA_SECTION_END";
    State2[State2["CHARACTER_REFERENCE"] = 71] = "CHARACTER_REFERENCE";
    State2[State2["AMBIGUOUS_AMPERSAND"] = 72] = "AMBIGUOUS_AMPERSAND";
  })(State || (State = {}));
  const TokenizerMode = {
    DATA: State.DATA,
    RCDATA: State.RCDATA,
    RAWTEXT: State.RAWTEXT,
    SCRIPT_DATA: State.SCRIPT_DATA,
    PLAINTEXT: State.PLAINTEXT,
    CDATA_SECTION: State.CDATA_SECTION
  };
  function isAsciiDigit(cp) {
    return cp >= CODE_POINTS.DIGIT_0 && cp <= CODE_POINTS.DIGIT_9;
  }
  function isAsciiUpper(cp) {
    return cp >= CODE_POINTS.LATIN_CAPITAL_A && cp <= CODE_POINTS.LATIN_CAPITAL_Z;
  }
  function isAsciiLower(cp) {
    return cp >= CODE_POINTS.LATIN_SMALL_A && cp <= CODE_POINTS.LATIN_SMALL_Z;
  }
  function isAsciiLetter(cp) {
    return isAsciiLower(cp) || isAsciiUpper(cp);
  }
  function isAsciiAlphaNumeric(cp) {
    return isAsciiLetter(cp) || isAsciiDigit(cp);
  }
  function toAsciiLower(cp) {
    return cp + 32;
  }
  function isWhitespace(cp) {
    return cp === CODE_POINTS.SPACE || cp === CODE_POINTS.LINE_FEED || cp === CODE_POINTS.TABULATION || cp === CODE_POINTS.FORM_FEED;
  }
  function isScriptDataDoubleEscapeSequenceEnd(cp) {
    return isWhitespace(cp) || cp === CODE_POINTS.SOLIDUS || cp === CODE_POINTS.GREATER_THAN_SIGN;
  }
  function getErrorForNumericCharacterReference(code) {
    if (code === CODE_POINTS.NULL) {
      return ERR.nullCharacterReference;
    } else if (code > 1114111) {
      return ERR.characterReferenceOutsideUnicodeRange;
    } else if (isSurrogate(code)) {
      return ERR.surrogateCharacterReference;
    } else if (isUndefinedCodePoint(code)) {
      return ERR.noncharacterCharacterReference;
    } else if (isControlCodePoint(code) || code === CODE_POINTS.CARRIAGE_RETURN) {
      return ERR.controlCharacterReference;
    }
    return null;
  }
  class Tokenizer {
    constructor(options, handler) {
      this.options = options;
      this.handler = handler;
      this.paused = false;
      this.inLoop = false;
      this.inForeignNode = false;
      this.lastStartTagName = "";
      this.active = false;
      this.state = State.DATA;
      this.returnState = State.DATA;
      this.entityStartPos = 0;
      this.consumedAfterSnapshot = -1;
      this.currentCharacterToken = null;
      this.currentToken = null;
      this.currentAttr = { name: "", value: "" };
      this.preprocessor = new Preprocessor(handler);
      this.currentLocation = this.getCurrentLocation(-1);
      this.entityDecoder = new EntityDecoder(htmlDecodeTree, (cp, consumed) => {
        this.preprocessor.pos = this.entityStartPos + consumed - 1;
        this._flushCodePointConsumedAsCharacterReference(cp);
      }, handler.onParseError ? {
        missingSemicolonAfterCharacterReference: () => {
          this._err(ERR.missingSemicolonAfterCharacterReference, 1);
        },
        absenceOfDigitsInNumericCharacterReference: (consumed) => {
          this._err(ERR.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + consumed);
        },
        validateNumericCharacterReference: (code) => {
          const error = getErrorForNumericCharacterReference(code);
          if (error)
            this._err(error, 1);
        }
      } : void 0);
    }
    //Errors
    _err(code, cpOffset = 0) {
      var _a2, _b;
      (_b = (_a2 = this.handler).onParseError) === null || _b === void 0 ? void 0 : _b.call(_a2, this.preprocessor.getError(code, cpOffset));
    }
    // NOTE: \`offset\` may never run across line boundaries.
    getCurrentLocation(offset) {
      if (!this.options.sourceCodeLocationInfo) {
        return null;
      }
      return {
        startLine: this.preprocessor.line,
        startCol: this.preprocessor.col - offset,
        startOffset: this.preprocessor.offset - offset,
        endLine: -1,
        endCol: -1,
        endOffset: -1
      };
    }
    _runParsingLoop() {
      if (this.inLoop)
        return;
      this.inLoop = true;
      while (this.active && !this.paused) {
        this.consumedAfterSnapshot = 0;
        const cp = this._consume();
        if (!this._ensureHibernation()) {
          this._callState(cp);
        }
      }
      this.inLoop = false;
    }
    //API
    pause() {
      this.paused = true;
    }
    resume(writeCallback) {
      if (!this.paused) {
        throw new Error("Parser was already resumed");
      }
      this.paused = false;
      if (this.inLoop)
        return;
      this._runParsingLoop();
      if (!this.paused) {
        writeCallback === null || writeCallback === void 0 ? void 0 : writeCallback();
      }
    }
    write(chunk, isLastChunk, writeCallback) {
      this.active = true;
      this.preprocessor.write(chunk, isLastChunk);
      this._runParsingLoop();
      if (!this.paused) {
        writeCallback === null || writeCallback === void 0 ? void 0 : writeCallback();
      }
    }
    insertHtmlAtCurrentPos(chunk) {
      this.active = true;
      this.preprocessor.insertHtmlAtCurrentPos(chunk);
      this._runParsingLoop();
    }
    //Hibernation
    _ensureHibernation() {
      if (this.preprocessor.endOfChunkHit) {
        this.preprocessor.retreat(this.consumedAfterSnapshot);
        this.consumedAfterSnapshot = 0;
        this.active = false;
        return true;
      }
      return false;
    }
    //Consumption
    _consume() {
      this.consumedAfterSnapshot++;
      return this.preprocessor.advance();
    }
    _advanceBy(count) {
      this.consumedAfterSnapshot += count;
      for (let i = 0; i < count; i++) {
        this.preprocessor.advance();
      }
    }
    _consumeSequenceIfMatch(pattern, caseSensitive) {
      if (this.preprocessor.startsWith(pattern, caseSensitive)) {
        this._advanceBy(pattern.length - 1);
        return true;
      }
      return false;
    }
    //Token creation
    _createStartTagToken() {
      this.currentToken = {
        type: TokenType.START_TAG,
        tagName: "",
        tagID: TAG_ID.UNKNOWN,
        selfClosing: false,
        ackSelfClosing: false,
        attrs: [],
        location: this.getCurrentLocation(1)
      };
    }
    _createEndTagToken() {
      this.currentToken = {
        type: TokenType.END_TAG,
        tagName: "",
        tagID: TAG_ID.UNKNOWN,
        selfClosing: false,
        ackSelfClosing: false,
        attrs: [],
        location: this.getCurrentLocation(2)
      };
    }
    _createCommentToken(offset) {
      this.currentToken = {
        type: TokenType.COMMENT,
        data: "",
        location: this.getCurrentLocation(offset)
      };
    }
    _createDoctypeToken(initialName) {
      this.currentToken = {
        type: TokenType.DOCTYPE,
        name: initialName,
        forceQuirks: false,
        publicId: null,
        systemId: null,
        location: this.currentLocation
      };
    }
    _createCharacterToken(type, chars) {
      this.currentCharacterToken = {
        type,
        chars,
        location: this.currentLocation
      };
    }
    //Tag attributes
    _createAttr(attrNameFirstCh) {
      this.currentAttr = {
        name: attrNameFirstCh,
        value: ""
      };
      this.currentLocation = this.getCurrentLocation(0);
    }
    _leaveAttrName() {
      var _a2;
      var _b;
      const token = this.currentToken;
      if (getTokenAttr(token, this.currentAttr.name) === null) {
        token.attrs.push(this.currentAttr);
        if (token.location && this.currentLocation) {
          const attrLocations = (_a2 = (_b = token.location).attrs) !== null && _a2 !== void 0 ? _a2 : _b.attrs = /* @__PURE__ */ Object.create(null);
          attrLocations[this.currentAttr.name] = this.currentLocation;
          this._leaveAttrValue();
        }
      } else {
        this._err(ERR.duplicateAttribute);
      }
    }
    _leaveAttrValue() {
      if (this.currentLocation) {
        this.currentLocation.endLine = this.preprocessor.line;
        this.currentLocation.endCol = this.preprocessor.col;
        this.currentLocation.endOffset = this.preprocessor.offset;
      }
    }
    //Token emission
    prepareToken(ct2) {
      this._emitCurrentCharacterToken(ct2.location);
      this.currentToken = null;
      if (ct2.location) {
        ct2.location.endLine = this.preprocessor.line;
        ct2.location.endCol = this.preprocessor.col + 1;
        ct2.location.endOffset = this.preprocessor.offset + 1;
      }
      this.currentLocation = this.getCurrentLocation(-1);
    }
    emitCurrentTagToken() {
      const ct2 = this.currentToken;
      this.prepareToken(ct2);
      ct2.tagID = getTagID(ct2.tagName);
      if (ct2.type === TokenType.START_TAG) {
        this.lastStartTagName = ct2.tagName;
        this.handler.onStartTag(ct2);
      } else {
        if (ct2.attrs.length > 0) {
          this._err(ERR.endTagWithAttributes);
        }
        if (ct2.selfClosing) {
          this._err(ERR.endTagWithTrailingSolidus);
        }
        this.handler.onEndTag(ct2);
      }
      this.preprocessor.dropParsedChunk();
    }
    emitCurrentComment(ct2) {
      this.prepareToken(ct2);
      this.handler.onComment(ct2);
      this.preprocessor.dropParsedChunk();
    }
    emitCurrentDoctype(ct2) {
      this.prepareToken(ct2);
      this.handler.onDoctype(ct2);
      this.preprocessor.dropParsedChunk();
    }
    _emitCurrentCharacterToken(nextLocation) {
      if (this.currentCharacterToken) {
        if (nextLocation && this.currentCharacterToken.location) {
          this.currentCharacterToken.location.endLine = nextLocation.startLine;
          this.currentCharacterToken.location.endCol = nextLocation.startCol;
          this.currentCharacterToken.location.endOffset = nextLocation.startOffset;
        }
        switch (this.currentCharacterToken.type) {
          case TokenType.CHARACTER: {
            this.handler.onCharacter(this.currentCharacterToken);
            break;
          }
          case TokenType.NULL_CHARACTER: {
            this.handler.onNullCharacter(this.currentCharacterToken);
            break;
          }
          case TokenType.WHITESPACE_CHARACTER: {
            this.handler.onWhitespaceCharacter(this.currentCharacterToken);
            break;
          }
        }
        this.currentCharacterToken = null;
      }
    }
    _emitEOFToken() {
      const location = this.getCurrentLocation(0);
      if (location) {
        location.endLine = location.startLine;
        location.endCol = location.startCol;
        location.endOffset = location.startOffset;
      }
      this._emitCurrentCharacterToken(location);
      this.handler.onEof({ type: TokenType.EOF, location });
      this.active = false;
    }
    //Characters emission
    //OPTIMIZATION: The specification uses only one type of character token (one token per character).
    //This causes a huge memory overhead and a lot of unnecessary parser loops. parse5 uses 3 groups of characters.
    //If we have a sequence of characters that belong to the same group, the parser can process it
    //as a single solid character token.
    //So, there are 3 types of character tokens in parse5:
    //1)TokenType.NULL_CHARACTER - \\u0000-character sequences (e.g. '\\u0000\\u0000\\u0000')
    //2)TokenType.WHITESPACE_CHARACTER - any whitespace/new-line character sequences (e.g. '\\n  \\r\\t   \\f')
    //3)TokenType.CHARACTER - any character sequence which don't belong to groups 1 and 2 (e.g. 'abcdef1234@@#$%^')
    _appendCharToCurrentCharacterToken(type, ch) {
      if (this.currentCharacterToken) {
        if (this.currentCharacterToken.type === type) {
          this.currentCharacterToken.chars += ch;
          return;
        } else {
          this.currentLocation = this.getCurrentLocation(0);
          this._emitCurrentCharacterToken(this.currentLocation);
          this.preprocessor.dropParsedChunk();
        }
      }
      this._createCharacterToken(type, ch);
    }
    _emitCodePoint(cp) {
      const type = isWhitespace(cp) ? TokenType.WHITESPACE_CHARACTER : cp === CODE_POINTS.NULL ? TokenType.NULL_CHARACTER : TokenType.CHARACTER;
      this._appendCharToCurrentCharacterToken(type, cp < 65536 ? String.fromCharCode(cp) : String.fromCodePoint(cp));
    }
    //NOTE: used when we emit characters explicitly.
    //This is always for non-whitespace and non-null characters, which allows us to avoid additional checks.
    _emitChars(ch) {
      this._appendCharToCurrentCharacterToken(TokenType.CHARACTER, ch);
    }
    // Character reference helpers
    _startCharacterReference() {
      this.returnState = this.state;
      this.state = State.CHARACTER_REFERENCE;
      this.entityStartPos = this.preprocessor.pos;
      this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? DecodingMode.Attribute : DecodingMode.Legacy);
    }
    _isCharacterReferenceInAttribute() {
      return this.returnState === State.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === State.ATTRIBUTE_VALUE_UNQUOTED;
    }
    _flushCodePointConsumedAsCharacterReference(cp) {
      if (this._isCharacterReferenceInAttribute()) {
        this.currentAttr.value += String.fromCodePoint(cp);
      } else {
        this._emitCodePoint(cp);
      }
    }
    // Calling states this way turns out to be much faster than any other approach.
    _callState(cp) {
      switch (this.state) {
        case State.DATA: {
          this._stateData(cp);
          break;
        }
        case State.RCDATA: {
          this._stateRcdata(cp);
          break;
        }
        case State.RAWTEXT: {
          this._stateRawtext(cp);
          break;
        }
        case State.SCRIPT_DATA: {
          this._stateScriptData(cp);
          break;
        }
        case State.PLAINTEXT: {
          this._statePlaintext(cp);
          break;
        }
        case State.TAG_OPEN: {
          this._stateTagOpen(cp);
          break;
        }
        case State.END_TAG_OPEN: {
          this._stateEndTagOpen(cp);
          break;
        }
        case State.TAG_NAME: {
          this._stateTagName(cp);
          break;
        }
        case State.RCDATA_LESS_THAN_SIGN: {
          this._stateRcdataLessThanSign(cp);
          break;
        }
        case State.RCDATA_END_TAG_OPEN: {
          this._stateRcdataEndTagOpen(cp);
          break;
        }
        case State.RCDATA_END_TAG_NAME: {
          this._stateRcdataEndTagName(cp);
          break;
        }
        case State.RAWTEXT_LESS_THAN_SIGN: {
          this._stateRawtextLessThanSign(cp);
          break;
        }
        case State.RAWTEXT_END_TAG_OPEN: {
          this._stateRawtextEndTagOpen(cp);
          break;
        }
        case State.RAWTEXT_END_TAG_NAME: {
          this._stateRawtextEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_LESS_THAN_SIGN: {
          this._stateScriptDataLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_END_TAG_OPEN: {
          this._stateScriptDataEndTagOpen(cp);
          break;
        }
        case State.SCRIPT_DATA_END_TAG_NAME: {
          this._stateScriptDataEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPE_START: {
          this._stateScriptDataEscapeStart(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPE_START_DASH: {
          this._stateScriptDataEscapeStartDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED: {
          this._stateScriptDataEscaped(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_DASH: {
          this._stateScriptDataEscapedDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_DASH_DASH: {
          this._stateScriptDataEscapedDashDash(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN: {
          this._stateScriptDataEscapedLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN: {
          this._stateScriptDataEscapedEndTagOpen(cp);
          break;
        }
        case State.SCRIPT_DATA_ESCAPED_END_TAG_NAME: {
          this._stateScriptDataEscapedEndTagName(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPE_START: {
          this._stateScriptDataDoubleEscapeStart(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED: {
          this._stateScriptDataDoubleEscaped(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH: {
          this._stateScriptDataDoubleEscapedDash(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH: {
          this._stateScriptDataDoubleEscapedDashDash(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN: {
          this._stateScriptDataDoubleEscapedLessThanSign(cp);
          break;
        }
        case State.SCRIPT_DATA_DOUBLE_ESCAPE_END: {
          this._stateScriptDataDoubleEscapeEnd(cp);
          break;
        }
        case State.BEFORE_ATTRIBUTE_NAME: {
          this._stateBeforeAttributeName(cp);
          break;
        }
        case State.ATTRIBUTE_NAME: {
          this._stateAttributeName(cp);
          break;
        }
        case State.AFTER_ATTRIBUTE_NAME: {
          this._stateAfterAttributeName(cp);
          break;
        }
        case State.BEFORE_ATTRIBUTE_VALUE: {
          this._stateBeforeAttributeValue(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_DOUBLE_QUOTED: {
          this._stateAttributeValueDoubleQuoted(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_SINGLE_QUOTED: {
          this._stateAttributeValueSingleQuoted(cp);
          break;
        }
        case State.ATTRIBUTE_VALUE_UNQUOTED: {
          this._stateAttributeValueUnquoted(cp);
          break;
        }
        case State.AFTER_ATTRIBUTE_VALUE_QUOTED: {
          this._stateAfterAttributeValueQuoted(cp);
          break;
        }
        case State.SELF_CLOSING_START_TAG: {
          this._stateSelfClosingStartTag(cp);
          break;
        }
        case State.BOGUS_COMMENT: {
          this._stateBogusComment(cp);
          break;
        }
        case State.MARKUP_DECLARATION_OPEN: {
          this._stateMarkupDeclarationOpen(cp);
          break;
        }
        case State.COMMENT_START: {
          this._stateCommentStart(cp);
          break;
        }
        case State.COMMENT_START_DASH: {
          this._stateCommentStartDash(cp);
          break;
        }
        case State.COMMENT: {
          this._stateComment(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN: {
          this._stateCommentLessThanSign(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG: {
          this._stateCommentLessThanSignBang(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG_DASH: {
          this._stateCommentLessThanSignBangDash(cp);
          break;
        }
        case State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH: {
          this._stateCommentLessThanSignBangDashDash(cp);
          break;
        }
        case State.COMMENT_END_DASH: {
          this._stateCommentEndDash(cp);
          break;
        }
        case State.COMMENT_END: {
          this._stateCommentEnd(cp);
          break;
        }
        case State.COMMENT_END_BANG: {
          this._stateCommentEndBang(cp);
          break;
        }
        case State.DOCTYPE: {
          this._stateDoctype(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_NAME: {
          this._stateBeforeDoctypeName(cp);
          break;
        }
        case State.DOCTYPE_NAME: {
          this._stateDoctypeName(cp);
          break;
        }
        case State.AFTER_DOCTYPE_NAME: {
          this._stateAfterDoctypeName(cp);
          break;
        }
        case State.AFTER_DOCTYPE_PUBLIC_KEYWORD: {
          this._stateAfterDoctypePublicKeyword(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER: {
          this._stateBeforeDoctypePublicIdentifier(cp);
          break;
        }
        case State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED: {
          this._stateDoctypePublicIdentifierDoubleQuoted(cp);
          break;
        }
        case State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED: {
          this._stateDoctypePublicIdentifierSingleQuoted(cp);
          break;
        }
        case State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER: {
          this._stateAfterDoctypePublicIdentifier(cp);
          break;
        }
        case State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS: {
          this._stateBetweenDoctypePublicAndSystemIdentifiers(cp);
          break;
        }
        case State.AFTER_DOCTYPE_SYSTEM_KEYWORD: {
          this._stateAfterDoctypeSystemKeyword(cp);
          break;
        }
        case State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER: {
          this._stateBeforeDoctypeSystemIdentifier(cp);
          break;
        }
        case State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED: {
          this._stateDoctypeSystemIdentifierDoubleQuoted(cp);
          break;
        }
        case State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED: {
          this._stateDoctypeSystemIdentifierSingleQuoted(cp);
          break;
        }
        case State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER: {
          this._stateAfterDoctypeSystemIdentifier(cp);
          break;
        }
        case State.BOGUS_DOCTYPE: {
          this._stateBogusDoctype(cp);
          break;
        }
        case State.CDATA_SECTION: {
          this._stateCdataSection(cp);
          break;
        }
        case State.CDATA_SECTION_BRACKET: {
          this._stateCdataSectionBracket(cp);
          break;
        }
        case State.CDATA_SECTION_END: {
          this._stateCdataSectionEnd(cp);
          break;
        }
        case State.CHARACTER_REFERENCE: {
          this._stateCharacterReference();
          break;
        }
        case State.AMBIGUOUS_AMPERSAND: {
          this._stateAmbiguousAmpersand(cp);
          break;
        }
        default: {
          throw new Error("Unknown state");
        }
      }
    }
    // State machine
    // Data state
    //------------------------------------------------------------------
    _stateData(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.TAG_OPEN;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this._startCharacterReference();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitCodePoint(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    //  RCDATA state
    //------------------------------------------------------------------
    _stateRcdata(cp) {
      switch (cp) {
        case CODE_POINTS.AMPERSAND: {
          this._startCharacterReference();
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.RCDATA_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // RAWTEXT state
    //------------------------------------------------------------------
    _stateRawtext(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.RAWTEXT_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data state
    //------------------------------------------------------------------
    _stateScriptData(cp) {
      switch (cp) {
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // PLAINTEXT state
    //------------------------------------------------------------------
    _statePlaintext(cp) {
      switch (cp) {
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Tag open state
    //------------------------------------------------------------------
    _stateTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this._createStartTagToken();
        this.state = State.TAG_NAME;
        this._stateTagName(cp);
      } else
        switch (cp) {
          case CODE_POINTS.EXCLAMATION_MARK: {
            this.state = State.MARKUP_DECLARATION_OPEN;
            break;
          }
          case CODE_POINTS.SOLIDUS: {
            this.state = State.END_TAG_OPEN;
            break;
          }
          case CODE_POINTS.QUESTION_MARK: {
            this._err(ERR.unexpectedQuestionMarkInsteadOfTagName);
            this._createCommentToken(1);
            this.state = State.BOGUS_COMMENT;
            this._stateBogusComment(cp);
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofBeforeTagName);
            this._emitChars("<");
            this._emitEOFToken();
            break;
          }
          default: {
            this._err(ERR.invalidFirstCharacterOfTagName);
            this._emitChars("<");
            this.state = State.DATA;
            this._stateData(cp);
          }
        }
    }
    // End tag open state
    //------------------------------------------------------------------
    _stateEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this._createEndTagToken();
        this.state = State.TAG_NAME;
        this._stateTagName(cp);
      } else
        switch (cp) {
          case CODE_POINTS.GREATER_THAN_SIGN: {
            this._err(ERR.missingEndTagName);
            this.state = State.DATA;
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofBeforeTagName);
            this._emitChars("</");
            this._emitEOFToken();
            break;
          }
          default: {
            this._err(ERR.invalidFirstCharacterOfTagName);
            this._createCommentToken(2);
            this.state = State.BOGUS_COMMENT;
            this._stateBogusComment(cp);
          }
        }
    }
    // Tag name state
    //------------------------------------------------------------------
    _stateTagName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.tagName += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          token.tagName += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // RCDATA less-than sign state
    //------------------------------------------------------------------
    _stateRcdataLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.RCDATA_END_TAG_OPEN;
      } else {
        this._emitChars("<");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    // RCDATA end tag open state
    //------------------------------------------------------------------
    _stateRcdataEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.RCDATA_END_TAG_NAME;
        this._stateRcdataEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    handleSpecialEndTag(_cp) {
      if (!this.preprocessor.startsWith(this.lastStartTagName, false)) {
        return !this._ensureHibernation();
      }
      this._createEndTagToken();
      const token = this.currentToken;
      token.tagName = this.lastStartTagName;
      const cp = this.preprocessor.peek(this.lastStartTagName.length);
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._advanceBy(this.lastStartTagName.length);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          return false;
        }
        case CODE_POINTS.SOLIDUS: {
          this._advanceBy(this.lastStartTagName.length);
          this.state = State.SELF_CLOSING_START_TAG;
          return false;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._advanceBy(this.lastStartTagName.length);
          this.emitCurrentTagToken();
          this.state = State.DATA;
          return false;
        }
        default: {
          return !this._ensureHibernation();
        }
      }
    }
    // RCDATA end tag name state
    //------------------------------------------------------------------
    _stateRcdataEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.RCDATA;
        this._stateRcdata(cp);
      }
    }
    // RAWTEXT less-than sign state
    //------------------------------------------------------------------
    _stateRawtextLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.RAWTEXT_END_TAG_OPEN;
      } else {
        this._emitChars("<");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // RAWTEXT end tag open state
    //------------------------------------------------------------------
    _stateRawtextEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.RAWTEXT_END_TAG_NAME;
        this._stateRawtextEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // RAWTEXT end tag name state
    //------------------------------------------------------------------
    _stateRawtextEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.RAWTEXT;
        this._stateRawtext(cp);
      }
    }
    // Script data less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataLessThanSign(cp) {
      switch (cp) {
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SCRIPT_DATA_END_TAG_OPEN;
          break;
        }
        case CODE_POINTS.EXCLAMATION_MARK: {
          this.state = State.SCRIPT_DATA_ESCAPE_START;
          this._emitChars("<!");
          break;
        }
        default: {
          this._emitChars("<");
          this.state = State.SCRIPT_DATA;
          this._stateScriptData(cp);
        }
      }
    }
    // Script data end tag open state
    //------------------------------------------------------------------
    _stateScriptDataEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.SCRIPT_DATA_END_TAG_NAME;
        this._stateScriptDataEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data end tag name state
    //------------------------------------------------------------------
    _stateScriptDataEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escape start state
    //------------------------------------------------------------------
    _stateScriptDataEscapeStart(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.SCRIPT_DATA_ESCAPE_START_DASH;
        this._emitChars("-");
      } else {
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escape start dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapeStartDash(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
        this._emitChars("-");
      } else {
        this.state = State.SCRIPT_DATA;
        this._stateScriptData(cp);
      }
    }
    // Script data escaped state
    //------------------------------------------------------------------
    _stateScriptDataEscaped(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_ESCAPED_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapedDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_ESCAPED_DASH_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped dash dash state
    //------------------------------------------------------------------
    _stateScriptDataEscapedDashDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.SCRIPT_DATA;
          this._emitChars(">");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data escaped less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataEscapedLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_OPEN;
      } else if (isAsciiLetter(cp)) {
        this._emitChars("<");
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_START;
        this._stateScriptDataDoubleEscapeStart(cp);
      } else {
        this._emitChars("<");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data escaped end tag open state
    //------------------------------------------------------------------
    _stateScriptDataEscapedEndTagOpen(cp) {
      if (isAsciiLetter(cp)) {
        this.state = State.SCRIPT_DATA_ESCAPED_END_TAG_NAME;
        this._stateScriptDataEscapedEndTagName(cp);
      } else {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data escaped end tag name state
    //------------------------------------------------------------------
    _stateScriptDataEscapedEndTagName(cp) {
      if (this.handleSpecialEndTag(cp)) {
        this._emitChars("</");
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data double escape start state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapeStart(cp) {
      if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
        this._emitCodePoint(cp);
        for (let i = 0; i < SEQUENCES.SCRIPT.length; i++) {
          this._emitCodePoint(this._consume());
        }
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
      } else if (!this._ensureHibernation()) {
        this.state = State.SCRIPT_DATA_ESCAPED;
        this._stateScriptDataEscaped(cp);
      }
    }
    // Script data double escaped state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscaped(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped dash state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH;
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped dash dash state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedDashDash(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this._emitChars("-");
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN;
          this._emitChars("<");
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.SCRIPT_DATA;
          this._emitChars(">");
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitChars(REPLACEMENT_CHARACTER);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInScriptHtmlCommentLikeText);
          this._emitEOFToken();
          break;
        }
        default: {
          this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
          this._emitCodePoint(cp);
        }
      }
    }
    // Script data double escaped less-than sign state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapedLessThanSign(cp) {
      if (cp === CODE_POINTS.SOLIDUS) {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPE_END;
        this._emitChars("/");
      } else {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
        this._stateScriptDataDoubleEscaped(cp);
      }
    }
    // Script data double escape end state
    //------------------------------------------------------------------
    _stateScriptDataDoubleEscapeEnd(cp) {
      if (this.preprocessor.startsWith(SEQUENCES.SCRIPT, false) && isScriptDataDoubleEscapeSequenceEnd(this.preprocessor.peek(SEQUENCES.SCRIPT.length))) {
        this._emitCodePoint(cp);
        for (let i = 0; i < SEQUENCES.SCRIPT.length; i++) {
          this._emitCodePoint(this._consume());
        }
        this.state = State.SCRIPT_DATA_ESCAPED;
      } else if (!this._ensureHibernation()) {
        this.state = State.SCRIPT_DATA_DOUBLE_ESCAPED;
        this._stateScriptDataDoubleEscaped(cp);
      }
    }
    // Before attribute name state
    //------------------------------------------------------------------
    _stateBeforeAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.SOLIDUS:
        case CODE_POINTS.GREATER_THAN_SIGN:
        case CODE_POINTS.EOF: {
          this.state = State.AFTER_ATTRIBUTE_NAME;
          this._stateAfterAttributeName(cp);
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this._err(ERR.unexpectedEqualsSignBeforeAttributeName);
          this._createAttr("=");
          this.state = State.ATTRIBUTE_NAME;
          break;
        }
        default: {
          this._createAttr("");
          this.state = State.ATTRIBUTE_NAME;
          this._stateAttributeName(cp);
        }
      }
    }
    // Attribute name state
    //------------------------------------------------------------------
    _stateAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED:
        case CODE_POINTS.SOLIDUS:
        case CODE_POINTS.GREATER_THAN_SIGN:
        case CODE_POINTS.EOF: {
          this._leaveAttrName();
          this.state = State.AFTER_ATTRIBUTE_NAME;
          this._stateAfterAttributeName(cp);
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this._leaveAttrName();
          this.state = State.BEFORE_ATTRIBUTE_VALUE;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK:
        case CODE_POINTS.APOSTROPHE:
        case CODE_POINTS.LESS_THAN_SIGN: {
          this._err(ERR.unexpectedCharacterInAttributeName);
          this.currentAttr.name += String.fromCodePoint(cp);
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.name += REPLACEMENT_CHARACTER;
          break;
        }
        default: {
          this.currentAttr.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // After attribute name state
    //------------------------------------------------------------------
    _stateAfterAttributeName(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.EQUALS_SIGN: {
          this.state = State.BEFORE_ATTRIBUTE_VALUE;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._createAttr("");
          this.state = State.ATTRIBUTE_NAME;
          this._stateAttributeName(cp);
        }
      }
    }
    // Before attribute value state
    //------------------------------------------------------------------
    _stateBeforeAttributeValue(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.ATTRIBUTE_VALUE_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingAttributeValue);
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        default: {
          this.state = State.ATTRIBUTE_VALUE_UNQUOTED;
          this._stateAttributeValueUnquoted(cp);
        }
      }
    }
    // Attribute value (double-quoted) state
    //------------------------------------------------------------------
    _stateAttributeValueDoubleQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this._startCharacterReference();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // Attribute value (single-quoted) state
    //------------------------------------------------------------------
    _stateAttributeValueSingleQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_ATTRIBUTE_VALUE_QUOTED;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this._startCharacterReference();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // Attribute value (unquoted) state
    //------------------------------------------------------------------
    _stateAttributeValueUnquoted(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._leaveAttrValue();
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.AMPERSAND: {
          this._startCharacterReference();
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._leaveAttrValue();
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          this.currentAttr.value += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK:
        case CODE_POINTS.APOSTROPHE:
        case CODE_POINTS.LESS_THAN_SIGN:
        case CODE_POINTS.EQUALS_SIGN:
        case CODE_POINTS.GRAVE_ACCENT: {
          this._err(ERR.unexpectedCharacterInUnquotedAttributeValue);
          this.currentAttr.value += String.fromCodePoint(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this.currentAttr.value += String.fromCodePoint(cp);
        }
      }
    }
    // After attribute value (quoted) state
    //------------------------------------------------------------------
    _stateAfterAttributeValueQuoted(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this._leaveAttrValue();
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          break;
        }
        case CODE_POINTS.SOLIDUS: {
          this._leaveAttrValue();
          this.state = State.SELF_CLOSING_START_TAG;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._leaveAttrValue();
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingWhitespaceBetweenAttributes);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          this._stateBeforeAttributeName(cp);
        }
      }
    }
    // Self-closing start tag state
    //------------------------------------------------------------------
    _stateSelfClosingStartTag(cp) {
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          const token = this.currentToken;
          token.selfClosing = true;
          this.state = State.DATA;
          this.emitCurrentTagToken();
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInTag);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.unexpectedSolidusInTag);
          this.state = State.BEFORE_ATTRIBUTE_NAME;
          this._stateBeforeAttributeName(cp);
        }
      }
    }
    // Bogus comment state
    //------------------------------------------------------------------
    _stateBogusComment(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.data += REPLACEMENT_CHARACTER;
          break;
        }
        default: {
          token.data += String.fromCodePoint(cp);
        }
      }
    }
    // Markup declaration open state
    //------------------------------------------------------------------
    _stateMarkupDeclarationOpen(cp) {
      if (this._consumeSequenceIfMatch(SEQUENCES.DASH_DASH, true)) {
        this._createCommentToken(SEQUENCES.DASH_DASH.length + 1);
        this.state = State.COMMENT_START;
      } else if (this._consumeSequenceIfMatch(SEQUENCES.DOCTYPE, false)) {
        this.currentLocation = this.getCurrentLocation(SEQUENCES.DOCTYPE.length + 1);
        this.state = State.DOCTYPE;
      } else if (this._consumeSequenceIfMatch(SEQUENCES.CDATA_START, true)) {
        if (this.inForeignNode) {
          this.state = State.CDATA_SECTION;
        } else {
          this._err(ERR.cdataInHtmlContent);
          this._createCommentToken(SEQUENCES.CDATA_START.length + 1);
          this.currentToken.data = "[CDATA[";
          this.state = State.BOGUS_COMMENT;
        }
      } else if (!this._ensureHibernation()) {
        this._err(ERR.incorrectlyOpenedComment);
        this._createCommentToken(2);
        this.state = State.BOGUS_COMMENT;
        this._stateBogusComment(cp);
      }
    }
    // Comment start state
    //------------------------------------------------------------------
    _stateCommentStart(cp) {
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_START_DASH;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptClosingOfEmptyComment);
          this.state = State.DATA;
          const token = this.currentToken;
          this.emitCurrentComment(token);
          break;
        }
        default: {
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment start dash state
    //------------------------------------------------------------------
    _stateCommentStartDash(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptClosingOfEmptyComment);
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "-";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment state
    //------------------------------------------------------------------
    _stateComment(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END_DASH;
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          token.data += "<";
          this.state = State.COMMENT_LESS_THAN_SIGN;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.data += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += String.fromCodePoint(cp);
        }
      }
    }
    // Comment less-than sign state
    //------------------------------------------------------------------
    _stateCommentLessThanSign(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.EXCLAMATION_MARK: {
          token.data += "!";
          this.state = State.COMMENT_LESS_THAN_SIGN_BANG;
          break;
        }
        case CODE_POINTS.LESS_THAN_SIGN: {
          token.data += "<";
          break;
        }
        default: {
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment less-than sign bang state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBang(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH;
      } else {
        this.state = State.COMMENT;
        this._stateComment(cp);
      }
    }
    // Comment less-than sign bang dash state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBangDash(cp) {
      if (cp === CODE_POINTS.HYPHEN_MINUS) {
        this.state = State.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH;
      } else {
        this.state = State.COMMENT_END_DASH;
        this._stateCommentEndDash(cp);
      }
    }
    // Comment less-than sign bang dash dash state
    //------------------------------------------------------------------
    _stateCommentLessThanSignBangDashDash(cp) {
      if (cp !== CODE_POINTS.GREATER_THAN_SIGN && cp !== CODE_POINTS.EOF) {
        this._err(ERR.nestedComment);
      }
      this.state = State.COMMENT_END;
      this._stateCommentEnd(cp);
    }
    // Comment end dash state
    //------------------------------------------------------------------
    _stateCommentEndDash(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          this.state = State.COMMENT_END;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "-";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment end state
    //------------------------------------------------------------------
    _stateCommentEnd(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EXCLAMATION_MARK: {
          this.state = State.COMMENT_END_BANG;
          break;
        }
        case CODE_POINTS.HYPHEN_MINUS: {
          token.data += "-";
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "--";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // Comment end bang state
    //------------------------------------------------------------------
    _stateCommentEndBang(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.HYPHEN_MINUS: {
          token.data += "--!";
          this.state = State.COMMENT_END_DASH;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.incorrectlyClosedComment);
          this.state = State.DATA;
          this.emitCurrentComment(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInComment);
          this.emitCurrentComment(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.data += "--!";
          this.state = State.COMMENT;
          this._stateComment(cp);
        }
      }
    }
    // DOCTYPE state
    //------------------------------------------------------------------
    _stateDoctype(cp) {
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_NAME;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.BEFORE_DOCTYPE_NAME;
          this._stateBeforeDoctypeName(cp);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          this._createDoctypeToken(null);
          const token = this.currentToken;
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingWhitespaceBeforeDoctypeName);
          this.state = State.BEFORE_DOCTYPE_NAME;
          this._stateBeforeDoctypeName(cp);
        }
      }
    }
    // Before DOCTYPE name state
    //------------------------------------------------------------------
    _stateBeforeDoctypeName(cp) {
      if (isAsciiUpper(cp)) {
        this._createDoctypeToken(String.fromCharCode(toAsciiLower(cp)));
        this.state = State.DOCTYPE_NAME;
      } else
        switch (cp) {
          case CODE_POINTS.SPACE:
          case CODE_POINTS.LINE_FEED:
          case CODE_POINTS.TABULATION:
          case CODE_POINTS.FORM_FEED: {
            break;
          }
          case CODE_POINTS.NULL: {
            this._err(ERR.unexpectedNullCharacter);
            this._createDoctypeToken(REPLACEMENT_CHARACTER);
            this.state = State.DOCTYPE_NAME;
            break;
          }
          case CODE_POINTS.GREATER_THAN_SIGN: {
            this._err(ERR.missingDoctypeName);
            this._createDoctypeToken(null);
            const token = this.currentToken;
            token.forceQuirks = true;
            this.emitCurrentDoctype(token);
            this.state = State.DATA;
            break;
          }
          case CODE_POINTS.EOF: {
            this._err(ERR.eofInDoctype);
            this._createDoctypeToken(null);
            const token = this.currentToken;
            token.forceQuirks = true;
            this.emitCurrentDoctype(token);
            this._emitEOFToken();
            break;
          }
          default: {
            this._createDoctypeToken(String.fromCodePoint(cp));
            this.state = State.DOCTYPE_NAME;
          }
        }
    }
    // DOCTYPE name state
    //------------------------------------------------------------------
    _stateDoctypeName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.AFTER_DOCTYPE_NAME;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.name += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.name += String.fromCodePoint(isAsciiUpper(cp) ? toAsciiLower(cp) : cp);
        }
      }
    }
    // After DOCTYPE name state
    //------------------------------------------------------------------
    _stateAfterDoctypeName(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          if (this._consumeSequenceIfMatch(SEQUENCES.PUBLIC, false)) {
            this.state = State.AFTER_DOCTYPE_PUBLIC_KEYWORD;
          } else if (this._consumeSequenceIfMatch(SEQUENCES.SYSTEM, false)) {
            this.state = State.AFTER_DOCTYPE_SYSTEM_KEYWORD;
          } else if (!this._ensureHibernation()) {
            this._err(ERR.invalidCharacterSequenceAfterDoctypeName);
            token.forceQuirks = true;
            this.state = State.BOGUS_DOCTYPE;
            this._stateBogusDoctype(cp);
          }
        }
      }
    }
    // After DOCTYPE public keyword state
    //------------------------------------------------------------------
    _stateAfterDoctypePublicKeyword(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceAfterDoctypePublicKeyword);
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Before DOCTYPE public identifier state
    //------------------------------------------------------------------
    _stateBeforeDoctypePublicIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.publicId = "";
          this.state = State.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // DOCTYPE public identifier (double-quoted) state
    //------------------------------------------------------------------
    _stateDoctypePublicIdentifierDoubleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.publicId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.publicId += String.fromCodePoint(cp);
        }
      }
    }
    // DOCTYPE public identifier (single-quoted) state
    //------------------------------------------------------------------
    _stateDoctypePublicIdentifierSingleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.publicId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypePublicIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.publicId += String.fromCodePoint(cp);
        }
      }
    }
    // After DOCTYPE public identifier state
    //------------------------------------------------------------------
    _stateAfterDoctypePublicIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Between DOCTYPE public and system identifiers state
    //------------------------------------------------------------------
    _stateBetweenDoctypePublicAndSystemIdentifiers(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // After DOCTYPE system keyword state
    //------------------------------------------------------------------
    _stateAfterDoctypeSystemKeyword(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          this.state = State.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          this._err(ERR.missingWhitespaceAfterDoctypeSystemKeyword);
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Before DOCTYPE system identifier state
    //------------------------------------------------------------------
    _stateBeforeDoctypeSystemIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.QUOTATION_MARK: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
          break;
        }
        case CODE_POINTS.APOSTROPHE: {
          token.systemId = "";
          this.state = State.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.missingDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.DATA;
          this.emitCurrentDoctype(token);
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.missingQuoteBeforeDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // DOCTYPE system identifier (double-quoted) state
    //------------------------------------------------------------------
    _stateDoctypeSystemIdentifierDoubleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.QUOTATION_MARK: {
          this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.systemId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.systemId += String.fromCodePoint(cp);
        }
      }
    }
    // DOCTYPE system identifier (single-quoted) state
    //------------------------------------------------------------------
    _stateDoctypeSystemIdentifierSingleQuoted(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.APOSTROPHE: {
          this.state = State.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          token.systemId += REPLACEMENT_CHARACTER;
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this._err(ERR.abruptDoctypeSystemIdentifier);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          token.systemId += String.fromCodePoint(cp);
        }
      }
    }
    // After DOCTYPE system identifier state
    //------------------------------------------------------------------
    _stateAfterDoctypeSystemIdentifier(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.SPACE:
        case CODE_POINTS.LINE_FEED:
        case CODE_POINTS.TABULATION:
        case CODE_POINTS.FORM_FEED: {
          break;
        }
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInDoctype);
          token.forceQuirks = true;
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
        default: {
          this._err(ERR.unexpectedCharacterAfterDoctypeSystemIdentifier);
          this.state = State.BOGUS_DOCTYPE;
          this._stateBogusDoctype(cp);
        }
      }
    }
    // Bogus DOCTYPE state
    //------------------------------------------------------------------
    _stateBogusDoctype(cp) {
      const token = this.currentToken;
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.emitCurrentDoctype(token);
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.NULL: {
          this._err(ERR.unexpectedNullCharacter);
          break;
        }
        case CODE_POINTS.EOF: {
          this.emitCurrentDoctype(token);
          this._emitEOFToken();
          break;
        }
      }
    }
    // CDATA section state
    //------------------------------------------------------------------
    _stateCdataSection(cp) {
      switch (cp) {
        case CODE_POINTS.RIGHT_SQUARE_BRACKET: {
          this.state = State.CDATA_SECTION_BRACKET;
          break;
        }
        case CODE_POINTS.EOF: {
          this._err(ERR.eofInCdata);
          this._emitEOFToken();
          break;
        }
        default: {
          this._emitCodePoint(cp);
        }
      }
    }
    // CDATA section bracket state
    //------------------------------------------------------------------
    _stateCdataSectionBracket(cp) {
      if (cp === CODE_POINTS.RIGHT_SQUARE_BRACKET) {
        this.state = State.CDATA_SECTION_END;
      } else {
        this._emitChars("]");
        this.state = State.CDATA_SECTION;
        this._stateCdataSection(cp);
      }
    }
    // CDATA section end state
    //------------------------------------------------------------------
    _stateCdataSectionEnd(cp) {
      switch (cp) {
        case CODE_POINTS.GREATER_THAN_SIGN: {
          this.state = State.DATA;
          break;
        }
        case CODE_POINTS.RIGHT_SQUARE_BRACKET: {
          this._emitChars("]");
          break;
        }
        default: {
          this._emitChars("]]");
          this.state = State.CDATA_SECTION;
          this._stateCdataSection(cp);
        }
      }
    }
    // Character reference state
    //------------------------------------------------------------------
    _stateCharacterReference() {
      let length = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
      if (length < 0) {
        if (this.preprocessor.lastChunkWritten) {
          length = this.entityDecoder.end();
        } else {
          this.active = false;
          this.preprocessor.pos = this.preprocessor.html.length - 1;
          this.consumedAfterSnapshot = 0;
          this.preprocessor.endOfChunkHit = true;
          return;
        }
      }
      if (length === 0) {
        this.preprocessor.pos = this.entityStartPos;
        this._flushCodePointConsumedAsCharacterReference(CODE_POINTS.AMPERSAND);
        this.state = !this._isCharacterReferenceInAttribute() && isAsciiAlphaNumeric(this.preprocessor.peek(1)) ? State.AMBIGUOUS_AMPERSAND : this.returnState;
      } else {
        this.state = this.returnState;
      }
    }
    // Ambiguos ampersand state
    //------------------------------------------------------------------
    _stateAmbiguousAmpersand(cp) {
      if (isAsciiAlphaNumeric(cp)) {
        this._flushCodePointConsumedAsCharacterReference(cp);
      } else {
        if (cp === CODE_POINTS.SEMICOLON) {
          this._err(ERR.unknownNamedCharacterReference);
        }
        this.state = this.returnState;
        this._callState(cp);
      }
    }
  }
  const IMPLICIT_END_TAG_REQUIRED = /* @__PURE__ */ new Set([TAG_ID.DD, TAG_ID.DT, TAG_ID.LI, TAG_ID.OPTGROUP, TAG_ID.OPTION, TAG_ID.P, TAG_ID.RB, TAG_ID.RP, TAG_ID.RT, TAG_ID.RTC]);
  const IMPLICIT_END_TAG_REQUIRED_THOROUGHLY = /* @__PURE__ */ new Set([
    ...IMPLICIT_END_TAG_REQUIRED,
    TAG_ID.CAPTION,
    TAG_ID.COLGROUP,
    TAG_ID.TBODY,
    TAG_ID.TD,
    TAG_ID.TFOOT,
    TAG_ID.TH,
    TAG_ID.THEAD,
    TAG_ID.TR
  ]);
  const SCOPING_ELEMENTS_HTML = /* @__PURE__ */ new Set([
    TAG_ID.APPLET,
    TAG_ID.CAPTION,
    TAG_ID.HTML,
    TAG_ID.MARQUEE,
    TAG_ID.OBJECT,
    TAG_ID.TABLE,
    TAG_ID.TD,
    TAG_ID.TEMPLATE,
    TAG_ID.TH
  ]);
  const SCOPING_ELEMENTS_HTML_LIST = /* @__PURE__ */ new Set([...SCOPING_ELEMENTS_HTML, TAG_ID.OL, TAG_ID.UL]);
  const SCOPING_ELEMENTS_HTML_BUTTON = /* @__PURE__ */ new Set([...SCOPING_ELEMENTS_HTML, TAG_ID.BUTTON]);
  const SCOPING_ELEMENTS_MATHML = /* @__PURE__ */ new Set([TAG_ID.ANNOTATION_XML, TAG_ID.MI, TAG_ID.MN, TAG_ID.MO, TAG_ID.MS, TAG_ID.MTEXT]);
  const SCOPING_ELEMENTS_SVG = /* @__PURE__ */ new Set([TAG_ID.DESC, TAG_ID.FOREIGN_OBJECT, TAG_ID.TITLE]);
  const TABLE_ROW_CONTEXT = /* @__PURE__ */ new Set([TAG_ID.TR, TAG_ID.TEMPLATE, TAG_ID.HTML]);
  const TABLE_BODY_CONTEXT = /* @__PURE__ */ new Set([TAG_ID.TBODY, TAG_ID.TFOOT, TAG_ID.THEAD, TAG_ID.TEMPLATE, TAG_ID.HTML]);
  const TABLE_CONTEXT = /* @__PURE__ */ new Set([TAG_ID.TABLE, TAG_ID.TEMPLATE, TAG_ID.HTML]);
  const TABLE_CELLS = /* @__PURE__ */ new Set([TAG_ID.TD, TAG_ID.TH]);
  class OpenElementStack {
    get currentTmplContentOrNode() {
      return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
    }
    constructor(document, treeAdapter, handler) {
      this.treeAdapter = treeAdapter;
      this.handler = handler;
      this.items = [];
      this.tagIDs = [];
      this.stackTop = -1;
      this.tmplCount = 0;
      this.currentTagId = TAG_ID.UNKNOWN;
      this.current = document;
    }
    //Index of element
    _indexOf(element) {
      return this.items.lastIndexOf(element, this.stackTop);
    }
    //Update current element
    _isInTemplate() {
      return this.currentTagId === TAG_ID.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === NS.HTML;
    }
    _updateCurrentElement() {
      this.current = this.items[this.stackTop];
      this.currentTagId = this.tagIDs[this.stackTop];
    }
    //Mutations
    push(element, tagID) {
      this.stackTop++;
      this.items[this.stackTop] = element;
      this.current = element;
      this.tagIDs[this.stackTop] = tagID;
      this.currentTagId = tagID;
      if (this._isInTemplate()) {
        this.tmplCount++;
      }
      this.handler.onItemPush(element, tagID, true);
    }
    pop() {
      const popped = this.current;
      if (this.tmplCount > 0 && this._isInTemplate()) {
        this.tmplCount--;
      }
      this.stackTop--;
      this._updateCurrentElement();
      this.handler.onItemPop(popped, true);
    }
    replace(oldElement, newElement) {
      const idx = this._indexOf(oldElement);
      this.items[idx] = newElement;
      if (idx === this.stackTop) {
        this.current = newElement;
      }
    }
    insertAfter(referenceElement, newElement, newElementID) {
      const insertionIdx = this._indexOf(referenceElement) + 1;
      this.items.splice(insertionIdx, 0, newElement);
      this.tagIDs.splice(insertionIdx, 0, newElementID);
      this.stackTop++;
      if (insertionIdx === this.stackTop) {
        this._updateCurrentElement();
      }
      if (this.current && this.currentTagId !== void 0) {
        this.handler.onItemPush(this.current, this.currentTagId, insertionIdx === this.stackTop);
      }
    }
    popUntilTagNamePopped(tagName) {
      let targetIdx = this.stackTop + 1;
      do {
        targetIdx = this.tagIDs.lastIndexOf(tagName, targetIdx - 1);
      } while (targetIdx > 0 && this.treeAdapter.getNamespaceURI(this.items[targetIdx]) !== NS.HTML);
      this.shortenToLength(Math.max(targetIdx, 0));
    }
    shortenToLength(idx) {
      while (this.stackTop >= idx) {
        const popped = this.current;
        if (this.tmplCount > 0 && this._isInTemplate()) {
          this.tmplCount -= 1;
        }
        this.stackTop--;
        this._updateCurrentElement();
        this.handler.onItemPop(popped, this.stackTop < idx);
      }
    }
    popUntilElementPopped(element) {
      const idx = this._indexOf(element);
      this.shortenToLength(Math.max(idx, 0));
    }
    popUntilPopped(tagNames, targetNS) {
      const idx = this._indexOfTagNames(tagNames, targetNS);
      this.shortenToLength(Math.max(idx, 0));
    }
    popUntilNumberedHeaderPopped() {
      this.popUntilPopped(NUMBERED_HEADERS, NS.HTML);
    }
    popUntilTableCellPopped() {
      this.popUntilPopped(TABLE_CELLS, NS.HTML);
    }
    popAllUpToHtmlElement() {
      this.tmplCount = 0;
      this.shortenToLength(1);
    }
    _indexOfTagNames(tagNames, namespace) {
      for (let i = this.stackTop; i >= 0; i--) {
        if (tagNames.has(this.tagIDs[i]) && this.treeAdapter.getNamespaceURI(this.items[i]) === namespace) {
          return i;
        }
      }
      return -1;
    }
    clearBackTo(tagNames, targetNS) {
      const idx = this._indexOfTagNames(tagNames, targetNS);
      this.shortenToLength(idx + 1);
    }
    clearBackToTableContext() {
      this.clearBackTo(TABLE_CONTEXT, NS.HTML);
    }
    clearBackToTableBodyContext() {
      this.clearBackTo(TABLE_BODY_CONTEXT, NS.HTML);
    }
    clearBackToTableRowContext() {
      this.clearBackTo(TABLE_ROW_CONTEXT, NS.HTML);
    }
    remove(element) {
      const idx = this._indexOf(element);
      if (idx >= 0) {
        if (idx === this.stackTop) {
          this.pop();
        } else {
          this.items.splice(idx, 1);
          this.tagIDs.splice(idx, 1);
          this.stackTop--;
          this._updateCurrentElement();
          this.handler.onItemPop(element, false);
        }
      }
    }
    //Search
    tryPeekProperlyNestedBodyElement() {
      return this.stackTop >= 1 && this.tagIDs[1] === TAG_ID.BODY ? this.items[1] : null;
    }
    contains(element) {
      return this._indexOf(element) > -1;
    }
    getCommonAncestor(element) {
      const elementIdx = this._indexOf(element) - 1;
      return elementIdx >= 0 ? this.items[elementIdx] : null;
    }
    isRootHtmlElementCurrent() {
      return this.stackTop === 0 && this.tagIDs[0] === TAG_ID.HTML;
    }
    //Element in scope
    hasInDynamicScope(tagName, htmlScope) {
      for (let i = this.stackTop; i >= 0; i--) {
        const tn2 = this.tagIDs[i];
        switch (this.treeAdapter.getNamespaceURI(this.items[i])) {
          case NS.HTML: {
            if (tn2 === tagName)
              return true;
            if (htmlScope.has(tn2))
              return false;
            break;
          }
          case NS.SVG: {
            if (SCOPING_ELEMENTS_SVG.has(tn2))
              return false;
            break;
          }
          case NS.MATHML: {
            if (SCOPING_ELEMENTS_MATHML.has(tn2))
              return false;
            break;
          }
        }
      }
      return true;
    }
    hasInScope(tagName) {
      return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML);
    }
    hasInListItemScope(tagName) {
      return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML_LIST);
    }
    hasInButtonScope(tagName) {
      return this.hasInDynamicScope(tagName, SCOPING_ELEMENTS_HTML_BUTTON);
    }
    hasNumberedHeaderInScope() {
      for (let i = this.stackTop; i >= 0; i--) {
        const tn2 = this.tagIDs[i];
        switch (this.treeAdapter.getNamespaceURI(this.items[i])) {
          case NS.HTML: {
            if (NUMBERED_HEADERS.has(tn2))
              return true;
            if (SCOPING_ELEMENTS_HTML.has(tn2))
              return false;
            break;
          }
          case NS.SVG: {
            if (SCOPING_ELEMENTS_SVG.has(tn2))
              return false;
            break;
          }
          case NS.MATHML: {
            if (SCOPING_ELEMENTS_MATHML.has(tn2))
              return false;
            break;
          }
        }
      }
      return true;
    }
    hasInTableScope(tagName) {
      for (let i = this.stackTop; i >= 0; i--) {
        if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) {
          continue;
        }
        switch (this.tagIDs[i]) {
          case tagName: {
            return true;
          }
          case TAG_ID.TABLE:
          case TAG_ID.HTML: {
            return false;
          }
        }
      }
      return true;
    }
    hasTableBodyContextInTableScope() {
      for (let i = this.stackTop; i >= 0; i--) {
        if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) {
          continue;
        }
        switch (this.tagIDs[i]) {
          case TAG_ID.TBODY:
          case TAG_ID.THEAD:
          case TAG_ID.TFOOT: {
            return true;
          }
          case TAG_ID.TABLE:
          case TAG_ID.HTML: {
            return false;
          }
        }
      }
      return true;
    }
    hasInSelectScope(tagName) {
      for (let i = this.stackTop; i >= 0; i--) {
        if (this.treeAdapter.getNamespaceURI(this.items[i]) !== NS.HTML) {
          continue;
        }
        switch (this.tagIDs[i]) {
          case tagName: {
            return true;
          }
          case TAG_ID.OPTION:
          case TAG_ID.OPTGROUP: {
            break;
          }
          default: {
            return false;
          }
        }
      }
      return true;
    }
    //Implied end tags
    generateImpliedEndTags() {
      while (this.currentTagId !== void 0 && IMPLICIT_END_TAG_REQUIRED.has(this.currentTagId)) {
        this.pop();
      }
    }
    generateImpliedEndTagsThoroughly() {
      while (this.currentTagId !== void 0 && IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) {
        this.pop();
      }
    }
    generateImpliedEndTagsWithExclusion(exclusionId) {
      while (this.currentTagId !== void 0 && this.currentTagId !== exclusionId && IMPLICIT_END_TAG_REQUIRED_THOROUGHLY.has(this.currentTagId)) {
        this.pop();
      }
    }
  }
  const NOAH_ARK_CAPACITY = 3;
  var EntryType;
  (function(EntryType2) {
    EntryType2[EntryType2["Marker"] = 0] = "Marker";
    EntryType2[EntryType2["Element"] = 1] = "Element";
  })(EntryType || (EntryType = {}));
  const MARKER = { type: EntryType.Marker };
  class FormattingElementList {
    constructor(treeAdapter) {
      this.treeAdapter = treeAdapter;
      this.entries = [];
      this.bookmark = null;
    }
    //Noah Ark's condition
    //OPTIMIZATION: at first we try to find possible candidates for exclusion using
    //lightweight heuristics without thorough attributes check.
    _getNoahArkConditionCandidates(newElement, neAttrs) {
      const candidates = [];
      const neAttrsLength = neAttrs.length;
      const neTagName = this.treeAdapter.getTagName(newElement);
      const neNamespaceURI = this.treeAdapter.getNamespaceURI(newElement);
      for (let i = 0; i < this.entries.length; i++) {
        const entry = this.entries[i];
        if (entry.type === EntryType.Marker) {
          break;
        }
        const { element } = entry;
        if (this.treeAdapter.getTagName(element) === neTagName && this.treeAdapter.getNamespaceURI(element) === neNamespaceURI) {
          const elementAttrs = this.treeAdapter.getAttrList(element);
          if (elementAttrs.length === neAttrsLength) {
            candidates.push({ idx: i, attrs: elementAttrs });
          }
        }
      }
      return candidates;
    }
    _ensureNoahArkCondition(newElement) {
      if (this.entries.length < NOAH_ARK_CAPACITY)
        return;
      const neAttrs = this.treeAdapter.getAttrList(newElement);
      const candidates = this._getNoahArkConditionCandidates(newElement, neAttrs);
      if (candidates.length < NOAH_ARK_CAPACITY)
        return;
      const neAttrsMap = new Map(neAttrs.map((neAttr) => [neAttr.name, neAttr.value]));
      let validCandidates = 0;
      for (let i = 0; i < candidates.length; i++) {
        const candidate = candidates[i];
        if (candidate.attrs.every((cAttr) => neAttrsMap.get(cAttr.name) === cAttr.value)) {
          validCandidates += 1;
          if (validCandidates >= NOAH_ARK_CAPACITY) {
            this.entries.splice(candidate.idx, 1);
          }
        }
      }
    }
    //Mutations
    insertMarker() {
      this.entries.unshift(MARKER);
    }
    pushElement(element, token) {
      this._ensureNoahArkCondition(element);
      this.entries.unshift({
        type: EntryType.Element,
        element,
        token
      });
    }
    insertElementAfterBookmark(element, token) {
      const bookmarkIdx = this.entries.indexOf(this.bookmark);
      this.entries.splice(bookmarkIdx, 0, {
        type: EntryType.Element,
        element,
        token
      });
    }
    removeEntry(entry) {
      const entryIndex = this.entries.indexOf(entry);
      if (entryIndex !== -1) {
        this.entries.splice(entryIndex, 1);
      }
    }
    /**
     * Clears the list of formatting elements up to the last marker.
     *
     * @see https://html.spec.whatwg.org/multipage/parsing.html#clear-the-list-of-active-formatting-elements-up-to-the-last-marker
     */
    clearToLastMarker() {
      const markerIdx = this.entries.indexOf(MARKER);
      if (markerIdx === -1) {
        this.entries.length = 0;
      } else {
        this.entries.splice(0, markerIdx + 1);
      }
    }
    //Search
    getElementEntryInScopeWithTagName(tagName) {
      const entry = this.entries.find((entry2) => entry2.type === EntryType.Marker || this.treeAdapter.getTagName(entry2.element) === tagName);
      return entry && entry.type === EntryType.Element ? entry : null;
    }
    getElementEntry(element) {
      return this.entries.find((entry) => entry.type === EntryType.Element && entry.element === element);
    }
  }
  const defaultTreeAdapter = {
    //Node construction
    createDocument() {
      return {
        nodeName: "#document",
        mode: DOCUMENT_MODE.NO_QUIRKS,
        childNodes: []
      };
    },
    createDocumentFragment() {
      return {
        nodeName: "#document-fragment",
        childNodes: []
      };
    },
    createElement(tagName, namespaceURI, attrs) {
      return {
        nodeName: tagName,
        tagName,
        attrs,
        namespaceURI,
        childNodes: [],
        parentNode: null
      };
    },
    createCommentNode(data) {
      return {
        nodeName: "#comment",
        data,
        parentNode: null
      };
    },
    createTextNode(value) {
      return {
        nodeName: "#text",
        value,
        parentNode: null
      };
    },
    //Tree mutation
    appendChild(parentNode, newNode) {
      parentNode.childNodes.push(newNode);
      newNode.parentNode = parentNode;
    },
    insertBefore(parentNode, newNode, referenceNode) {
      const insertionIdx = parentNode.childNodes.indexOf(referenceNode);
      parentNode.childNodes.splice(insertionIdx, 0, newNode);
      newNode.parentNode = parentNode;
    },
    setTemplateContent(templateElement, contentElement) {
      templateElement.content = contentElement;
    },
    getTemplateContent(templateElement) {
      return templateElement.content;
    },
    setDocumentType(document, name, publicId, systemId) {
      const doctypeNode = document.childNodes.find((node) => node.nodeName === "#documentType");
      if (doctypeNode) {
        doctypeNode.name = name;
        doctypeNode.publicId = publicId;
        doctypeNode.systemId = systemId;
      } else {
        const node = {
          nodeName: "#documentType",
          name,
          publicId,
          systemId,
          parentNode: null
        };
        defaultTreeAdapter.appendChild(document, node);
      }
    },
    setDocumentMode(document, mode) {
      document.mode = mode;
    },
    getDocumentMode(document) {
      return document.mode;
    },
    detachNode(node) {
      if (node.parentNode) {
        const idx = node.parentNode.childNodes.indexOf(node);
        node.parentNode.childNodes.splice(idx, 1);
        node.parentNode = null;
      }
    },
    insertText(parentNode, text) {
      if (parentNode.childNodes.length > 0) {
        const prevNode = parentNode.childNodes[parentNode.childNodes.length - 1];
        if (defaultTreeAdapter.isTextNode(prevNode)) {
          prevNode.value += text;
          return;
        }
      }
      defaultTreeAdapter.appendChild(parentNode, defaultTreeAdapter.createTextNode(text));
    },
    insertTextBefore(parentNode, text, referenceNode) {
      const prevNode = parentNode.childNodes[parentNode.childNodes.indexOf(referenceNode) - 1];
      if (prevNode && defaultTreeAdapter.isTextNode(prevNode)) {
        prevNode.value += text;
      } else {
        defaultTreeAdapter.insertBefore(parentNode, defaultTreeAdapter.createTextNode(text), referenceNode);
      }
    },
    adoptAttributes(recipient, attrs) {
      const recipientAttrsMap = new Set(recipient.attrs.map((attr) => attr.name));
      for (let j2 = 0; j2 < attrs.length; j2++) {
        if (!recipientAttrsMap.has(attrs[j2].name)) {
          recipient.attrs.push(attrs[j2]);
        }
      }
    },
    //Tree traversing
    getFirstChild(node) {
      return node.childNodes[0];
    },
    getChildNodes(node) {
      return node.childNodes;
    },
    getParentNode(node) {
      return node.parentNode;
    },
    getAttrList(element) {
      return element.attrs;
    },
    //Node data
    getTagName(element) {
      return element.tagName;
    },
    getNamespaceURI(element) {
      return element.namespaceURI;
    },
    getTextNodeContent(textNode) {
      return textNode.value;
    },
    getCommentNodeContent(commentNode) {
      return commentNode.data;
    },
    getDocumentTypeNodeName(doctypeNode) {
      return doctypeNode.name;
    },
    getDocumentTypeNodePublicId(doctypeNode) {
      return doctypeNode.publicId;
    },
    getDocumentTypeNodeSystemId(doctypeNode) {
      return doctypeNode.systemId;
    },
    //Node types
    isTextNode(node) {
      return node.nodeName === "#text";
    },
    isCommentNode(node) {
      return node.nodeName === "#comment";
    },
    isDocumentTypeNode(node) {
      return node.nodeName === "#documentType";
    },
    isElementNode(node) {
      return Object.prototype.hasOwnProperty.call(node, "tagName");
    },
    // Source code location
    setNodeSourceCodeLocation(node, location) {
      node.sourceCodeLocation = location;
    },
    getNodeSourceCodeLocation(node) {
      return node.sourceCodeLocation;
    },
    updateNodeSourceCodeLocation(node, endLocation) {
      node.sourceCodeLocation = { ...node.sourceCodeLocation, ...endLocation };
    }
  };
  const VALID_DOCTYPE_NAME = "html";
  const VALID_SYSTEM_ID = "about:legacy-compat";
  const QUIRKS_MODE_SYSTEM_ID = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd";
  const QUIRKS_MODE_PUBLIC_ID_PREFIXES = [
    "+//silmaril//dtd html pro v0r11 19970101//",
    "-//as//dtd html 3.0 aswedit + extensions//",
    "-//advasoft ltd//dtd html 3.0 aswedit + extensions//",
    "-//ietf//dtd html 2.0 level 1//",
    "-//ietf//dtd html 2.0 level 2//",
    "-//ietf//dtd html 2.0 strict level 1//",
    "-//ietf//dtd html 2.0 strict level 2//",
    "-//ietf//dtd html 2.0 strict//",
    "-//ietf//dtd html 2.0//",
    "-//ietf//dtd html 2.1e//",
    "-//ietf//dtd html 3.0//",
    "-//ietf//dtd html 3.2 final//",
    "-//ietf//dtd html 3.2//",
    "-//ietf//dtd html 3//",
    "-//ietf//dtd html level 0//",
    "-//ietf//dtd html level 1//",
    "-//ietf//dtd html level 2//",
    "-//ietf//dtd html level 3//",
    "-//ietf//dtd html strict level 0//",
    "-//ietf//dtd html strict level 1//",
    "-//ietf//dtd html strict level 2//",
    "-//ietf//dtd html strict level 3//",
    "-//ietf//dtd html strict//",
    "-//ietf//dtd html//",
    "-//metrius//dtd metrius presentational//",
    "-//microsoft//dtd internet explorer 2.0 html strict//",
    "-//microsoft//dtd internet explorer 2.0 html//",
    "-//microsoft//dtd internet explorer 2.0 tables//",
    "-//microsoft//dtd internet explorer 3.0 html strict//",
    "-//microsoft//dtd internet explorer 3.0 html//",
    "-//microsoft//dtd internet explorer 3.0 tables//",
    "-//netscape comm. corp.//dtd html//",
    "-//netscape comm. corp.//dtd strict html//",
    "-//o'reilly and associates//dtd html 2.0//",
    "-//o'reilly and associates//dtd html extended 1.0//",
    "-//o'reilly and associates//dtd html extended relaxed 1.0//",
    "-//sq//dtd html 2.0 hotmetal + extensions//",
    "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//",
    "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//",
    "-//spyglass//dtd html 2.0 extended//",
    "-//sun microsystems corp.//dtd hotjava html//",
    "-//sun microsystems corp.//dtd hotjava strict html//",
    "-//w3c//dtd html 3 1995-03-24//",
    "-//w3c//dtd html 3.2 draft//",
    "-//w3c//dtd html 3.2 final//",
    "-//w3c//dtd html 3.2//",
    "-//w3c//dtd html 3.2s draft//",
    "-//w3c//dtd html 4.0 frameset//",
    "-//w3c//dtd html 4.0 transitional//",
    "-//w3c//dtd html experimental 19960712//",
    "-//w3c//dtd html experimental 970421//",
    "-//w3c//dtd w3 html//",
    "-//w3o//dtd w3 html 3.0//",
    "-//webtechs//dtd mozilla html 2.0//",
    "-//webtechs//dtd mozilla html//"
  ];
  const QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
    ...QUIRKS_MODE_PUBLIC_ID_PREFIXES,
    "-//w3c//dtd html 4.01 frameset//",
    "-//w3c//dtd html 4.01 transitional//"
  ];
  const QUIRKS_MODE_PUBLIC_IDS = /* @__PURE__ */ new Set([
    "-//w3o//dtd w3 html strict 3.0//en//",
    "-/w3c/dtd html 4.0 transitional/en",
    "html"
  ]);
  const LIMITED_QUIRKS_PUBLIC_ID_PREFIXES = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"];
  const LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES = [
    ...LIMITED_QUIRKS_PUBLIC_ID_PREFIXES,
    "-//w3c//dtd html 4.01 frameset//",
    "-//w3c//dtd html 4.01 transitional//"
  ];
  function hasPrefix(publicId, prefixes) {
    return prefixes.some((prefix) => publicId.startsWith(prefix));
  }
  function isConforming(token) {
    return token.name === VALID_DOCTYPE_NAME && token.publicId === null && (token.systemId === null || token.systemId === VALID_SYSTEM_ID);
  }
  function getDocumentMode(token) {
    if (token.name !== VALID_DOCTYPE_NAME) {
      return DOCUMENT_MODE.QUIRKS;
    }
    const { systemId } = token;
    if (systemId && systemId.toLowerCase() === QUIRKS_MODE_SYSTEM_ID) {
      return DOCUMENT_MODE.QUIRKS;
    }
    let { publicId } = token;
    if (publicId !== null) {
      publicId = publicId.toLowerCase();
      if (QUIRKS_MODE_PUBLIC_IDS.has(publicId)) {
        return DOCUMENT_MODE.QUIRKS;
      }
      let prefixes = systemId === null ? QUIRKS_MODE_NO_SYSTEM_ID_PUBLIC_ID_PREFIXES : QUIRKS_MODE_PUBLIC_ID_PREFIXES;
      if (hasPrefix(publicId, prefixes)) {
        return DOCUMENT_MODE.QUIRKS;
      }
      prefixes = systemId === null ? LIMITED_QUIRKS_PUBLIC_ID_PREFIXES : LIMITED_QUIRKS_WITH_SYSTEM_ID_PUBLIC_ID_PREFIXES;
      if (hasPrefix(publicId, prefixes)) {
        return DOCUMENT_MODE.LIMITED_QUIRKS;
      }
    }
    return DOCUMENT_MODE.NO_QUIRKS;
  }
  const MIME_TYPES = {
    TEXT_HTML: "text/html",
    APPLICATION_XML: "application/xhtml+xml"
  };
  const DEFINITION_URL_ATTR = "definitionurl";
  const ADJUSTED_DEFINITION_URL_ATTR = "definitionURL";
  const SVG_ATTRS_ADJUSTMENT_MAP = new Map([
    "attributeName",
    "attributeType",
    "baseFrequency",
    "baseProfile",
    "calcMode",
    "clipPathUnits",
    "diffuseConstant",
    "edgeMode",
    "filterUnits",
    "glyphRef",
    "gradientTransform",
    "gradientUnits",
    "kernelMatrix",
    "kernelUnitLength",
    "keyPoints",
    "keySplines",
    "keyTimes",
    "lengthAdjust",
    "limitingConeAngle",
    "markerHeight",
    "markerUnits",
    "markerWidth",
    "maskContentUnits",
    "maskUnits",
    "numOctaves",
    "pathLength",
    "patternContentUnits",
    "patternTransform",
    "patternUnits",
    "pointsAtX",
    "pointsAtY",
    "pointsAtZ",
    "preserveAlpha",
    "preserveAspectRatio",
    "primitiveUnits",
    "refX",
    "refY",
    "repeatCount",
    "repeatDur",
    "requiredExtensions",
    "requiredFeatures",
    "specularConstant",
    "specularExponent",
    "spreadMethod",
    "startOffset",
    "stdDeviation",
    "stitchTiles",
    "surfaceScale",
    "systemLanguage",
    "tableValues",
    "targetX",
    "targetY",
    "textLength",
    "viewBox",
    "viewTarget",
    "xChannelSelector",
    "yChannelSelector",
    "zoomAndPan"
  ].map((attr) => [attr.toLowerCase(), attr]));
  const XML_ATTRS_ADJUSTMENT_MAP = /* @__PURE__ */ new Map([
    ["xlink:actuate", { prefix: "xlink", name: "actuate", namespace: NS.XLINK }],
    ["xlink:arcrole", { prefix: "xlink", name: "arcrole", namespace: NS.XLINK }],
    ["xlink:href", { prefix: "xlink", name: "href", namespace: NS.XLINK }],
    ["xlink:role", { prefix: "xlink", name: "role", namespace: NS.XLINK }],
    ["xlink:show", { prefix: "xlink", name: "show", namespace: NS.XLINK }],
    ["xlink:title", { prefix: "xlink", name: "title", namespace: NS.XLINK }],
    ["xlink:type", { prefix: "xlink", name: "type", namespace: NS.XLINK }],
    ["xml:lang", { prefix: "xml", name: "lang", namespace: NS.XML }],
    ["xml:space", { prefix: "xml", name: "space", namespace: NS.XML }],
    ["xmlns", { prefix: "", name: "xmlns", namespace: NS.XMLNS }],
    ["xmlns:xlink", { prefix: "xmlns", name: "xlink", namespace: NS.XMLNS }]
  ]);
  const SVG_TAG_NAMES_ADJUSTMENT_MAP = new Map([
    "altGlyph",
    "altGlyphDef",
    "altGlyphItem",
    "animateColor",
    "animateMotion",
    "animateTransform",
    "clipPath",
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
    "foreignObject",
    "glyphRef",
    "linearGradient",
    "radialGradient",
    "textPath"
  ].map((tn2) => [tn2.toLowerCase(), tn2]));
  const EXITS_FOREIGN_CONTENT = /* @__PURE__ */ new Set([
    TAG_ID.B,
    TAG_ID.BIG,
    TAG_ID.BLOCKQUOTE,
    TAG_ID.BODY,
    TAG_ID.BR,
    TAG_ID.CENTER,
    TAG_ID.CODE,
    TAG_ID.DD,
    TAG_ID.DIV,
    TAG_ID.DL,
    TAG_ID.DT,
    TAG_ID.EM,
    TAG_ID.EMBED,
    TAG_ID.H1,
    TAG_ID.H2,
    TAG_ID.H3,
    TAG_ID.H4,
    TAG_ID.H5,
    TAG_ID.H6,
    TAG_ID.HEAD,
    TAG_ID.HR,
    TAG_ID.I,
    TAG_ID.IMG,
    TAG_ID.LI,
    TAG_ID.LISTING,
    TAG_ID.MENU,
    TAG_ID.META,
    TAG_ID.NOBR,
    TAG_ID.OL,
    TAG_ID.P,
    TAG_ID.PRE,
    TAG_ID.RUBY,
    TAG_ID.S,
    TAG_ID.SMALL,
    TAG_ID.SPAN,
    TAG_ID.STRONG,
    TAG_ID.STRIKE,
    TAG_ID.SUB,
    TAG_ID.SUP,
    TAG_ID.TABLE,
    TAG_ID.TT,
    TAG_ID.U,
    TAG_ID.UL,
    TAG_ID.VAR
  ]);
  function causesExit(startTagToken) {
    const tn2 = startTagToken.tagID;
    const isFontWithAttrs = tn2 === TAG_ID.FONT && startTagToken.attrs.some(({ name }) => name === ATTRS.COLOR || name === ATTRS.SIZE || name === ATTRS.FACE);
    return isFontWithAttrs || EXITS_FOREIGN_CONTENT.has(tn2);
  }
  function adjustTokenMathMLAttrs(token) {
    for (let i = 0; i < token.attrs.length; i++) {
      if (token.attrs[i].name === DEFINITION_URL_ATTR) {
        token.attrs[i].name = ADJUSTED_DEFINITION_URL_ATTR;
        break;
      }
    }
  }
  function adjustTokenSVGAttrs(token) {
    for (let i = 0; i < token.attrs.length; i++) {
      const adjustedAttrName = SVG_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i].name);
      if (adjustedAttrName != null) {
        token.attrs[i].name = adjustedAttrName;
      }
    }
  }
  function adjustTokenXMLAttrs(token) {
    for (let i = 0; i < token.attrs.length; i++) {
      const adjustedAttrEntry = XML_ATTRS_ADJUSTMENT_MAP.get(token.attrs[i].name);
      if (adjustedAttrEntry) {
        token.attrs[i].prefix = adjustedAttrEntry.prefix;
        token.attrs[i].name = adjustedAttrEntry.name;
        token.attrs[i].namespace = adjustedAttrEntry.namespace;
      }
    }
  }
  function adjustTokenSVGTagName(token) {
    const adjustedTagName = SVG_TAG_NAMES_ADJUSTMENT_MAP.get(token.tagName);
    if (adjustedTagName != null) {
      token.tagName = adjustedTagName;
      token.tagID = getTagID(token.tagName);
    }
  }
  function isMathMLTextIntegrationPoint(tn2, ns2) {
    return ns2 === NS.MATHML && (tn2 === TAG_ID.MI || tn2 === TAG_ID.MO || tn2 === TAG_ID.MN || tn2 === TAG_ID.MS || tn2 === TAG_ID.MTEXT);
  }
  function isHtmlIntegrationPoint(tn2, ns2, attrs) {
    if (ns2 === NS.MATHML && tn2 === TAG_ID.ANNOTATION_XML) {
      for (let i = 0; i < attrs.length; i++) {
        if (attrs[i].name === ATTRS.ENCODING) {
          const value = attrs[i].value.toLowerCase();
          return value === MIME_TYPES.TEXT_HTML || value === MIME_TYPES.APPLICATION_XML;
        }
      }
    }
    return ns2 === NS.SVG && (tn2 === TAG_ID.FOREIGN_OBJECT || tn2 === TAG_ID.DESC || tn2 === TAG_ID.TITLE);
  }
  function isIntegrationPoint(tn2, ns2, attrs, foreignNS) {
    return (!foreignNS || foreignNS === NS.HTML) && isHtmlIntegrationPoint(tn2, ns2, attrs) || (!foreignNS || foreignNS === NS.MATHML) && isMathMLTextIntegrationPoint(tn2, ns2);
  }
  const HIDDEN_INPUT_TYPE = "hidden";
  const AA_OUTER_LOOP_ITER = 8;
  const AA_INNER_LOOP_ITER = 3;
  var InsertionMode;
  (function(InsertionMode2) {
    InsertionMode2[InsertionMode2["INITIAL"] = 0] = "INITIAL";
    InsertionMode2[InsertionMode2["BEFORE_HTML"] = 1] = "BEFORE_HTML";
    InsertionMode2[InsertionMode2["BEFORE_HEAD"] = 2] = "BEFORE_HEAD";
    InsertionMode2[InsertionMode2["IN_HEAD"] = 3] = "IN_HEAD";
    InsertionMode2[InsertionMode2["IN_HEAD_NO_SCRIPT"] = 4] = "IN_HEAD_NO_SCRIPT";
    InsertionMode2[InsertionMode2["AFTER_HEAD"] = 5] = "AFTER_HEAD";
    InsertionMode2[InsertionMode2["IN_BODY"] = 6] = "IN_BODY";
    InsertionMode2[InsertionMode2["TEXT"] = 7] = "TEXT";
    InsertionMode2[InsertionMode2["IN_TABLE"] = 8] = "IN_TABLE";
    InsertionMode2[InsertionMode2["IN_TABLE_TEXT"] = 9] = "IN_TABLE_TEXT";
    InsertionMode2[InsertionMode2["IN_CAPTION"] = 10] = "IN_CAPTION";
    InsertionMode2[InsertionMode2["IN_COLUMN_GROUP"] = 11] = "IN_COLUMN_GROUP";
    InsertionMode2[InsertionMode2["IN_TABLE_BODY"] = 12] = "IN_TABLE_BODY";
    InsertionMode2[InsertionMode2["IN_ROW"] = 13] = "IN_ROW";
    InsertionMode2[InsertionMode2["IN_CELL"] = 14] = "IN_CELL";
    InsertionMode2[InsertionMode2["IN_SELECT"] = 15] = "IN_SELECT";
    InsertionMode2[InsertionMode2["IN_SELECT_IN_TABLE"] = 16] = "IN_SELECT_IN_TABLE";
    InsertionMode2[InsertionMode2["IN_TEMPLATE"] = 17] = "IN_TEMPLATE";
    InsertionMode2[InsertionMode2["AFTER_BODY"] = 18] = "AFTER_BODY";
    InsertionMode2[InsertionMode2["IN_FRAMESET"] = 19] = "IN_FRAMESET";
    InsertionMode2[InsertionMode2["AFTER_FRAMESET"] = 20] = "AFTER_FRAMESET";
    InsertionMode2[InsertionMode2["AFTER_AFTER_BODY"] = 21] = "AFTER_AFTER_BODY";
    InsertionMode2[InsertionMode2["AFTER_AFTER_FRAMESET"] = 22] = "AFTER_AFTER_FRAMESET";
  })(InsertionMode || (InsertionMode = {}));
  const BASE_LOC = {
    startLine: -1,
    startCol: -1,
    startOffset: -1,
    endLine: -1,
    endCol: -1,
    endOffset: -1
  };
  const TABLE_STRUCTURE_TAGS = /* @__PURE__ */ new Set([TAG_ID.TABLE, TAG_ID.TBODY, TAG_ID.TFOOT, TAG_ID.THEAD, TAG_ID.TR]);
  const defaultParserOptions = {
    scriptingEnabled: true,
    sourceCodeLocationInfo: false,
    treeAdapter: defaultTreeAdapter,
    onParseError: null
  };
  class Parser {
    constructor(options, document, fragmentContext = null, scriptHandler = null) {
      this.fragmentContext = fragmentContext;
      this.scriptHandler = scriptHandler;
      this.currentToken = null;
      this.stopped = false;
      this.insertionMode = InsertionMode.INITIAL;
      this.originalInsertionMode = InsertionMode.INITIAL;
      this.headElement = null;
      this.formElement = null;
      this.currentNotInHTML = false;
      this.tmplInsertionModeStack = [];
      this.pendingCharacterTokens = [];
      this.hasNonWhitespacePendingCharacterToken = false;
      this.framesetOk = true;
      this.skipNextNewLine = false;
      this.fosterParentingEnabled = false;
      this.options = {
        ...defaultParserOptions,
        ...options
      };
      this.treeAdapter = this.options.treeAdapter;
      this.onParseError = this.options.onParseError;
      if (this.onParseError) {
        this.options.sourceCodeLocationInfo = true;
      }
      this.document = document !== null && document !== void 0 ? document : this.treeAdapter.createDocument();
      this.tokenizer = new Tokenizer(this.options, this);
      this.activeFormattingElements = new FormattingElementList(this.treeAdapter);
      this.fragmentContextID = fragmentContext ? getTagID(this.treeAdapter.getTagName(fragmentContext)) : TAG_ID.UNKNOWN;
      this._setContextModes(fragmentContext !== null && fragmentContext !== void 0 ? fragmentContext : this.document, this.fragmentContextID);
      this.openElements = new OpenElementStack(this.document, this.treeAdapter, this);
    }
    // API
    static parse(html, options) {
      const parser = new this(options);
      parser.tokenizer.write(html, true);
      return parser.document;
    }
    static getFragmentParser(fragmentContext, options) {
      const opts = {
        ...defaultParserOptions,
        ...options
      };
      fragmentContext !== null && fragmentContext !== void 0 ? fragmentContext : fragmentContext = opts.treeAdapter.createElement(TAG_NAMES.TEMPLATE, NS.HTML, []);
      const documentMock = opts.treeAdapter.createElement("documentmock", NS.HTML, []);
      const parser = new this(opts, documentMock, fragmentContext);
      if (parser.fragmentContextID === TAG_ID.TEMPLATE) {
        parser.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
      }
      parser._initTokenizerForFragmentParsing();
      parser._insertFakeRootElement();
      parser._resetInsertionMode();
      parser._findFormInFragmentContext();
      return parser;
    }
    getFragment() {
      const rootElement = this.treeAdapter.getFirstChild(this.document);
      const fragment = this.treeAdapter.createDocumentFragment();
      this._adoptNodes(rootElement, fragment);
      return fragment;
    }
    //Errors
    /** @internal */
    _err(token, code, beforeToken) {
      var _a2;
      if (!this.onParseError)
        return;
      const loc = (_a2 = token.location) !== null && _a2 !== void 0 ? _a2 : BASE_LOC;
      const err = {
        code,
        startLine: loc.startLine,
        startCol: loc.startCol,
        startOffset: loc.startOffset,
        endLine: beforeToken ? loc.startLine : loc.endLine,
        endCol: beforeToken ? loc.startCol : loc.endCol,
        endOffset: beforeToken ? loc.startOffset : loc.endOffset
      };
      this.onParseError(err);
    }
    //Stack events
    /** @internal */
    onItemPush(node, tid, isTop) {
      var _a2, _b;
      (_b = (_a2 = this.treeAdapter).onItemPush) === null || _b === void 0 ? void 0 : _b.call(_a2, node);
      if (isTop && this.openElements.stackTop > 0)
        this._setContextModes(node, tid);
    }
    /** @internal */
    onItemPop(node, isTop) {
      var _a2, _b;
      if (this.options.sourceCodeLocationInfo) {
        this._setEndLocation(node, this.currentToken);
      }
      (_b = (_a2 = this.treeAdapter).onItemPop) === null || _b === void 0 ? void 0 : _b.call(_a2, node, this.openElements.current);
      if (isTop) {
        let current;
        let currentTagId;
        if (this.openElements.stackTop === 0 && this.fragmentContext) {
          current = this.fragmentContext;
          currentTagId = this.fragmentContextID;
        } else {
          ({ current, currentTagId } = this.openElements);
        }
        this._setContextModes(current, currentTagId);
      }
    }
    _setContextModes(current, tid) {
      const isHTML = current === this.document || current && this.treeAdapter.getNamespaceURI(current) === NS.HTML;
      this.currentNotInHTML = !isHTML;
      this.tokenizer.inForeignNode = !isHTML && current !== void 0 && tid !== void 0 && !this._isIntegrationPoint(tid, current);
    }
    /** @protected */
    _switchToTextParsing(currentToken, nextTokenizerState) {
      this._insertElement(currentToken, NS.HTML);
      this.tokenizer.state = nextTokenizerState;
      this.originalInsertionMode = this.insertionMode;
      this.insertionMode = InsertionMode.TEXT;
    }
    switchToPlaintextParsing() {
      this.insertionMode = InsertionMode.TEXT;
      this.originalInsertionMode = InsertionMode.IN_BODY;
      this.tokenizer.state = TokenizerMode.PLAINTEXT;
    }
    //Fragment parsing
    /** @protected */
    _getAdjustedCurrentElement() {
      return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
    }
    /** @protected */
    _findFormInFragmentContext() {
      let node = this.fragmentContext;
      while (node) {
        if (this.treeAdapter.getTagName(node) === TAG_NAMES.FORM) {
          this.formElement = node;
          break;
        }
        node = this.treeAdapter.getParentNode(node);
      }
    }
    _initTokenizerForFragmentParsing() {
      if (!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== NS.HTML) {
        return;
      }
      switch (this.fragmentContextID) {
        case TAG_ID.TITLE:
        case TAG_ID.TEXTAREA: {
          this.tokenizer.state = TokenizerMode.RCDATA;
          break;
        }
        case TAG_ID.STYLE:
        case TAG_ID.XMP:
        case TAG_ID.IFRAME:
        case TAG_ID.NOEMBED:
        case TAG_ID.NOFRAMES:
        case TAG_ID.NOSCRIPT: {
          this.tokenizer.state = TokenizerMode.RAWTEXT;
          break;
        }
        case TAG_ID.SCRIPT: {
          this.tokenizer.state = TokenizerMode.SCRIPT_DATA;
          break;
        }
        case TAG_ID.PLAINTEXT: {
          this.tokenizer.state = TokenizerMode.PLAINTEXT;
          break;
        }
      }
    }
    //Tree mutation
    /** @protected */
    _setDocumentType(token) {
      const name = token.name || "";
      const publicId = token.publicId || "";
      const systemId = token.systemId || "";
      this.treeAdapter.setDocumentType(this.document, name, publicId, systemId);
      if (token.location) {
        const documentChildren = this.treeAdapter.getChildNodes(this.document);
        const docTypeNode = documentChildren.find((node) => this.treeAdapter.isDocumentTypeNode(node));
        if (docTypeNode) {
          this.treeAdapter.setNodeSourceCodeLocation(docTypeNode, token.location);
        }
      }
    }
    /** @protected */
    _attachElementToTree(element, location) {
      if (this.options.sourceCodeLocationInfo) {
        const loc = location && {
          ...location,
          startTag: location
        };
        this.treeAdapter.setNodeSourceCodeLocation(element, loc);
      }
      if (this._shouldFosterParentOnInsertion()) {
        this._fosterParentElement(element);
      } else {
        const parent = this.openElements.currentTmplContentOrNode;
        this.treeAdapter.appendChild(parent !== null && parent !== void 0 ? parent : this.document, element);
      }
    }
    /**
     * For self-closing tags. Add an element to the tree, but skip adding it
     * to the stack.
     */
    /** @protected */
    _appendElement(token, namespaceURI) {
      const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
      this._attachElementToTree(element, token.location);
    }
    /** @protected */
    _insertElement(token, namespaceURI) {
      const element = this.treeAdapter.createElement(token.tagName, namespaceURI, token.attrs);
      this._attachElementToTree(element, token.location);
      this.openElements.push(element, token.tagID);
    }
    /** @protected */
    _insertFakeElement(tagName, tagID) {
      const element = this.treeAdapter.createElement(tagName, NS.HTML, []);
      this._attachElementToTree(element, null);
      this.openElements.push(element, tagID);
    }
    /** @protected */
    _insertTemplate(token) {
      const tmpl = this.treeAdapter.createElement(token.tagName, NS.HTML, token.attrs);
      const content = this.treeAdapter.createDocumentFragment();
      this.treeAdapter.setTemplateContent(tmpl, content);
      this._attachElementToTree(tmpl, token.location);
      this.openElements.push(tmpl, token.tagID);
      if (this.options.sourceCodeLocationInfo)
        this.treeAdapter.setNodeSourceCodeLocation(content, null);
    }
    /** @protected */
    _insertFakeRootElement() {
      const element = this.treeAdapter.createElement(TAG_NAMES.HTML, NS.HTML, []);
      if (this.options.sourceCodeLocationInfo)
        this.treeAdapter.setNodeSourceCodeLocation(element, null);
      this.treeAdapter.appendChild(this.openElements.current, element);
      this.openElements.push(element, TAG_ID.HTML);
    }
    /** @protected */
    _appendCommentNode(token, parent) {
      const commentNode = this.treeAdapter.createCommentNode(token.data);
      this.treeAdapter.appendChild(parent, commentNode);
      if (this.options.sourceCodeLocationInfo) {
        this.treeAdapter.setNodeSourceCodeLocation(commentNode, token.location);
      }
    }
    /** @protected */
    _insertCharacters(token) {
      let parent;
      let beforeElement;
      if (this._shouldFosterParentOnInsertion()) {
        ({ parent, beforeElement } = this._findFosterParentingLocation());
        if (beforeElement) {
          this.treeAdapter.insertTextBefore(parent, token.chars, beforeElement);
        } else {
          this.treeAdapter.insertText(parent, token.chars);
        }
      } else {
        parent = this.openElements.currentTmplContentOrNode;
        this.treeAdapter.insertText(parent, token.chars);
      }
      if (!token.location)
        return;
      const siblings = this.treeAdapter.getChildNodes(parent);
      const textNodeIdx = beforeElement ? siblings.lastIndexOf(beforeElement) : siblings.length;
      const textNode = siblings[textNodeIdx - 1];
      const tnLoc = this.treeAdapter.getNodeSourceCodeLocation(textNode);
      if (tnLoc) {
        const { endLine, endCol, endOffset } = token.location;
        this.treeAdapter.updateNodeSourceCodeLocation(textNode, { endLine, endCol, endOffset });
      } else if (this.options.sourceCodeLocationInfo) {
        this.treeAdapter.setNodeSourceCodeLocation(textNode, token.location);
      }
    }
    /** @protected */
    _adoptNodes(donor, recipient) {
      for (let child = this.treeAdapter.getFirstChild(donor); child; child = this.treeAdapter.getFirstChild(donor)) {
        this.treeAdapter.detachNode(child);
        this.treeAdapter.appendChild(recipient, child);
      }
    }
    /** @protected */
    _setEndLocation(element, closingToken) {
      if (this.treeAdapter.getNodeSourceCodeLocation(element) && closingToken.location) {
        const ctLoc = closingToken.location;
        const tn2 = this.treeAdapter.getTagName(element);
        const endLoc = (
          // NOTE: For cases like <p> <p> </p> - First 'p' closes without a closing
          // tag and for cases like <td> <p> </td> - 'p' closes without a closing tag.
          closingToken.type === TokenType.END_TAG && tn2 === closingToken.tagName ? {
            endTag: { ...ctLoc },
            endLine: ctLoc.endLine,
            endCol: ctLoc.endCol,
            endOffset: ctLoc.endOffset
          } : {
            endLine: ctLoc.startLine,
            endCol: ctLoc.startCol,
            endOffset: ctLoc.startOffset
          }
        );
        this.treeAdapter.updateNodeSourceCodeLocation(element, endLoc);
      }
    }
    //Token processing
    shouldProcessStartTagTokenInForeignContent(token) {
      if (!this.currentNotInHTML)
        return false;
      let current;
      let currentTagId;
      if (this.openElements.stackTop === 0 && this.fragmentContext) {
        current = this.fragmentContext;
        currentTagId = this.fragmentContextID;
      } else {
        ({ current, currentTagId } = this.openElements);
      }
      if (token.tagID === TAG_ID.SVG && this.treeAdapter.getTagName(current) === TAG_NAMES.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(current) === NS.MATHML) {
        return false;
      }
      return (
        // Check that \`current\` is not an integration point for HTML or MathML elements.
        this.tokenizer.inForeignNode || // If it _is_ an integration point, then we might have to check that it is not an HTML
        // integration point.
        (token.tagID === TAG_ID.MGLYPH || token.tagID === TAG_ID.MALIGNMARK) && currentTagId !== void 0 && !this._isIntegrationPoint(currentTagId, current, NS.HTML)
      );
    }
    /** @protected */
    _processToken(token) {
      switch (token.type) {
        case TokenType.CHARACTER: {
          this.onCharacter(token);
          break;
        }
        case TokenType.NULL_CHARACTER: {
          this.onNullCharacter(token);
          break;
        }
        case TokenType.COMMENT: {
          this.onComment(token);
          break;
        }
        case TokenType.DOCTYPE: {
          this.onDoctype(token);
          break;
        }
        case TokenType.START_TAG: {
          this._processStartTag(token);
          break;
        }
        case TokenType.END_TAG: {
          this.onEndTag(token);
          break;
        }
        case TokenType.EOF: {
          this.onEof(token);
          break;
        }
        case TokenType.WHITESPACE_CHARACTER: {
          this.onWhitespaceCharacter(token);
          break;
        }
      }
    }
    //Integration points
    /** @protected */
    _isIntegrationPoint(tid, element, foreignNS) {
      const ns2 = this.treeAdapter.getNamespaceURI(element);
      const attrs = this.treeAdapter.getAttrList(element);
      return isIntegrationPoint(tid, ns2, attrs, foreignNS);
    }
    //Active formatting elements reconstruction
    /** @protected */
    _reconstructActiveFormattingElements() {
      const listLength = this.activeFormattingElements.entries.length;
      if (listLength) {
        const endIndex = this.activeFormattingElements.entries.findIndex((entry) => entry.type === EntryType.Marker || this.openElements.contains(entry.element));
        const unopenIdx = endIndex === -1 ? listLength - 1 : endIndex - 1;
        for (let i = unopenIdx; i >= 0; i--) {
          const entry = this.activeFormattingElements.entries[i];
          this._insertElement(entry.token, this.treeAdapter.getNamespaceURI(entry.element));
          entry.element = this.openElements.current;
        }
      }
    }
    //Close elements
    /** @protected */
    _closeTableCell() {
      this.openElements.generateImpliedEndTags();
      this.openElements.popUntilTableCellPopped();
      this.activeFormattingElements.clearToLastMarker();
      this.insertionMode = InsertionMode.IN_ROW;
    }
    /** @protected */
    _closePElement() {
      this.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.P);
      this.openElements.popUntilTagNamePopped(TAG_ID.P);
    }
    //Insertion modes
    /** @protected */
    _resetInsertionMode() {
      for (let i = this.openElements.stackTop; i >= 0; i--) {
        switch (i === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[i]) {
          case TAG_ID.TR: {
            this.insertionMode = InsertionMode.IN_ROW;
            return;
          }
          case TAG_ID.TBODY:
          case TAG_ID.THEAD:
          case TAG_ID.TFOOT: {
            this.insertionMode = InsertionMode.IN_TABLE_BODY;
            return;
          }
          case TAG_ID.CAPTION: {
            this.insertionMode = InsertionMode.IN_CAPTION;
            return;
          }
          case TAG_ID.COLGROUP: {
            this.insertionMode = InsertionMode.IN_COLUMN_GROUP;
            return;
          }
          case TAG_ID.TABLE: {
            this.insertionMode = InsertionMode.IN_TABLE;
            return;
          }
          case TAG_ID.BODY: {
            this.insertionMode = InsertionMode.IN_BODY;
            return;
          }
          case TAG_ID.FRAMESET: {
            this.insertionMode = InsertionMode.IN_FRAMESET;
            return;
          }
          case TAG_ID.SELECT: {
            this._resetInsertionModeForSelect(i);
            return;
          }
          case TAG_ID.TEMPLATE: {
            this.insertionMode = this.tmplInsertionModeStack[0];
            return;
          }
          case TAG_ID.HTML: {
            this.insertionMode = this.headElement ? InsertionMode.AFTER_HEAD : InsertionMode.BEFORE_HEAD;
            return;
          }
          case TAG_ID.TD:
          case TAG_ID.TH: {
            if (i > 0) {
              this.insertionMode = InsertionMode.IN_CELL;
              return;
            }
            break;
          }
          case TAG_ID.HEAD: {
            if (i > 0) {
              this.insertionMode = InsertionMode.IN_HEAD;
              return;
            }
            break;
          }
        }
      }
      this.insertionMode = InsertionMode.IN_BODY;
    }
    /** @protected */
    _resetInsertionModeForSelect(selectIdx) {
      if (selectIdx > 0) {
        for (let i = selectIdx - 1; i > 0; i--) {
          const tn2 = this.openElements.tagIDs[i];
          if (tn2 === TAG_ID.TEMPLATE) {
            break;
          } else if (tn2 === TAG_ID.TABLE) {
            this.insertionMode = InsertionMode.IN_SELECT_IN_TABLE;
            return;
          }
        }
      }
      this.insertionMode = InsertionMode.IN_SELECT;
    }
    //Foster parenting
    /** @protected */
    _isElementCausesFosterParenting(tn2) {
      return TABLE_STRUCTURE_TAGS.has(tn2);
    }
    /** @protected */
    _shouldFosterParentOnInsertion() {
      return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
    }
    /** @protected */
    _findFosterParentingLocation() {
      for (let i = this.openElements.stackTop; i >= 0; i--) {
        const openElement = this.openElements.items[i];
        switch (this.openElements.tagIDs[i]) {
          case TAG_ID.TEMPLATE: {
            if (this.treeAdapter.getNamespaceURI(openElement) === NS.HTML) {
              return { parent: this.treeAdapter.getTemplateContent(openElement), beforeElement: null };
            }
            break;
          }
          case TAG_ID.TABLE: {
            const parent = this.treeAdapter.getParentNode(openElement);
            if (parent) {
              return { parent, beforeElement: openElement };
            }
            return { parent: this.openElements.items[i - 1], beforeElement: null };
          }
        }
      }
      return { parent: this.openElements.items[0], beforeElement: null };
    }
    /** @protected */
    _fosterParentElement(element) {
      const location = this._findFosterParentingLocation();
      if (location.beforeElement) {
        this.treeAdapter.insertBefore(location.parent, element, location.beforeElement);
      } else {
        this.treeAdapter.appendChild(location.parent, element);
      }
    }
    //Special elements
    /** @protected */
    _isSpecialElement(element, id) {
      const ns2 = this.treeAdapter.getNamespaceURI(element);
      return SPECIAL_ELEMENTS[ns2].has(id);
    }
    /** @internal */
    onCharacter(token) {
      this.skipNextNewLine = false;
      if (this.tokenizer.inForeignNode) {
        characterInForeignContent(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_TEMPLATE: {
          characterInBody(this, token);
          break;
        }
        case InsertionMode.TEXT:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          characterInTableText(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          tokenInColumnGroup(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          tokenAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
      }
    }
    /** @internal */
    onNullCharacter(token) {
      this.skipNextNewLine = false;
      if (this.tokenizer.inForeignNode) {
        nullCharacterInForeignContent(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          tokenInColumnGroup(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          tokenAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
      }
    }
    /** @internal */
    onComment(token) {
      this.skipNextNewLine = false;
      if (this.currentNotInHTML) {
        appendComment(this, token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.INITIAL:
        case InsertionMode.BEFORE_HTML:
        case InsertionMode.BEFORE_HEAD:
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD:
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE:
        case InsertionMode.IN_TEMPLATE:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET: {
          appendComment(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          appendCommentToRootHtmlElement(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          appendCommentToDocument(this, token);
          break;
        }
      }
    }
    /** @internal */
    onDoctype(token) {
      this.skipNextNewLine = false;
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          doctypeInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD:
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD: {
          this._err(token, ERR.misplacedDoctype);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
      }
    }
    /** @internal */
    onStartTag(token) {
      this.skipNextNewLine = false;
      this.currentToken = token;
      this._processStartTag(token);
      if (token.selfClosing && !token.ackSelfClosing) {
        this._err(token, ERR.nonVoidHtmlElementStartTagWithTrailingSolidus);
      }
    }
    /**
     * Processes a given start tag.
     *
     * \`onStartTag\` checks if a self-closing tag was recognized. When a token
     * is moved inbetween multiple insertion modes, this check for self-closing
     * could lead to false positives. To avoid this, \`_processStartTag\` is used
     * for nested calls.
     *
     * @param token The token to process.
     * @protected
     */
    _processStartTag(token) {
      if (this.shouldProcessStartTagTokenInForeignContent(token)) {
        startTagInForeignContent(this, token);
      } else {
        this._startTagOutsideForeignContent(token);
      }
    }
    /** @protected */
    _startTagOutsideForeignContent(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          startTagBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          startTagBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          startTagInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          startTagInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          startTagAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY: {
          startTagInBody(this, token);
          break;
        }
        case InsertionMode.IN_TABLE: {
          startTagInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_CAPTION: {
          startTagInCaption(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          startTagInColumnGroup(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_BODY: {
          startTagInTableBody(this, token);
          break;
        }
        case InsertionMode.IN_ROW: {
          startTagInRow(this, token);
          break;
        }
        case InsertionMode.IN_CELL: {
          startTagInCell(this, token);
          break;
        }
        case InsertionMode.IN_SELECT: {
          startTagInSelect(this, token);
          break;
        }
        case InsertionMode.IN_SELECT_IN_TABLE: {
          startTagInSelectInTable(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          startTagInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          startTagAfterBody(this, token);
          break;
        }
        case InsertionMode.IN_FRAMESET: {
          startTagInFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_FRAMESET: {
          startTagAfterFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          startTagAfterAfterBody(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          startTagAfterAfterFrameset(this, token);
          break;
        }
      }
    }
    /** @internal */
    onEndTag(token) {
      this.skipNextNewLine = false;
      this.currentToken = token;
      if (this.currentNotInHTML) {
        endTagInForeignContent(this, token);
      } else {
        this._endTagOutsideForeignContent(token);
      }
    }
    /** @protected */
    _endTagOutsideForeignContent(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          endTagBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          endTagBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          endTagInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          endTagInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          endTagAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY: {
          endTagInBody(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          endTagInText(this, token);
          break;
        }
        case InsertionMode.IN_TABLE: {
          endTagInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_CAPTION: {
          endTagInCaption(this, token);
          break;
        }
        case InsertionMode.IN_COLUMN_GROUP: {
          endTagInColumnGroup(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_BODY: {
          endTagInTableBody(this, token);
          break;
        }
        case InsertionMode.IN_ROW: {
          endTagInRow(this, token);
          break;
        }
        case InsertionMode.IN_CELL: {
          endTagInCell(this, token);
          break;
        }
        case InsertionMode.IN_SELECT: {
          endTagInSelect(this, token);
          break;
        }
        case InsertionMode.IN_SELECT_IN_TABLE: {
          endTagInSelectInTable(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          endTagInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY: {
          endTagAfterBody(this, token);
          break;
        }
        case InsertionMode.IN_FRAMESET: {
          endTagInFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_FRAMESET: {
          endTagAfterFrameset(this, token);
          break;
        }
        case InsertionMode.AFTER_AFTER_BODY: {
          tokenAfterAfterBody(this, token);
          break;
        }
      }
    }
    /** @internal */
    onEof(token) {
      switch (this.insertionMode) {
        case InsertionMode.INITIAL: {
          tokenInInitialMode(this, token);
          break;
        }
        case InsertionMode.BEFORE_HTML: {
          tokenBeforeHtml(this, token);
          break;
        }
        case InsertionMode.BEFORE_HEAD: {
          tokenBeforeHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD: {
          tokenInHead(this, token);
          break;
        }
        case InsertionMode.IN_HEAD_NO_SCRIPT: {
          tokenInHeadNoScript(this, token);
          break;
        }
        case InsertionMode.AFTER_HEAD: {
          tokenAfterHead(this, token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE: {
          eofInBody(this, token);
          break;
        }
        case InsertionMode.TEXT: {
          eofInText(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          tokenInTableText(this, token);
          break;
        }
        case InsertionMode.IN_TEMPLATE: {
          eofInTemplate(this, token);
          break;
        }
        case InsertionMode.AFTER_BODY:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET:
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          stopParsing(this, token);
          break;
        }
      }
    }
    /** @internal */
    onWhitespaceCharacter(token) {
      if (this.skipNextNewLine) {
        this.skipNextNewLine = false;
        if (token.chars.charCodeAt(0) === CODE_POINTS.LINE_FEED) {
          if (token.chars.length === 1) {
            return;
          }
          token.chars = token.chars.substr(1);
        }
      }
      if (this.tokenizer.inForeignNode) {
        this._insertCharacters(token);
        return;
      }
      switch (this.insertionMode) {
        case InsertionMode.IN_HEAD:
        case InsertionMode.IN_HEAD_NO_SCRIPT:
        case InsertionMode.AFTER_HEAD:
        case InsertionMode.TEXT:
        case InsertionMode.IN_COLUMN_GROUP:
        case InsertionMode.IN_SELECT:
        case InsertionMode.IN_SELECT_IN_TABLE:
        case InsertionMode.IN_FRAMESET:
        case InsertionMode.AFTER_FRAMESET: {
          this._insertCharacters(token);
          break;
        }
        case InsertionMode.IN_BODY:
        case InsertionMode.IN_CAPTION:
        case InsertionMode.IN_CELL:
        case InsertionMode.IN_TEMPLATE:
        case InsertionMode.AFTER_BODY:
        case InsertionMode.AFTER_AFTER_BODY:
        case InsertionMode.AFTER_AFTER_FRAMESET: {
          whitespaceCharacterInBody(this, token);
          break;
        }
        case InsertionMode.IN_TABLE:
        case InsertionMode.IN_TABLE_BODY:
        case InsertionMode.IN_ROW: {
          characterInTable(this, token);
          break;
        }
        case InsertionMode.IN_TABLE_TEXT: {
          whitespaceCharacterInTableText(this, token);
          break;
        }
      }
    }
  }
  function aaObtainFormattingElementEntry(p2, token) {
    let formattingElementEntry = p2.activeFormattingElements.getElementEntryInScopeWithTagName(token.tagName);
    if (formattingElementEntry) {
      if (!p2.openElements.contains(formattingElementEntry.element)) {
        p2.activeFormattingElements.removeEntry(formattingElementEntry);
        formattingElementEntry = null;
      } else if (!p2.openElements.hasInScope(token.tagID)) {
        formattingElementEntry = null;
      }
    } else {
      genericEndTagInBody(p2, token);
    }
    return formattingElementEntry;
  }
  function aaObtainFurthestBlock(p2, formattingElementEntry) {
    let furthestBlock = null;
    let idx = p2.openElements.stackTop;
    for (; idx >= 0; idx--) {
      const element = p2.openElements.items[idx];
      if (element === formattingElementEntry.element) {
        break;
      }
      if (p2._isSpecialElement(element, p2.openElements.tagIDs[idx])) {
        furthestBlock = element;
      }
    }
    if (!furthestBlock) {
      p2.openElements.shortenToLength(Math.max(idx, 0));
      p2.activeFormattingElements.removeEntry(formattingElementEntry);
    }
    return furthestBlock;
  }
  function aaInnerLoop(p2, furthestBlock, formattingElement) {
    let lastElement = furthestBlock;
    let nextElement = p2.openElements.getCommonAncestor(furthestBlock);
    for (let i = 0, element = nextElement; element !== formattingElement; i++, element = nextElement) {
      nextElement = p2.openElements.getCommonAncestor(element);
      const elementEntry = p2.activeFormattingElements.getElementEntry(element);
      const counterOverflow = elementEntry && i >= AA_INNER_LOOP_ITER;
      const shouldRemoveFromOpenElements = !elementEntry || counterOverflow;
      if (shouldRemoveFromOpenElements) {
        if (counterOverflow) {
          p2.activeFormattingElements.removeEntry(elementEntry);
        }
        p2.openElements.remove(element);
      } else {
        element = aaRecreateElementFromEntry(p2, elementEntry);
        if (lastElement === furthestBlock) {
          p2.activeFormattingElements.bookmark = elementEntry;
        }
        p2.treeAdapter.detachNode(lastElement);
        p2.treeAdapter.appendChild(element, lastElement);
        lastElement = element;
      }
    }
    return lastElement;
  }
  function aaRecreateElementFromEntry(p2, elementEntry) {
    const ns2 = p2.treeAdapter.getNamespaceURI(elementEntry.element);
    const newElement = p2.treeAdapter.createElement(elementEntry.token.tagName, ns2, elementEntry.token.attrs);
    p2.openElements.replace(elementEntry.element, newElement);
    elementEntry.element = newElement;
    return newElement;
  }
  function aaInsertLastNodeInCommonAncestor(p2, commonAncestor, lastElement) {
    const tn2 = p2.treeAdapter.getTagName(commonAncestor);
    const tid = getTagID(tn2);
    if (p2._isElementCausesFosterParenting(tid)) {
      p2._fosterParentElement(lastElement);
    } else {
      const ns2 = p2.treeAdapter.getNamespaceURI(commonAncestor);
      if (tid === TAG_ID.TEMPLATE && ns2 === NS.HTML) {
        commonAncestor = p2.treeAdapter.getTemplateContent(commonAncestor);
      }
      p2.treeAdapter.appendChild(commonAncestor, lastElement);
    }
  }
  function aaReplaceFormattingElement(p2, furthestBlock, formattingElementEntry) {
    const ns2 = p2.treeAdapter.getNamespaceURI(formattingElementEntry.element);
    const { token } = formattingElementEntry;
    const newElement = p2.treeAdapter.createElement(token.tagName, ns2, token.attrs);
    p2._adoptNodes(furthestBlock, newElement);
    p2.treeAdapter.appendChild(furthestBlock, newElement);
    p2.activeFormattingElements.insertElementAfterBookmark(newElement, token);
    p2.activeFormattingElements.removeEntry(formattingElementEntry);
    p2.openElements.remove(formattingElementEntry.element);
    p2.openElements.insertAfter(furthestBlock, newElement, token.tagID);
  }
  function callAdoptionAgency(p2, token) {
    for (let i = 0; i < AA_OUTER_LOOP_ITER; i++) {
      const formattingElementEntry = aaObtainFormattingElementEntry(p2, token);
      if (!formattingElementEntry) {
        break;
      }
      const furthestBlock = aaObtainFurthestBlock(p2, formattingElementEntry);
      if (!furthestBlock) {
        break;
      }
      p2.activeFormattingElements.bookmark = formattingElementEntry;
      const lastElement = aaInnerLoop(p2, furthestBlock, formattingElementEntry.element);
      const commonAncestor = p2.openElements.getCommonAncestor(formattingElementEntry.element);
      p2.treeAdapter.detachNode(lastElement);
      if (commonAncestor)
        aaInsertLastNodeInCommonAncestor(p2, commonAncestor, lastElement);
      aaReplaceFormattingElement(p2, furthestBlock, formattingElementEntry);
    }
  }
  function appendComment(p2, token) {
    p2._appendCommentNode(token, p2.openElements.currentTmplContentOrNode);
  }
  function appendCommentToRootHtmlElement(p2, token) {
    p2._appendCommentNode(token, p2.openElements.items[0]);
  }
  function appendCommentToDocument(p2, token) {
    p2._appendCommentNode(token, p2.document);
  }
  function stopParsing(p2, token) {
    p2.stopped = true;
    if (token.location) {
      const target = p2.fragmentContext ? 0 : 2;
      for (let i = p2.openElements.stackTop; i >= target; i--) {
        p2._setEndLocation(p2.openElements.items[i], token);
      }
      if (!p2.fragmentContext && p2.openElements.stackTop >= 0) {
        const htmlElement = p2.openElements.items[0];
        const htmlLocation = p2.treeAdapter.getNodeSourceCodeLocation(htmlElement);
        if (htmlLocation && !htmlLocation.endTag) {
          p2._setEndLocation(htmlElement, token);
          if (p2.openElements.stackTop >= 1) {
            const bodyElement = p2.openElements.items[1];
            const bodyLocation = p2.treeAdapter.getNodeSourceCodeLocation(bodyElement);
            if (bodyLocation && !bodyLocation.endTag) {
              p2._setEndLocation(bodyElement, token);
            }
          }
        }
      }
    }
  }
  function doctypeInInitialMode(p2, token) {
    p2._setDocumentType(token);
    const mode = token.forceQuirks ? DOCUMENT_MODE.QUIRKS : getDocumentMode(token);
    if (!isConforming(token)) {
      p2._err(token, ERR.nonConformingDoctype);
    }
    p2.treeAdapter.setDocumentMode(p2.document, mode);
    p2.insertionMode = InsertionMode.BEFORE_HTML;
  }
  function tokenInInitialMode(p2, token) {
    p2._err(token, ERR.missingDoctype, true);
    p2.treeAdapter.setDocumentMode(p2.document, DOCUMENT_MODE.QUIRKS);
    p2.insertionMode = InsertionMode.BEFORE_HTML;
    p2._processToken(token);
  }
  function startTagBeforeHtml(p2, token) {
    if (token.tagID === TAG_ID.HTML) {
      p2._insertElement(token, NS.HTML);
      p2.insertionMode = InsertionMode.BEFORE_HEAD;
    } else {
      tokenBeforeHtml(p2, token);
    }
  }
  function endTagBeforeHtml(p2, token) {
    const tn2 = token.tagID;
    if (tn2 === TAG_ID.HTML || tn2 === TAG_ID.HEAD || tn2 === TAG_ID.BODY || tn2 === TAG_ID.BR) {
      tokenBeforeHtml(p2, token);
    }
  }
  function tokenBeforeHtml(p2, token) {
    p2._insertFakeRootElement();
    p2.insertionMode = InsertionMode.BEFORE_HEAD;
    p2._processToken(token);
  }
  function startTagBeforeHead(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.HEAD: {
        p2._insertElement(token, NS.HTML);
        p2.headElement = p2.openElements.current;
        p2.insertionMode = InsertionMode.IN_HEAD;
        break;
      }
      default: {
        tokenBeforeHead(p2, token);
      }
    }
  }
  function endTagBeforeHead(p2, token) {
    const tn2 = token.tagID;
    if (tn2 === TAG_ID.HEAD || tn2 === TAG_ID.BODY || tn2 === TAG_ID.HTML || tn2 === TAG_ID.BR) {
      tokenBeforeHead(p2, token);
    } else {
      p2._err(token, ERR.endTagWithoutMatchingOpenElement);
    }
  }
  function tokenBeforeHead(p2, token) {
    p2._insertFakeElement(TAG_NAMES.HEAD, TAG_ID.HEAD);
    p2.headElement = p2.openElements.current;
    p2.insertionMode = InsertionMode.IN_HEAD;
    p2._processToken(token);
  }
  function startTagInHead(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META: {
        p2._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.TITLE: {
        p2._switchToTextParsing(token, TokenizerMode.RCDATA);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        if (p2.options.scriptingEnabled) {
          p2._switchToTextParsing(token, TokenizerMode.RAWTEXT);
        } else {
          p2._insertElement(token, NS.HTML);
          p2.insertionMode = InsertionMode.IN_HEAD_NO_SCRIPT;
        }
        break;
      }
      case TAG_ID.NOFRAMES:
      case TAG_ID.STYLE: {
        p2._switchToTextParsing(token, TokenizerMode.RAWTEXT);
        break;
      }
      case TAG_ID.SCRIPT: {
        p2._switchToTextParsing(token, TokenizerMode.SCRIPT_DATA);
        break;
      }
      case TAG_ID.TEMPLATE: {
        p2._insertTemplate(token);
        p2.activeFormattingElements.insertMarker();
        p2.framesetOk = false;
        p2.insertionMode = InsertionMode.IN_TEMPLATE;
        p2.tmplInsertionModeStack.unshift(InsertionMode.IN_TEMPLATE);
        break;
      }
      case TAG_ID.HEAD: {
        p2._err(token, ERR.misplacedStartTagForHeadElement);
        break;
      }
      default: {
        tokenInHead(p2, token);
      }
    }
  }
  function endTagInHead(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HEAD: {
        p2.openElements.pop();
        p2.insertionMode = InsertionMode.AFTER_HEAD;
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.BR:
      case TAG_ID.HTML: {
        tokenInHead(p2, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
      default: {
        p2._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function templateEndTagInHead(p2, token) {
    if (p2.openElements.tmplCount > 0) {
      p2.openElements.generateImpliedEndTagsThoroughly();
      if (p2.openElements.currentTagId !== TAG_ID.TEMPLATE) {
        p2._err(token, ERR.closingOfElementWithOpenChildElements);
      }
      p2.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
      p2.activeFormattingElements.clearToLastMarker();
      p2.tmplInsertionModeStack.shift();
      p2._resetInsertionMode();
    } else {
      p2._err(token, ERR.endTagWithoutMatchingOpenElement);
    }
  }
  function tokenInHead(p2, token) {
    p2.openElements.pop();
    p2.insertionMode = InsertionMode.AFTER_HEAD;
    p2._processToken(token);
  }
  function startTagInHeadNoScript(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.HEAD:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.STYLE: {
        startTagInHead(p2, token);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        p2._err(token, ERR.nestedNoscriptInHead);
        break;
      }
      default: {
        tokenInHeadNoScript(p2, token);
      }
    }
  }
  function endTagInHeadNoScript(p2, token) {
    switch (token.tagID) {
      case TAG_ID.NOSCRIPT: {
        p2.openElements.pop();
        p2.insertionMode = InsertionMode.IN_HEAD;
        break;
      }
      case TAG_ID.BR: {
        tokenInHeadNoScript(p2, token);
        break;
      }
      default: {
        p2._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function tokenInHeadNoScript(p2, token) {
    const errCode = token.type === TokenType.EOF ? ERR.openElementsLeftAfterEof : ERR.disallowedContentInNoscriptInHead;
    p2._err(token, errCode);
    p2.openElements.pop();
    p2.insertionMode = InsertionMode.IN_HEAD;
    p2._processToken(token);
  }
  function startTagAfterHead(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.BODY: {
        p2._insertElement(token, NS.HTML);
        p2.framesetOk = false;
        p2.insertionMode = InsertionMode.IN_BODY;
        break;
      }
      case TAG_ID.FRAMESET: {
        p2._insertElement(token, NS.HTML);
        p2.insertionMode = InsertionMode.IN_FRAMESET;
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.SCRIPT:
      case TAG_ID.STYLE:
      case TAG_ID.TEMPLATE:
      case TAG_ID.TITLE: {
        p2._err(token, ERR.abandonedHeadElementChild);
        p2.openElements.push(p2.headElement, TAG_ID.HEAD);
        startTagInHead(p2, token);
        p2.openElements.remove(p2.headElement);
        break;
      }
      case TAG_ID.HEAD: {
        p2._err(token, ERR.misplacedStartTagForHeadElement);
        break;
      }
      default: {
        tokenAfterHead(p2, token);
      }
    }
  }
  function endTagAfterHead(p2, token) {
    switch (token.tagID) {
      case TAG_ID.BODY:
      case TAG_ID.HTML:
      case TAG_ID.BR: {
        tokenAfterHead(p2, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
      default: {
        p2._err(token, ERR.endTagWithoutMatchingOpenElement);
      }
    }
  }
  function tokenAfterHead(p2, token) {
    p2._insertFakeElement(TAG_NAMES.BODY, TAG_ID.BODY);
    p2.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p2, token);
  }
  function modeInBody(p2, token) {
    switch (token.type) {
      case TokenType.CHARACTER: {
        characterInBody(p2, token);
        break;
      }
      case TokenType.WHITESPACE_CHARACTER: {
        whitespaceCharacterInBody(p2, token);
        break;
      }
      case TokenType.COMMENT: {
        appendComment(p2, token);
        break;
      }
      case TokenType.START_TAG: {
        startTagInBody(p2, token);
        break;
      }
      case TokenType.END_TAG: {
        endTagInBody(p2, token);
        break;
      }
      case TokenType.EOF: {
        eofInBody(p2, token);
        break;
      }
    }
  }
  function whitespaceCharacterInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertCharacters(token);
  }
  function characterInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertCharacters(token);
    p2.framesetOk = false;
  }
  function htmlStartTagInBody(p2, token) {
    if (p2.openElements.tmplCount === 0) {
      p2.treeAdapter.adoptAttributes(p2.openElements.items[0], token.attrs);
    }
  }
  function bodyStartTagInBody(p2, token) {
    const bodyElement = p2.openElements.tryPeekProperlyNestedBodyElement();
    if (bodyElement && p2.openElements.tmplCount === 0) {
      p2.framesetOk = false;
      p2.treeAdapter.adoptAttributes(bodyElement, token.attrs);
    }
  }
  function framesetStartTagInBody(p2, token) {
    const bodyElement = p2.openElements.tryPeekProperlyNestedBodyElement();
    if (p2.framesetOk && bodyElement) {
      p2.treeAdapter.detachNode(bodyElement);
      p2.openElements.popAllUpToHtmlElement();
      p2._insertElement(token, NS.HTML);
      p2.insertionMode = InsertionMode.IN_FRAMESET;
    }
  }
  function addressStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._insertElement(token, NS.HTML);
  }
  function numberedHeaderStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    if (p2.openElements.currentTagId !== void 0 && NUMBERED_HEADERS.has(p2.openElements.currentTagId)) {
      p2.openElements.pop();
    }
    p2._insertElement(token, NS.HTML);
  }
  function preStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._insertElement(token, NS.HTML);
    p2.skipNextNewLine = true;
    p2.framesetOk = false;
  }
  function formStartTagInBody(p2, token) {
    const inTemplate = p2.openElements.tmplCount > 0;
    if (!p2.formElement || inTemplate) {
      if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
        p2._closePElement();
      }
      p2._insertElement(token, NS.HTML);
      if (!inTemplate) {
        p2.formElement = p2.openElements.current;
      }
    }
  }
  function listItemStartTagInBody(p2, token) {
    p2.framesetOk = false;
    const tn2 = token.tagID;
    for (let i = p2.openElements.stackTop; i >= 0; i--) {
      const elementId = p2.openElements.tagIDs[i];
      if (tn2 === TAG_ID.LI && elementId === TAG_ID.LI || (tn2 === TAG_ID.DD || tn2 === TAG_ID.DT) && (elementId === TAG_ID.DD || elementId === TAG_ID.DT)) {
        p2.openElements.generateImpliedEndTagsWithExclusion(elementId);
        p2.openElements.popUntilTagNamePopped(elementId);
        break;
      }
      if (elementId !== TAG_ID.ADDRESS && elementId !== TAG_ID.DIV && elementId !== TAG_ID.P && p2._isSpecialElement(p2.openElements.items[i], elementId)) {
        break;
      }
    }
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._insertElement(token, NS.HTML);
  }
  function plaintextStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._insertElement(token, NS.HTML);
    p2.tokenizer.state = TokenizerMode.PLAINTEXT;
  }
  function buttonStartTagInBody(p2, token) {
    if (p2.openElements.hasInScope(TAG_ID.BUTTON)) {
      p2.openElements.generateImpliedEndTags();
      p2.openElements.popUntilTagNamePopped(TAG_ID.BUTTON);
    }
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
    p2.framesetOk = false;
  }
  function aStartTagInBody(p2, token) {
    const activeElementEntry = p2.activeFormattingElements.getElementEntryInScopeWithTagName(TAG_NAMES.A);
    if (activeElementEntry) {
      callAdoptionAgency(p2, token);
      p2.openElements.remove(activeElementEntry.element);
      p2.activeFormattingElements.removeEntry(activeElementEntry);
    }
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
    p2.activeFormattingElements.pushElement(p2.openElements.current, token);
  }
  function bStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
    p2.activeFormattingElements.pushElement(p2.openElements.current, token);
  }
  function nobrStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    if (p2.openElements.hasInScope(TAG_ID.NOBR)) {
      callAdoptionAgency(p2, token);
      p2._reconstructActiveFormattingElements();
    }
    p2._insertElement(token, NS.HTML);
    p2.activeFormattingElements.pushElement(p2.openElements.current, token);
  }
  function appletStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
    p2.activeFormattingElements.insertMarker();
    p2.framesetOk = false;
  }
  function tableStartTagInBody(p2, token) {
    if (p2.treeAdapter.getDocumentMode(p2.document) !== DOCUMENT_MODE.QUIRKS && p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._insertElement(token, NS.HTML);
    p2.framesetOk = false;
    p2.insertionMode = InsertionMode.IN_TABLE;
  }
  function areaStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._appendElement(token, NS.HTML);
    p2.framesetOk = false;
    token.ackSelfClosing = true;
  }
  function isHiddenInput(token) {
    const inputType = getTokenAttr(token, ATTRS.TYPE);
    return inputType != null && inputType.toLowerCase() === HIDDEN_INPUT_TYPE;
  }
  function inputStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._appendElement(token, NS.HTML);
    if (!isHiddenInput(token)) {
      p2.framesetOk = false;
    }
    token.ackSelfClosing = true;
  }
  function paramStartTagInBody(p2, token) {
    p2._appendElement(token, NS.HTML);
    token.ackSelfClosing = true;
  }
  function hrStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._appendElement(token, NS.HTML);
    p2.framesetOk = false;
    token.ackSelfClosing = true;
  }
  function imageStartTagInBody(p2, token) {
    token.tagName = TAG_NAMES.IMG;
    token.tagID = TAG_ID.IMG;
    areaStartTagInBody(p2, token);
  }
  function textareaStartTagInBody(p2, token) {
    p2._insertElement(token, NS.HTML);
    p2.skipNextNewLine = true;
    p2.tokenizer.state = TokenizerMode.RCDATA;
    p2.originalInsertionMode = p2.insertionMode;
    p2.framesetOk = false;
    p2.insertionMode = InsertionMode.TEXT;
  }
  function xmpStartTagInBody(p2, token) {
    if (p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._closePElement();
    }
    p2._reconstructActiveFormattingElements();
    p2.framesetOk = false;
    p2._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function iframeStartTagInBody(p2, token) {
    p2.framesetOk = false;
    p2._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function rawTextStartTagInBody(p2, token) {
    p2._switchToTextParsing(token, TokenizerMode.RAWTEXT);
  }
  function selectStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
    p2.framesetOk = false;
    p2.insertionMode = p2.insertionMode === InsertionMode.IN_TABLE || p2.insertionMode === InsertionMode.IN_CAPTION || p2.insertionMode === InsertionMode.IN_TABLE_BODY || p2.insertionMode === InsertionMode.IN_ROW || p2.insertionMode === InsertionMode.IN_CELL ? InsertionMode.IN_SELECT_IN_TABLE : InsertionMode.IN_SELECT;
  }
  function optgroupStartTagInBody(p2, token) {
    if (p2.openElements.currentTagId === TAG_ID.OPTION) {
      p2.openElements.pop();
    }
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
  }
  function rbStartTagInBody(p2, token) {
    if (p2.openElements.hasInScope(TAG_ID.RUBY)) {
      p2.openElements.generateImpliedEndTags();
    }
    p2._insertElement(token, NS.HTML);
  }
  function rtStartTagInBody(p2, token) {
    if (p2.openElements.hasInScope(TAG_ID.RUBY)) {
      p2.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.RTC);
    }
    p2._insertElement(token, NS.HTML);
  }
  function mathStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    adjustTokenMathMLAttrs(token);
    adjustTokenXMLAttrs(token);
    if (token.selfClosing) {
      p2._appendElement(token, NS.MATHML);
    } else {
      p2._insertElement(token, NS.MATHML);
    }
    token.ackSelfClosing = true;
  }
  function svgStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    adjustTokenSVGAttrs(token);
    adjustTokenXMLAttrs(token);
    if (token.selfClosing) {
      p2._appendElement(token, NS.SVG);
    } else {
      p2._insertElement(token, NS.SVG);
    }
    token.ackSelfClosing = true;
  }
  function genericStartTagInBody(p2, token) {
    p2._reconstructActiveFormattingElements();
    p2._insertElement(token, NS.HTML);
  }
  function startTagInBody(p2, token) {
    switch (token.tagID) {
      case TAG_ID.I:
      case TAG_ID.S:
      case TAG_ID.B:
      case TAG_ID.U:
      case TAG_ID.EM:
      case TAG_ID.TT:
      case TAG_ID.BIG:
      case TAG_ID.CODE:
      case TAG_ID.FONT:
      case TAG_ID.SMALL:
      case TAG_ID.STRIKE:
      case TAG_ID.STRONG: {
        bStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.A: {
        aStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.H1:
      case TAG_ID.H2:
      case TAG_ID.H3:
      case TAG_ID.H4:
      case TAG_ID.H5:
      case TAG_ID.H6: {
        numberedHeaderStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.P:
      case TAG_ID.DL:
      case TAG_ID.OL:
      case TAG_ID.UL:
      case TAG_ID.DIV:
      case TAG_ID.DIR:
      case TAG_ID.NAV:
      case TAG_ID.MAIN:
      case TAG_ID.MENU:
      case TAG_ID.ASIDE:
      case TAG_ID.CENTER:
      case TAG_ID.FIGURE:
      case TAG_ID.FOOTER:
      case TAG_ID.HEADER:
      case TAG_ID.HGROUP:
      case TAG_ID.DIALOG:
      case TAG_ID.DETAILS:
      case TAG_ID.ADDRESS:
      case TAG_ID.ARTICLE:
      case TAG_ID.SEARCH:
      case TAG_ID.SECTION:
      case TAG_ID.SUMMARY:
      case TAG_ID.FIELDSET:
      case TAG_ID.BLOCKQUOTE:
      case TAG_ID.FIGCAPTION: {
        addressStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.LI:
      case TAG_ID.DD:
      case TAG_ID.DT: {
        listItemStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.BR:
      case TAG_ID.IMG:
      case TAG_ID.WBR:
      case TAG_ID.AREA:
      case TAG_ID.EMBED:
      case TAG_ID.KEYGEN: {
        areaStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.HR: {
        hrStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.RB:
      case TAG_ID.RTC: {
        rbStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.RT:
      case TAG_ID.RP: {
        rtStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.PRE:
      case TAG_ID.LISTING: {
        preStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.XMP: {
        xmpStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.SVG: {
        svgStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.HTML: {
        htmlStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.BASE:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.STYLE:
      case TAG_ID.TITLE:
      case TAG_ID.SCRIPT:
      case TAG_ID.BGSOUND:
      case TAG_ID.BASEFONT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p2, token);
        break;
      }
      case TAG_ID.BODY: {
        bodyStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.FORM: {
        formStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.NOBR: {
        nobrStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.MATH: {
        mathStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.TABLE: {
        tableStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.INPUT: {
        inputStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.PARAM:
      case TAG_ID.TRACK:
      case TAG_ID.SOURCE: {
        paramStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.IMAGE: {
        imageStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.BUTTON: {
        buttonStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.APPLET:
      case TAG_ID.OBJECT:
      case TAG_ID.MARQUEE: {
        appletStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.IFRAME: {
        iframeStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.SELECT: {
        selectStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.OPTION:
      case TAG_ID.OPTGROUP: {
        optgroupStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.NOEMBED:
      case TAG_ID.NOFRAMES: {
        rawTextStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.FRAMESET: {
        framesetStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.TEXTAREA: {
        textareaStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.NOSCRIPT: {
        if (p2.options.scriptingEnabled) {
          rawTextStartTagInBody(p2, token);
        } else {
          genericStartTagInBody(p2, token);
        }
        break;
      }
      case TAG_ID.PLAINTEXT: {
        plaintextStartTagInBody(p2, token);
        break;
      }
      case TAG_ID.COL:
      case TAG_ID.TH:
      case TAG_ID.TD:
      case TAG_ID.TR:
      case TAG_ID.HEAD:
      case TAG_ID.FRAME:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.CAPTION:
      case TAG_ID.COLGROUP: {
        break;
      }
      default: {
        genericStartTagInBody(p2, token);
      }
    }
  }
  function bodyEndTagInBody(p2, token) {
    if (p2.openElements.hasInScope(TAG_ID.BODY)) {
      p2.insertionMode = InsertionMode.AFTER_BODY;
      if (p2.options.sourceCodeLocationInfo) {
        const bodyElement = p2.openElements.tryPeekProperlyNestedBodyElement();
        if (bodyElement) {
          p2._setEndLocation(bodyElement, token);
        }
      }
    }
  }
  function htmlEndTagInBody(p2, token) {
    if (p2.openElements.hasInScope(TAG_ID.BODY)) {
      p2.insertionMode = InsertionMode.AFTER_BODY;
      endTagAfterBody(p2, token);
    }
  }
  function addressEndTagInBody(p2, token) {
    const tn2 = token.tagID;
    if (p2.openElements.hasInScope(tn2)) {
      p2.openElements.generateImpliedEndTags();
      p2.openElements.popUntilTagNamePopped(tn2);
    }
  }
  function formEndTagInBody(p2) {
    const inTemplate = p2.openElements.tmplCount > 0;
    const { formElement } = p2;
    if (!inTemplate) {
      p2.formElement = null;
    }
    if ((formElement || inTemplate) && p2.openElements.hasInScope(TAG_ID.FORM)) {
      p2.openElements.generateImpliedEndTags();
      if (inTemplate) {
        p2.openElements.popUntilTagNamePopped(TAG_ID.FORM);
      } else if (formElement) {
        p2.openElements.remove(formElement);
      }
    }
  }
  function pEndTagInBody(p2) {
    if (!p2.openElements.hasInButtonScope(TAG_ID.P)) {
      p2._insertFakeElement(TAG_NAMES.P, TAG_ID.P);
    }
    p2._closePElement();
  }
  function liEndTagInBody(p2) {
    if (p2.openElements.hasInListItemScope(TAG_ID.LI)) {
      p2.openElements.generateImpliedEndTagsWithExclusion(TAG_ID.LI);
      p2.openElements.popUntilTagNamePopped(TAG_ID.LI);
    }
  }
  function ddEndTagInBody(p2, token) {
    const tn2 = token.tagID;
    if (p2.openElements.hasInScope(tn2)) {
      p2.openElements.generateImpliedEndTagsWithExclusion(tn2);
      p2.openElements.popUntilTagNamePopped(tn2);
    }
  }
  function numberedHeaderEndTagInBody(p2) {
    if (p2.openElements.hasNumberedHeaderInScope()) {
      p2.openElements.generateImpliedEndTags();
      p2.openElements.popUntilNumberedHeaderPopped();
    }
  }
  function appletEndTagInBody(p2, token) {
    const tn2 = token.tagID;
    if (p2.openElements.hasInScope(tn2)) {
      p2.openElements.generateImpliedEndTags();
      p2.openElements.popUntilTagNamePopped(tn2);
      p2.activeFormattingElements.clearToLastMarker();
    }
  }
  function brEndTagInBody(p2) {
    p2._reconstructActiveFormattingElements();
    p2._insertFakeElement(TAG_NAMES.BR, TAG_ID.BR);
    p2.openElements.pop();
    p2.framesetOk = false;
  }
  function genericEndTagInBody(p2, token) {
    const tn2 = token.tagName;
    const tid = token.tagID;
    for (let i = p2.openElements.stackTop; i > 0; i--) {
      const element = p2.openElements.items[i];
      const elementId = p2.openElements.tagIDs[i];
      if (tid === elementId && (tid !== TAG_ID.UNKNOWN || p2.treeAdapter.getTagName(element) === tn2)) {
        p2.openElements.generateImpliedEndTagsWithExclusion(tid);
        if (p2.openElements.stackTop >= i)
          p2.openElements.shortenToLength(i);
        break;
      }
      if (p2._isSpecialElement(element, elementId)) {
        break;
      }
    }
  }
  function endTagInBody(p2, token) {
    switch (token.tagID) {
      case TAG_ID.A:
      case TAG_ID.B:
      case TAG_ID.I:
      case TAG_ID.S:
      case TAG_ID.U:
      case TAG_ID.EM:
      case TAG_ID.TT:
      case TAG_ID.BIG:
      case TAG_ID.CODE:
      case TAG_ID.FONT:
      case TAG_ID.NOBR:
      case TAG_ID.SMALL:
      case TAG_ID.STRIKE:
      case TAG_ID.STRONG: {
        callAdoptionAgency(p2, token);
        break;
      }
      case TAG_ID.P: {
        pEndTagInBody(p2);
        break;
      }
      case TAG_ID.DL:
      case TAG_ID.UL:
      case TAG_ID.OL:
      case TAG_ID.DIR:
      case TAG_ID.DIV:
      case TAG_ID.NAV:
      case TAG_ID.PRE:
      case TAG_ID.MAIN:
      case TAG_ID.MENU:
      case TAG_ID.ASIDE:
      case TAG_ID.BUTTON:
      case TAG_ID.CENTER:
      case TAG_ID.FIGURE:
      case TAG_ID.FOOTER:
      case TAG_ID.HEADER:
      case TAG_ID.HGROUP:
      case TAG_ID.DIALOG:
      case TAG_ID.ADDRESS:
      case TAG_ID.ARTICLE:
      case TAG_ID.DETAILS:
      case TAG_ID.SEARCH:
      case TAG_ID.SECTION:
      case TAG_ID.SUMMARY:
      case TAG_ID.LISTING:
      case TAG_ID.FIELDSET:
      case TAG_ID.BLOCKQUOTE:
      case TAG_ID.FIGCAPTION: {
        addressEndTagInBody(p2, token);
        break;
      }
      case TAG_ID.LI: {
        liEndTagInBody(p2);
        break;
      }
      case TAG_ID.DD:
      case TAG_ID.DT: {
        ddEndTagInBody(p2, token);
        break;
      }
      case TAG_ID.H1:
      case TAG_ID.H2:
      case TAG_ID.H3:
      case TAG_ID.H4:
      case TAG_ID.H5:
      case TAG_ID.H6: {
        numberedHeaderEndTagInBody(p2);
        break;
      }
      case TAG_ID.BR: {
        brEndTagInBody(p2);
        break;
      }
      case TAG_ID.BODY: {
        bodyEndTagInBody(p2, token);
        break;
      }
      case TAG_ID.HTML: {
        htmlEndTagInBody(p2, token);
        break;
      }
      case TAG_ID.FORM: {
        formEndTagInBody(p2);
        break;
      }
      case TAG_ID.APPLET:
      case TAG_ID.OBJECT:
      case TAG_ID.MARQUEE: {
        appletEndTagInBody(p2, token);
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
      default: {
        genericEndTagInBody(p2, token);
      }
    }
  }
  function eofInBody(p2, token) {
    if (p2.tmplInsertionModeStack.length > 0) {
      eofInTemplate(p2, token);
    } else {
      stopParsing(p2, token);
    }
  }
  function endTagInText(p2, token) {
    var _a2;
    if (token.tagID === TAG_ID.SCRIPT) {
      (_a2 = p2.scriptHandler) === null || _a2 === void 0 ? void 0 : _a2.call(p2, p2.openElements.current);
    }
    p2.openElements.pop();
    p2.insertionMode = p2.originalInsertionMode;
  }
  function eofInText(p2, token) {
    p2._err(token, ERR.eofInElementThatCanContainOnlyText);
    p2.openElements.pop();
    p2.insertionMode = p2.originalInsertionMode;
    p2.onEof(token);
  }
  function characterInTable(p2, token) {
    if (p2.openElements.currentTagId !== void 0 && TABLE_STRUCTURE_TAGS.has(p2.openElements.currentTagId)) {
      p2.pendingCharacterTokens.length = 0;
      p2.hasNonWhitespacePendingCharacterToken = false;
      p2.originalInsertionMode = p2.insertionMode;
      p2.insertionMode = InsertionMode.IN_TABLE_TEXT;
      switch (token.type) {
        case TokenType.CHARACTER: {
          characterInTableText(p2, token);
          break;
        }
        case TokenType.WHITESPACE_CHARACTER: {
          whitespaceCharacterInTableText(p2, token);
          break;
        }
      }
    } else {
      tokenInTable(p2, token);
    }
  }
  function captionStartTagInTable(p2, token) {
    p2.openElements.clearBackToTableContext();
    p2.activeFormattingElements.insertMarker();
    p2._insertElement(token, NS.HTML);
    p2.insertionMode = InsertionMode.IN_CAPTION;
  }
  function colgroupStartTagInTable(p2, token) {
    p2.openElements.clearBackToTableContext();
    p2._insertElement(token, NS.HTML);
    p2.insertionMode = InsertionMode.IN_COLUMN_GROUP;
  }
  function colStartTagInTable(p2, token) {
    p2.openElements.clearBackToTableContext();
    p2._insertFakeElement(TAG_NAMES.COLGROUP, TAG_ID.COLGROUP);
    p2.insertionMode = InsertionMode.IN_COLUMN_GROUP;
    startTagInColumnGroup(p2, token);
  }
  function tbodyStartTagInTable(p2, token) {
    p2.openElements.clearBackToTableContext();
    p2._insertElement(token, NS.HTML);
    p2.insertionMode = InsertionMode.IN_TABLE_BODY;
  }
  function tdStartTagInTable(p2, token) {
    p2.openElements.clearBackToTableContext();
    p2._insertFakeElement(TAG_NAMES.TBODY, TAG_ID.TBODY);
    p2.insertionMode = InsertionMode.IN_TABLE_BODY;
    startTagInTableBody(p2, token);
  }
  function tableStartTagInTable(p2, token) {
    if (p2.openElements.hasInTableScope(TAG_ID.TABLE)) {
      p2.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
      p2._resetInsertionMode();
      p2._processStartTag(token);
    }
  }
  function inputStartTagInTable(p2, token) {
    if (isHiddenInput(token)) {
      p2._appendElement(token, NS.HTML);
    } else {
      tokenInTable(p2, token);
    }
    token.ackSelfClosing = true;
  }
  function formStartTagInTable(p2, token) {
    if (!p2.formElement && p2.openElements.tmplCount === 0) {
      p2._insertElement(token, NS.HTML);
      p2.formElement = p2.openElements.current;
      p2.openElements.pop();
    }
  }
  function startTagInTable(p2, token) {
    switch (token.tagID) {
      case TAG_ID.TD:
      case TAG_ID.TH:
      case TAG_ID.TR: {
        tdStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.STYLE:
      case TAG_ID.SCRIPT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p2, token);
        break;
      }
      case TAG_ID.COL: {
        colStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.FORM: {
        formStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.TABLE: {
        tableStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        tbodyStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.INPUT: {
        inputStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.CAPTION: {
        captionStartTagInTable(p2, token);
        break;
      }
      case TAG_ID.COLGROUP: {
        colgroupStartTagInTable(p2, token);
        break;
      }
      default: {
        tokenInTable(p2, token);
      }
    }
  }
  function endTagInTable(p2, token) {
    switch (token.tagID) {
      case TAG_ID.TABLE: {
        if (p2.openElements.hasInTableScope(TAG_ID.TABLE)) {
          p2.openElements.popUntilTagNamePopped(TAG_ID.TABLE);
          p2._resetInsertionMode();
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TBODY:
      case TAG_ID.TD:
      case TAG_ID.TFOOT:
      case TAG_ID.TH:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        break;
      }
      default: {
        tokenInTable(p2, token);
      }
    }
  }
  function tokenInTable(p2, token) {
    const savedFosterParentingState = p2.fosterParentingEnabled;
    p2.fosterParentingEnabled = true;
    modeInBody(p2, token);
    p2.fosterParentingEnabled = savedFosterParentingState;
  }
  function whitespaceCharacterInTableText(p2, token) {
    p2.pendingCharacterTokens.push(token);
  }
  function characterInTableText(p2, token) {
    p2.pendingCharacterTokens.push(token);
    p2.hasNonWhitespacePendingCharacterToken = true;
  }
  function tokenInTableText(p2, token) {
    let i = 0;
    if (p2.hasNonWhitespacePendingCharacterToken) {
      for (; i < p2.pendingCharacterTokens.length; i++) {
        tokenInTable(p2, p2.pendingCharacterTokens[i]);
      }
    } else {
      for (; i < p2.pendingCharacterTokens.length; i++) {
        p2._insertCharacters(p2.pendingCharacterTokens[i]);
      }
    }
    p2.insertionMode = p2.originalInsertionMode;
    p2._processToken(token);
  }
  const TABLE_VOID_ELEMENTS = /* @__PURE__ */ new Set([TAG_ID.CAPTION, TAG_ID.COL, TAG_ID.COLGROUP, TAG_ID.TBODY, TAG_ID.TD, TAG_ID.TFOOT, TAG_ID.TH, TAG_ID.THEAD, TAG_ID.TR]);
  function startTagInCaption(p2, token) {
    const tn2 = token.tagID;
    if (TABLE_VOID_ELEMENTS.has(tn2)) {
      if (p2.openElements.hasInTableScope(TAG_ID.CAPTION)) {
        p2.openElements.generateImpliedEndTags();
        p2.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
        p2.activeFormattingElements.clearToLastMarker();
        p2.insertionMode = InsertionMode.IN_TABLE;
        startTagInTable(p2, token);
      }
    } else {
      startTagInBody(p2, token);
    }
  }
  function endTagInCaption(p2, token) {
    const tn2 = token.tagID;
    switch (tn2) {
      case TAG_ID.CAPTION:
      case TAG_ID.TABLE: {
        if (p2.openElements.hasInTableScope(TAG_ID.CAPTION)) {
          p2.openElements.generateImpliedEndTags();
          p2.openElements.popUntilTagNamePopped(TAG_ID.CAPTION);
          p2.activeFormattingElements.clearToLastMarker();
          p2.insertionMode = InsertionMode.IN_TABLE;
          if (tn2 === TAG_ID.TABLE) {
            endTagInTable(p2, token);
          }
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TBODY:
      case TAG_ID.TD:
      case TAG_ID.TFOOT:
      case TAG_ID.TH:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        break;
      }
      default: {
        endTagInBody(p2, token);
      }
    }
  }
  function startTagInColumnGroup(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.COL: {
        p2._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.TEMPLATE: {
        startTagInHead(p2, token);
        break;
      }
      default: {
        tokenInColumnGroup(p2, token);
      }
    }
  }
  function endTagInColumnGroup(p2, token) {
    switch (token.tagID) {
      case TAG_ID.COLGROUP: {
        if (p2.openElements.currentTagId === TAG_ID.COLGROUP) {
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE;
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
      case TAG_ID.COL: {
        break;
      }
      default: {
        tokenInColumnGroup(p2, token);
      }
    }
  }
  function tokenInColumnGroup(p2, token) {
    if (p2.openElements.currentTagId === TAG_ID.COLGROUP) {
      p2.openElements.pop();
      p2.insertionMode = InsertionMode.IN_TABLE;
      p2._processToken(token);
    }
  }
  function startTagInTableBody(p2, token) {
    switch (token.tagID) {
      case TAG_ID.TR: {
        p2.openElements.clearBackToTableBodyContext();
        p2._insertElement(token, NS.HTML);
        p2.insertionMode = InsertionMode.IN_ROW;
        break;
      }
      case TAG_ID.TH:
      case TAG_ID.TD: {
        p2.openElements.clearBackToTableBodyContext();
        p2._insertFakeElement(TAG_NAMES.TR, TAG_ID.TR);
        p2.insertionMode = InsertionMode.IN_ROW;
        startTagInRow(p2, token);
        break;
      }
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p2.openElements.hasTableBodyContextInTableScope()) {
          p2.openElements.clearBackToTableBodyContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE;
          startTagInTable(p2, token);
        }
        break;
      }
      default: {
        startTagInTable(p2, token);
      }
    }
  }
  function endTagInTableBody(p2, token) {
    const tn2 = token.tagID;
    switch (token.tagID) {
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p2.openElements.hasInTableScope(tn2)) {
          p2.openElements.clearBackToTableBodyContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE;
        }
        break;
      }
      case TAG_ID.TABLE: {
        if (p2.openElements.hasTableBodyContextInTableScope()) {
          p2.openElements.clearBackToTableBodyContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE;
          endTagInTable(p2, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TD:
      case TAG_ID.TH:
      case TAG_ID.TR: {
        break;
      }
      default: {
        endTagInTable(p2, token);
      }
    }
  }
  function startTagInRow(p2, token) {
    switch (token.tagID) {
      case TAG_ID.TH:
      case TAG_ID.TD: {
        p2.openElements.clearBackToTableRowContext();
        p2._insertElement(token, NS.HTML);
        p2.insertionMode = InsertionMode.IN_CELL;
        p2.activeFormattingElements.insertMarker();
        break;
      }
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        if (p2.openElements.hasInTableScope(TAG_ID.TR)) {
          p2.openElements.clearBackToTableRowContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE_BODY;
          startTagInTableBody(p2, token);
        }
        break;
      }
      default: {
        startTagInTable(p2, token);
      }
    }
  }
  function endTagInRow(p2, token) {
    switch (token.tagID) {
      case TAG_ID.TR: {
        if (p2.openElements.hasInTableScope(TAG_ID.TR)) {
          p2.openElements.clearBackToTableRowContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE_BODY;
        }
        break;
      }
      case TAG_ID.TABLE: {
        if (p2.openElements.hasInTableScope(TAG_ID.TR)) {
          p2.openElements.clearBackToTableRowContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE_BODY;
          endTagInTableBody(p2, token);
        }
        break;
      }
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        if (p2.openElements.hasInTableScope(token.tagID) || p2.openElements.hasInTableScope(TAG_ID.TR)) {
          p2.openElements.clearBackToTableRowContext();
          p2.openElements.pop();
          p2.insertionMode = InsertionMode.IN_TABLE_BODY;
          endTagInTableBody(p2, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML:
      case TAG_ID.TD:
      case TAG_ID.TH: {
        break;
      }
      default: {
        endTagInTable(p2, token);
      }
    }
  }
  function startTagInCell(p2, token) {
    const tn2 = token.tagID;
    if (TABLE_VOID_ELEMENTS.has(tn2)) {
      if (p2.openElements.hasInTableScope(TAG_ID.TD) || p2.openElements.hasInTableScope(TAG_ID.TH)) {
        p2._closeTableCell();
        startTagInRow(p2, token);
      }
    } else {
      startTagInBody(p2, token);
    }
  }
  function endTagInCell(p2, token) {
    const tn2 = token.tagID;
    switch (tn2) {
      case TAG_ID.TD:
      case TAG_ID.TH: {
        if (p2.openElements.hasInTableScope(tn2)) {
          p2.openElements.generateImpliedEndTags();
          p2.openElements.popUntilTagNamePopped(tn2);
          p2.activeFormattingElements.clearToLastMarker();
          p2.insertionMode = InsertionMode.IN_ROW;
        }
        break;
      }
      case TAG_ID.TABLE:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD:
      case TAG_ID.TR: {
        if (p2.openElements.hasInTableScope(tn2)) {
          p2._closeTableCell();
          endTagInRow(p2, token);
        }
        break;
      }
      case TAG_ID.BODY:
      case TAG_ID.CAPTION:
      case TAG_ID.COL:
      case TAG_ID.COLGROUP:
      case TAG_ID.HTML: {
        break;
      }
      default: {
        endTagInBody(p2, token);
      }
    }
  }
  function startTagInSelect(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.OPTION: {
        if (p2.openElements.currentTagId === TAG_ID.OPTION) {
          p2.openElements.pop();
        }
        p2._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.OPTGROUP: {
        if (p2.openElements.currentTagId === TAG_ID.OPTION) {
          p2.openElements.pop();
        }
        if (p2.openElements.currentTagId === TAG_ID.OPTGROUP) {
          p2.openElements.pop();
        }
        p2._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.HR: {
        if (p2.openElements.currentTagId === TAG_ID.OPTION) {
          p2.openElements.pop();
        }
        if (p2.openElements.currentTagId === TAG_ID.OPTGROUP) {
          p2.openElements.pop();
        }
        p2._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.INPUT:
      case TAG_ID.KEYGEN:
      case TAG_ID.TEXTAREA:
      case TAG_ID.SELECT: {
        if (p2.openElements.hasInSelectScope(TAG_ID.SELECT)) {
          p2.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
          p2._resetInsertionMode();
          if (token.tagID !== TAG_ID.SELECT) {
            p2._processStartTag(token);
          }
        }
        break;
      }
      case TAG_ID.SCRIPT:
      case TAG_ID.TEMPLATE: {
        startTagInHead(p2, token);
        break;
      }
    }
  }
  function endTagInSelect(p2, token) {
    switch (token.tagID) {
      case TAG_ID.OPTGROUP: {
        if (p2.openElements.stackTop > 0 && p2.openElements.currentTagId === TAG_ID.OPTION && p2.openElements.tagIDs[p2.openElements.stackTop - 1] === TAG_ID.OPTGROUP) {
          p2.openElements.pop();
        }
        if (p2.openElements.currentTagId === TAG_ID.OPTGROUP) {
          p2.openElements.pop();
        }
        break;
      }
      case TAG_ID.OPTION: {
        if (p2.openElements.currentTagId === TAG_ID.OPTION) {
          p2.openElements.pop();
        }
        break;
      }
      case TAG_ID.SELECT: {
        if (p2.openElements.hasInSelectScope(TAG_ID.SELECT)) {
          p2.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
          p2._resetInsertionMode();
        }
        break;
      }
      case TAG_ID.TEMPLATE: {
        templateEndTagInHead(p2, token);
        break;
      }
    }
  }
  function startTagInSelectInTable(p2, token) {
    const tn2 = token.tagID;
    if (tn2 === TAG_ID.CAPTION || tn2 === TAG_ID.TABLE || tn2 === TAG_ID.TBODY || tn2 === TAG_ID.TFOOT || tn2 === TAG_ID.THEAD || tn2 === TAG_ID.TR || tn2 === TAG_ID.TD || tn2 === TAG_ID.TH) {
      p2.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
      p2._resetInsertionMode();
      p2._processStartTag(token);
    } else {
      startTagInSelect(p2, token);
    }
  }
  function endTagInSelectInTable(p2, token) {
    const tn2 = token.tagID;
    if (tn2 === TAG_ID.CAPTION || tn2 === TAG_ID.TABLE || tn2 === TAG_ID.TBODY || tn2 === TAG_ID.TFOOT || tn2 === TAG_ID.THEAD || tn2 === TAG_ID.TR || tn2 === TAG_ID.TD || tn2 === TAG_ID.TH) {
      if (p2.openElements.hasInTableScope(tn2)) {
        p2.openElements.popUntilTagNamePopped(TAG_ID.SELECT);
        p2._resetInsertionMode();
        p2.onEndTag(token);
      }
    } else {
      endTagInSelect(p2, token);
    }
  }
  function startTagInTemplate(p2, token) {
    switch (token.tagID) {
      // First, handle tags that can start without a mode change
      case TAG_ID.BASE:
      case TAG_ID.BASEFONT:
      case TAG_ID.BGSOUND:
      case TAG_ID.LINK:
      case TAG_ID.META:
      case TAG_ID.NOFRAMES:
      case TAG_ID.SCRIPT:
      case TAG_ID.STYLE:
      case TAG_ID.TEMPLATE:
      case TAG_ID.TITLE: {
        startTagInHead(p2, token);
        break;
      }
      // Re-process the token in the appropriate mode
      case TAG_ID.CAPTION:
      case TAG_ID.COLGROUP:
      case TAG_ID.TBODY:
      case TAG_ID.TFOOT:
      case TAG_ID.THEAD: {
        p2.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE;
        p2.insertionMode = InsertionMode.IN_TABLE;
        startTagInTable(p2, token);
        break;
      }
      case TAG_ID.COL: {
        p2.tmplInsertionModeStack[0] = InsertionMode.IN_COLUMN_GROUP;
        p2.insertionMode = InsertionMode.IN_COLUMN_GROUP;
        startTagInColumnGroup(p2, token);
        break;
      }
      case TAG_ID.TR: {
        p2.tmplInsertionModeStack[0] = InsertionMode.IN_TABLE_BODY;
        p2.insertionMode = InsertionMode.IN_TABLE_BODY;
        startTagInTableBody(p2, token);
        break;
      }
      case TAG_ID.TD:
      case TAG_ID.TH: {
        p2.tmplInsertionModeStack[0] = InsertionMode.IN_ROW;
        p2.insertionMode = InsertionMode.IN_ROW;
        startTagInRow(p2, token);
        break;
      }
      default: {
        p2.tmplInsertionModeStack[0] = InsertionMode.IN_BODY;
        p2.insertionMode = InsertionMode.IN_BODY;
        startTagInBody(p2, token);
      }
    }
  }
  function endTagInTemplate(p2, token) {
    if (token.tagID === TAG_ID.TEMPLATE) {
      templateEndTagInHead(p2, token);
    }
  }
  function eofInTemplate(p2, token) {
    if (p2.openElements.tmplCount > 0) {
      p2.openElements.popUntilTagNamePopped(TAG_ID.TEMPLATE);
      p2.activeFormattingElements.clearToLastMarker();
      p2.tmplInsertionModeStack.shift();
      p2._resetInsertionMode();
      p2.onEof(token);
    } else {
      stopParsing(p2, token);
    }
  }
  function startTagAfterBody(p2, token) {
    if (token.tagID === TAG_ID.HTML) {
      startTagInBody(p2, token);
    } else {
      tokenAfterBody(p2, token);
    }
  }
  function endTagAfterBody(p2, token) {
    var _a2;
    if (token.tagID === TAG_ID.HTML) {
      if (!p2.fragmentContext) {
        p2.insertionMode = InsertionMode.AFTER_AFTER_BODY;
      }
      if (p2.options.sourceCodeLocationInfo && p2.openElements.tagIDs[0] === TAG_ID.HTML) {
        p2._setEndLocation(p2.openElements.items[0], token);
        const bodyElement = p2.openElements.items[1];
        if (bodyElement && !((_a2 = p2.treeAdapter.getNodeSourceCodeLocation(bodyElement)) === null || _a2 === void 0 ? void 0 : _a2.endTag)) {
          p2._setEndLocation(bodyElement, token);
        }
      }
    } else {
      tokenAfterBody(p2, token);
    }
  }
  function tokenAfterBody(p2, token) {
    p2.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p2, token);
  }
  function startTagInFrameset(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.FRAMESET: {
        p2._insertElement(token, NS.HTML);
        break;
      }
      case TAG_ID.FRAME: {
        p2._appendElement(token, NS.HTML);
        token.ackSelfClosing = true;
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p2, token);
        break;
      }
    }
  }
  function endTagInFrameset(p2, token) {
    if (token.tagID === TAG_ID.FRAMESET && !p2.openElements.isRootHtmlElementCurrent()) {
      p2.openElements.pop();
      if (!p2.fragmentContext && p2.openElements.currentTagId !== TAG_ID.FRAMESET) {
        p2.insertionMode = InsertionMode.AFTER_FRAMESET;
      }
    }
  }
  function startTagAfterFrameset(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p2, token);
        break;
      }
    }
  }
  function endTagAfterFrameset(p2, token) {
    if (token.tagID === TAG_ID.HTML) {
      p2.insertionMode = InsertionMode.AFTER_AFTER_FRAMESET;
    }
  }
  function startTagAfterAfterBody(p2, token) {
    if (token.tagID === TAG_ID.HTML) {
      startTagInBody(p2, token);
    } else {
      tokenAfterAfterBody(p2, token);
    }
  }
  function tokenAfterAfterBody(p2, token) {
    p2.insertionMode = InsertionMode.IN_BODY;
    modeInBody(p2, token);
  }
  function startTagAfterAfterFrameset(p2, token) {
    switch (token.tagID) {
      case TAG_ID.HTML: {
        startTagInBody(p2, token);
        break;
      }
      case TAG_ID.NOFRAMES: {
        startTagInHead(p2, token);
        break;
      }
    }
  }
  function nullCharacterInForeignContent(p2, token) {
    token.chars = REPLACEMENT_CHARACTER;
    p2._insertCharacters(token);
  }
  function characterInForeignContent(p2, token) {
    p2._insertCharacters(token);
    p2.framesetOk = false;
  }
  function popUntilHtmlOrIntegrationPoint(p2) {
    while (p2.treeAdapter.getNamespaceURI(p2.openElements.current) !== NS.HTML && p2.openElements.currentTagId !== void 0 && !p2._isIntegrationPoint(p2.openElements.currentTagId, p2.openElements.current)) {
      p2.openElements.pop();
    }
  }
  function startTagInForeignContent(p2, token) {
    if (causesExit(token)) {
      popUntilHtmlOrIntegrationPoint(p2);
      p2._startTagOutsideForeignContent(token);
    } else {
      const current = p2._getAdjustedCurrentElement();
      const currentNs = p2.treeAdapter.getNamespaceURI(current);
      if (currentNs === NS.MATHML) {
        adjustTokenMathMLAttrs(token);
      } else if (currentNs === NS.SVG) {
        adjustTokenSVGTagName(token);
        adjustTokenSVGAttrs(token);
      }
      adjustTokenXMLAttrs(token);
      if (token.selfClosing) {
        p2._appendElement(token, currentNs);
      } else {
        p2._insertElement(token, currentNs);
      }
      token.ackSelfClosing = true;
    }
  }
  function endTagInForeignContent(p2, token) {
    if (token.tagID === TAG_ID.P || token.tagID === TAG_ID.BR) {
      popUntilHtmlOrIntegrationPoint(p2);
      p2._endTagOutsideForeignContent(token);
      return;
    }
    for (let i = p2.openElements.stackTop; i > 0; i--) {
      const element = p2.openElements.items[i];
      if (p2.treeAdapter.getNamespaceURI(element) === NS.HTML) {
        p2._endTagOutsideForeignContent(token);
        break;
      }
      const tagName = p2.treeAdapter.getTagName(element);
      if (tagName.toLowerCase() === token.tagName) {
        token.tagName = tagName;
        p2.openElements.shortenToLength(i);
        break;
      }
    }
  }
  /* @__PURE__ */ new Set([
    TAG_NAMES.AREA,
    TAG_NAMES.BASE,
    TAG_NAMES.BASEFONT,
    TAG_NAMES.BGSOUND,
    TAG_NAMES.BR,
    TAG_NAMES.COL,
    TAG_NAMES.EMBED,
    TAG_NAMES.FRAME,
    TAG_NAMES.HR,
    TAG_NAMES.IMG,
    TAG_NAMES.INPUT,
    TAG_NAMES.KEYGEN,
    TAG_NAMES.LINK,
    TAG_NAMES.META,
    TAG_NAMES.PARAM,
    TAG_NAMES.SOURCE,
    TAG_NAMES.TRACK,
    TAG_NAMES.WBR
  ]);
  function parse(html, options) {
    return Parser.parse(html, options);
  }
  function parseFragment(fragmentContext, html, options) {
    if (typeof fragmentContext === "string") {
      options = html;
      html = fragmentContext;
      fragmentContext = null;
    }
    const parser = Parser.getFragmentParser(fragmentContext, options);
    parser.tokenizer.write(html, true);
    return parser.getFragment();
  }
  function createPosition(line, column, offset) {
    return Object.freeze({ column, line, offset });
  }
  function convertSourceRange(location) {
    return Object.freeze({
      end: createPosition(
        location.endLine,
        location.endCol,
        location.endOffset
      ),
      start: createPosition(
        location.startLine,
        location.startCol,
        location.startOffset
      )
    });
  }
  function convertElementSourceRange(location) {
    return Object.freeze({
      ...convertSourceRange(location),
      ...location.endTag === void 0 ? {} : { endTag: convertSourceRange(location.endTag) },
      ...location.startTag === void 0 ? {} : { startTag: convertSourceRange(location.startTag) }
    });
  }
  function findAttributeSourceRange(location, name, prefix) {
    const ranges = location?.attrs;
    if (ranges === void 0) {
      return void 0;
    }
    const qualifiedName = prefix === void 0 ? name : \`\${prefix}:\${name}\`;
    const range = ranges[qualifiedName] ?? ranges[name];
    return range === void 0 ? void 0 : convertSourceRange(range);
  }
  function convertDiagnosticSource(error) {
    return convertSourceRange(error);
  }
  function convertDocument(document) {
    return Object.freeze({
      children: Object.freeze(
        document.childNodes.map((node) => convertDocumentChild(node))
      ),
      type: "document"
    });
  }
  function convertDocumentFragment(fragment) {
    return Object.freeze({
      children: Object.freeze(
        fragment.childNodes.map((node) => convertChild(node))
      ),
      type: "document-fragment"
    });
  }
  function convertDocumentChild(node) {
    if (defaultTreeAdapter.isDocumentTypeNode(node)) {
      return convertDoctype(node);
    }
    return convertChild(node);
  }
  function convertChild(node) {
    if (defaultTreeAdapter.isElementNode(node)) {
      return convertElement(node);
    }
    if (defaultTreeAdapter.isTextNode(node)) {
      return convertText(node);
    }
    if (defaultTreeAdapter.isCommentNode(node)) {
      return convertComment(node);
    }
    throw new Error(
      \`Unexpected document type node outside a complete document: "\${node.name}".\`
    );
  }
  function convertElement(node) {
    const location = node.sourceCodeLocation;
    const children = isHtmlTemplate(node) ? node.content.childNodes : node.childNodes;
    return Object.freeze({
      attributes: Object.freeze(
        node.attrs.map(
          (attribute) => convertAttribute(attribute, location)
        )
      ),
      children: Object.freeze(children.map((child) => convertChild(child))),
      namespace: convertNamespace$1(node.namespaceURI),
      ...location === void 0 || location === null ? {} : { source: convertElementSourceRange(location) },
      tagName: node.tagName,
      type: "element"
    });
  }
  function convertAttribute(attribute, elementLocation) {
    const source = findAttributeSourceRange(
      elementLocation,
      attribute.name,
      attribute.prefix
    );
    return Object.freeze({
      name: attribute.name,
      ...attribute.namespace === void 0 ? {} : { namespace: attribute.namespace },
      ...attribute.prefix === void 0 ? {} : { prefix: attribute.prefix },
      ...source === void 0 ? {} : { source },
      value: attribute.value
    });
  }
  function convertText(node) {
    const source = node.sourceCodeLocation;
    return Object.freeze({
      ...source === void 0 || source === null ? {} : { source: convertSourceRange(source) },
      type: "text",
      value: node.value
    });
  }
  function convertComment(node) {
    const source = node.sourceCodeLocation;
    return Object.freeze({
      ...source === void 0 || source === null ? {} : { source: convertSourceRange(source) },
      type: "comment",
      value: node.data
    });
  }
  function convertDoctype(node) {
    const source = node.sourceCodeLocation;
    return Object.freeze({
      name: node.name,
      publicId: node.publicId,
      ...source === void 0 || source === null ? {} : { source: convertSourceRange(source) },
      systemId: node.systemId,
      type: "doctype"
    });
  }
  function isHtmlTemplate(node) {
    return node.namespaceURI === NS.HTML && node.tagName === "template" && "content" in node;
  }
  function convertNamespace$1(namespace) {
    switch (namespace) {
      case NS.HTML:
        return "html";
      case NS.SVG:
        return "svg";
      case NS.MATHML:
        return "mathml";
      default:
        throw new Error(\`Unsupported element namespace "\${namespace}".\`);
    }
  }
  class Parse5HtmlParser {
    parseDocument(source) {
      const diagnostics = [];
      const document = parse(source, {
        onParseError: (error) => diagnostics.push(convertDiagnostic(error)),
        sourceCodeLocationInfo: true
      });
      return Object.freeze({
        diagnostics: Object.freeze(diagnostics),
        document: convertDocument(document)
      });
    }
    parseFragment(source) {
      const diagnostics = [];
      const fragment = parseFragment(source, {
        onParseError: (error) => diagnostics.push(convertDiagnostic(error)),
        sourceCodeLocationInfo: true
      });
      return Object.freeze({
        diagnostics: Object.freeze(diagnostics),
        document: convertDocumentFragment(fragment)
      });
    }
  }
  function convertDiagnostic(error) {
    return Object.freeze({
      code: error.code,
      message: \`HTML parse error: \${humanizeCode(error.code)}.\`,
      severity: "error",
      source: convertDiagnosticSource(error)
    });
  }
  function humanizeCode(code) {
    return code.replaceAll("-", " ");
  }
  const defaultParser = new Parse5HtmlParser();
  function parseHtmlDocument(source) {
    return defaultParser.parseDocument(source);
  }
  function parseHtmlFragment(source) {
    return defaultParser.parseFragment(source);
  }
  function hasHtmlParserErrors(source) {
    const diagnostics = isCompleteDocument(source) ? parseHtmlDocument(source).diagnostics : parseHtmlFragment(source).diagnostics;
    return diagnostics.some((diagnostic) => diagnostic.severity === "error");
  }
  function isCompleteDocument(source) {
    return /<!doctype\\s|<\\/?(?:html|head|body)(?:\\s|>)/iu.test(source);
  }
  const addEventListenerValue = Reflect.get(
    globalThis,
    "addEventListener"
  );
  if (typeof addEventListenerValue !== "function") {
    throw new Error("HTML formatting worker cannot receive messages.");
  }
  Reflect.apply(addEventListenerValue, globalThis, [
    "message",
    (event) => {
      const request = readRequest(
        typeof event === "object" && event !== null ? Reflect.get(event, "data") : void 0
      );
      if (request === void 0) return;
      if (hasHtmlParserErrors(request.source)) {
        postResponse({
          id: request.id,
          reason: "invalid-source",
          type: "failure"
        });
        return;
      }
      void Pu(request.source, {
        parser: "html",
        plugins: [Zi],
        ...request.options
      }).then(
        (result) => {
          postResponse({
            id: request.id,
            result: keepTagClosingBracketsInline(result),
            type: "success"
          });
        },
        (error) => {
          postResponse({
            id: request.id,
            message: error instanceof Error ? error.message : String(error),
            reason: "formatter",
            type: "failure"
          });
        }
      );
    }
  ]);
  function postResponse(response) {
    const postMessageValue = Reflect.get(globalThis, "postMessage");
    if (typeof postMessageValue !== "function") {
      throw new Error("HTML formatting worker cannot send messages.");
    }
    Reflect.apply(postMessageValue, globalThis, [response]);
  }
  function readRequest(value) {
    if (typeof value !== "object" || value === null) return void 0;
    const id = Reflect.get(value, "id");
    const options = readOptions(Reflect.get(value, "options"));
    const source = Reflect.get(value, "source");
    if (typeof id !== "number" || typeof source !== "string" || options === null) {
      return void 0;
    }
    return {
      id,
      ...options === void 0 ? {} : { options },
      source
    };
  }
  function readOptions(value) {
    if (value === void 0) return void 0;
    if (typeof value !== "object" || value === null) return null;
    const htmlWhitespaceSensitivity = Reflect.get(
      value,
      "htmlWhitespaceSensitivity"
    );
    const printWidth = Reflect.get(value, "printWidth");
    const singleAttributePerLine = Reflect.get(
      value,
      "singleAttributePerLine"
    );
    const tabWidth = Reflect.get(value, "tabWidth");
    const useTabs = Reflect.get(value, "useTabs");
    if (htmlWhitespaceSensitivity !== void 0 && htmlWhitespaceSensitivity !== "css" && htmlWhitespaceSensitivity !== "ignore" && htmlWhitespaceSensitivity !== "strict" || printWidth !== void 0 && typeof printWidth !== "number" || singleAttributePerLine !== void 0 && typeof singleAttributePerLine !== "boolean" || tabWidth !== void 0 && typeof tabWidth !== "number" || useTabs !== void 0 && typeof useTabs !== "boolean") {
      return null;
    }
    return {
      ...htmlWhitespaceSensitivity === void 0 ? {} : { htmlWhitespaceSensitivity },
      ...printWidth === void 0 ? {} : { printWidth },
      ...singleAttributePerLine === void 0 ? {} : { singleAttributePerLine },
      ...tabWidth === void 0 ? {} : { tabWidth },
      ...useTabs === void 0 ? {} : { useTabs }
    };
  }
})();
//# sourceMappingURL=formatting-worker-DS8WsxrR.js.map
`,G=typeof self<"u"&&self.Blob&&new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);",$],{type:"text/javascript;charset=utf-8"});function de(n){let e;try{if(e=G&&(self.URL||self.webkitURL).createObjectURL(G),!e)throw"";const t=new Worker(e,{name:n?.name});return t.addEventListener("error",()=>{(self.URL||self.webkitURL).revokeObjectURL(e)}),t}catch{return new Worker("data:text/javascript;charset=utf-8,"+encodeURIComponent($),{name:n?.name})}}function he(n){let e="",t=!1,r,a,o=-1;for(let s=0;s<n.length;s+=1){const c=n[s];if(!t){if(a!==void 0){if(!Te(n,s,a)){e+=c;continue}t=!0,o=s,e+=c;continue}if(n.startsWith("<!--",s)){const i=n.indexOf("-->",s+4);if(i===-1){e+=n.slice(s);break}e+=n.slice(s,i+3),s=i+2;continue}e+=c,c==="<"&&De(n[s+1])&&(t=!0,o=s);continue}if(r!==void 0){e+=c,c===r&&(r=void 0);continue}if(c==='"'||c==="'"){r=c,e+=c;continue}if(c===">"){const i=n.slice(o,s+1);t=!1,e+=c,/^<script(?:\s|>)/iu.test(i)?a="script":/^<style(?:\s|>)/iu.test(i)?a="style":a!==void 0&&new RegExp(`^<\\/${a}(?:\\s|>)`,"iu").test(i)&&(a=void 0);continue}if(c===`
`||c==="\r"){let i=s+1;for(c==="\r"&&n[i]===`
`&&(i+=1);n[i]===" "||n[i]==="	";)i+=1;if(n[i]===">"){s=i-1;continue}}e+=c}return e}function De(n){return n!==void 0&&/[!/?A-Za-z]/u.test(n)}function Te(n,e,t){const r=n.slice(e,e+t.length+3);return new RegExp(`^<\\/${t}(?:\\s|>)`,"iu").test(r)}function Y(n){return(me(n)?g(n).diagnostics:I(n).diagnostics).some(t=>t.severity==="error")}function me(n){return/<!doctype\s|<\/?(?:html|head|body)(?:\s|>)/iu.test(n)}const Ee=P("soeditor.html-formatting");class S extends Error{constructor(){super("HTML source has parser errors and cannot be formatted safely."),this.name="InvalidHtmlFormattingSourceError"}}class M extends Error{constructor(){super("HTML source changed before formatting completed."),this.name="StaleHtmlFormattingError"}}class _e extends Error{constructor(){super("HTML formatting supports source up to 2 MB."),this.name="HtmlFormattingSourceTooLargeError"}}class fe extends Error{constructor(){super("HTML formatting exceeded 15 seconds and was stopped."),this.name="HtmlFormattingTimeoutError"}}function He(){return Object.freeze({format:(n,e)=>Q(n,V(e===void 0?[]:[e])),minify:async n=>{if(h(n),Y(n))throw new S;return W(n)}})}class $e extends f{static id="html-formatting";static requires=[O];#e=!1;init(){const t=Object.freeze({format:(r,a)=>this.#r(r,a),minify:r=>this.#a(r)});this.editor.services.register(Ee,t),this.editor.commands.register({id:"document.format",label:"Format source HTML",canExecute:({editor:r})=>r.state.document.format==="html"&&r.state.mode==="source",execute:async({editor:r},...a)=>{const o=V(a),s=r.getData();h(s);const c=r.state.document.revision,i=await t.format(s,o);if(r.state.document.revision!==c||r.getData()!==s)throw new M;return i!==s&&r.update(l=>l.replaceDocument(i),{origin:"command"}),i}}),this.editor.commands.register({id:"document.minify",label:"Minify source HTML",canExecute:({editor:r})=>r.state.document.format==="html"&&r.state.mode==="source",execute:async({editor:r},...a)=>{if(a.length!==0)throw new TypeError('Command "document.minify" does not accept arguments.');const o=r.getData();h(o);const s=r.state.document.revision;if((await r.services.get(C).validate(o)).some(l=>l.provider==="html.parser"&&l.severity==="error"))throw new S;const i=await t.minify(o);if(r.state.document.revision!==s||r.getData()!==o)throw new M;return i!==o&&r.update(l=>l.replaceDocument(i),{origin:"command"}),i}})}destroy(){this.#e=!0}async#r(e,t){if(this.#e)throw new b;return Q(e,t)}async#a(e){if(this.#e)throw new b;return h(e),W(e)}}async function Q(n,e){if(h(n),typeof Worker<"u")try{return await Se(n,e)}catch(t){if(!(t instanceof m))throw t}return ge(n,e)}async function ge(n,e){if(Y(n))throw new S;const[{format:t},r]=await Promise.all([R(()=>import("./standalone-Cayz_KD-.js"),[]),R(()=>import("./html-DwgzGnwN.js"),[])]);return he(await t(n,{parser:"html",plugins:[r],...e}))}const Ie=2*1024*1024,Ce=15e3;class m extends Error{constructor(e="HTML formatting worker is unavailable."){super(e),this.name="HtmlFormattingWorkerUnavailableError"}}function h(n){if(n.length>Ie)throw new _e}function Se(n,e){return new Promise((t,r)=>{let a;try{a=new de({name:"soeditor-html-formatter",type:"module"})}catch(i){r(new m(i instanceof Error?i.message:void 0));return}let o=!1;const s=i=>{o||(o=!0,clearTimeout(c),a.terminate(),i())},c=setTimeout(()=>{s(()=>r(new fe))},Ce);a.addEventListener("message",i=>{const l=ke(i.data);l===void 0||l.id!==1||(l.type==="success"?s(()=>t(l.result)):l.reason==="invalid-source"?s(()=>r(new S)):s(()=>r(new Error(l.message??"HTML formatting worker failed."))))}),a.addEventListener("error",i=>{s(()=>r(new m(i.message||"HTML formatting worker failed.")))});try{a.postMessage({id:1,options:e,source:n})}catch(i){s(()=>r(new m(i instanceof Error?i.message:void 0)))}})}function ke(n){if(typeof n!="object"||n===null)return;const e=Reflect.get(n,"id"),t=Reflect.get(n,"type");if(e!==1||t!=="success"&&t!=="failure")return;if(t==="success"){const o=Reflect.get(n,"result");return typeof o=="string"?{id:e,result:o,type:t}:void 0}const r=Reflect.get(n,"reason");if(r!=="formatter"&&r!=="invalid-source")return;const a=Reflect.get(n,"message");if(!(a!==void 0&&typeof a!="string"))return{id:e,...a===void 0?{}:{message:a},reason:r,type:t}}const Ne=new Set(["address","article","aside","blockquote","body","caption","dd","details","dialog","div","dl","dt","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","li","main","menu","nav","ol","p","pre","section","summary","table","tbody","td","tfoot","th","thead","tr","ul"]),be=new Set(["html","head","table","tbody","tfoot","thead","tr"]);function W(n){if(/^\s*(?:<!doctype\s|<html(?:\s|>))/iu.test(n)){const r=g(n),a=Object.freeze({type:"document",children:Fe(r.document.children)});return ne(a)}const e=I(n),t=Object.freeze({type:"document-fragment",children:K(e.document.children)});return te(t)}function Fe(n){return Object.freeze(n.map(e=>e.type==="element"?J(e):e).filter(e=>e.type!=="text"||!/^\s+$/u.test(e.value)||!/[\r\n]/u.test(e.value)))}function K(n,e){const t=n.map(r=>r.type==="element"?J(r):r).filter((r,a,o)=>{if(r.type!=="text"||!/^\s+$/u.test(r.value)||!/[\r\n]/u.test(r.value))return!0;const s=o[a-1],c=o[a+1];return e!==void 0&&be.has(e)?!1:!(T(s)&&T(c)||s===void 0&&T(c)||T(s)&&c===void 0)});return Object.freeze(t)}function J(n){return n.tagName==="pre"||n.tagName==="textarea"||n.tagName==="script"||n.tagName==="style"?n:Object.freeze({...n,children:K(n.children,n.tagName)})}function T(n){return n?.type==="element"&&Ne.has(n.tagName)}function V(n){if(n.length===0)return;if(n.length!==1)throw new TypeError('Command "document.format" accepts at most one options object.');const e=n[0];if(typeof e!="object"||e===null||Array.isArray(e))throw new TypeError('Command "document.format" requires an options object.');const t=e,r=["printWidth","tabWidth","useTabs","singleAttributePerLine","htmlWhitespaceSensitivity"],a=Object.keys(t).find(ee=>!r.includes(ee));if(a!==void 0)throw new TypeError(`Command "document.format" does not support option "${a}".`);const o=v(t.printWidth,"printWidth",40,240),s=v(t.tabWidth,"tabWidth",1,8),c=w(t.useTabs,"useTabs"),i=w(t.singleAttributePerLine,"singleAttributePerLine"),l=t.htmlWhitespaceSensitivity;if(l!==void 0&&l!=="css"&&l!=="strict"&&l!=="ignore")throw new TypeError('Option "htmlWhitespaceSensitivity" must be css, strict, or ignore.');return Object.freeze({...o===void 0?{}:{printWidth:o},...s===void 0?{}:{tabWidth:s},...c===void 0?{}:{useTabs:c},...i===void 0?{}:{singleAttributePerLine:i},...l===void 0?{}:{htmlWhitespaceSensitivity:l}})}function v(n,e,t,r){if(n!==void 0){if(!Number.isInteger(n)||Number(n)<t||Number(n)>r)throw new TypeError(`Option "${e}" must be an integer from ${t} to ${r}.`);return Number(n)}}function w(n,e){if(n!==void 0&&typeof n!="boolean")throw new TypeError(`Option "${e}" must be boolean.`);return n}class N extends TypeError{constructor(e,t){super(`Invalid diagnostic rule configuration at "${e}": ${t}`),this.name="InvalidDiagnosticRuleConfigurationError"}}const ye=Object.freeze({"a11y.form-label":"warning","a11y.heading-order":"warning","a11y.iframe-title":"warning","a11y.interactive-name":"warning"}),Oe=Object.freeze({"seo.document-title":"warning","seo.h1":"info","seo.meta-description":"info"});class Ye extends f{static id="html-accessibility-diagnostics";static requires=[O];#e;init(){const e=j(this.editor.config,"htmlTools.accessibility.rules",ye),t=Object.freeze({id:"html.accessibility",provide:r=>Re(r,e)});this.#e=this.editor.services.get(C).register(t)}destroy(){this.#e?.(),this.#e=void 0}}class Qe extends f{static id="html-seo-diagnostics";static requires=[O];#e;init(){const e=j(this.editor.config,"htmlTools.seo.rules",Oe),t=Object.freeze({id:"html.seo",provide:r=>Be(r,e)});this.#e=this.editor.services.get(C).register(t)}destroy(){this.#e?.(),this.#e=void 0}}function j(n,e,t){const r=n.get(e),a={...t};if(r===void 0)return Object.freeze(a);if(typeof r!="object"||r===null||Array.isArray(r))throw new N(e,"expected an object keyed by a supported rule code.");for(const[o,s]of Object.entries(r)){if(!Object.prototype.hasOwnProperty.call(t,o))throw new N(`${e}.${o}`,"unknown rule code.");if(s!==!1&&!Le(s))throw new N(`${e}.${o}`,'expected false, "error", "warning", "info", or "hint".');a[o]=s}return Object.freeze(a)}function Z(n){const e=xe(n),t=e?g(n):I(n);return{complete:e,children:t.document.children}}function q(n){const e=[],t=(r,a)=>{for(const o of r){if(o.type!=="element")continue;const s=o.namespace==="html"&&o.tagName==="label";e.push({element:o,insideLabel:a}),!(o.namespace==="html"&&o.tagName==="template")&&t(o.children,a||s)}};return t(n,!1),e}function Re(n,e){const t=Z(n),r=q(t.children),a=[],o=new Set;for(const{element:s}of r)if(E(s,"label")){const c=u(s,"for")?.trim();c!==void 0&&c.length>0&&o.add(c)}for(const{element:s,insideLabel:c}of r)if(s.namespace==="html"){if(p(e,"a11y.iframe-title")&&s.tagName==="iframe"){const i=u(s,"title");(i===void 0||i.trim().length===0)&&a.push(A(e,"a11y.iframe-title","Iframe requires a non-empty title for an accessible name.",X(s,"title")))}p(e,"a11y.interactive-name")&&Ge(s)&&!Me(s)&&a.push(A(e,"a11y.interactive-name","Interactive control requires a discernible accessible name.",d(s))),p(e,"a11y.form-label")&&ve(s)&&!c&&!z(s)&&!we(s,o)&&a.push(A(e,"a11y.form-label","Form control requires an associated label or accessible name.",d(s)))}if(t.complete&&p(e,"a11y.heading-order")){let s=0;for(const{element:c}of r){const i=Pe(c);i!==void 0&&(s>0&&i>s+1&&a.push(A(e,"a11y.heading-order",`Heading level jumps from h${s} to h${i}.`,d(c))),s=i)}}return a}function Be(n,e){const t=Z(n);if(!t.complete)return[];const r=q(t.children).map(({element:i})=>i),a=[],o=r.filter(i=>E(i,"title")),s=r.filter(i=>E(i,"meta")&&u(i,"name")?.toLowerCase()==="description"),c=r.filter(i=>E(i,"h1"));if(p(e,"seo.document-title")){if(o.length===0)a.push(A(e,"seo.document-title","Complete HTML document is missing a title element."));else if(o.some(i=>_(i).trim().length===0)){const i=o.find(l=>_(l).trim().length===0);a.push(A(e,"seo.document-title","Document title must not be empty.",i===void 0?void 0:d(i)))}else if(o.length>1){const i=o.at(1);a.push(A(e,"seo.document-title","Complete HTML document contains more than one title element.",i===void 0?void 0:d(i)))}}if(p(e,"seo.meta-description")&&s.find(l=>(u(l,"content")??"").trim().length>0)===void 0){const l=s.at(0);a.push(A(e,"seo.meta-description",s.length===0?"Complete HTML document is missing a meta description.":"Meta description must have non-empty content.",l===void 0?void 0:X(l,"content")))}if(p(e,"seo.h1")){if(c.length===0)a.push(A(e,"seo.h1","Complete HTML document has no h1 heading."));else if(c.length>1){const i=c.at(1);a.push(A(e,"seo.h1","Complete HTML document contains more than one h1 heading.",i===void 0?void 0:d(i)))}}return a}function A(n,e,t,r){const a=n[e];if(a===!1)throw new Error(`Disabled diagnostic rule "${e}" was emitted.`);return{code:e,message:t,severity:a,...r===void 0?{}:{source:r}}}function p(n,e){return n[e]!==!1}function E(n,e){return n.namespace==="html"&&n.tagName===e}function u(n,e){return n.attributes.find(t=>t.name===e)?.value}function X(n,e){return n.attributes.find(t=>t.name===e)?.source??d(n)}function d(n){return n.source?.startTag??n.source}function _(n){let e="";for(const t of n.children)t.type==="text"?e+=t.value:t.type==="element"&&t.tagName!=="template"&&(e+=_(t));return e}function z(n){return["aria-label","aria-labelledby"].some(e=>(u(n,e)??"").trim().length>0)}function Ge(n){if(n.tagName==="button")return!0;if(n.tagName!=="input")return!1;const e=(u(n,"type")??"text").toLowerCase();return["button","image","reset","submit"].includes(e)}function Me(n){return z(n)||_(n).trim().length>0?!0:(((u(n,"type")??"").toLowerCase()==="image"?u(n,"alt"):u(n,"value"))??"").trim().length>0}function ve(n){if(n.tagName==="textarea"||n.tagName==="select")return!0;if(n.tagName!=="input")return!1;const e=(u(n,"type")??"text").toLowerCase();return!["button","hidden","image","reset","submit"].includes(e)}function we(n,e){const t=u(n,"id");return t!==void 0&&t.length>0&&e.has(t)}function Pe(n){if(!(n.namespace!=="html"||!/^h[1-6]$/u.test(n.tagName)))return Number(n.tagName.slice(1))}function Le(n){return n==="error"||n==="warning"||n==="info"||n==="hint"}function xe(n){return/<!doctype\s|<\/?(?:html|head|body)(?:\s|>)/iu.test(n)}export{Ye as AccessibilityDiagnosticsPlugin,re as DiagnosticProviderAlreadyRegisteredError,O as DiagnosticsPlugin,$e as HtmlFormattingPlugin,_e as HtmlFormattingSourceTooLargeError,fe as HtmlFormattingTimeoutError,y as InvalidDiagnosticError,N as InvalidDiagnosticRuleConfigurationError,S as InvalidHtmlFormattingSourceError,Qe as SeoDiagnosticsPlugin,M as StaleHtmlFormattingError,He as createHtmlFormattingService,C as diagnosticsServiceToken,Ee as htmlFormattingServiceToken};
//# sourceMappingURL=index-Dl3snZwh.js.map
