var t=function(){"use strict"
"undefined"!=typeof document&&document.currentScript
class t extends Error{constructor(t,e){super(t,e),this.name=new.target.name}}class e extends t{constructor(){super("The editor has been destroyed and can no longer be used.")}}class i extends t{constructor(){super("Editor initialization was aborted because destruction began before startup completed.")}}class o extends t{constructor(){super("Cannot dispatch a transaction while another dispatch is active.")}}class s extends t{constructor(){super("The transaction was not created by this editor.")}}class r extends t{constructor(){super("The transaction has already been committed.")}}class n extends t{constructor(t,e){super(`Transaction base version ${t} does not match current editor version ${e}.`)}}class a extends t{constructor(t,e){super(`Configuration value at "${t}" has unsupported type "${e}".`)}}class c extends t{constructor(t){super(`Configuration value at "${t}" contains a cycle.`)}}class l extends t{constructor(t){super(`Document format "${t}" is not supported in this release.`)}}class A extends t{constructor(t){super(`Command "${t}" is not registered.`)}}class h extends t{constructor(t){super(`Command "${t}" is already registered.`)}}class d extends t{constructor(t){super(`Plugin "${t}" is not loaded.`)}}class u extends t{constructor(t){super(`Plugin ID "${t}" is declared by multiple plugin constructors.`)}}class f extends t{path
constructor(t){super(`Plugin dependency cycle detected: ${t.join(" -> ")}.`),this.path=Object.freeze([...t])}}class b extends t{constructor(t){super(`Service "${t}" is not registered.`)}}class m extends t{constructor(t){super(`Service "${t}" is already registered.`)}}function p(t,e="config",i=new Set){if(null===t||"boolean"==typeof t||"number"==typeof t||"string"==typeof t)return t
if("object"!=typeof t)throw new a(e,typeof t)
if(i.has(t))throw new c(e)
if(i.add(t),Array.isArray(t))try{return((t,e,i)=>{if(Object.getOwnPropertySymbols(t).length>0)throw new a(e,"symbol-keyed array")
const o=Object.getOwnPropertyNames(t).filter(t=>"length"!==t)
for(const r of o){const t=Number(r)
if(!Number.isInteger(t)||t<0||t+""!==r)throw new a(`${e}.${r}`,"custom array property")}if(o.length!==t.length)throw new a(e,"sparse array")
const s=[]
for(let r=0;r<t.length;r+=1){const o=Object.getOwnPropertyDescriptor(t,r+"")
if(void 0===o||!o.enumerable||!("value"in o))throw new a(`${e}[${r}]`,void 0===o||"value"in o?"nonstandard array index":"accessor")
s.push(p(o.value,`${e}[${r}]`,i))}return Object.freeze(s)})(t,e,i)}finally{i.delete(t)}if(!(t=>{const e=Object.getPrototypeOf(t)
return e===Object.prototype||null===e})(t))throw i.delete(t),new a(e,"non-plain object")
try{if(Object.getOwnPropertySymbols(t).length>0)throw new a(e,"symbol-keyed object")
const o={}
for(const[s,r]of Object.entries(Object.getOwnPropertyDescriptors(t))){if(!("value"in r))throw new a(`${e}.${s}`,"accessor")
r.enumerable&&Object.defineProperty(o,s,{enumerable:!0,value:p(r.value,`${e}.${s}`,i),writable:!0})}return Object.freeze(o)}finally{i.delete(t)}}class g{#t
constructor(t={}){this.#t=p(t)}has(t){return this.#e(t).t}get(t){const e=this.#e(t)
return e.t?e.value:void 0}#e(t){if(0===t.length)return{t:!1}
let e=this.#t
for(const i of t.split(".")){if("object"!=typeof e||null===e||!Object.prototype.hasOwnProperty.call(e,i))return{t:!1}
e=e[i]}return{t:!0,value:e}}}const w=new WeakMap
class v{constructor(t=()=>{}){w.set(this,{i:t,listeners:new Map})}on(t,e){const i=y(this)
i.i()
const o=i.listeners.get(t)??new Set
return o.add(e),i.listeners.set(t,o),()=>{o.delete(e),0===o.size&&i.listeners.delete(t)}}once(t,e){let i=()=>{}
return i=this.on(t,t=>{i(),e(t)}),i}emit(t,e){const i=y(this)
i.i(),C(k(i,t,e))}}function y(t){const e=w.get(t)
if(void 0===e)throw Error("Event bus storage is unavailable.")
return e}function k(t,e,i){const o=t.listeners.get(e)
if(void 0===o)return[]
const s=[]
for(const n of[...o])try{n(i)}catch(r){s.push(r)}return s}function C(t){if(1===t.length)throw t[0]
if(t.length>1)throw new AggregateError(t,"Multiple event listeners failed.")}function I(t,e,i){const o=y(t),s=k(o,e,i)
if("event:error"!==e)for(const r of s)k(o,"event:error",{eventName:e+"",error:r})
return s}function E(t,e,i){C(k(y(t),e,i))}const B=new WeakMap
class x{constructor(t,e,i){B.set(this,{i,commands:new Map,context:Object.freeze({editor:t}),events:e})}register(t){const e=S(this)
if(e.i(),e.commands.has(t.id))throw new h(t.id)
e.commands.set(t.id,t)}unregister(t){const e=S(this)
return e.i(),e.commands.delete(t)}has(t){const e=S(this)
return e.i(),e.commands.has(t)}get(t){const e=S(this)
e.i()
const i=e.commands.get(t)
if(void 0===i)throw new A(t)
return i}ids(){const t=S(this)
return t.i(),Object.freeze([...t.commands.keys()])}canExecute(t){const e=S(this),i=this.get(t)
return i.canExecute?.(e.context)??!0}isActive(t){const e=S(this),i=this.get(t)
return i.isActive?.(e.context)??!1}execute(t,...e){const i=S(this),o=this.get(t)
if(!(o.canExecute?.(i.context)??!0))return
const s=Object.freeze({commandId:t,args:Object.freeze(e)})
let r,n
E(i.events,"command:beforeExecute",s)
try{r=o.execute(i.context,...e),n=(t=>{if(("object"!=typeof t||null===t)&&"function"!=typeof t)return
const e=Reflect.get(t,"then")
return"function"==typeof e?e:void 0})(r)}catch(a){throw I(i.events,"command:error",Object.freeze({...s,error:a})),a}return void 0!==n?((t,e)=>new Promise((i,o)=>{try{e.call(t,i,o)}catch(a){o(a)}}))(r,n).then(t=>(E(i.events,"command:afterExecute",s),t),t=>{throw I(i.events,"command:error",Object.freeze({...s,error:t})),t}):(E(i.events,"command:afterExecute",s),r)}}function S(t){const e=B.get(t)
if(void 0===e)throw Error("Command registry storage is unavailable.")
return e}const D=new WeakMap
class M{constructor(t,e,i){D.set(this,{i,editor:t,events:e,o:new Map,order:[]})}has(t){const e=T(this)
return e.i(),e.o.has("string"==typeof t?t:t.id)}get(t){const e=T(this)
e.i()
const i="string"==typeof t?t:t.id,o=e.o.get(i)
if(void 0===o)throw new d(i)
return o.l}tryGet(t){const e=T(this)
e.i()
const i="string"==typeof t?t:t.id
return e.o.get(i)?.l}}function T(t){const e=D.get(t)
if(void 0===e)throw Error("Plugin manager storage is unavailable.")
return e}function R(t,e,i,o){I(t.events,"plugin:error",Object.freeze({pluginId:e,phase:i,error:o}))}async function F(t,e){const i=Promise.resolve(t).then(()=>({status:"fulfilled"}),t=>({status:"rejected",error:t})),o=e.h()
if(void 0!==o)return await o,void e.u()
const s=await Promise.race([i,e.m.then(()=>({status:"destroying"}))])
if("rejected"===s.status)throw s.error
if("destroying"===s.status){const t=e.h()
if(void 0===t)throw Error("Editor destruction started without a shared destroy promise.")
await t,e.u()}}const _=new WeakMap
function Q(t){return"string"==typeof t?t:t.id}class O{constructor(t){_.set(this,{i:t,services:new Map})}register(t,e){const i=N(this)
i.i()
const o=Q(t)
if(i.services.has(o))throw new m(o)
i.services.set(o,e)}replace(t,e){const i=N(this)
i.i(),i.services.set(Q(t),e)}has(t){const e=N(this)
return e.i(),e.services.has(Q(t))}get(t){const e=N(this)
e.i()
const i=Q(t)
if(!e.services.has(i))throw new b(i)
return e.services.get(i)}tryGet(t){const e=N(this)
return e.i(),e.services.get(Q(t))}unregister(t){const e=N(this)
return e.i(),e.services.delete(Q(t))}}function N(t){const e=_.get(t)
if(void 0===e)throw Error("Service registry storage is unavailable.")
return e}function q(t,e,i=0,o={}){return Object.freeze({format:e,source:t,revision:i,metadata:Object.freeze({...o})})}function j(t){return Object.freeze({...t})}const G=new WeakMap
class H{constructor(t){G.set(this,t)}get origin(){return K(this).origin}get operations(){return[...K(this).operations]}get metadata(){return Object.freeze(Object.fromEntries(K(this).metadata))}replaceDocument(t){return Y(this).operations.push(Object.freeze({type:"replace-document",source:t})),this}setMode(t){return Y(this).operations.push(Object.freeze({type:"set-mode",mode:t})),this}setMeta(t,e){return Y(this).metadata.set(t,e),this}getMeta(t){return K(this).metadata.get(t)}}function K(t){const e=G.get(t)
if(void 0===e)throw new s
return e}function Y(t){const e=K(t)
if(e.committed)throw new r
return e}class W{commands
config
events
plugins
services
#i
#o
#s
#r=Object.freeze({})
#n
#a
#c
#l=!1
#A="initializing"
#h
#d
#u=0
constructor(t){const e=t.format??"html"
if("html"!==e&&"markdown"!==e)throw new l(e)
this.#d=j({document:q(t.data??"",e),mode:t.mode??("markdown"===e?"markdown":"visual"),readonly:t.readonly??!1,dirty:!1}),this.#o=new Promise(t=>{this.#h=t}),this.config=new g(t.config)
const i=()=>this.#f()
var o
this.#s=new v(i),this.#i=new x(this,this.#s,i),this.#a=new O(i),this.#n=new M(this,this.#s,i),this.commands=this.#i,this.events=(o=this.#s,Object.freeze({on:o.on.bind(o),once:o.once.bind(o)})),this.services=this.#a,this.plugins=this.#n}get state(){return this.#d}static async create(t={}){const e=new W(t)
try{let o
await(async(t,e,i)=>{const o=T(t),s=(t=>{const e=new Map,i=new Set,o=[],s=[],r=t=>{const n=e.get(t.id)
if(void 0!==n&&n!==t)throw new u(t.id)
e.set(t.id,t)
const a=o.indexOf(t)
if(-1!==a){const e=o.slice(a).map(t=>t.id)
throw e.push(t.id),new f(e)}if(!i.has(t)){o.push(t)
for(const e of t.requires??[])r(e)
o.pop(),i.add(t),s.push(t)}}
for(const n of t)r(n)
return Object.freeze(s)})(e)
i.u(),o.order=s
const r=Object.freeze({editor:o.editor})
for(const a of o.order){let t
i.u()
try{t=new a(r)}catch(n){throw i.u(),R(o,a.id,"construct",n),n}i.u(),o.o.set(a.id,{constructor:a,l:t,p:"constructed"})}for(const a of o.order){i.u()
const t=o.o.get(a.id)
if(void 0===t)throw Error(`Plugin "${a.id}" was not constructed.`)
try{await F(t.l.init?.(),i)}catch(n){throw i.u(),R(o,a.id,"init",n),n}i.u(),t.p="initialized"}for(const a of o.order){i.u()
const t=o.o.get(a.id)
if(void 0===t)throw Error(`Plugin "${a.id}" was not constructed.`)
try{await F(t.l.ready?.(),i)}catch(n){throw i.u(),R(o,a.id,"ready",n),n}i.u(),t.p="ready"}i.u()})(e.#n,t.plugins??[],{u:()=>e.#b(),m:e.#o,h:()=>e.#c}),e.#m()
let s=!1
try{E(e.#s,"editor:ready",Object.freeze({editor:e}))}catch(i){s=!0,o=i}if(e.#p(),s)throw o
return e}catch(i){throw await e.destroy(),i}}createTransaction(t={}){return this.#g(),((t,e,i)=>new H({v:e,committed:!1,metadata:new Map,operations:[],origin:i.origin??"system",k:t}))(this.#r,this.#u,t)}dispatch(t){if(this.#g(),this.#l)throw new o
this.#l=!0
try{const e=((t,e,i)=>{const o=Y(t)
if(o.k!==e)throw new s
if(o.v!==i)throw new n(o.v,i)
return o.committed=!0,Object.freeze([...o.operations])})(t,this.#r,this.#u)
this.#w(t,e)}finally{this.#l=!1}}update(t,e={}){this.#g()
const i=this.createTransaction(e)
t(i),this.dispatch(i)}execute(t,...e){return this.#g(),this.#i.execute(t,...e)}getData(){return this.#d.document.source}setData(t){this.update(e=>e.replaceDocument(t),{origin:"source"})}setReadonly(t){if(this.#g(),"boolean"!=typeof t)throw new TypeError("Editor readonly state must be a boolean.")
if(this.#d.readonly===t)return
const e=this.#d,i=j({...e,readonly:t})
this.#d=i,this.#u+=1,E(this.#s,"state:change",Object.freeze({previous:e,current:i}))}markClean(){if(this.#g(),!this.#d.dirty)return
const t=this.#d,e=j({...t,dirty:!1})
this.#d=e,this.#u+=1,E(this.#s,"state:change",Object.freeze({previous:t,current:e}))}destroy(){if(void 0!==this.#c)return this.#c
let t,e
this.#A="destroying"
const i=new Promise((i,o)=>{t=i,e=o})
return this.#c=i,this.#h(),this.#v().then(t,e),i}#w(t,e){const i=this.#d
let o=i.document.source,s=i.mode
for(const A of e)switch(A.type){case"replace-document":o=A.source
break
case"set-mode":s=A.mode
break
default:z(A)}const r=o!==i.document.source,n=s!==i.mode
if(!r&&!n)return
const a=r?q(o,i.document.format,i.document.revision+1,i.document.metadata):i.document,c=j({document:a,mode:s,readonly:i.readonly,dirty:!!r||i.dirty})
r&&E(this.#s,"document:beforeChange",Object.freeze({previous:i.document,current:a,transaction:t})),this.#d=c,this.#u+=1
const l=[]
r&&Z(l,()=>E(this.#s,"document:change",Object.freeze({previous:i.document,current:a,transaction:t}))),n&&Z(l,()=>E(this.#s,"mode:change",Object.freeze({previous:i.mode,current:s,transaction:t}))),Z(l,()=>E(this.#s,"state:change",Object.freeze({previous:i,current:c,transaction:t}))),(t=>{if(1===t.length)throw t[0]
if(t.length>1)throw new AggregateError(t,"Multiple editor state notifications failed.")})(l)}async#v(){try{await(async()=>{const t=T(this.#n)
for(const i of[...t.order].reverse()){const o=t.o.get(i.id)
if(void 0!==o&&"constructed"!==o.p&&"destroyed"!==o.p){o.p="destroyed"
try{await(o.l.destroy?.())}catch(e){R(t,i.id,"destroy",e)}}}t.o.clear(),t.order=[]})()}finally{this.#A="destroyed"
try{I(this.#s,"editor:destroy",Object.freeze({editor:this}))}finally{S(this.#i).commands.clear(),N(this.#a).services.clear(),y(this.#s).listeners.clear()}}}#g(){if("destroying"===this.#A||"destroyed"===this.#A)throw new e}#b(){if("initializing"!==this.#A)throw new i}#m(){this.#b(),this.#A="ready"}#p(){if("ready"!==this.#A)throw new i}#f(){if("destroying"===this.#A||"destroyed"===this.#A)throw new e}}function z(t){throw Error(`Unsupported operation: ${JSON.stringify(t)}.`)}function Z(t,e){try{e()}catch(i){t.push(i)}}class U{editor
constructor(t){this.editor=t.editor}}function J(t){return Object.freeze({id:t})}class L extends Error{constructor(){super("A classic editor is already attached to this host."),this.name="ClassicEditorAlreadyAttachedError"}}class P extends Error{constructor(){super("The classic editor has been destroyed."),this.name="ClassicEditorDestroyedError"}}const V=new Set([65534,65535,131070,131071,196606,196607,262142,262143,327678,327679,393214,393215,458750,458751,524286,524287,589822,589823,655358,655359,720894,720895,786430,786431,851966,851967,917502,917503,983038,983039,1048574,1048575,1114110,1114111]),X="�"
var $,tt;(tt=$||($={}))[tt.EOF=-1]="EOF",tt[tt.NULL=0]="NULL",tt[tt.TABULATION=9]="TABULATION",tt[tt.CARRIAGE_RETURN=13]="CARRIAGE_RETURN",tt[tt.LINE_FEED=10]="LINE_FEED",tt[tt.FORM_FEED=12]="FORM_FEED",tt[tt.SPACE=32]="SPACE",tt[tt.EXCLAMATION_MARK=33]="EXCLAMATION_MARK",tt[tt.QUOTATION_MARK=34]="QUOTATION_MARK",tt[tt.AMPERSAND=38]="AMPERSAND",tt[tt.APOSTROPHE=39]="APOSTROPHE",tt[tt.HYPHEN_MINUS=45]="HYPHEN_MINUS",tt[tt.SOLIDUS=47]="SOLIDUS",tt[tt.DIGIT_0=48]="DIGIT_0",tt[tt.DIGIT_9=57]="DIGIT_9",tt[tt.SEMICOLON=59]="SEMICOLON",tt[tt.LESS_THAN_SIGN=60]="LESS_THAN_SIGN",tt[tt.EQUALS_SIGN=61]="EQUALS_SIGN",tt[tt.GREATER_THAN_SIGN=62]="GREATER_THAN_SIGN",tt[tt.QUESTION_MARK=63]="QUESTION_MARK",tt[tt.LATIN_CAPITAL_A=65]="LATIN_CAPITAL_A",tt[tt.LATIN_CAPITAL_Z=90]="LATIN_CAPITAL_Z",tt[tt.RIGHT_SQUARE_BRACKET=93]="RIGHT_SQUARE_BRACKET",tt[tt.GRAVE_ACCENT=96]="GRAVE_ACCENT",tt[tt.LATIN_SMALL_A=97]="LATIN_SMALL_A",tt[tt.LATIN_SMALL_Z=122]="LATIN_SMALL_Z"
const et="script"
function it(t){return t>=55296&&t<=57343}function ot(t){return 32!==t&&10!==t&&13!==t&&9!==t&&12!==t&&t>=1&&t<=31||t>=127&&t<=159}function st(t){return t>=64976&&t<=65007||V.has(t)}var rt,nt,at,ct;(nt=rt||(rt={})).controlCharacterInInputStream="control-character-in-input-stream",nt.noncharacterInInputStream="noncharacter-in-input-stream",nt.surrogateInInputStream="surrogate-in-input-stream",nt.nonVoidHtmlElementStartTagWithTrailingSolidus="non-void-html-element-start-tag-with-trailing-solidus",nt.endTagWithAttributes="end-tag-with-attributes",nt.endTagWithTrailingSolidus="end-tag-with-trailing-solidus",nt.unexpectedSolidusInTag="unexpected-solidus-in-tag",nt.unexpectedNullCharacter="unexpected-null-character",nt.unexpectedQuestionMarkInsteadOfTagName="unexpected-question-mark-instead-of-tag-name",nt.invalidFirstCharacterOfTagName="invalid-first-character-of-tag-name",nt.unexpectedEqualsSignBeforeAttributeName="unexpected-equals-sign-before-attribute-name",nt.missingEndTagName="missing-end-tag-name",nt.unexpectedCharacterInAttributeName="unexpected-character-in-attribute-name",nt.unknownNamedCharacterReference="unknown-named-character-reference",nt.missingSemicolonAfterCharacterReference="missing-semicolon-after-character-reference",nt.unexpectedCharacterAfterDoctypeSystemIdentifier="unexpected-character-after-doctype-system-identifier",nt.unexpectedCharacterInUnquotedAttributeValue="unexpected-character-in-unquoted-attribute-value",nt.eofBeforeTagName="eof-before-tag-name",nt.eofInTag="eof-in-tag",nt.missingAttributeValue="missing-attribute-value",nt.missingWhitespaceBetweenAttributes="missing-whitespace-between-attributes",nt.missingWhitespaceAfterDoctypePublicKeyword="missing-whitespace-after-doctype-public-keyword",nt.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers="missing-whitespace-between-doctype-public-and-system-identifiers",nt.missingWhitespaceAfterDoctypeSystemKeyword="missing-whitespace-after-doctype-system-keyword",nt.missingQuoteBeforeDoctypePublicIdentifier="missing-quote-before-doctype-public-identifier",nt.missingQuoteBeforeDoctypeSystemIdentifier="missing-quote-before-doctype-system-identifier",nt.missingDoctypePublicIdentifier="missing-doctype-public-identifier",nt.missingDoctypeSystemIdentifier="missing-doctype-system-identifier",nt.abruptDoctypePublicIdentifier="abrupt-doctype-public-identifier",nt.abruptDoctypeSystemIdentifier="abrupt-doctype-system-identifier",nt.cdataInHtmlContent="cdata-in-html-content",nt.incorrectlyOpenedComment="incorrectly-opened-comment",nt.eofInScriptHtmlCommentLikeText="eof-in-script-html-comment-like-text",nt.eofInDoctype="eof-in-doctype",nt.nestedComment="nested-comment",nt.abruptClosingOfEmptyComment="abrupt-closing-of-empty-comment",nt.eofInComment="eof-in-comment",nt.incorrectlyClosedComment="incorrectly-closed-comment",nt.eofInCdata="eof-in-cdata",nt.absenceOfDigitsInNumericCharacterReference="absence-of-digits-in-numeric-character-reference",nt.nullCharacterReference="null-character-reference",nt.surrogateCharacterReference="surrogate-character-reference",nt.characterReferenceOutsideUnicodeRange="character-reference-outside-unicode-range",nt.controlCharacterReference="control-character-reference",nt.noncharacterCharacterReference="noncharacter-character-reference",nt.missingWhitespaceBeforeDoctypeName="missing-whitespace-before-doctype-name",nt.missingDoctypeName="missing-doctype-name",nt.invalidCharacterSequenceAfterDoctypeName="invalid-character-sequence-after-doctype-name",nt.duplicateAttribute="duplicate-attribute",nt.nonConformingDoctype="non-conforming-doctype",nt.missingDoctype="missing-doctype",nt.misplacedDoctype="misplaced-doctype",nt.endTagWithoutMatchingOpenElement="end-tag-without-matching-open-element",nt.closingOfElementWithOpenChildElements="closing-of-element-with-open-child-elements",nt.disallowedContentInNoscriptInHead="disallowed-content-in-noscript-in-head",nt.openElementsLeftAfterEof="open-elements-left-after-eof",nt.abandonedHeadElementChild="abandoned-head-element-child",nt.misplacedStartTagForHeadElement="misplaced-start-tag-for-head-element",nt.nestedNoscriptInHead="nested-noscript-in-head",nt.eofInElementThatCanContainOnlyText="eof-in-element-that-can-contain-only-text"
class lt{constructor(t){this.C=t,this.html="",this.D=-1,this.M=-2,this.T=[],this.R=!1,this.F=!1,this._=!1,this.O=65536,this.N=!1,this.q=0,this.j=0,this.line=1,this.G=-1}get H(){return this.D-this.q+Number(this.M!==this.D)}get offset(){return this.j+this.D}getError(t,e){const{line:i,H:o,offset:s}=this,r=o+e,n=s+e
return{code:t,K:i,Y:i,W:r,Z:r,startOffset:n,endOffset:n}}J(t){this.C.L&&this.G!==this.offset&&(this.G=this.offset,this.C.L(this.getError(t,0)))}V(){this.T.push(this.M),this.M=this.D}X(t){if(this.D!==this.html.length-1){const e=this.html.charCodeAt(this.D+1)
if((t=>t>=56320&&t<=57343)(e))return this.D++,this.V(),1024*(t-55296)+9216+e}else if(!this.F)return this._=!0,$.EOF
return this.J(rt.surrogateInInputStream),t}$(){return this.D>this.O}tt(){this.$()&&(this.html=this.html.substring(this.D),this.q-=this.D,this.j+=this.D,this.D=0,this.M=-2,this.T.length=0)}write(t,e){this.html.length>0?this.html+=t:this.html=t,this._=!1,this.F=e}et(t){this.html=this.html.substring(0,this.D+1)+t+this.html.substring(this.D+1),this._=!1}startsWith(t,e){if(this.D+t.length>this.html.length)return this._=!this.F,!1
if(e)return this.html.startsWith(t,this.D)
for(let i=0;i<t.length;i++)if((32|this.html.charCodeAt(this.D+i))!==t.charCodeAt(i))return!1
return!0}it(t){const e=this.D+t
if(e>=this.html.length)return this._=!this.F,$.EOF
const i=this.html.charCodeAt(e)
return i===$.CARRIAGE_RETURN?$.LINE_FEED:i}advance(){if(this.D++,this.N&&(this.N=!1,this.line++,this.q=this.D),this.D>=this.html.length)return this._=!this.F,$.EOF
let t=this.html.charCodeAt(this.D)
return t===$.CARRIAGE_RETURN?(this.N=!0,this.R=!0,$.LINE_FEED):t===$.LINE_FEED&&(this.N=!0,this.R)?(this.line--,this.R=!1,this.V(),this.advance()):(this.R=!1,it(t)&&(t=this.X(t)),null===this.C.L||t>31&&t<127||t===$.LINE_FEED||t===$.CARRIAGE_RETURN||t>159&&t<64976||this.ot(t),t)}ot(t){ot(t)?this.J(rt.controlCharacterInInputStream):st(t)&&this.J(rt.noncharacterInInputStream)}st(t){for(this.D-=t;this.D<this.M;)this.M=this.T.pop(),this.D--
this.N=!1}}function At(t,e){for(let i=t.rt.length-1;i>=0;i--)if(t.rt[i].name===e)return t.rt[i].value
return null}(ct=at||(at={}))[ct.CHARACTER=0]="CHARACTER",ct[ct.NULL_CHARACTER=1]="NULL_CHARACTER",ct[ct.WHITESPACE_CHARACTER=2]="WHITESPACE_CHARACTER",ct[ct.START_TAG=3]="START_TAG",ct[ct.END_TAG=4]="END_TAG",ct[ct.COMMENT=5]="COMMENT",ct[ct.DOCTYPE=6]="DOCTYPE",ct[ct.EOF=7]="EOF",ct[ct.HIBERNATION=8]="HIBERNATION"
const ht=new Map([[0,65533],[128,8364],[130,8218],[131,402],[132,8222],[133,8230],[134,8224],[135,8225],[136,710],[137,8240],[138,352],[139,8249],[140,338],[142,381],[145,8216],[146,8217],[147,8220],[148,8221],[149,8226],[150,8211],[151,8212],[152,732],[153,8482],[154,353],[155,8250],[156,339],[158,382],[159,376]])
function dt(t){const e=atob(t),i=-2&e.length,o=new Uint16Array(i/2)
for(let s=0,r=0;s<i;s+=2){const t=e.charCodeAt(s),i=e.charCodeAt(s+1)
o[r++]=t|i<<8}return o}const ut=dt("QR08ALkAAgH6AYsDNQR2BO0EPgXZBQEGLAbdBxMISQrvCmQLfQurDKQNLw4fD4YPpA+6D/IPAAAAAAAAAAAAAAAAKhBMEY8TmxUWF2EYLBkxGuAa3RsJHDscWR8YIC8jSCSIJcMl6ie3Ku8rEC0CLjoupS7kLgAIRU1hYmNmZ2xtbm9wcnN0dVQAWgBeAGUAaQBzAHcAfgCBAIQAhwCSAJoAoACsALMAbABpAGcAO4DGAMZAUAA7gCYAJkBjAHUAdABlADuAwQDBQHIiZXZlAAJhAAFpeW0AcgByAGMAO4DCAMJAEGRyAADgNdgE3XIAYQB2AGUAO4DAAMBA8CFoYZFj4SFjcgBhZAAAoFMqAAFncIsAjgBvAG4ABGFmAADgNdg43fAlbHlGdW5jdGlvbgCgYSBpAG4AZwA7gMUAxUAAAWNzpACoAHIAAOA12Jzc6SFnbgCgVCJpAGwAZABlADuAwwDDQG0AbAA7gMQAxEAABGFjZWZvcnN1xQDYANoA7QDxAPYA+QD8AAABY3LJAM8AayNzbGFzaAAAoBYidgHTANUAAKDnKmUAZAAAoAYjeQARZIABY3J0AOAA5QDrAGEidXNlAACgNSLuI291bGxpcwCgLCFhAJJjcgAA4DXYBd1wAGYAAOA12Dnd5SF2ZdhiYwDyAOoAbSJwZXEAAKBOIgAHSE9hY2RlZmhpbG9yc3UXARoBHwE6AVIBVQFiAWQBZgGCAakB6QHtAfIBYwB5ACdkUABZADuAqQCpQIABY3B5ACUBKAE1AfUhdGUGYWmg0iJ0KGFsRGlmZmVyZW50aWFsRAAAoEUhbCJleXMAAKAtIQACYWVpb0EBRAFKAU0B8iFvbgxhZABpAGwAO4DHAMdAcgBjAAhhbiJpbnQAAKAwIm8AdAAKYQABZG5ZAV0BaSJsbGEAuGB0I2VyRG90ALdg8gA5AWkAp2NyImNsZQAAAkRNUFRwAXQBeQF9AW8AdAAAoJkiaSJudXMAAKCWIuwhdXMAoJUiaSJtZXMAAKCXIm8AAAFjc4cBlAFrKndpc2VDb250b3VySW50ZWdyYWwAAKAyImUjQ3VybHkAAAFEUZwBpAFvJXVibGVRdW90ZQAAoB0gdSJvdGUAAKAZIAACbG5wdbABtgHNAdgBbwBuAGWgNyIAoHQqgAFnaXQAvAHBAcUB8iJ1ZW50AKBhIm4AdAAAoC8i7yV1ckludGVncmFsAKAuIgABZnLRAdMBAKACIe8iZHVjdACgECJuLnRlckNsb2Nrd2lzZUNvbnRvdXJJbnRlZ3JhbAAAoDMi7yFzcwCgLypjAHIAAOA12J7ccABDoNMiYQBwAACgTSKABURKU1phY2VmaW9zAAsCEgIVAhgCGwIsAjQCOQI9AnMCfwNvoEUh9CJyYWhkAKARKWMAeQACZGMAeQAFZGMAeQAPZIABZ3JzACECJQIoAuchZXIAoCEgcgAAoKEhaAB2AACg5CoAAWF5MAIzAvIhb24OYRRkbAB0oAciYQCUY3IAAOA12AfdAAFhZkECawIAAWNtRQJnAvIjaXRpY2FsAAJBREdUUAJUAl8CYwJjInV0ZQC0YG8AdAFZAloC2WJiJGxlQWN1dGUA3WJyImF2ZQBgYGkibGRlANxi7yFuZACgxCJmJWVyZW50aWFsRAAAoEYhcAR9AgAAAAAAAIECjgIAABoDZgAA4DXYO91EoagAhQKJAm8AdAAAoNwgcSJ1YWwAAKBQIuIhbGUAA0NETFJVVpkCqAK1Au8C/wIRA28AbgB0AG8AdQByAEkAbgB0AGUAZwByAGEA7ADEAW8AdAKvAgAAAACwAqhgbiNBcnJvdwAAoNMhAAFlb7kC0AJmAHQAgAFBUlQAwQLGAs0CciJyb3cAAKDQIekkZ2h0QXJyb3cAoNQhZQDlACsCbgBnAAABTFLWAugC5SFmdAABQVLcAuECciJyb3cAAKD4J+kkZ2h0QXJyb3cAoPon6SRnaHRBcnJvdwCg+SdpImdodAAAAUFU9gL7AnIicm93AACg0iFlAGUAAKCoInAAQQIGAwAAAAALA3Iicm93AACg0SFvJHduQXJyb3cAAKDVIWUlcnRpY2FsQmFyAACgJSJuAAADQUJMUlRhJAM2AzoDWgNxA3oDciJyb3cAAKGTIUJVLAMwA2EAcgAAoBMpcCNBcnJvdwAAoPUhciJldmUAEWPlIWZ00gJDAwAASwMAAFIDaSVnaHRWZWN0b3IAAKBQKWUkZVZlY3RvcgAAoF4p5SJjdG9yQqC9IWEAcgAAoFYpaSJnaHQA1AFiAwAAaQNlJGVWZWN0b3IAAKBfKeUiY3RvckKgwSFhAHIAAKBXKWUAZQBBoKQiciJyb3cAAKCnIXIAcgBvAPcAtAIAAWN0gwOHA3IAAOA12J/c8iFvaxBhAAhOVGFjZGZnbG1vcHFzdHV4owOlA6kDsAO/A8IDxgPNA9ID8gP9AwEEFAQeBCAEJQRHAEphSAA7gNAA0EBjAHUAdABlADuAyQDJQIABYWl5ALYDuQO+A/Ihb24aYXIAYwA7gMoAykAtZG8AdAAWYXIAAOA12AjdcgBhAHYAZQA7gMgAyEDlIm1lbnQAoAgiAAFhcNYD2QNjAHIAEmF0AHkAUwLhAwAAAADpA20lYWxsU3F1YXJlAACg+yVlJ3J5U21hbGxTcXVhcmUAAKCrJQABZ3D2A/kDbwBuABhhZgAA4DXYPN3zImlsb26VY3UAAAFhaQYEDgRsAFSgdSppImxkZQAAoEIi7CNpYnJpdW0AoMwhAAFjaRgEGwRyAACgMCFtAACgcyphAJdjbQBsADuAywDLQAABaXApBC0E8yF0cwCgAyLvJG5lbnRpYWxFAKBHIYACY2Zpb3MAPQQ/BEMEXQRyBHkAJGRyAADgNdgJ3WwibGVkAFMCTAQAAAAAVARtJWFsbFNxdWFyZQAAoPwlZSdyeVNtYWxsU3F1YXJlAACgqiVwA2UEAABpBAAAAABtBGYAAOA12D3dwSFsbACgACLyI2llcnRyZgCgMSFjAPIAcQQABkpUYWJjZGZnb3JzdIgEiwSOBJMElwSkBKcEqwStBLIE5QTqBGMAeQADZDuAPgA+QO0hbWFkoJMD3GNyImV2ZQAeYYABZWl5AJ0EoASjBOQhaWwiYXIAYwAcYRNkbwB0ACBhcgAA4DXYCt0AoNkicABmAADgNdg+3eUiYXRlcgADRUZHTFNUvwTIBM8E1QTZBOAEcSJ1YWwATKBlIuUhc3MAoNsidSRsbEVxdWFsAACgZyJyI2VhdGVyAACgoirlIXNzAKB3IuwkYW50RXF1YWwAoH4qaSJsZGUAAKBzImMAcgAA4DXYotwAoGsiAARBYWNmaW9zdfkE/QQFBQgFCwUTBSIFKwVSIkRjeQAqZAABY3QBBQQFZQBrAMdiXmDpIXJjJGFyAACgDCFsJWJlcnRTcGFjZQAAoAsh8AEYBQAAGwVmAACgDSHpJXpvbnRhbExpbmUAoAAlAAFjdCYFKAXyABIF8iFvayZhbQBwAEQBMQU5BW8AdwBuAEgAdQBtAPAAAAFxInVhbAAAoE8iAAdFSk9hY2RmZ21ub3N0dVMFVgVZBVwFYwVtBXAFcwV6BZAFtgXFBckFzQVjAHkAFWTsIWlnMmFjAHkAAWRjAHUAdABlADuAzQDNQAABaXlnBWwFcgBjADuAzgDOQBhkbwB0ADBhcgAAoBEhcgBhAHYAZQA7gMwAzEAAoREhYXB/BYsFAAFjZ4MFhQVyACphaSNuYXJ5SQAAoEghbABpAGUA8wD6AvQBlQUAAKUFZaAsIgABZ3KaBZ4F8iFhbACgKyLzI2VjdGlvbgCgwiJpI3NpYmxlAAABQ1SsBbEFbyJtbWEAAKBjIGkibWVzAACgYiCAAWdwdAC8Bb8FwwVvAG4ALmFmAADgNdhA3WEAmWNjAHIAAKAQIWkibGRlAChh6wHSBQAA1QVjAHkABmRsADuAzwDPQIACY2Zvc3UA4QXpBe0F8gX9BQABaXnlBegFcgBjADRhGWRyAADgNdgN3XAAZgAA4DXYQd3jAfcFAAD7BXIAAOA12KXc8iFjeQhk6yFjeQRkgANISmFjZm9zAAwGDwYSBhUGHQYhBiYGYwB5ACVkYwB5AAxk8CFwYZpjAAFleRkGHAbkIWlsNmEaZHIAAOA12A7dcABmAADgNdhC3WMAcgAA4DXYptyABUpUYWNlZmxtb3N0AD0GQAZDBl4GawZkB2gHcAd0B80H2gdjAHkACWQ7gDwAPECAAmNtbnByAEwGTwZSBlUGWwb1IXRlOWHiIWRhm2NnAACg6ifsI2FjZXRyZgCgEiFyAACgniGAAWFleQBkBmcGagbyIW9uPWHkIWlsO2EbZAABZnNvBjQHdAAABUFDREZSVFVWYXKABp4GpAbGBssG3AYDByEHwQIqBwABbnKEBowGZyVsZUJyYWNrZXQAAKDoJ/Ihb3cAoZAhQlKTBpcGYQByAACg5CHpJGdodEFycm93AKDGIWUjaWxpbmcAAKAII28A9QGqBgAAsgZiJWxlQnJhY2tldAAAoOYnbgDUAbcGAAC+BmUkZVZlY3RvcgAAoGEp5SJjdG9yQqDDIWEAcgAAoFkpbCJvb3IAAKAKI2kiZ2h0AAABQVbSBtcGciJyb3cAAKCUIeUiY3RvcgCgTikAAWVy4AbwBmUAAKGjIkFW5gbrBnIicm93AACgpCHlImN0b3IAoFopaSNhbmdsZQBCorIi+wYAAAAA/wZhAHIAAKDPKXEidWFsAACgtCJwAIABRFRWAAoHEQcYB+8kd25WZWN0b3IAoFEpZSRlVmVjdG9yAACgYCnlImN0b3JCoL8hYQByAACgWCnlImN0b3JCoLwhYQByAACgUilpAGcAaAB0AGEAcgByAG8A9wDMAnMAAANFRkdMU1Q/B0cHTgdUB1gHXwfxJXVhbEdyZWF0ZXIAoNoidSRsbEVxdWFsAACgZiJyI2VhdGVyAACgdiLlIXNzAKChKuwkYW50RXF1YWwAoH0qaSJsZGUAAKByInIAAOA12A/dZaDYIuYjdGFycm93AKDaIWkiZG90AD9hgAFucHcAege1B7kHZwAAAkxSbHKCB5QHmwerB+UhZnQAAUFSiAeNB3Iicm93AACg9SfpJGdodEFycm93AKD3J+kkZ2h0QXJyb3cAoPYn5SFmdAABYXLcAqEHaQBnAGgAdABhAHIAcgBvAPcA5wJpAGcAaAB0AGEAcgByAG8A9wDuAmYAAOA12EPdZQByAAABTFK/B8YHZSRmdEFycm93AACgmSHpJGdodEFycm93AKCYIYABY2h0ANMH1QfXB/IAWgYAoLAh8iFva0FhAKBqIgAEYWNlZmlvc3XpB+wH7gf/BwMICQgOCBEIcAAAoAUpeQAcZAABZGzyB/kHaSR1bVNwYWNlAACgXyBsI2ludHJmAACgMyFyAADgNdgQ3e4jdXNQbHVzAKATInAAZgAA4DXYRN1jAPIA/gecY4AESmFjZWZvc3R1ACEIJAgoCDUIgQiFCDsKQApHCmMAeQAKZGMidXRlAENhgAFhZXkALggxCDQI8iFvbkdh5CFpbEVhHWSAAWdzdwA7CGEIfQjhInRpdmWAAU1UVgBECEwIWQhlJWRpdW1TcGFjZQAAoAsgaABpAAABY25SCFMIawBTAHAAYQBjAOUASwhlAHIAeQBUAGgAaQDuAFQI9CFlZAABR0xnCHUIcgBlAGEAdABlAHIARwByAGUAYQB0AGUA8gDrBGUAcwBzAEwAZQBzAPMA2wdMImluZQAKYHIAAOA12BHdAAJCbnB0jAiRCJkInAhyImVhawAAoGAgwiZyZWFraW5nU3BhY2WgYGYAAKAVIUOq7CqzCMIIzQgAAOcIGwkAAAAAAAAtCQAAbwkAAIcJAACdCcAJGQoAADQKAAFvdbYIvAjuI2dydWVudACgYiJwIkNhcAAAoG0ibyh1YmxlVmVydGljYWxCYXIAAKAmIoABbHF4ANII1wjhCOUibWVudACgCSL1IWFsVKBgImkibGRlAADgQiI4A2kic3RzAACgBCJyI2VhdGVyAACjbyJFRkdMU1T1CPoIAgkJCQ0JFQlxInVhbAAAoHEidSRsbEVxdWFsAADgZyI4A3IjZWF0ZXIAAOBrIjgD5SFzcwCgeSLsJGFudEVxdWFsAOB+KjgDaSJsZGUAAKB1IvUhbXBEASAJJwnvI3duSHVtcADgTiI4A3EidWFsAADgTyI4A2UAAAFmczEJRgn0JFRyaWFuZ2xlQqLqIj0JAAAAAEIJYQByAADgzyk4A3EidWFsAACg7CJzAICibiJFR0xTVABRCVYJXAlhCWkJcSJ1YWwAAKBwInIjZWF0ZXIAAKB4IuUhc3MA4GoiOAPsJGFudEVxdWFsAOB9KjgDaSJsZGUAAKB0IuUic3RlZAABR0x1CX8J8iZlYXRlckdyZWF0ZXIA4KIqOAPlI3NzTGVzcwDgoSo4A/IjZWNlZGVzAKGAIkVTjwmVCXEidWFsAADgryo4A+wkYW50RXF1YWwAoOAiAAFlaaAJqQl2JmVyc2VFbGVtZW50AACgDCLnJWh0VHJpYW5nbGVCousitgkAAAAAuwlhAHIAAODQKTgDcSJ1YWwAAKDtIgABcXXDCeAJdSNhcmVTdQAAAWJwywnVCfMhZXRF4I8iOANxInVhbAAAoOIi5SJyc2V0ReCQIjgDcSJ1YWwAAKDjIoABYmNwAOYJ8AkNCvMhZXRF4IIi0iBxInVhbAAAoIgi4yJlZWRzgKGBIkVTVAD6CQAKBwpxInVhbAAA4LAqOAPsJGFudEVxdWFsAKDhImkibGRlAADgfyI4A+UicnNldEXggyLSIHEidWFsAACgiSJpImxkZQCAoUEiRUZUACIKJwouCnEidWFsAACgRCJ1JGxsRXF1YWwAAKBHImkibGRlAACgSSJlJXJ0aWNhbEJhcgAAoCQiYwByAADgNdip3GkAbABkAGUAO4DRANFAnWMAB0VhY2RmZ21vcHJzdHV2XgphCmgKcgp2CnoKgQqRCpYKqwqtCrsKyArNCuwhaWdSYWMAdQB0AGUAO4DTANNAAAFpeWwKcQpyAGMAO4DUANRAHmRiImxhYwBQYXIAAOA12BLdcgBhAHYAZQA7gNIA0kCAAWFlaQCHCooKjQpjAHIATGFnAGEAqWNjInJvbgCfY3AAZgAA4DXYRt3lI25DdXJseQABRFGeCqYKbyV1YmxlUXVvdGUAAKAcIHUib3RlAACgGCAAoFQqAAFjbLEKtQpyAADgNdiq3GEAcwBoADuA2ADYQGkAbAHACsUKZABlADuA1QDVQGUAcwAAoDcqbQBsADuA1gDWQGUAcgAAAUJQ0wrmCgABYXLXCtoKcgAAoD4gYQBjAAABZWvgCuIKAKDeI2UAdAAAoLQjYSVyZW50aGVzaXMAAKDcI4AEYWNmaGlsb3JzAP0KAwsFCwkLCwsMCxELIwtaC3IjdGlhbEQAAKACInkAH2RyAADgNdgT3WkApmOgY/Ujc01pbnVzsWAAAWlwFQsgC24AYwBhAHIAZQBwAGwAYQBuAOUACgVmAACgGSGAobsqZWlvACoLRQtJC+MiZWRlc4CheiJFU1QANAs5C0ALcSJ1YWwAAKCvKuwkYW50RXF1YWwAoHwiaSJsZGUAAKB+Im0AZQAAoDMgAAFkcE0LUQv1IWN0AKAPIm8jcnRpb24AYaA3ImwAAKAdIgABY2leC2ILcgAA4DXYq9yoYwACVWZvc2oLbwtzC3cLTwBUADuAIgAiQHIAAOA12BTdcABmAACgGiFjAHIAAOA12KzcAAZCRWFjZWZoaW9yc3WPC5MLlwupC7YL2AvbC90LhQyTDJoMowzhIXJyAKAQKUcAO4CuAK5AgAFjbnIAnQugC6ML9SF0ZVRhZwAAoOsncgB0oKAhbAAAoBYpgAFhZXkArwuyC7UL8iFvblhh5CFpbFZhIGR2oBwhZSJyc2UAAAFFVb8LzwsAAWxxwwvIC+UibWVudACgCyL1JGlsaWJyaXVtAKDLIXAmRXF1aWxpYnJpdW0AAKBvKXIAAKAcIW8AoWPnIWh0AARBQ0RGVFVWYewLCgwQDDIMNwxeDHwM9gIAAW5y8Av4C2clbGVCcmFja2V0AACg6SfyIW93AKGSIUJM/wsDDGEAcgAAoOUhZSRmdEFycm93AACgxCFlI2lsaW5nAACgCSNvAPUBFgwAAB4MYiVsZUJyYWNrZXQAAKDnJ24A1AEjDAAAKgxlJGVWZWN0b3IAAKBdKeUiY3RvckKgwiFhAHIAAKBVKWwib29yAACgCyMAAWVyOwxLDGUAAKGiIkFWQQxGDHIicm93AACgpiHlImN0b3IAoFspaSNhbmdsZQBCorMiVgwAAAAAWgxhAHIAAKDQKXEidWFsAACgtSJwAIABRFRWAGUMbAxzDO8kd25WZWN0b3IAoE8pZSRlVmVjdG9yAACgXCnlImN0b3JCoL4hYQByAACgVCnlImN0b3JCoMAhYQByAACgUykAAXB1iQyMDGYAAKAdIe4kZEltcGxpZXMAoHAp6SRnaHRhcnJvdwCg2yEAAWNongyhDHIAAKAbIQCgsSHsJGVEZWxheWVkAKD0KYAGSE9hY2ZoaW1vcXN0dQC/DMgMzAzQDOIM5gwKDQ0NFA0ZDU8NVA1YDQABQ2PDDMYMyCFjeSlkeQAoZEYiVGN5ACxkYyJ1dGUAWmEAorwqYWVpedgM2wzeDOEM8iFvbmBh5CFpbF5hcgBjAFxhIWRyAADgNdgW3e8hcnQAAkRMUlXvDPYM/QwEDW8kd25BcnJvdwAAoJMhZSRmdEFycm93AACgkCHpJGdodEFycm93AKCSIXAjQXJyb3cAAKCRIechbWGjY+EkbGxDaXJjbGUAoBgicABmAADgNdhK3XICHw0AAAAAIg10AACgGiLhIXJlgKGhJUlTVQAqDTINSg3uJXRlcnNlY3Rpb24AoJMidQAAAWJwNw1ADfMhZXRFoI8icSJ1YWwAAKCRIuUicnNldEWgkCJxInVhbAAAoJIibiJpb24AAKCUImMAcgAA4DXYrtxhAHIAAKDGIgACYmNtcF8Nag2ODZANc6DQImUAdABFoNAicSJ1YWwAAKCGIgABY2huDYkNZSJlZHMAgKF7IkVTVAB4DX0NhA1xInVhbAAAoLAq7CRhbnRFcXVhbACgfSJpImxkZQAAoH8iVABoAGEA9ADHCwCgESIAodEiZXOVDZ8NciJzZXQARaCDInEidWFsAACghyJlAHQAAKDRIoAFSFJTYWNmaGlvcnMAtQ27Db8NyA3ODdsN3w3+DRgOHQ4jDk8AUgBOADuA3gDeQMEhREUAoCIhAAFIY8MNxg1jAHkAC2R5ACZkAAFidcwNzQ0JYKRjgAFhZXkA1A3XDdoN8iFvbmRh5CFpbGJhImRyAADgNdgX3QABZWnjDe4N8gHoDQAA7Q3lImZvcmUAoDQiYQCYYwABY27yDfkNayNTcGFjZQAA4F8gCiDTInBhY2UAoAkg7CFkZYChPCJFRlQABw4MDhMOcSJ1YWwAAKBDInUkbGxFcXVhbAAAoEUiaSJsZGUAAKBIInAAZgAA4DXYS93pI3BsZURvdACg2yAAAWN0Jw4rDnIAAOA12K/c8iFva2Zh4QpFDlYOYA5qDgAAbg5yDgAAAAAAAAAAAAB5DnwOqA6zDgAADg8RDxYPGg8AAWNySA5ODnUAdABlADuA2gDaQHIAb6CfIeMhaXIAoEkpcgDjAVsOAABdDnkADmR2AGUAbGEAAWl5Yw5oDnIAYwA7gNsA20AjZGIibGFjAHBhcgAA4DXYGN1yAGEAdgBlADuA2QDZQOEhY3JqYQABZGl/Dp8OZQByAAABQlCFDpcOAAFhcokOiw5yAF9gYQBjAAABZWuRDpMOAKDfI2UAdAAAoLUjYSVyZW50aGVzaXMAAKDdI28AbgBQoMMi7CF1cwCgjiIAAWdwqw6uDm8AbgByYWYAAOA12EzdAARBREVUYWRwc78O0g7ZDuEOBQPqDvMOBw9yInJvdwDCoZEhyA4AAMwOYQByAACgEilvJHduQXJyb3cAAKDFIW8kd25BcnJvdwAAoJUhcSV1aWxpYnJpdW0AAKBuKWUAZQBBoKUiciJyb3cAAKClIW8AdwBuAGEAcgByAG8A9wAQA2UAcgAAAUxS+Q4AD2UkZnRBcnJvdwAAoJYh6SRnaHRBcnJvdwCglyFpAGyg0gNvAG4ApWPpIW5nbmFjAHIAAOA12LDcaSJsZGUAaGFtAGwAO4DcANxAgAREYmNkZWZvc3YALQ8xDzUPNw89D3IPdg97D4AP4SFzaACgqyJhAHIAAKDrKnkAEmThIXNobKCpIgCg5ioAAWVyQQ9DDwCgwSKAAWJ0eQBJD00Paw9hAHIAAKAWIGmgFiDjIWFsAAJCTFNUWA9cD18PZg9hAHIAAKAjIukhbmV8YGUkcGFyYXRvcgAAoFgnaSJsZGUAAKBAItQkaGluU3BhY2UAoAogcgAA4DXYGd1wAGYAAOA12E3dYwByAADgNdix3GQiYXNoAACgqiKAAmNlZm9zAI4PkQ+VD5kPng/pIXJjdGHkIWdlAKDAInIAAOA12BrdcABmAADgNdhO3WMAcgAA4DXYstwAAmZpb3OqD64Prw+0D3IAAOA12BvdnmNwAGYAAOA12E/dYwByAADgNdiz3IAEQUlVYWNmb3N1AMgPyw/OD9EP2A/gD+QP6Q/uD2MAeQAvZGMAeQAHZGMAeQAuZGMAdQB0AGUAO4DdAN1AAAFpedwP3w9yAGMAdmErZHIAAOA12BzdcABmAADgNdhQ3WMAcgAA4DXYtNxtAGwAeGEABEhhY2RlZm9z/g8BEAUQDRAQEB0QIBAkEGMAeQAWZGMidXRlAHlhAAFheQkQDBDyIW9ufWEXZG8AdAB7YfIBFRAAABwQbwBXAGkAZAB0AOgAVAhhAJZjcgAAoCghcABmAACgJCFjAHIAAOA12LXc4QtCEEkQTRAAAGcQbRByEAAAAAAAAAAAeRCKEJcQ8hD9EAAAGxEhETIROREAAD4RYwB1AHQAZQA7gOEA4UByImV2ZQADYYCiPiJFZGl1eQBWEFkQWxBgEGUQAOA+IjMDAKA/InIAYwA7gOIA4kB0AGUAO4C0ALRAMGRsAGkAZwA7gOYA5kByoGEgAOA12B7dcgBhAHYAZQA7gOAA4EAAAWVwfBCGEAABZnCAEIQQ8yF5bQCgNSHoAIMQaABhALFjAAFhcI0QWwAAAWNskRCTEHIAAWFnAACgPypkApwQAAAAALEQAKInImFkc3ajEKcQqRCuEG4AZAAAoFUqAKBcKmwib3BlAACgWCoAoFoqAKMgImVsbXJzersQvRDAEN0Q5RDtEACgpCllAACgICJzAGQAYaAhImEEzhDQENIQ1BDWENgQ2hDcEACgqCkAoKkpAKCqKQCgqykAoKwpAKCtKQCgrikAoK8pdAB2oB8iYgBkoL4iAKCdKQABcHTpEOwQaAAAoCIixWDhIXJyAKB8IwABZ3D1EPgQbwBuAAVhZgAA4DXYUt0Ao0giRWFlaW9wBxEJEQ0RDxESERQRAKBwKuMhaXIAoG8qAKBKImQAAKBLInMAJ2DyIW94ZaBIIvEADhFpAG4AZwA7gOUA5UCAAWN0eQAmESoRKxFyAADgNdi23CpgbQBwAGWgSCLxAPgBaQBsAGQAZQA7gOMA40BtAGwAO4DkAORAAAFjaUERRxFvAG4AaQBuAPQA6AFuAHQAAKARKgAITmFiY2RlZmlrbG5vcHJzdWQRaBGXEZ8RpxGrEdIR1hErEjASexKKEn0RThNbE3oTbwB0AACg7SoAAWNybBGJEWsAAAJjZXBzdBF4EX0RghHvIW5nAKBMInAjc2lsb24A9mNyImltZQAAoDUgaQBtAGWgPSJxAACgzSJ2AY0RkRFlAGUAAKC9ImUAZABnoAUjZQAAoAUjcgBrAHSgtSPiIXJrAKC2IwABb3mjEaYRbgDnAHcRMWTxIXVvAKAeIIACY21wcnQAtBG5Eb4RwRHFEeEhdXPloDUi5ABwInR5dgAAoLApcwDpAH0RbgBvAPUA6gCAAWFodwDLEcwRzhGyYwCgNiHlIWVuAKBsInIAAOA12B/dZwCAA2Nvc3R1dncA4xHyEQUSEhIhEiYSKRKAAWFpdQDpEesR7xHwAKMFcgBjAACg7yVwAACgwyKAAWRwdAD4EfwRABJvAHQAAKAAKuwhdXMAoAEqaSJtZXMAAKACKnECCxIAAAAADxLjIXVwAKAGKmEAcgAAoAUm8iNpYW5nbGUAAWR1GhIeEu8hd24AoL0lcAAAoLMlcCJsdXMAAKAEKmUA5QBCD+UAkg9hInJvdwAAoA0pgAFha28ANhJoEncSAAFjbjoSZRJrAIABbHN0AEESRxJNEm8jemVuZ2UAAKDrKXEAdQBhAHIA5QBcBPIjaWFuZ2xlgKG0JWRscgBYElwSYBLvIXduAKC+JeUhZnQAoMIlaSJnaHQAAKC4JWsAAKAjJLEBbRIAAHUSsgFxEgAAcxIAoJIlAKCRJTQAAKCTJWMAawAAoIglAAFlb38ShxJx4D0A5SD1IWl2AOBhIuUgdAAAoBAjAAJwdHd4kRKVEpsSnxJmAADgNdhT3XSgpSJvAG0AAKClIvQhaWUAoMgiAAZESFVWYmRobXB0dXayEsES0RLgEvcS+xIKExoTHxMjEygTNxMAAkxSbHK5ErsSvRK/EgCgVyUAoFQlAKBWJQCgUyUAolAlRFVkdckSyxLNEs8SAKBmJQCgaSUAoGQlAKBnJQACTFJsctgS2hLcEt4SAKBdJQCgWiUAoFwlAKBZJQCjUSVITFJobHLrEu0S7xLxEvMS9RIAoGwlAKBjJQCgYCUAoGslAKBiJQCgXyVvAHgAAKDJKQACTFJscgITBBMGEwgTAKBVJQCgUiUAoBAlAKAMJQCiACVEVWR1EhMUExYTGBMAoGUlAKBoJQCgLCUAoDQlaSJudXMAAKCfIuwhdXMAoJ4iaSJtZXMAAKCgIgACTFJsci8TMRMzEzUTAKBbJQCgWCUAoBglAKAUJQCjAiVITFJobHJCE0QTRhNIE0oTTBMAoGolAKBhJQCgXiUAoDwlAKAkJQCgHCUAAWV2UhNVE3YA5QD5AGIAYQByADuApgCmQAACY2Vpb2ITZhNqE24TcgAA4DXYt9xtAGkAAKBPIG0A5aA9IogRbAAAoVwAYmh0E3YTAKDFKfMhdWIAoMgnbAF+E4QTbABloCIgdAAAoCIgcAAAoU4iRWWJE4sTAKCuKvGgTyI8BeEMqRMAAN8TABQDFB8UAAAjFDQUAAAAAIUUAAAAAI0UAAAAANcU4xT3FPsUAACIFQAAlhWAAWNwcgCuE7ET1RP1IXRlB2GAoikiYWJjZHMAuxO/E8QTzhPSE24AZAAAoEQqciJjdXAAAKBJKgABYXXIE8sTcAAAoEsqcAAAoEcqbwB0AACgQCoA4CkiAP4AAWVv2RPcE3QAAKBBIO4ABAUAAmFlaXXlE+8T9RP4E/AB6hMAAO0TcwAAoE0qbwBuAA1hZABpAGwAO4DnAOdAcgBjAAlhcABzAHOgTCptAACgUCpvAHQAC2GAAWRtbgAIFA0UEhRpAGwAO4C4ALhAcCJ0eXYAAKCyKXQAAIGiADtlGBQZFKJAcgBkAG8A9ABiAXIAAOA12CDdgAFjZWkAKBQqFDIUeQBHZGMAawBtoBMn4SFyawCgEyfHY3IAAKPLJUVjZWZtcz8UQRRHFHcUfBSAFACgwykAocYCZWxGFEkUcQAAoFciZQBhAlAUAAAAAGAUciJyb3cAAAFsclYUWhTlIWZ0AKC6IWkiZ2h0AACguyGAAlJTYWNkAGgUaRRrFG8UcxSuYACgyCRzAHQAAKCbIukhcmMAoJoi4SFzaACgnSJuImludAAAoBAqaQBkAACg7yrjIWlyAKDCKfUhYnN1oGMmaQB0AACgYybsApMUmhS2FAAAwxRvAG4AZaA6APGgVCKrAG0CnxQAAAAAoxRhAHSgLABAYAChASJmbKcUqRTuABMNZQAAAW14rhSyFOUhbnQAoAEiZQDzANIB5wG6FAAAwBRkoEUibwB0AACgbSpuAPQAzAGAAWZyeQDIFMsUzhQA4DXYVN1vAOQA1wEAgakAO3MeAdMUcgAAoBchAAFhb9oU3hRyAHIAAKC1IXMAcwAAoBcnAAFjdeYU6hRyAADgNdi43AABYnDuFPIUZaDPKgCg0SploNAqAKDSKuQhb3QAoO8igANkZWxwcnZ3AAYVEBUbFSEVRBVlFYQV4SFycgABbHIMFQ4VAKA4KQCgNSlwAhYVAAAAABkVcgAAoN4iYwAAoN8i4SFycnCgtiEAoD0pgKIqImJjZG9zACsVMBU6FT4VQRVyImNhcAAAoEgqAAFhdTQVNxVwAACgRipwAACgSipvAHQAAKCNInIAAKBFKgDgKiIA/gACYWxydksVURVuFXMVcgByAG2gtyEAoDwpeQCAAWV2dwBYFWUVaRVxAHACXxUAAAAAYxVyAGUA4wAXFXUA4wAZFWUAZQAAoM4iZSJkZ2UAAKDPImUAbgA7gKQApEBlI2Fycm93AAABbHJ7FX8V5SFmdACgtiFpImdodAAAoLchZQDkAG0VAAFjaYsVkRVvAG4AaQBuAPQAkwFuAHQAAKAxImwiY3R5AACgLSOACUFIYWJjZGVmaGlqbG9yc3R1d3oAuBW7Fb8V1RXgFegV+RUKFhUWHxZUFlcWZRbFFtsW7xb7FgUXChdyAPIAtAJhAHIAAKBlKQACZ2xyc8YVyhXOFdAV5yFlcgCgICDlIXRoAKA4IfIA9QxoAHagECAAoKMiawHZFd4VYSJyb3cAAKAPKWEA4wBfAgABYXnkFecV8iFvbg9hNGQAoUYhYW/tFfQVAAFnciEC8RVyAACgyiF0InNlcQAAoHcqgAFnbG0A/xUCFgUWO4CwALBAdABhALRjcCJ0eXYAAKCxKQABaXIOFhIW8yFodACgfykA4DXYId1hAHIAAAFschsWHRYAoMMhAKDCIYACYWVnc3YAKBauAjYWOhY+Fm0AAKHEIm9zLhY0Fm4AZABzoMQi9SFpdACgZiZhIm1tYQDdY2kAbgAAoPIiAKH3AGlvQxZRFmQAZQAAgfcAO29KFksW90BuI3RpbWVzAACgxyJuAPgAUBZjAHkAUmRjAG8CXhYAAAAAYhZyAG4AAKAeI28AcAAAoA0jgAJscHR1dwBuFnEWdRaSFp4W7CFhciRgZgAA4DXYVd0AotkCZW1wc30WhBaJFo0WcQBkoFAibwB0AACgUSJpIm51cwAAoDgi7CF1cwCgFCLxInVhcmUAoKEiYgBsAGUAYgBhAHIAdwBlAGQAZwDlANcAbgCAAWFkaAClFqoWtBZyAHIAbwD3APUMbwB3AG4AYQByAHIAbwB3APMA8xVhI3Jwb29uAAABbHK8FsAWZQBmAPQAHBZpAGcAaAD0AB4WYgHJFs8WawBhAHIAbwD3AJILbwLUFgAAAADYFnIAbgAAoB8jbwBwAACgDCOAAWNvdADhFukW7BYAAXJ55RboFgDgNdi53FVkbAAAoPYp8iFvaxFhAAFkcvMW9xZvAHQAAKDxImkA5qC/JVsSAAFhaP8WAhdyAPIANQNhAPIA1wvhIm5nbGUAoKYpAAFjaQ4XEBd5AF9k5yJyYXJyAKD/JwAJRGFjZGVmZ2xtbm9wcXJzdHV4MRc4F0YXWxcyBF4XaRd5F40XrBe0F78X2RcVGCEYLRg1GEAYAAFEbzUXgRZvAPQA+BUAAWNzPBdCF3UAdABlADuA6QDpQPQhZXIAoG4qAAJhaW95TRdQF1YXWhfyIW9uG2FyAGOgViI7gOoA6kDsIW9uAKBVIk1kbwB0ABdhAAFEcmIXZhdvAHQAAKBSIgDgNdgi3XKhmipuF3QXYQB2AGUAO4DoAOhAZKCWKm8AdAAAoJgqgKGZKmlscwCAF4UXhxfuInRlcnMAoOcjAKATIWSglSpvAHQAAKCXKoABYXBzAJMXlheiF2MAcgATYXQAeQBzogUinxcAAAAAoRdlAHQAAKAFInAAMaADIDMBqRerFwCgBCAAoAUgAAFnc7AXsRdLYXAAAKACIAABZ3C4F7sXbwBuABlhZgAA4DXYVt2AAWFscwDFF8sXzxdyAHOg1SJsAACg4yl1AHMAAKBxKmkAAKG1A2x21RfYF28AbgC1Y/VjAAJjc3V24BfoF/0XEBgAAWlv5BdWF3IAYwAAoFYiaQLuFwAAAADwF+0ADQThIW50AAFnbPUX+Rd0AHIAAKCWKuUhc3MAoJUqgAFhZWkAAxgGGAoYbABzAD1gcwB0AACgXyJ2AESgYSJEAACgeCrwImFyc2wAoOUpAAFEYRkYHRhvAHQAAKBTInIAcgAAoHEpgAFjZGkAJxgqGO0XcgAAoC8hbwD0AIwCAAFhaDEYMhi3YzuA8ADwQAABbXI5GD0YbAA7gOsA60BvAACgrCCAAWNpcABGGEgYSxhsACFgcwD0ACwEAAFlb08YVxhjAHQAYQB0AGkAbwDuABoEbgBlAG4AdABpAGEAbADlADME4Ql1GAAAgRgAAIMYiBgAAAAAoRilGAAAqhgAALsYvhjRGAAA1xgnGWwAbABpAG4AZwBkAG8AdABzAGUA8QBlF3kARGRtImFsZQAAoEAmgAFpbHIAjRiRGJ0Y7CFpZwCgA/tpApcYAAAAAJoYZwAAoAD7aQBnAACgBPsA4DXYI93sIWlnAKAB++whaWcA4GYAagCAAWFsdACvGLIYthh0AACgbSZpAGcAAKAC+24AcwAAoLElbwBmAJJh8AHCGAAAxhhmAADgNdhX3QABYWvJGMwYbADsAGsEdqDUIgCg2SphI3J0aW50AACgDSoAAWFv2hgiGQABY3PeGB8ZsQPnGP0YBRkSGRUZAAAdGbID7xjyGPQY9xj5GAAA+xg7gL0AvUAAoFMhO4C8ALxAAKBVIQCgWSEAoFshswEBGQAAAxkAoFQhAKBWIbQCCxkOGQAAAAAQGTuAvgC+QACgVyEAoFwhNQAAoFghtgEZGQAAGxkAoFohAKBdITgAAKBeIWwAAKBEIHcAbgAAoCIjYwByAADgNdi73IAIRWFiY2RlZmdpamxub3JzdHYARhlKGVoZXhlmGWkZkhmWGZkZnRmgGa0ZxhnLGc8Z4BkjGmygZyIAoIwqgAFjbXAAUBlTGVgZ9SF0ZfVhbQBhAOSgswM6FgCghipyImV2ZQAfYQABaXliGWUZcgBjAB1hM2RvAHQAIWGAoWUibHFzAMYEcBl6GfGhZSLOBAAAdhlsAGEAbgD0AN8EgKF+KmNkbACBGYQZjBljAACgqSpvAHQAb6CAKmyggioAoIQqZeDbIgD+cwAAoJQqcgAA4DXYJN3noGsirATtIWVsAKA3IWMAeQBTZIChdyJFYWoApxmpGasZAKCSKgCgpSoAoKQqAAJFYWVztBm2Gb0ZwhkAoGkicABwoIoq8iFveACgiipxoIgq8aCIKrUZaQBtAACg5yJwAGYAAOA12FjdYQB2AOUAYwIAAWNp0xnWGXIAAKAKIW0AAKFzImVs3BneGQCgjioAoJAqAIM+ADtjZGxxco0E6xn0GfgZ/BkBGgABY2nvGfEZAKCnKnIAAKB6Km8AdAAAoNci0CFhcgCglSl1ImVzdAAAoHwqgAJhZGVscwAKGvQZFhrVBCAa8AEPGgAAFBpwAHIAbwD4AFkZcgAAoHgpcQAAAWxxxAQbGmwAZQBzAPMASRlpAO0A5AQAAWVuJxouGnIjdG5lcXEAAOBpIgD+xQAsGgAFQWFiY2Vma29zeUAaQxpmGmoabRqDGocalhrCGtMacgDyAMwCAAJpbG1yShpOGlAaVBpyAHMA8ABxD2YAvWBpAGwA9AASBQABZHJYGlsaYwB5AEpkAKGUIWN3YBpkGmkAcgAAoEgpAKCtIWEAcgAAoA8h6SFyYyVhgAFhbHIAcxp7Gn8a8iF0c3WgZSZpAHQAAKBlJuwhaXAAoCYg4yFvbgCguSJyAADgNdgl3XMAAAFld4wakRphInJvdwAAoCUpYSJyb3cAAKAmKYACYW1vcHIAnxqjGqcauhq+GnIAcgAAoP8h9CFodACgOyJrAAABbHKsGrMaZSRmdGFycm93AACgqSHpJGdodGFycm93AKCqIWYAAOA12Fnd4iFhcgCgFSCAAWNsdADIGswa0BpyAADgNdi93GEAcwDoAGka8iFvaydhAAFicNca2xr1IWxsAKBDIOghZW4AoBAg4Qr2GgAA/RoAAAgbExsaGwAAIRs7GwAAAAA+G2IbmRuVG6sbAACyG80b0htjAHUAdABlADuA7QDtQAChYyBpeQEbBhtyAGMAO4DuAO5AOGQAAWN4CxsNG3kANWRjAGwAO4ChAKFAAAFmcssCFhsA4DXYJt1yAGEAdgBlADuA7ADsQIChSCFpbm8AJxsyGzYbAAFpbisbLxtuAHQAAKAMKnQAAKAtIuYhaW4AoNwpdABhAACgKSHsIWlnM2GAAWFvcABDG1sbXhuAAWNndABJG0sbWRtyACthgAFlbHAAcQVRG1UbaQBuAOUAyAVhAHIA9AByBWgAMWFmAACgtyJlAGQAtWEAoggiY2ZvdGkbbRt1G3kb4SFyZQCgBSFpAG4AdKAeImkAZQAAoN0pZABvAPQAWxsAoisiY2VscIEbhRuPG5QbYQBsAACguiIAAWdyiRuNG2UAcgDzACMQ4wCCG2EicmhrAACgFyryIW9kAKA8KgACY2dwdJ8boRukG6gbeQBRZG8AbgAvYWYAAOA12FrdYQC5Y3UAZQBzAHQAO4C/AL9AAAFjabUbuRtyAADgNdi+3G4AAKIIIkVkc3bCG8QbyBvQAwCg+SJvAHQAAKD1Inag9CIAoPMiaaBiIOwhZGUpYesB1hsAANkbYwB5AFZkbAA7gO8A70AAA2NmbW9zdeYb7hvyG/Ub+hsFHAABaXnqG+0bcgBjADVhOWRyAADgNdgn3eEhdGg3YnAAZgAA4DXYW93jAf8bAAADHHIAAOA12L/c8iFjeVhk6yFjeVRkAARhY2ZnaGpvcxUcGhwiHCYcKhwtHDAcNRzwIXBhdqC6A/BjAAFleR4cIRzkIWlsN2E6ZHIAAOA12CjdciJlZW4AOGFjAHkARWRjAHkAXGRwAGYAAOA12FzdYwByAADgNdjA3IALQUJFSGFiY2RlZmdoamxtbm9wcnN0dXYAXhxtHHEcdRx5HN8cBx0dHTwd3B3tHfEdAR4EHh0eLB5FHrwewx7hHgkfPR9LH4ABYXJ0AGQcZxxpHHIA8gBvB/IAxQLhIWlsAKAbKeEhcnIAoA4pZ6BmIgCgiyphAHIAAKBiKWMJjRwAAJAcAACVHAAAAAAAAAAAAACZHJwcAACmHKgcrRwAANIc9SF0ZTph7SJwdHl2AKC0KXIAYQDuAFoG4iFkYbtjZwAAoegnZGyhHKMcAKCRKeUAiwYAoIUqdQBvADuAqwCrQHIAgKOQIWJmaGxwc3QAuhy/HMIcxBzHHMoczhxmoOQhcwAAoB8pcwAAoB0p6wCyGnAAAKCrIWwAAKA5KWkAbQAAoHMpbAAAoKIhAKGrKmFl1hzaHGkAbAAAoBkpc6CtKgDgrSoA/oABYWJyAOUc6RztHHIAcgAAoAwpcgBrAACgcicAAWFr8Rz4HGMAAAFla/Yc9xx7YFtgAAFlc/wc/hwAoIspbAAAAWR1Ax0FHQCgjykAoI0pAAJhZXV5Dh0RHRodHB3yIW9uPmEAAWRpFR0YHWkAbAA8YewAowbiAPccO2QAAmNxcnMkHScdLB05HWEAAKA2KXUAbwDyoBwgqhEAAWR1MB00HeghYXIAoGcpcyJoYXIAAKBLKWgAAKCyIQCiZCJmZ3FzRB1FB5Qdnh10AIACYWhscnQATh1WHWUdbB2NHXIicm93AHSgkCFhAOkAzxxhI3Jwb29uAAABZHVeHWId7yF3bgCgvSFwAACgvCHlJGZ0YXJyb3dzAKDHIWkiZ2h0AIABYWhzAHUdex2DHXIicm93APOglCGdBmEAcgBwAG8AbwBuAPMAzgtxAHUAaQBnAGEAcgByAG8A9wBlGugkcmVldGltZXMAoMsi8aFkIk0HAACaHWwAYQBuAPQAXgcAon0qY2Rnc6YdqR2xHbcdYwAAoKgqbwB0AG+gfypyoIEqAKCDKmXg2iIA/nMAAKCTKoACYWRlZ3MAwB3GHcod1h3ZHXAAcAByAG8A+ACmHG8AdAAAoNYicQAAAWdxzx3SHXQA8gBGB2cAdADyAHQcdADyAFMHaQDtAGMHgAFpbHIA4h3mHeod8yFodACgfClvAG8A8gDKBgDgNdgp3UWgdiIAoJEqYQH1Hf4dcgAAAWR1YB35HWygvCEAoGopbABrAACghCVjAHkAWWQAomoiYWNodAweDx4VHhkecgDyAGsdbwByAG4AZQDyAGAW4SFyZACgaylyAGkAAKD6JQABaW8hHiQe5CFvdEBh9SFzdGGgsCPjIWhlAKCwIwACRWFlczMeNR48HkEeAKBoInAAcKCJKvIhb3gAoIkqcaCHKvGghyo0HmkAbQAAoOYiAARhYm5vcHR3elIeXB5fHoUelh6mHqsetB4AAW5yVh5ZHmcAAKDsJ3IAAKD9IXIA6wCwBmcAgAFsbXIAZh52Hnse5SFmdAABYXKIB2weaQBnAGgAdABhAHIAcgBvAPcAkwfhInBzdG8AoPwnaQBnAGgAdABhAHIAcgBvAPcAmgdwI2Fycm93AAABbHKNHpEeZQBmAPQAxhxpImdodAAAoKwhgAFhZmwAnB6fHqIecgAAoIUpAOA12F3ddQBzAACgLSppIm1lcwAAoDQqYQGvHrMecwB0AACgFyLhAIoOZaHKJbkeRhLuIWdlAKDKJWEAcgBsoCgAdAAAoJMpgAJhY2htdADMHs8e1R7bHt0ecgDyAJ0GbwByAG4AZQDyANYWYQByAGSgyyEAoG0pAKAOIHIAaQAAoL8iAANhY2hpcXTrHu8e1QfzHv0eBh/xIXVvAKA5IHIAAOA12MHcbQDloXIi+h4AAPweAKCNKgCgjyoAAWJ19xwBH28AcqAYIACgGiDyIW9rQmEAhDwAO2NkaGlscXJCBhcfxh0gHyQfKB8sHzEfAAFjaRsfHR8AoKYqcgAAoHkqcgBlAOUAkx3tIWVzAKDJIuEhcnIAoHYpdSJlc3QAAKB7KgABUGk1HzkfYQByAACglillocMlAgdfEnIAAAFkdUIfRx9zImhhcgAAoEop6CFhcgCgZikAAWVuTx9WH3IjdG5lcXEAAOBoIgD+xQBUHwAHRGFjZGVmaGlsbm9wc3VuH3Ifoh+rH68ftx+7H74f5h/uH/MfBwj/HwsgxCFvdACgOiIAAmNscHJ5H30fiR+eH3IAO4CvAK9AAAFldIEfgx8AoEImZaAgJ3MAZQAAoCAnc6CmIXQAbwCAoaYhZGx1AJQfmB+cH28AdwDuAHkDZQBmAPQA6gbwAOkO6yFlcgCgriUAAW95ph+qH+0hbWEAoCkqPGThIXNoAKAUIOElc3VyZWRhbmdsZQCgISJyAADgNdgq3W8AAKAnIYABY2RuAMQfyR/bH3IAbwA7gLUAtUBhoiMi0B8AANMf1x9zAPQAKxFpAHIAAKDwKm8AdAA7gLcAt0B1AHMA4qESIh4TAADjH3WgOCIAoCoqYwHqH+0fcAAAoNsq8gB+GnAAbAB1APMACAgAAWRw9x/7H+UhbHMAoKciZgAA4DXYXt0AAWN0AyAHIHIAAOA12MLc8CFvcwCgPiJsobwDECAVIPQiaW1hcACguCJhAPAAEyAADEdMUlZhYmNkZWZnaGlqbG1vcHJzdHV2dzwgRyBmIG0geSCqILgg2iDeIBEhFSEyIUMhTSFQIZwhnyHSIQAiIyKLIrEivyIUIwABZ3RAIEMgAODZIjgD9uBrItIgBwmAAWVsdABNIF8gYiBmAHQAAAFhclMgWCByInJvdwAAoM0h6SRnaHRhcnJvdwCgziEA4NgiOAP24Goi0iBfCekkZ2h0YXJyb3cAoM8hAAFEZHEgdSDhIXNoAKCvIuEhc2gAoK4igAJiY25wdACCIIYgiSCNIKIgbABhAACgByL1IXRlRGFnAADgICLSIACiSSJFaW9wlSCYIJwgniAA4HAqOANkAADgSyI4A3MASWFyAG8A+AAyCnUAcgBhoG4mbADzoG4mmwjzAa8gAACzIHAAO4CgAKBAbQBwAOXgTiI4AyoJgAJhZW91eQDBIMogzSDWINkg8AHGIAAAyCAAoEMqbwBuAEhh5CFpbEZhbgBnAGSgRyJvAHQAAOBtKjgDcAAAoEIqPWThIXNoAKATIACjYCJBYWRxc3jpIO0g+SD+IAIhDCFyAHIAAKDXIXIAAAFocvIg9SBrAACgJClvoJch9wAGD28AdAAA4FAiOAN1AGkA9gC7CAABZWkGIQohYQByAACgKCntAN8I6SFzdPOgBCLlCHIAAOA12CvdAAJFZXN0/wgcISshLiHxoXEiIiEAABMJ8aFxIgAJAAAnIWwAYQBuAPQAEwlpAO0AGQlyoG8iAKBvIoABQWFwADghOyE/IXIA8gBeIHIAcgAAoK4hYQByAACg8ipzogsiSiEAAAAAxwtkoPwiAKD6ImMAeQBaZIADQUVhZGVzdABcIV8hYiFmIWkhkyGWIXIA8gBXIADgZiI4A3IAcgAAoJohcgAAoCUggKFwImZxcwBwIYQhjiF0AAABYXJ1IXohcgByAG8A9wBlIWkAZwBoAHQAYQByAHIAbwD3AD4h8aFwImAhAACKIWwAYQBuAPQAZwlz4H0qOAMAoG4iaQDtAG0JcqBuImkA5aDqIkUJaQDkADoKAAFwdKMhpyFmAADgNdhf3YCBrAA7aW4AriGvIcchrEBuAIChCSJFZHYAtyG6Ib8hAOD5IjgDbwB0AADg9SI4A+EB1gjEIcYhAKD3IgCg9iJpAHagDCLhAagJzyHRIQCg/iIAoP0igAFhb3IA2CHsIfEhcgCAoSYiYXN0AOAh5SHpIWwAbABlAOwAywhsAADg/SrlIADgAiI4A2wiaW50AACgFCrjoYAi9yEAAPohdQDlAJsJY+CvKjgDZaCAIvEAkwkAAkFhaXQHIgoiFyIeInIA8gBsIHIAcgAAoZshY3cRIhQiAOAzKTgDAOCdITgDZyRodGFycm93AACgmyFyAGkA5aDrIr4JgANjaGltcHF1AC8iPCJHIpwhTSJQIloigKGBImNlcgA2Iv0JOSJ1AOUABgoA4DXYw9zvIXJ0bQKdIQAAAABEImEAcgDhAOEhbQBloEEi8aBEIiYKYQDyAMsIcwB1AAABYnBWIlgi5QDUCeUA3wmAAWJjcABgInMieCKAoYQiRWVzAGci7glqIgDgxSo4A2UAdABl4IIi0iBxAPGgiCJoImMAZaCBIvEA/gmAoYUiRWVzAH8iFgqCIgDgxio4A2UAdABl4IMi0iBxAPGgiSKAIgACZ2lscpIilCKaIpwi7AAMCWwAZABlADuA8QDxQOcAWwlpI2FuZ2xlAAABbHKkIqoi5SFmdGWg6iLxAEUJaSJnaHQAZaDrIvEAvgltoL0DAKEjAGVzuCK8InIAbwAAoBYhcAAAoAcggARESGFkZ2lscnMAziLSItYi2iLeIugi7SICIw8j4SFzaACgrSLhIXJyAKAEKXAAAOBNItIg4SFzaACgrCIAAWV04iLlIgDgZSLSIADgPgDSIG4iZmluAACg3imAAUFldADzIvci+iJyAHIAAKACKQDgZCLSIHLgPADSIGkAZQAA4LQi0iAAAUF0BiMKI3IAcgAAoAMp8iFpZQDgtSLSIGkAbQAA4Dwi0iCAAUFhbgAaIx4jKiNyAHIAAKDWIXIAAAFociMjJiNrAACgIylvoJYh9wD/DuUhYXIAoCcpUxJqFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVCMAAF4jaSN/I4IjjSOeI8AUAAAAAKYjwCMAANoj3yMAAO8jHiQvJD8kRCQAAWNzVyNsFHUAdABlADuA8wDzQAABaXlhI2cjcgBjoJoiO4D0APRAPmSAAmFiaW9zAHEjdCN3I3EBeiNzAOgAdhTsIWFjUWF2AACgOCrvIWxkAKC8KewhaWdTYQABY3KFI4kjaQByAACgvykA4DXYLN1vA5QjAAAAAJYjAACcI24A22JhAHYAZQA7gPIA8kAAoMEpAAFibaEjjAphAHIAAKC1KQACYWNpdKwjryO6I70jcgDyAFkUAAFpcrMjtiNyAACgvinvIXNzAKC7KW4A5QDZCgCgwCmAAWFlaQDFI8gjyyNjAHIATWFnAGEAyWOAAWNkbgDRI9Qj1iPyIW9uv2MAoLYpdQDzAHgBcABmAADgNdhg3YABYWVsAOQj5yPrI3IAAKC3KXIAcAAAoLkpdQDzAHwBAKMoImFkaW9zdvkj/CMPJBMkFiQbJHIA8gBeFIChXSplZm0AAyQJJAwkcgBvoDQhZgAAoDQhO4CqAKpAO4C6ALpA5yFvZgCgtiJyAACgVipsIm9wZQAAoFcqAKBbKoABY2xvACMkJSQrJPIACCRhAHMAaAA7gPgA+EBsAACgmCJpAGwBMyQ4JGQAZQA7gPUA9UBlAHMAYaCXInMAAKA2Km0AbAA7gPYA9kDiIWFyAKA9I+EKXiQAAHokAAB8JJQkAACYJKkkAAAAALUkEQsAAPAkAAAAAAQleiUAAIMlcgCAoSUiYXN0AGUkbyQBCwCBtgA7bGokayS2QGwAZQDsABgDaQJ1JAAAAAB4JG0AAKDzKgCg/Sp5AD9kcgCAAmNpbXB0AIUkiCSLJJkSjyRuAHQAJWBvAGQALmBpAGwAAKAwIOUhbmsAoDEgcgAA4DXYLd2AAWltbwCdJKAkpCR2oMYD1WNtAGEA9AD+B24AZQAAoA4m9KHAA64kAAC0JGMjaGZvcmsAAKDUItZjAAFhdbgkxCRuAAABY2u9JMIkawBooA8hAKAOIfYAaRpzAACkKwBhYmNkZW1zdNMkIRPXJNsk4STjJOck6yTjIWlyAKAjKmkAcgAAoCIqAAFvdYsW3yQAoCUqAKByKm4AO4CxALFAaQBtAACgJip3AG8AAKAnKoABaXB1APUk+iT+JO4idGludACgFSpmAADgNdhh3W4AZAA7gKMAo0CApHoiRWFjZWlub3N1ABMlFSUYJRslTCVRJVklSSV1JQCgsypwAACgtyp1AOUAPwtjoK8qgKJ6ImFjZW5zACclLSU0JTYlSSVwAHAAcgBvAPgAFyV1AHIAbAB5AGUA8QA/C/EAOAuAAWFlcwA8JUElRSXwInByb3gAoLkqcQBxAACgtSppAG0AAKDoImkA7QBEC20AZQDzoDIgIguAAUVhcwBDJVclRSXwAEAlgAFkZnAATwtfJXElgAFhbHMAZSVpJW0l7CFhcgCgLiPpIW5lAKASI/UhcmYAoBMjdKAdIu8AWQvyIWVsAKCwIgABY2l9JYElcgAA4DXYxdzIY24iY3NwAACgCCAAA2Zpb3BzdZElKxuVJZolnyWkJXIAAOA12C7dcABmAADgNdhi3XIiaW1lAACgVyBjAHIAAOA12MbcgAFhZW8AqiW6JcAldAAAAWVpryW2JXIAbgBpAG8AbgDzABkFbgB0AACgFipzAHQAZaA/APEACRj0AG0LgApBQkhhYmNkZWZoaWxtbm9wcnN0dXgA4yXyJfYl+iVpJpAmpia9JtUm5ib4JlonaCdxJ3UnnietJ7EnyCfiJ+cngAFhcnQA6SXsJe4lcgDyAJkM8gD6AuEhaWwAoBwpYQByAPIA3BVhAHIAAKBkKYADY2RlbnFydAAGJhAmEyYYJiYmKyZaJgABZXUKJg0mAOA9IjEDdABlAFVhaQDjACAN7SJwdHl2AKCzKWcAgKHpJ2RlbAAgJiImJCYAoJIpAKClKeUA9wt1AG8AO4C7ALtAcgAApZIhYWJjZmhscHN0dz0mQCZFJkcmSiZMJk4mUSZVJlgmcAAAoHUpZqDlIXMAAKAgKQCgMylzAACgHinrALka8ACVHmwAAKBFKWkAbQAAoHQpbAAAoKMhAKCdIQABYWleJmImaQBsAACgGilvAG6gNiJhAGwA8wB2C4ABYWJyAG8mciZ2JnIA8gAvEnIAawAAoHMnAAFha3omgSZjAAABZWt/JoAmfWBdYAABZXOFJocmAKCMKWwAAAFkdYwmjiYAoI4pAKCQKQACYWV1eZcmmiajJqUm8iFvbllhAAFkaZ4moSZpAGwAV2HsAA8M4gCAJkBkAAJjbHFzrSawJrUmuiZhAACgNylkImhhcgAAoGkpdQBvAPKgHSCjAWgAAKCzIYABYWNnAMMm0iaUC2wAgKEcIWlwcwDLJs4migxuAOUAoAxhAHIA9ADaC3QAAKCtJYABaWxyANsm3ybjJvMhaHQAoH0pbwBvAPIANgwA4DXYL90AAWFv6ib1JnIAAAFkde8m8SYAoMEhbKDAIQCgbCl2oMED8WOAAWducwD+Jk4nUCdoAHQAAANhaGxyc3QKJxInISc1Jz0nRydyInJvdwB0oJIhYQDpAFYmYSNycG9vbgAAAWR1GiceJ28AdwDuAPAmcAAAoMAh5SFmdAABYWgnJy0ncgByAG8AdwDzAAkMYQByAHAAbwBvAG4A8wATBGklZ2h0YXJyb3dzAACgySFxAHUAaQBnAGEAcgByAG8A9wBZJugkcmVldGltZXMAoMwiZwDaYmkAbgBnAGQAbwB0AHMAZQDxABwYgAFhaG0AYCdjJ2YncgDyAAkMYQDyABMEAKAPIG8idXN0AGGgsSPjIWhlAKCxI+0haWQAoO4qAAJhYnB0fCeGJ4knmScAAW5ygCeDJ2cAAKDtJ3IAAKD+IXIA6wAcDIABYWZsAI8nkieVJ3IAAKCGKQDgNdhj3XUAcwAAoC4qaSJtZXMAAKA1KgABYXCiJ6gncgBnoCkAdAAAoJQp7yJsaW50AKASKmEAcgDyADwnAAJhY2hxuCe8J6EMwCfxIXVvAKA6IHIAAOA12MfcAAFidYAmxCdvAPKgGSCoAYABaGlyAM4n0ifWJ3IAZQDlAE0n7SFlcwCgyiJpAIChuSVlZmwAXAxjEt4n9CFyaQCgzinsInVoYXIAoGgpAKAeIWENBSgJKA0oSyhVKIYoAACLKLAoAAAAAOMo5ygAABApJCkxKW0pcSmHKaYpAACYKgAAAACxKmMidXRlAFthcQB1AO8ABR+ApHsiRWFjZWlucHN5ABwoHignKCooLygyKEEoRihJKACgtCrwASMoAAAlKACguCpvAG4AYWF1AOUAgw1koLAqaQBsAF9hcgBjAF1hgAFFYXMAOCg6KD0oAKC2KnAAAKC6KmkAbQAAoOki7yJsaW50AKATKmkA7QCIDUFkbwB0AGKixSKRFgAAAABTKACgZiqAA0FhY21zdHgAYChkKG8ocyh1KHkogihyAHIAAKDYIXIAAAFocmkoayjrAJAab6CYIfcAzAd0ADuApwCnQGkAO2D3IWFyAKApKW0AAAFpbn4ozQBuAHUA8wDOAHQAAKA2J3IA7+A12DDdIxkAAmFjb3mRKJUonSisKHIAcAAAoG8mAAFoeZkonChjAHkASWRIZHIAdABtAqUoAAAAAKgoaQDkAFsPYQByAGEA7ABsJDuArQCtQAABZ22zKLsobQBhAAChwwNmdroouijCY4CjPCJkZWdsbnByAMgozCjPKNMo1yjaKN4obwB0AACgairxoEMiCw5FoJ4qAKCgKkWgnSoAoJ8qZQAAoEYi7CF1cwCgJCrhIXJyAKByKWEAcgDyAPwMAAJhZWl07Sj8KAEpCCkAAWxz8Sj4KGwAcwBlAHQAbQDpAH8oaABwAACgMyrwImFyc2wAoOQpAAFkbFoPBSllAACgIyNloKoqc6CsKgDgrCoA/oABZmxwABUpGCkfKfQhY3lMZGKgLwBhoMQpcgAAoD8jZgAA4DXYZN1hAAABZHIoKRcDZQBzAHWgYCZpAHQAAKBgJoABY3N1ADYpRilhKQABYXU6KUApcABzoJMiAOCTIgD+cABzoJQiAOCUIgD+dQAAAWJwSylWKQChjyJlcz4NUCllAHQAZaCPIvEAPw0AoZAiZXNIDVspZQB0AGWgkCLxAEkNAKGhJWFmZilbBHIAZQFrKVwEAKChJWEAcgDyAAMNAAJjZW10dyl7KX8pgilyAADgNdjI3HQAbQDuAM4AaQDsAAYpYQByAOYAVw0AAWFyiimOKXIA5qAGJhESAAFhbpIpoylpImdodAAAAWVwmSmgKXAAcwBpAGwAbwDuANkXaADpAKAkcwCvYIACYmNtbnAArin8KY4NJSooKgCkgiJFZGVtbnByc7wpvinCKcgpzCnUKdgp3CkAoMUqbwB0AACgvSpkoIYibwB0AACgwyr1IWx0AKDBKgABRWXQKdIpAKDLKgCgiiLsIXVzAKC/KuEhcnIAoHkpgAFlaXUA4inxKfQpdAAAoYIiZW7oKewpcQDxoIYivSllAHEA8aCKItEpbQAAoMcqAAFicPgp+ikAoNUqAKDTKmMAgKJ7ImFjZW5zAAcqDSoUKhYqRihwAHAAcgBvAPgAIyh1AHIAbAB5AGUA8QCDDfEAfA2AAWFlcwAcKiIqPShwAHAAcgBvAPgAPChxAPEAOShnAACgaiYApoMiMTIzRWRlaGxtbnBzPCo/KkIqRSpHKlIqWCpjKmcqaypzKncqO4C5ALlAO4CyALJAO4CzALNAAKDGKgABb3NLKk4qdAAAoL4qdQBiAACg2CpkoIcibwB0AACgxCpzAAABb3VdKmAqbAAAoMknYgAAoNcq4SFycgCgeyn1IWx0AKDCKgABRWVvKnEqAKDMKgCgiyLsIXVzAKDAKoABZWl1AH0qjCqPKnQAAKGDImVugyqHKnEA8aCHIkYqZQBxAPGgiyJwKm0AAKDIKgABYnCTKpUqAKDUKgCg1iqAAUFhbgCdKqEqrCpyAHIAAKDZIXIAAAFocqYqqCrrAJUab6CZIfcAxQf3IWFyAKAqKWwAaQBnADuA3wDfQOELzyrZKtwq6SrsKvEqAAD1KjQrAAAAAAAAAAAAAEwrbCsAAHErvSsAAAAAAADRK3IC1CoAAAAA2CrnIWV0AKAWI8RjcgDrAOUKgAFhZXkA4SrkKucq8iFvbmVh5CFpbGNhQmRvAPQAIg5sInJlYwAAoBUjcgAA4DXYMd0AAmVpa2/7KhIrKCsuK/IBACsAAAkrZQAAATRm6g0EK28AcgDlAOsNYQBzorgDECsAAAAAEit5AG0A0WMAAWNuFislK2sAAAFhcxsrIStwAHAAcgBvAPgAFw5pAG0AAKA8InMA8AD9DQABYXMsKyEr8AAXDnIAbgA7gP4A/kDsATgrOyswG2QA5QBnAmUAcwCAgdcAO2JkAEMrRCtJK9dAYaCgInIAAKAxKgCgMCqAAWVwcwBRK1MraSvhAAkh4qKkIlsrXysAAAAAYytvAHQAAKA2I2kAcgAAoPEqb+A12GXdcgBrAACg2irhAHgociJpbWUAAKA0IIABYWlwAHYreSu3K2QA5QC+DYADYWRlbXBzdACFK6MrmiunK6wrsCuzK24iZ2xlAACitSVkbHFykCuUK5ornCvvIXduAKC/JeUhZnRloMMl8QACBwCgXCJpImdodABloLkl8QBdDG8AdAAAoOwlaSJudXMAAKA6KuwhdXMAoDkqYgAAoM0p6SFtZQCgOyrlInppdW0AoOIjgAFjaHQAwivKK80rAAFyecYrySsA4DXYydxGZGMAeQBbZPIhb2tnYQABaW/UK9creAD0ANERaCJlYWQAAAFsct4r5ytlAGYAdABhAHIAcgBvAPcAXQbpJGdodGFycm93AKCgIQAJQUhhYmNkZmdobG1vcHJzdHV3CiwNLBEsHSwnLDEsQCxLLFIsYix6LIQsjyzLLOgs7Sz/LAotcgDyAAkDYQByAACgYykAAWNyFSwbLHUAdABlADuA+gD6QPIACQ1yAOMBIywAACUseQBeZHYAZQBtYQABaXkrLDAscgBjADuA+wD7QENkgAFhYmgANyw6LD0scgDyANEO7CFhY3FhYQDyAOAOAAFpckQsSCzzIWh0AKB+KQDgNdgy3XIAYQB2AGUAO4D5APlAYQFWLF8scgAAAWxyWixcLACgvyEAoL4hbABrAACggCUAAWN0Zix2LG8CbCwAAAAAcyxyAG4AZaAcI3IAAKAcI28AcAAAoA8jcgBpAACg+CUAAWFsfiyBLGMAcgBrYTuAqACoQAABZ3CILIssbwBuAHNhZgAA4DXYZt0AA2FkaGxzdZksniynLLgsuyzFLHIAcgBvAPcACQ1vAHcAbgBhAHIAcgBvAPcA2A5hI3Jwb29uAAABbHKvLLMsZQBmAPQAWyxpAGcAaAD0AF0sdQDzAKYOaQAAocUDaGzBLMIs0mNvAG4AxWPwI2Fycm93cwCgyCGAAWNpdADRLOEs5CxvAtcsAAAAAN4scgBuAGWgHSNyAACgHSNvAHAAAKAOI24AZwBvYXIAaQAAoPklYwByAADgNdjK3IABZGlyAPMs9yz6LG8AdAAAoPAi7CFkZWlhaQBmoLUlAKC0JQABYW0DLQYtcgDyAMosbAA7gPwA/EDhIm5nbGUAoKcpgAdBQkRhY2RlZmxub3Byc3oAJy0qLTAtNC2bLZ0toS2/LcMtxy3TLdgt3C3gLfwtcgDyABADYQByAHag6CoAoOkqYQBzAOgA/gIAAW5yOC08LechcnQAoJwpgANla25wcnN0AJkpSC1NLVQtXi1iLYItYQBwAHAA4QAaHG8AdABoAGkAbgDnAKEXgAFoaXIAoSmzJFotbwBwAPQAdCVooJUh7wD4JgABaXVmLWotZwBtAOEAuygAAWJwbi14LXMjZXRuZXEAceCKIgD+AODLKgD+cyNldG5lcQBx4IsiAP4A4MwqAP4AAWhyhi2KLWUAdADhABIraSNhbmdsZQAAAWxyki2WLeUhZnQAoLIiaSJnaHQAAKCzInkAMmThIXNoAKCiIoABZWxyAKcttC24LWKiKCKuLQAAAACyLWEAcgAAoLsicQAAoFoi7CFpcACg7iIAAWJ0vC1eD2EA8gBfD3IAAOA12DPddAByAOkAlS1zAHUAAAFicM0t0C0A4IIi0iAA4IMi0iBwAGYAAOA12GfdcgBvAPAAWQt0AHIA6QCaLQABY3XkLegtcgAA4DXYy9wAAWJw7C30LW4AAAFFZXUt8S0A4IoiAP5uAAABRWV/LfktAOCLIgD+6SJnemFnAKCaKYADY2Vmb3BycwANLhAuJS4pLiMuLi40LukhcmN1YQABZGkULiEuAAFiZxguHC5hAHIAAKBfKmUAcaAnIgCgWSLlIXJwAKAYIXIAAOA12DTdcABmAADgNdho3WWgQCJhAHQA6ABqD2MAcgAA4DXYzNzjCuQRUC4AAFQuAABYLmIuAAAAAGMubS5wLnQuAAAAAIguki4AAJouJxIqEnQAcgDpAB0ScgAA4DXYNd0AAUFhWy5eLnIA8gDnAnIA8gCTB75jAAFBYWYuaS5yAPIA4AJyAPIAjAdhAPAAeh5pAHMAAKD7IoABZHB0APgReS6DLgABZmx9LoAuAOA12GnddQDzAP8RaQBtAOUABBIAAUFhiy6OLnIA8gDuAnIA8gCaBwABY3GVLgoScgAA4DXYzdwAAXB0nS6hLmwAdQDzACUScgDpACASAARhY2VmaW9zdbEuvC7ELsguzC7PLtQu2S5jAAABdXm2LrsudABlADuA/QD9QE9kAAFpecAuwy5yAGMAd2FLZG4AO4ClAKVAcgAA4DXYNt1jAHkAV2RwAGYAAOA12GrdYwByAADgNdjO3AABY23dLt8ueQBOZGwAO4D/AP9AAAVhY2RlZmhpb3N38y73Lv8uAi8MLxAvEy8YLx0vIi9jInV0ZQB6YQABYXn7Lv4u8iFvbn5hN2RvAHQAfGEAAWV0Bi8KL3QAcgDmAB8QYQC2Y3IAAOA12DfdYwB5ADZk5yJyYXJyAKDdIXAAZgAA4DXYa91jAHIAAOA12M/cAAFqbiYvKC8AoA0gagAAoAwg")
var ft,bt,mt,pt,gt,wt,vt,yt,kt,Ct,It,Et,Bt,xt,St,Dt,Mt,Tt
function Rt(t){return t>=mt.ZERO&&t<=mt.NINE}function Ft(t){return t>=mt.UPPER_A&&t<=mt.UPPER_F||t>=mt.LOWER_A&&t<=mt.LOWER_F}function _t(t){return t===mt.EQUALS||(t=>t>=mt.UPPER_A&&t<=mt.UPPER_Z||t>=mt.LOWER_A&&t<=mt.LOWER_Z||Rt(t))(t)}(bt=ft||(ft={}))[bt.VALUE_LENGTH=49152]="VALUE_LENGTH",bt[bt.FLAG13=8192]="FLAG13",bt[bt.BRANCH_LENGTH=8064]="BRANCH_LENGTH",bt[bt.JUMP_TABLE=127]="JUMP_TABLE",(pt=mt||(mt={}))[pt.NUM=35]="NUM",pt[pt.SEMI=59]="SEMI",pt[pt.EQUALS=61]="EQUALS",pt[pt.ZERO=48]="ZERO",pt[pt.NINE=57]="NINE",pt[pt.LOWER_A=97]="LOWER_A",pt[pt.LOWER_F=102]="LOWER_F",pt[pt.LOWER_X=120]="LOWER_X",pt[pt.LOWER_Z=122]="LOWER_Z",pt[pt.UPPER_A=65]="UPPER_A",pt[pt.UPPER_F=70]="UPPER_F",pt[pt.UPPER_Z=90]="UPPER_Z",(wt=gt||(gt={}))[wt.EntityStart=0]="EntityStart",wt[wt.NumericStart=1]="NumericStart",wt[wt.NumericDecimal=2]="NumericDecimal",wt[wt.NumericHex=3]="NumericHex",wt[wt.NamedEntity=4]="NamedEntity",(yt=vt||(vt={}))[yt.Legacy=0]="Legacy",yt[yt.Strict=1]="Strict",yt[yt.Attribute=2]="Attribute"
class Qt{nt
ct
lt
constructor(t,e,i){this.nt=t,this.ct=e,this.lt=i}state=gt.EntityStart
consumed=1
result=0
At=0
ht=1
dt=vt.Strict
ut=0
ft(t){this.dt=t,this.state=gt.EntityStart,this.result=0,this.At=0,this.ht=1,this.consumed=1,this.ut=0}write(t,e){switch(this.state){case gt.EntityStart:return t.charCodeAt(e)===mt.NUM?(this.state=gt.NumericStart,this.consumed+=1,this.bt(t,e+1)):(this.state=gt.NamedEntity,this.gt(t,e))
case gt.NumericStart:return this.bt(t,e)
case gt.NumericDecimal:return this.wt(t,e)
case gt.NumericHex:return this.vt(t,e)
case gt.NamedEntity:return this.gt(t,e)}}bt(t,e){return e>=t.length?-1:(32|t.charCodeAt(e))===mt.LOWER_X?(this.state=gt.NumericHex,this.consumed+=1,this.vt(t,e+1)):(this.state=gt.NumericDecimal,this.wt(t,e))}vt(t,e){for(;e<t.length;){const i=t.charCodeAt(e)
if(!Rt(i)&&!Ft(i))return this.yt(i,3)
{const t=i<=mt.NINE?i-mt.ZERO:(32|i)-mt.LOWER_A+10
this.result=16*this.result+t,this.consumed++,e++}}return-1}wt(t,e){for(;e<t.length;){const i=t.charCodeAt(e)
if(!Rt(i))return this.yt(i,2)
this.result=10*this.result+(i-mt.ZERO),this.consumed++,e++}return-1}yt(t,e){if(this.consumed<=e)return this.lt?.absenceOfDigitsInNumericCharacterReference(this.consumed),0
if(t===mt.SEMI)this.consumed+=1
else if(this.dt===vt.Strict)return 0
var i
return this.ct((i=this.result)>=55296&&i<=57343||i>1114111?65533:ht.get(i)??i,this.consumed),this.lt&&(t!==mt.SEMI&&this.lt.missingSemicolonAfterCharacterReference(),this.lt.kt(this.result)),this.consumed}gt(t,e){const{nt:i}=this
let o=i[this.At],s=(o&ft.VALUE_LENGTH)>>14
for(;e<t.length;){if(0===s&&0!==(o&ft.FLAG13)){const r=(o&ft.BRANCH_LENGTH)>>7
if(0===this.ut){const i=o&ft.JUMP_TABLE
if(t.charCodeAt(e)!==i)return 0===this.result?0:this.Ct()
e++,this.ht++,this.ut++}for(;this.ut<r;){if(e>=t.length)return-1
const o=this.ut-1,s=i[this.At+1+(o>>1)],r=o%2==0?255&s:s>>8&255
if(t.charCodeAt(e)!==r)return this.ut=0,0===this.result?0:this.Ct()
e++,this.ht++,this.ut++}this.ut=0,this.At+=1+(r>>1),o=i[this.At],s=(o&ft.VALUE_LENGTH)>>14}if(e>=t.length)break
const r=t.charCodeAt(e)
if(r===mt.SEMI&&0!==s&&0!==(o&ft.FLAG13))return this.It(this.At,s,this.consumed+this.ht)
if(this.At=Ot(i,o,this.At+Math.max(1,s),r),this.At<0)return 0===this.result||this.dt===vt.Attribute&&(0===s||_t(r))?0:this.Ct()
if(o=i[this.At],s=(o&ft.VALUE_LENGTH)>>14,0!==s){if(r===mt.SEMI)return this.It(this.At,s,this.consumed+this.ht)
this.dt!==vt.Strict&&0===(o&ft.FLAG13)&&(this.result=this.At,this.consumed+=this.ht,this.ht=0)}e++,this.ht++}return-1}Ct(){const{result:t,nt:e}=this,i=(e[t]&ft.VALUE_LENGTH)>>14
return this.It(t,i,this.consumed),this.lt?.missingSemicolonAfterCharacterReference(),this.consumed}It(t,e,i){const{nt:o}=this
return this.ct(1===e?o[t]&~(ft.VALUE_LENGTH|ft.FLAG13):o[t+1],i),3===e&&this.ct(o[t+2],i),i}end(){switch(this.state){case gt.NamedEntity:return 0===this.result||this.dt===vt.Attribute&&this.result!==this.At?0:this.Ct()
case gt.NumericDecimal:return this.yt(0,2)
case gt.NumericHex:return this.yt(0,3)
case gt.NumericStart:return this.lt?.absenceOfDigitsInNumericCharacterReference(this.consumed),0
case gt.EntityStart:return 0}}}function Ot(t,e,i,o){const s=(e&ft.BRANCH_LENGTH)>>7,r=e&ft.JUMP_TABLE
if(0===s)return 0!==r&&o===r?i:-1
if(r){const e=o-r
return e<0||e>=s?-1:t[i+e]-1}const n=s+1>>1
let a=0,c=s-1
for(;a<=c;){const e=a+c>>>1,s=t[i+(e>>1)]>>8*(1&e)&255
if(s<o)a=e+1
else{if(!(s>o))return t[i+n+e]
c=e-1}}return-1}(Ct=kt||(kt={})).HTML="http://www.w3.org/1999/xhtml",Ct.MATHML="http://www.w3.org/1998/Math/MathML",Ct.SVG="http://www.w3.org/2000/svg",Ct.XLINK="http://www.w3.org/1999/xlink",Ct.XML="http://www.w3.org/XML/1998/namespace",Ct.XMLNS="http://www.w3.org/2000/xmlns/",(Et=It||(It={})).TYPE="type",Et.ACTION="action",Et.ENCODING="encoding",Et.PROMPT="prompt",Et.NAME="name",Et.COLOR="color",Et.FACE="face",Et.SIZE="size",(xt=Bt||(Bt={})).NO_QUIRKS="no-quirks",xt.QUIRKS="quirks",xt.LIMITED_QUIRKS="limited-quirks",(Dt=St||(St={})).A="a",Dt.ADDRESS="address",Dt.ANNOTATION_XML="annotation-xml",Dt.APPLET="applet",Dt.AREA="area",Dt.ARTICLE="article",Dt.ASIDE="aside",Dt.B="b",Dt.BASE="base",Dt.BASEFONT="basefont",Dt.BGSOUND="bgsound",Dt.BIG="big",Dt.BLOCKQUOTE="blockquote",Dt.BODY="body",Dt.BR="br",Dt.BUTTON="button",Dt.CAPTION="caption",Dt.CENTER="center",Dt.CODE="code",Dt.COL="col",Dt.COLGROUP="colgroup",Dt.DD="dd",Dt.DESC="desc",Dt.DETAILS="details",Dt.DIALOG="dialog",Dt.DIR="dir",Dt.DIV="div",Dt.DL="dl",Dt.DT="dt",Dt.EM="em",Dt.EMBED="embed",Dt.FIELDSET="fieldset",Dt.FIGCAPTION="figcaption",Dt.FIGURE="figure",Dt.FONT="font",Dt.FOOTER="footer",Dt.FOREIGN_OBJECT="foreignObject",Dt.FORM="form",Dt.FRAME="frame",Dt.FRAMESET="frameset",Dt.H1="h1",Dt.H2="h2",Dt.H3="h3",Dt.H4="h4",Dt.H5="h5",Dt.H6="h6",Dt.HEAD="head",Dt.HEADER="header",Dt.HGROUP="hgroup",Dt.HR="hr",Dt.HTML="html",Dt.I="i",Dt.IMG="img",Dt.IMAGE="image",Dt.INPUT="input",Dt.IFRAME="iframe",Dt.KEYGEN="keygen",Dt.LABEL="label",Dt.LI="li",Dt.LINK="link",Dt.LISTING="listing",Dt.MAIN="main",Dt.MALIGNMARK="malignmark",Dt.MARQUEE="marquee",Dt.MATH="math",Dt.MENU="menu",Dt.META="meta",Dt.MGLYPH="mglyph",Dt.MI="mi",Dt.MO="mo",Dt.MN="mn",Dt.MS="ms",Dt.MTEXT="mtext",Dt.NAV="nav",Dt.NOBR="nobr",Dt.NOFRAMES="noframes",Dt.NOEMBED="noembed",Dt.NOSCRIPT="noscript",Dt.OBJECT="object",Dt.OL="ol",Dt.OPTGROUP="optgroup",Dt.OPTION="option",Dt.P="p",Dt.PARAM="param",Dt.PLAINTEXT="plaintext",Dt.PRE="pre",Dt.RB="rb",Dt.RP="rp",Dt.RT="rt",Dt.RTC="rtc",Dt.RUBY="ruby",Dt.S="s",Dt.SCRIPT="script",Dt.SEARCH="search",Dt.SECTION="section",Dt.SELECT="select",Dt.SOURCE="source",Dt.SMALL="small",Dt.SPAN="span",Dt.STRIKE="strike",Dt.STRONG="strong",Dt.STYLE="style",Dt.SUB="sub",Dt.SUMMARY="summary",Dt.SUP="sup",Dt.TABLE="table",Dt.TBODY="tbody",Dt.TEMPLATE="template",Dt.TEXTAREA="textarea",Dt.TFOOT="tfoot",Dt.TD="td",Dt.TH="th",Dt.THEAD="thead",Dt.TITLE="title",Dt.TR="tr",Dt.TRACK="track",Dt.TT="tt",Dt.U="u",Dt.UL="ul",Dt.SVG="svg",Dt.VAR="var",Dt.WBR="wbr",Dt.XMP="xmp",(Tt=Mt||(Mt={}))[Tt.UNKNOWN=0]="UNKNOWN",Tt[Tt.A=1]="A",Tt[Tt.ADDRESS=2]="ADDRESS",Tt[Tt.ANNOTATION_XML=3]="ANNOTATION_XML",Tt[Tt.APPLET=4]="APPLET",Tt[Tt.AREA=5]="AREA",Tt[Tt.ARTICLE=6]="ARTICLE",Tt[Tt.ASIDE=7]="ASIDE",Tt[Tt.B=8]="B",Tt[Tt.BASE=9]="BASE",Tt[Tt.BASEFONT=10]="BASEFONT",Tt[Tt.BGSOUND=11]="BGSOUND",Tt[Tt.BIG=12]="BIG",Tt[Tt.BLOCKQUOTE=13]="BLOCKQUOTE",Tt[Tt.BODY=14]="BODY",Tt[Tt.BR=15]="BR",Tt[Tt.BUTTON=16]="BUTTON",Tt[Tt.CAPTION=17]="CAPTION",Tt[Tt.CENTER=18]="CENTER",Tt[Tt.CODE=19]="CODE",Tt[Tt.COL=20]="COL",Tt[Tt.COLGROUP=21]="COLGROUP",Tt[Tt.DD=22]="DD",Tt[Tt.DESC=23]="DESC",Tt[Tt.DETAILS=24]="DETAILS",Tt[Tt.DIALOG=25]="DIALOG",Tt[Tt.DIR=26]="DIR",Tt[Tt.DIV=27]="DIV",Tt[Tt.DL=28]="DL",Tt[Tt.DT=29]="DT",Tt[Tt.EM=30]="EM",Tt[Tt.EMBED=31]="EMBED",Tt[Tt.FIELDSET=32]="FIELDSET",Tt[Tt.FIGCAPTION=33]="FIGCAPTION",Tt[Tt.FIGURE=34]="FIGURE",Tt[Tt.FONT=35]="FONT",Tt[Tt.FOOTER=36]="FOOTER",Tt[Tt.FOREIGN_OBJECT=37]="FOREIGN_OBJECT",Tt[Tt.FORM=38]="FORM",Tt[Tt.FRAME=39]="FRAME",Tt[Tt.FRAMESET=40]="FRAMESET",Tt[Tt.H1=41]="H1",Tt[Tt.H2=42]="H2",Tt[Tt.H3=43]="H3",Tt[Tt.H4=44]="H4",Tt[Tt.H5=45]="H5",Tt[Tt.H6=46]="H6",Tt[Tt.HEAD=47]="HEAD",Tt[Tt.HEADER=48]="HEADER",Tt[Tt.HGROUP=49]="HGROUP",Tt[Tt.HR=50]="HR",Tt[Tt.HTML=51]="HTML",Tt[Tt.I=52]="I",Tt[Tt.IMG=53]="IMG",Tt[Tt.IMAGE=54]="IMAGE",Tt[Tt.INPUT=55]="INPUT",Tt[Tt.IFRAME=56]="IFRAME",Tt[Tt.KEYGEN=57]="KEYGEN",Tt[Tt.LABEL=58]="LABEL",Tt[Tt.LI=59]="LI",Tt[Tt.LINK=60]="LINK",Tt[Tt.LISTING=61]="LISTING",Tt[Tt.MAIN=62]="MAIN",Tt[Tt.MALIGNMARK=63]="MALIGNMARK",Tt[Tt.MARQUEE=64]="MARQUEE",Tt[Tt.MATH=65]="MATH",Tt[Tt.MENU=66]="MENU",Tt[Tt.META=67]="META",Tt[Tt.MGLYPH=68]="MGLYPH",Tt[Tt.MI=69]="MI",Tt[Tt.MO=70]="MO",Tt[Tt.MN=71]="MN",Tt[Tt.MS=72]="MS",Tt[Tt.MTEXT=73]="MTEXT",Tt[Tt.NAV=74]="NAV",Tt[Tt.NOBR=75]="NOBR",Tt[Tt.NOFRAMES=76]="NOFRAMES",Tt[Tt.NOEMBED=77]="NOEMBED",Tt[Tt.NOSCRIPT=78]="NOSCRIPT",Tt[Tt.OBJECT=79]="OBJECT",Tt[Tt.OL=80]="OL",Tt[Tt.OPTGROUP=81]="OPTGROUP",Tt[Tt.OPTION=82]="OPTION",Tt[Tt.P=83]="P",Tt[Tt.PARAM=84]="PARAM",Tt[Tt.PLAINTEXT=85]="PLAINTEXT",Tt[Tt.PRE=86]="PRE",Tt[Tt.RB=87]="RB",Tt[Tt.RP=88]="RP",Tt[Tt.RT=89]="RT",Tt[Tt.RTC=90]="RTC",Tt[Tt.RUBY=91]="RUBY",Tt[Tt.S=92]="S",Tt[Tt.SCRIPT=93]="SCRIPT",Tt[Tt.SEARCH=94]="SEARCH",Tt[Tt.SECTION=95]="SECTION",Tt[Tt.SELECT=96]="SELECT",Tt[Tt.SOURCE=97]="SOURCE",Tt[Tt.SMALL=98]="SMALL",Tt[Tt.SPAN=99]="SPAN",Tt[Tt.STRIKE=100]="STRIKE",Tt[Tt.STRONG=101]="STRONG",Tt[Tt.STYLE=102]="STYLE",Tt[Tt.SUB=103]="SUB",Tt[Tt.SUMMARY=104]="SUMMARY",Tt[Tt.SUP=105]="SUP",Tt[Tt.TABLE=106]="TABLE",Tt[Tt.TBODY=107]="TBODY",Tt[Tt.TEMPLATE=108]="TEMPLATE",Tt[Tt.TEXTAREA=109]="TEXTAREA",Tt[Tt.TFOOT=110]="TFOOT",Tt[Tt.TD=111]="TD",Tt[Tt.TH=112]="TH",Tt[Tt.THEAD=113]="THEAD",Tt[Tt.TITLE=114]="TITLE",Tt[Tt.TR=115]="TR",Tt[Tt.TRACK=116]="TRACK",Tt[Tt.TT=117]="TT",Tt[Tt.U=118]="U",Tt[Tt.UL=119]="UL",Tt[Tt.SVG=120]="SVG",Tt[Tt.VAR=121]="VAR",Tt[Tt.WBR=122]="WBR",Tt[Tt.XMP=123]="XMP"
const Nt=new Map([[St.A,Mt.A],[St.ADDRESS,Mt.ADDRESS],[St.ANNOTATION_XML,Mt.ANNOTATION_XML],[St.APPLET,Mt.APPLET],[St.AREA,Mt.AREA],[St.ARTICLE,Mt.ARTICLE],[St.ASIDE,Mt.ASIDE],[St.B,Mt.B],[St.BASE,Mt.BASE],[St.BASEFONT,Mt.BASEFONT],[St.BGSOUND,Mt.BGSOUND],[St.BIG,Mt.BIG],[St.BLOCKQUOTE,Mt.BLOCKQUOTE],[St.BODY,Mt.BODY],[St.BR,Mt.BR],[St.BUTTON,Mt.BUTTON],[St.CAPTION,Mt.CAPTION],[St.CENTER,Mt.CENTER],[St.CODE,Mt.CODE],[St.COL,Mt.COL],[St.COLGROUP,Mt.COLGROUP],[St.DD,Mt.DD],[St.DESC,Mt.DESC],[St.DETAILS,Mt.DETAILS],[St.DIALOG,Mt.DIALOG],[St.DIR,Mt.DIR],[St.DIV,Mt.DIV],[St.DL,Mt.DL],[St.DT,Mt.DT],[St.EM,Mt.EM],[St.EMBED,Mt.EMBED],[St.FIELDSET,Mt.FIELDSET],[St.FIGCAPTION,Mt.FIGCAPTION],[St.FIGURE,Mt.FIGURE],[St.FONT,Mt.FONT],[St.FOOTER,Mt.FOOTER],[St.FOREIGN_OBJECT,Mt.FOREIGN_OBJECT],[St.FORM,Mt.FORM],[St.FRAME,Mt.FRAME],[St.FRAMESET,Mt.FRAMESET],[St.H1,Mt.H1],[St.H2,Mt.H2],[St.H3,Mt.H3],[St.H4,Mt.H4],[St.H5,Mt.H5],[St.H6,Mt.H6],[St.HEAD,Mt.HEAD],[St.HEADER,Mt.HEADER],[St.HGROUP,Mt.HGROUP],[St.HR,Mt.HR],[St.HTML,Mt.HTML],[St.I,Mt.I],[St.IMG,Mt.IMG],[St.IMAGE,Mt.IMAGE],[St.INPUT,Mt.INPUT],[St.IFRAME,Mt.IFRAME],[St.KEYGEN,Mt.KEYGEN],[St.LABEL,Mt.LABEL],[St.LI,Mt.LI],[St.LINK,Mt.LINK],[St.LISTING,Mt.LISTING],[St.MAIN,Mt.MAIN],[St.MALIGNMARK,Mt.MALIGNMARK],[St.MARQUEE,Mt.MARQUEE],[St.MATH,Mt.MATH],[St.MENU,Mt.MENU],[St.META,Mt.META],[St.MGLYPH,Mt.MGLYPH],[St.MI,Mt.MI],[St.MO,Mt.MO],[St.MN,Mt.MN],[St.MS,Mt.MS],[St.MTEXT,Mt.MTEXT],[St.NAV,Mt.NAV],[St.NOBR,Mt.NOBR],[St.NOFRAMES,Mt.NOFRAMES],[St.NOEMBED,Mt.NOEMBED],[St.NOSCRIPT,Mt.NOSCRIPT],[St.OBJECT,Mt.OBJECT],[St.OL,Mt.OL],[St.OPTGROUP,Mt.OPTGROUP],[St.OPTION,Mt.OPTION],[St.P,Mt.P],[St.PARAM,Mt.PARAM],[St.PLAINTEXT,Mt.PLAINTEXT],[St.PRE,Mt.PRE],[St.RB,Mt.RB],[St.RP,Mt.RP],[St.RT,Mt.RT],[St.RTC,Mt.RTC],[St.RUBY,Mt.RUBY],[St.S,Mt.S],[St.SCRIPT,Mt.SCRIPT],[St.SEARCH,Mt.SEARCH],[St.SECTION,Mt.SECTION],[St.SELECT,Mt.SELECT],[St.SOURCE,Mt.SOURCE],[St.SMALL,Mt.SMALL],[St.SPAN,Mt.SPAN],[St.STRIKE,Mt.STRIKE],[St.STRONG,Mt.STRONG],[St.STYLE,Mt.STYLE],[St.SUB,Mt.SUB],[St.SUMMARY,Mt.SUMMARY],[St.SUP,Mt.SUP],[St.TABLE,Mt.TABLE],[St.TBODY,Mt.TBODY],[St.TEMPLATE,Mt.TEMPLATE],[St.TEXTAREA,Mt.TEXTAREA],[St.TFOOT,Mt.TFOOT],[St.TD,Mt.TD],[St.TH,Mt.TH],[St.THEAD,Mt.THEAD],[St.TITLE,Mt.TITLE],[St.TR,Mt.TR],[St.TRACK,Mt.TRACK],[St.TT,Mt.TT],[St.U,Mt.U],[St.UL,Mt.UL],[St.SVG,Mt.SVG],[St.VAR,Mt.VAR],[St.WBR,Mt.WBR],[St.XMP,Mt.XMP]])
function qt(t){var e
return null!==(e=Nt.get(t))&&void 0!==e?e:Mt.UNKNOWN}const jt=Mt,Gt={[kt.HTML]:new Set([jt.ADDRESS,jt.APPLET,jt.AREA,jt.ARTICLE,jt.ASIDE,jt.BASE,jt.BASEFONT,jt.BGSOUND,jt.BLOCKQUOTE,jt.BODY,jt.BR,jt.BUTTON,jt.CAPTION,jt.CENTER,jt.COL,jt.COLGROUP,jt.DD,jt.DETAILS,jt.DIR,jt.DIV,jt.DL,jt.DT,jt.EMBED,jt.FIELDSET,jt.FIGCAPTION,jt.FIGURE,jt.FOOTER,jt.FORM,jt.FRAME,jt.FRAMESET,jt.H1,jt.H2,jt.H3,jt.H4,jt.H5,jt.H6,jt.HEAD,jt.HEADER,jt.HGROUP,jt.HR,jt.HTML,jt.IFRAME,jt.IMG,jt.INPUT,jt.LI,jt.LINK,jt.LISTING,jt.MAIN,jt.MARQUEE,jt.MENU,jt.META,jt.NAV,jt.NOEMBED,jt.NOFRAMES,jt.NOSCRIPT,jt.OBJECT,jt.OL,jt.P,jt.PARAM,jt.PLAINTEXT,jt.PRE,jt.SCRIPT,jt.SECTION,jt.SELECT,jt.SOURCE,jt.STYLE,jt.SUMMARY,jt.TABLE,jt.TBODY,jt.TD,jt.TEMPLATE,jt.TEXTAREA,jt.TFOOT,jt.TH,jt.THEAD,jt.TITLE,jt.TR,jt.TRACK,jt.UL,jt.WBR,jt.XMP]),[kt.MATHML]:new Set([jt.MI,jt.MO,jt.MN,jt.MS,jt.MTEXT,jt.ANNOTATION_XML]),[kt.SVG]:new Set([jt.TITLE,jt.FOREIGN_OBJECT,jt.DESC]),[kt.XLINK]:new Set,[kt.XML]:new Set,[kt.XMLNS]:new Set},Ht=new Set([jt.H1,jt.H2,jt.H3,jt.H4,jt.H5,jt.H6]),Kt=new Set([St.STYLE,St.SCRIPT,St.XMP,St.IFRAME,St.NOEMBED,St.NOFRAMES,St.PLAINTEXT])
var Yt,Wt;(Wt=Yt||(Yt={}))[Wt.DATA=0]="DATA",Wt[Wt.RCDATA=1]="RCDATA",Wt[Wt.RAWTEXT=2]="RAWTEXT",Wt[Wt.SCRIPT_DATA=3]="SCRIPT_DATA",Wt[Wt.PLAINTEXT=4]="PLAINTEXT",Wt[Wt.TAG_OPEN=5]="TAG_OPEN",Wt[Wt.END_TAG_OPEN=6]="END_TAG_OPEN",Wt[Wt.TAG_NAME=7]="TAG_NAME",Wt[Wt.RCDATA_LESS_THAN_SIGN=8]="RCDATA_LESS_THAN_SIGN",Wt[Wt.RCDATA_END_TAG_OPEN=9]="RCDATA_END_TAG_OPEN",Wt[Wt.RCDATA_END_TAG_NAME=10]="RCDATA_END_TAG_NAME",Wt[Wt.RAWTEXT_LESS_THAN_SIGN=11]="RAWTEXT_LESS_THAN_SIGN",Wt[Wt.RAWTEXT_END_TAG_OPEN=12]="RAWTEXT_END_TAG_OPEN",Wt[Wt.RAWTEXT_END_TAG_NAME=13]="RAWTEXT_END_TAG_NAME",Wt[Wt.SCRIPT_DATA_LESS_THAN_SIGN=14]="SCRIPT_DATA_LESS_THAN_SIGN",Wt[Wt.SCRIPT_DATA_END_TAG_OPEN=15]="SCRIPT_DATA_END_TAG_OPEN",Wt[Wt.SCRIPT_DATA_END_TAG_NAME=16]="SCRIPT_DATA_END_TAG_NAME",Wt[Wt.SCRIPT_DATA_ESCAPE_START=17]="SCRIPT_DATA_ESCAPE_START",Wt[Wt.SCRIPT_DATA_ESCAPE_START_DASH=18]="SCRIPT_DATA_ESCAPE_START_DASH",Wt[Wt.SCRIPT_DATA_ESCAPED=19]="SCRIPT_DATA_ESCAPED",Wt[Wt.SCRIPT_DATA_ESCAPED_DASH=20]="SCRIPT_DATA_ESCAPED_DASH",Wt[Wt.SCRIPT_DATA_ESCAPED_DASH_DASH=21]="SCRIPT_DATA_ESCAPED_DASH_DASH",Wt[Wt.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN=22]="SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN",Wt[Wt.SCRIPT_DATA_ESCAPED_END_TAG_OPEN=23]="SCRIPT_DATA_ESCAPED_END_TAG_OPEN",Wt[Wt.SCRIPT_DATA_ESCAPED_END_TAG_NAME=24]="SCRIPT_DATA_ESCAPED_END_TAG_NAME",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPE_START=25]="SCRIPT_DATA_DOUBLE_ESCAPE_START",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPED=26]="SCRIPT_DATA_DOUBLE_ESCAPED",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH=27]="SCRIPT_DATA_DOUBLE_ESCAPED_DASH",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH=28]="SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN=29]="SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN",Wt[Wt.SCRIPT_DATA_DOUBLE_ESCAPE_END=30]="SCRIPT_DATA_DOUBLE_ESCAPE_END",Wt[Wt.BEFORE_ATTRIBUTE_NAME=31]="BEFORE_ATTRIBUTE_NAME",Wt[Wt.ATTRIBUTE_NAME=32]="ATTRIBUTE_NAME",Wt[Wt.AFTER_ATTRIBUTE_NAME=33]="AFTER_ATTRIBUTE_NAME",Wt[Wt.BEFORE_ATTRIBUTE_VALUE=34]="BEFORE_ATTRIBUTE_VALUE",Wt[Wt.ATTRIBUTE_VALUE_DOUBLE_QUOTED=35]="ATTRIBUTE_VALUE_DOUBLE_QUOTED",Wt[Wt.ATTRIBUTE_VALUE_SINGLE_QUOTED=36]="ATTRIBUTE_VALUE_SINGLE_QUOTED",Wt[Wt.ATTRIBUTE_VALUE_UNQUOTED=37]="ATTRIBUTE_VALUE_UNQUOTED",Wt[Wt.AFTER_ATTRIBUTE_VALUE_QUOTED=38]="AFTER_ATTRIBUTE_VALUE_QUOTED",Wt[Wt.SELF_CLOSING_START_TAG=39]="SELF_CLOSING_START_TAG",Wt[Wt.BOGUS_COMMENT=40]="BOGUS_COMMENT",Wt[Wt.MARKUP_DECLARATION_OPEN=41]="MARKUP_DECLARATION_OPEN",Wt[Wt.COMMENT_START=42]="COMMENT_START",Wt[Wt.COMMENT_START_DASH=43]="COMMENT_START_DASH",Wt[Wt.COMMENT=44]="COMMENT",Wt[Wt.COMMENT_LESS_THAN_SIGN=45]="COMMENT_LESS_THAN_SIGN",Wt[Wt.COMMENT_LESS_THAN_SIGN_BANG=46]="COMMENT_LESS_THAN_SIGN_BANG",Wt[Wt.COMMENT_LESS_THAN_SIGN_BANG_DASH=47]="COMMENT_LESS_THAN_SIGN_BANG_DASH",Wt[Wt.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH=48]="COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH",Wt[Wt.COMMENT_END_DASH=49]="COMMENT_END_DASH",Wt[Wt.COMMENT_END=50]="COMMENT_END",Wt[Wt.COMMENT_END_BANG=51]="COMMENT_END_BANG",Wt[Wt.DOCTYPE=52]="DOCTYPE",Wt[Wt.BEFORE_DOCTYPE_NAME=53]="BEFORE_DOCTYPE_NAME",Wt[Wt.DOCTYPE_NAME=54]="DOCTYPE_NAME",Wt[Wt.AFTER_DOCTYPE_NAME=55]="AFTER_DOCTYPE_NAME",Wt[Wt.AFTER_DOCTYPE_PUBLIC_KEYWORD=56]="AFTER_DOCTYPE_PUBLIC_KEYWORD",Wt[Wt.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER=57]="BEFORE_DOCTYPE_PUBLIC_IDENTIFIER",Wt[Wt.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED=58]="DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED",Wt[Wt.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED=59]="DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED",Wt[Wt.AFTER_DOCTYPE_PUBLIC_IDENTIFIER=60]="AFTER_DOCTYPE_PUBLIC_IDENTIFIER",Wt[Wt.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS=61]="BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS",Wt[Wt.AFTER_DOCTYPE_SYSTEM_KEYWORD=62]="AFTER_DOCTYPE_SYSTEM_KEYWORD",Wt[Wt.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER=63]="BEFORE_DOCTYPE_SYSTEM_IDENTIFIER",Wt[Wt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED=64]="DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED",Wt[Wt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED=65]="DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED",Wt[Wt.AFTER_DOCTYPE_SYSTEM_IDENTIFIER=66]="AFTER_DOCTYPE_SYSTEM_IDENTIFIER",Wt[Wt.BOGUS_DOCTYPE=67]="BOGUS_DOCTYPE",Wt[Wt.CDATA_SECTION=68]="CDATA_SECTION",Wt[Wt.CDATA_SECTION_BRACKET=69]="CDATA_SECTION_BRACKET",Wt[Wt.CDATA_SECTION_END=70]="CDATA_SECTION_END",Wt[Wt.CHARACTER_REFERENCE=71]="CHARACTER_REFERENCE",Wt[Wt.AMBIGUOUS_AMPERSAND=72]="AMBIGUOUS_AMPERSAND"
const zt={DATA:Yt.DATA,RCDATA:Yt.RCDATA,RAWTEXT:Yt.RAWTEXT,SCRIPT_DATA:Yt.SCRIPT_DATA,PLAINTEXT:Yt.PLAINTEXT,CDATA_SECTION:Yt.CDATA_SECTION}
function Zt(t){return t>=$.LATIN_CAPITAL_A&&t<=$.LATIN_CAPITAL_Z}function Ut(t){return(t=>t>=$.LATIN_SMALL_A&&t<=$.LATIN_SMALL_Z)(t)||Zt(t)}function Jt(t){return Ut(t)||(t=>t>=$.DIGIT_0&&t<=$.DIGIT_9)(t)}function Lt(t){return t+32}function Pt(t){return t===$.SPACE||t===$.LINE_FEED||t===$.TABULATION||t===$.FORM_FEED}function Vt(t){return Pt(t)||t===$.SOLIDUS||t===$.GREATER_THAN_SIGN}class Xt{constructor(t,e){this.options=t,this.C=e,this.paused=!1,this.Et=!1,this.Bt=!1,this.xt="",this.active=!1,this.state=Yt.DATA,this.St=Yt.DATA,this.Dt=0,this.Mt=-1,this.Tt=null,this.Rt=null,this.Ft={name:"",value:""},this._t=new lt(e),this.Qt=this.Ot(-1),this.Nt=new Qt(ut,(t,e)=>{this._t.D=this.Dt+e-1,this.qt(t)},e.L?{missingSemicolonAfterCharacterReference:()=>{this.J(rt.missingSemicolonAfterCharacterReference,1)},absenceOfDigitsInNumericCharacterReference:t=>{this.J(rt.absenceOfDigitsInNumericCharacterReference,this.Dt-this._t.D+t)},kt:t=>{const e=(t=>t===$.NULL?rt.nullCharacterReference:t>1114111?rt.characterReferenceOutsideUnicodeRange:it(t)?rt.surrogateCharacterReference:st(t)?rt.noncharacterCharacterReference:ot(t)||t===$.CARRIAGE_RETURN?rt.controlCharacterReference:null)(t)
e&&this.J(e,1)}}:void 0)}J(t,e=0){var i,o
null===(o=(i=this.C).L)||void 0===o||o.call(i,this._t.getError(t,e))}Ot(t){return this.options.jt?{K:this._t.line,W:this._t.H-t,startOffset:this._t.offset-t,Y:-1,Z:-1,endOffset:-1}:null}Gt(){if(!this.Et){for(this.Et=!0;this.active&&!this.paused;){this.Mt=0
const t=this.Ht()
this.Kt()||this.Yt(t)}this.Et=!1}}pause(){this.paused=!0}resume(t){if(!this.paused)throw Error("Parser was already resumed")
this.paused=!1,this.Et||(this.Gt(),this.paused||null==t||t())}write(t,e,i){this.active=!0,this._t.write(t,e),this.Gt(),this.paused||null==i||i()}et(t){this.active=!0,this._t.et(t),this.Gt()}Kt(){return!!this._t._&&(this._t.st(this.Mt),this.Mt=0,this.active=!1,!0)}Ht(){return this.Mt++,this._t.advance()}Wt(t){this.Mt+=t
for(let e=0;e<t;e++)this._t.advance()}zt(t,e){return!!this._t.startsWith(t,e)&&(this.Wt(t.length-1),!0)}Zt(){this.Rt={type:at.START_TAG,tagName:"",Ut:Mt.UNKNOWN,Jt:!1,Lt:!1,rt:[],location:this.Ot(1)}}Pt(){this.Rt={type:at.END_TAG,tagName:"",Ut:Mt.UNKNOWN,Jt:!1,Lt:!1,rt:[],location:this.Ot(2)}}Vt(t){this.Rt={type:at.COMMENT,data:"",location:this.Ot(t)}}Xt(t){this.Rt={type:at.DOCTYPE,name:t,$t:!1,publicId:null,systemId:null,location:this.Qt}}te(t,e){this.Tt={type:t,ee:e,location:this.Qt}}ie(t){this.Ft={name:t,value:""},this.Qt=this.Ot(0)}oe(){var t,e
const i=this.Rt
null===At(i,this.Ft.name)?(i.rt.push(this.Ft),i.location&&this.Qt&&((null!==(t=(e=i.location).rt)&&void 0!==t?t:e.rt=Object.create(null))[this.Ft.name]=this.Qt,this.se())):this.J(rt.duplicateAttribute)}se(){this.Qt&&(this.Qt.Y=this._t.line,this.Qt.Z=this._t.H,this.Qt.endOffset=this._t.offset)}re(t){this.ne(t.location),this.Rt=null,t.location&&(t.location.Y=this._t.line,t.location.Z=this._t.H+1,t.location.endOffset=this._t.offset+1),this.Qt=this.Ot(-1)}ae(){const t=this.Rt
this.re(t),t.Ut=qt(t.tagName),t.type===at.START_TAG?(this.xt=t.tagName,this.C.ce(t)):(t.rt.length>0&&this.J(rt.endTagWithAttributes),t.Jt&&this.J(rt.endTagWithTrailingSolidus),this.C.le(t)),this._t.tt()}Ae(t){this.re(t),this.C.he(t),this._t.tt()}de(t){this.re(t),this.C.ue(t),this._t.tt()}ne(t){if(this.Tt){switch(t&&this.Tt.location&&(this.Tt.location.Y=t.K,this.Tt.location.Z=t.W,this.Tt.location.endOffset=t.startOffset),this.Tt.type){case at.CHARACTER:this.C.fe(this.Tt)
break
case at.NULL_CHARACTER:this.C.be(this.Tt)
break
case at.WHITESPACE_CHARACTER:this.C.me(this.Tt)}this.Tt=null}}pe(){const t=this.Ot(0)
t&&(t.Y=t.K,t.Z=t.W,t.endOffset=t.startOffset),this.ne(t),this.C.ge({type:at.EOF,location:t}),this.active=!1}we(t,e){if(this.Tt){if(this.Tt.type===t)return void(this.Tt.ee+=e)
this.Qt=this.Ot(0),this.ne(this.Qt),this._t.tt()}this.te(t,e)}ve(t){const e=Pt(t)?at.WHITESPACE_CHARACTER:t===$.NULL?at.NULL_CHARACTER:at.CHARACTER
this.we(e,t<65536?String.fromCharCode(t):String.fromCodePoint(t))}ye(t){this.we(at.CHARACTER,t)}ke(){this.St=this.state,this.state=Yt.CHARACTER_REFERENCE,this.Dt=this._t.D,this.Nt.ft(this.Ce()?vt.Attribute:vt.Legacy)}Ce(){return this.St===Yt.ATTRIBUTE_VALUE_DOUBLE_QUOTED||this.St===Yt.ATTRIBUTE_VALUE_SINGLE_QUOTED||this.St===Yt.ATTRIBUTE_VALUE_UNQUOTED}qt(t){this.Ce()?this.Ft.value+=String.fromCodePoint(t):this.ve(t)}Yt(t){switch(this.state){case Yt.DATA:this.Ie(t)
break
case Yt.RCDATA:this.Ee(t)
break
case Yt.RAWTEXT:this.Be(t)
break
case Yt.SCRIPT_DATA:this.xe(t)
break
case Yt.PLAINTEXT:this.Se(t)
break
case Yt.TAG_OPEN:this.De(t)
break
case Yt.END_TAG_OPEN:this.Me(t)
break
case Yt.TAG_NAME:this.Te(t)
break
case Yt.RCDATA_LESS_THAN_SIGN:this.Re(t)
break
case Yt.RCDATA_END_TAG_OPEN:this.Fe(t)
break
case Yt.RCDATA_END_TAG_NAME:this._e(t)
break
case Yt.RAWTEXT_LESS_THAN_SIGN:this.Qe(t)
break
case Yt.RAWTEXT_END_TAG_OPEN:this.Oe(t)
break
case Yt.RAWTEXT_END_TAG_NAME:this.Ne(t)
break
case Yt.SCRIPT_DATA_LESS_THAN_SIGN:this.qe(t)
break
case Yt.SCRIPT_DATA_END_TAG_OPEN:this.je(t)
break
case Yt.SCRIPT_DATA_END_TAG_NAME:this.Ge(t)
break
case Yt.SCRIPT_DATA_ESCAPE_START:this.He(t)
break
case Yt.SCRIPT_DATA_ESCAPE_START_DASH:this.Ke(t)
break
case Yt.SCRIPT_DATA_ESCAPED:this.Ye(t)
break
case Yt.SCRIPT_DATA_ESCAPED_DASH:this.We(t)
break
case Yt.SCRIPT_DATA_ESCAPED_DASH_DASH:this.ze(t)
break
case Yt.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:this.Ze(t)
break
case Yt.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:this.Ue(t)
break
case Yt.SCRIPT_DATA_ESCAPED_END_TAG_NAME:this.Je(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPE_START:this.Le(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPED:this.Pe(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:this.Ve(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:this.Xe(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:this.$e(t)
break
case Yt.SCRIPT_DATA_DOUBLE_ESCAPE_END:this.ti(t)
break
case Yt.BEFORE_ATTRIBUTE_NAME:this.ei(t)
break
case Yt.ATTRIBUTE_NAME:this.ii(t)
break
case Yt.AFTER_ATTRIBUTE_NAME:this.oi(t)
break
case Yt.BEFORE_ATTRIBUTE_VALUE:this.si(t)
break
case Yt.ATTRIBUTE_VALUE_DOUBLE_QUOTED:this.ri(t)
break
case Yt.ATTRIBUTE_VALUE_SINGLE_QUOTED:this.ni(t)
break
case Yt.ATTRIBUTE_VALUE_UNQUOTED:this.ai(t)
break
case Yt.AFTER_ATTRIBUTE_VALUE_QUOTED:this.ci(t)
break
case Yt.SELF_CLOSING_START_TAG:this.li(t)
break
case Yt.BOGUS_COMMENT:this.Ai(t)
break
case Yt.MARKUP_DECLARATION_OPEN:this.hi(t)
break
case Yt.COMMENT_START:this.di(t)
break
case Yt.COMMENT_START_DASH:this.fi(t)
break
case Yt.COMMENT:this.bi(t)
break
case Yt.COMMENT_LESS_THAN_SIGN:this.mi(t)
break
case Yt.COMMENT_LESS_THAN_SIGN_BANG:this.pi(t)
break
case Yt.COMMENT_LESS_THAN_SIGN_BANG_DASH:this.gi(t)
break
case Yt.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:this.wi(t)
break
case Yt.COMMENT_END_DASH:this.yi(t)
break
case Yt.COMMENT_END:this.ki(t)
break
case Yt.COMMENT_END_BANG:this.Ci(t)
break
case Yt.DOCTYPE:this.Ii(t)
break
case Yt.BEFORE_DOCTYPE_NAME:this.Ei(t)
break
case Yt.DOCTYPE_NAME:this.Bi(t)
break
case Yt.AFTER_DOCTYPE_NAME:this.xi(t)
break
case Yt.AFTER_DOCTYPE_PUBLIC_KEYWORD:this.Si(t)
break
case Yt.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:this.Di(t)
break
case Yt.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:this.Mi(t)
break
case Yt.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:this.Ti(t)
break
case Yt.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:this.Ri(t)
break
case Yt.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:this.Fi(t)
break
case Yt.AFTER_DOCTYPE_SYSTEM_KEYWORD:this._i(t)
break
case Yt.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:this.Qi(t)
break
case Yt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:this.Oi(t)
break
case Yt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:this.Ni(t)
break
case Yt.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:this.qi(t)
break
case Yt.BOGUS_DOCTYPE:this.ji(t)
break
case Yt.CDATA_SECTION:this.Gi(t)
break
case Yt.CDATA_SECTION_BRACKET:this.Hi(t)
break
case Yt.CDATA_SECTION_END:this.Ki(t)
break
case Yt.CHARACTER_REFERENCE:this.Yi()
break
case Yt.AMBIGUOUS_AMPERSAND:this.Wi(t)
break
default:throw Error("Unknown state")}}Ie(t){switch(t){case $.LESS_THAN_SIGN:this.state=Yt.TAG_OPEN
break
case $.AMPERSAND:this.ke()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ve(t)
break
case $.EOF:this.pe()
break
default:this.ve(t)}}Ee(t){switch(t){case $.AMPERSAND:this.ke()
break
case $.LESS_THAN_SIGN:this.state=Yt.RCDATA_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.pe()
break
default:this.ve(t)}}Be(t){switch(t){case $.LESS_THAN_SIGN:this.state=Yt.RAWTEXT_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.pe()
break
default:this.ve(t)}}xe(t){switch(t){case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.pe()
break
default:this.ve(t)}}Se(t){switch(t){case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.pe()
break
default:this.ve(t)}}De(t){if(Ut(t))this.Zt(),this.state=Yt.TAG_NAME,this.Te(t)
else switch(t){case $.EXCLAMATION_MARK:this.state=Yt.MARKUP_DECLARATION_OPEN
break
case $.SOLIDUS:this.state=Yt.END_TAG_OPEN
break
case $.QUESTION_MARK:this.J(rt.unexpectedQuestionMarkInsteadOfTagName),this.Vt(1),this.state=Yt.BOGUS_COMMENT,this.Ai(t)
break
case $.EOF:this.J(rt.eofBeforeTagName),this.ye("<"),this.pe()
break
default:this.J(rt.invalidFirstCharacterOfTagName),this.ye("<"),this.state=Yt.DATA,this.Ie(t)}}Me(t){if(Ut(t))this.Pt(),this.state=Yt.TAG_NAME,this.Te(t)
else switch(t){case $.GREATER_THAN_SIGN:this.J(rt.missingEndTagName),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofBeforeTagName),this.ye("</"),this.pe()
break
default:this.J(rt.invalidFirstCharacterOfTagName),this.Vt(2),this.state=Yt.BOGUS_COMMENT,this.Ai(t)}}Te(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.BEFORE_ATTRIBUTE_NAME
break
case $.SOLIDUS:this.state=Yt.SELF_CLOSING_START_TAG
break
case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.ae()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.tagName+=X
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:e.tagName+=String.fromCodePoint(Zt(t)?Lt(t):t)}}Re(t){t===$.SOLIDUS?this.state=Yt.RCDATA_END_TAG_OPEN:(this.ye("<"),this.state=Yt.RCDATA,this.Ee(t))}Fe(t){Ut(t)?(this.state=Yt.RCDATA_END_TAG_NAME,this._e(t)):(this.ye("</"),this.state=Yt.RCDATA,this.Ee(t))}zi(t){if(!this._t.startsWith(this.xt,!1))return!this.Kt()
switch(this.Pt(),this.Rt.tagName=this.xt,this._t.it(this.xt.length)){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:return this.Wt(this.xt.length),this.state=Yt.BEFORE_ATTRIBUTE_NAME,!1
case $.SOLIDUS:return this.Wt(this.xt.length),this.state=Yt.SELF_CLOSING_START_TAG,!1
case $.GREATER_THAN_SIGN:return this.Wt(this.xt.length),this.ae(),this.state=Yt.DATA,!1
default:return!this.Kt()}}_e(t){this.zi(t)&&(this.ye("</"),this.state=Yt.RCDATA,this.Ee(t))}Qe(t){t===$.SOLIDUS?this.state=Yt.RAWTEXT_END_TAG_OPEN:(this.ye("<"),this.state=Yt.RAWTEXT,this.Be(t))}Oe(t){Ut(t)?(this.state=Yt.RAWTEXT_END_TAG_NAME,this.Ne(t)):(this.ye("</"),this.state=Yt.RAWTEXT,this.Be(t))}Ne(t){this.zi(t)&&(this.ye("</"),this.state=Yt.RAWTEXT,this.Be(t))}qe(t){switch(t){case $.SOLIDUS:this.state=Yt.SCRIPT_DATA_END_TAG_OPEN
break
case $.EXCLAMATION_MARK:this.state=Yt.SCRIPT_DATA_ESCAPE_START,this.ye("<!")
break
default:this.ye("<"),this.state=Yt.SCRIPT_DATA,this.xe(t)}}je(t){Ut(t)?(this.state=Yt.SCRIPT_DATA_END_TAG_NAME,this.Ge(t)):(this.ye("</"),this.state=Yt.SCRIPT_DATA,this.xe(t))}Ge(t){this.zi(t)&&(this.ye("</"),this.state=Yt.SCRIPT_DATA,this.xe(t))}He(t){t===$.HYPHEN_MINUS?(this.state=Yt.SCRIPT_DATA_ESCAPE_START_DASH,this.ye("-")):(this.state=Yt.SCRIPT_DATA,this.xe(t))}Ke(t){t===$.HYPHEN_MINUS?(this.state=Yt.SCRIPT_DATA_ESCAPED_DASH_DASH,this.ye("-")):(this.state=Yt.SCRIPT_DATA,this.xe(t))}Ye(t){switch(t){case $.HYPHEN_MINUS:this.state=Yt.SCRIPT_DATA_ESCAPED_DASH,this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.ve(t)}}We(t){switch(t){case $.HYPHEN_MINUS:this.state=Yt.SCRIPT_DATA_ESCAPED_DASH_DASH,this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.state=Yt.SCRIPT_DATA_ESCAPED,this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.state=Yt.SCRIPT_DATA_ESCAPED,this.ve(t)}}ze(t){switch(t){case $.HYPHEN_MINUS:this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN
break
case $.GREATER_THAN_SIGN:this.state=Yt.SCRIPT_DATA,this.ye(">")
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.state=Yt.SCRIPT_DATA_ESCAPED,this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.state=Yt.SCRIPT_DATA_ESCAPED,this.ve(t)}}Ze(t){t===$.SOLIDUS?this.state=Yt.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:Ut(t)?(this.ye("<"),this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPE_START,this.Le(t)):(this.ye("<"),this.state=Yt.SCRIPT_DATA_ESCAPED,this.Ye(t))}Ue(t){Ut(t)?(this.state=Yt.SCRIPT_DATA_ESCAPED_END_TAG_NAME,this.Je(t)):(this.ye("</"),this.state=Yt.SCRIPT_DATA_ESCAPED,this.Ye(t))}Je(t){this.zi(t)&&(this.ye("</"),this.state=Yt.SCRIPT_DATA_ESCAPED,this.Ye(t))}Le(t){if(this._t.startsWith(et,!1)&&Vt(this._t.it(6))){this.ve(t)
for(let t=0;t<6;t++)this.ve(this.Ht())
this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED}else this.Kt()||(this.state=Yt.SCRIPT_DATA_ESCAPED,this.Ye(t))}Pe(t){switch(t){case $.HYPHEN_MINUS:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH,this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,this.ye("<")
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.ve(t)}}Ve(t){switch(t){case $.HYPHEN_MINUS:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH,this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,this.ye("<")
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.ve(t)}}Xe(t){switch(t){case $.HYPHEN_MINUS:this.ye("-")
break
case $.LESS_THAN_SIGN:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,this.ye("<")
break
case $.GREATER_THAN_SIGN:this.state=Yt.SCRIPT_DATA,this.ye(">")
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.ye(X)
break
case $.EOF:this.J(rt.eofInScriptHtmlCommentLikeText),this.pe()
break
default:this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.ve(t)}}$e(t){t===$.SOLIDUS?(this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPE_END,this.ye("/")):(this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.Pe(t))}ti(t){if(this._t.startsWith(et,!1)&&Vt(this._t.it(6))){this.ve(t)
for(let t=0;t<6;t++)this.ve(this.Ht())
this.state=Yt.SCRIPT_DATA_ESCAPED}else this.Kt()||(this.state=Yt.SCRIPT_DATA_DOUBLE_ESCAPED,this.Pe(t))}ei(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.SOLIDUS:case $.GREATER_THAN_SIGN:case $.EOF:this.state=Yt.AFTER_ATTRIBUTE_NAME,this.oi(t)
break
case $.EQUALS_SIGN:this.J(rt.unexpectedEqualsSignBeforeAttributeName),this.ie("="),this.state=Yt.ATTRIBUTE_NAME
break
default:this.ie(""),this.state=Yt.ATTRIBUTE_NAME,this.ii(t)}}ii(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:case $.SOLIDUS:case $.GREATER_THAN_SIGN:case $.EOF:this.oe(),this.state=Yt.AFTER_ATTRIBUTE_NAME,this.oi(t)
break
case $.EQUALS_SIGN:this.oe(),this.state=Yt.BEFORE_ATTRIBUTE_VALUE
break
case $.QUOTATION_MARK:case $.APOSTROPHE:case $.LESS_THAN_SIGN:this.J(rt.unexpectedCharacterInAttributeName),this.Ft.name+=String.fromCodePoint(t)
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.Ft.name+=X
break
default:this.Ft.name+=String.fromCodePoint(Zt(t)?Lt(t):t)}}oi(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.SOLIDUS:this.state=Yt.SELF_CLOSING_START_TAG
break
case $.EQUALS_SIGN:this.state=Yt.BEFORE_ATTRIBUTE_VALUE
break
case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.ae()
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.ie(""),this.state=Yt.ATTRIBUTE_NAME,this.ii(t)}}si(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.QUOTATION_MARK:this.state=Yt.ATTRIBUTE_VALUE_DOUBLE_QUOTED
break
case $.APOSTROPHE:this.state=Yt.ATTRIBUTE_VALUE_SINGLE_QUOTED
break
case $.GREATER_THAN_SIGN:this.J(rt.missingAttributeValue),this.state=Yt.DATA,this.ae()
break
default:this.state=Yt.ATTRIBUTE_VALUE_UNQUOTED,this.ai(t)}}ri(t){switch(t){case $.QUOTATION_MARK:this.state=Yt.AFTER_ATTRIBUTE_VALUE_QUOTED
break
case $.AMPERSAND:this.ke()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.Ft.value+=X
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.Ft.value+=String.fromCodePoint(t)}}ni(t){switch(t){case $.APOSTROPHE:this.state=Yt.AFTER_ATTRIBUTE_VALUE_QUOTED
break
case $.AMPERSAND:this.ke()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.Ft.value+=X
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.Ft.value+=String.fromCodePoint(t)}}ai(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.se(),this.state=Yt.BEFORE_ATTRIBUTE_NAME
break
case $.AMPERSAND:this.ke()
break
case $.GREATER_THAN_SIGN:this.se(),this.state=Yt.DATA,this.ae()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.Ft.value+=X
break
case $.QUOTATION_MARK:case $.APOSTROPHE:case $.LESS_THAN_SIGN:case $.EQUALS_SIGN:case $.GRAVE_ACCENT:this.J(rt.unexpectedCharacterInUnquotedAttributeValue),this.Ft.value+=String.fromCodePoint(t)
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.Ft.value+=String.fromCodePoint(t)}}ci(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.se(),this.state=Yt.BEFORE_ATTRIBUTE_NAME
break
case $.SOLIDUS:this.se(),this.state=Yt.SELF_CLOSING_START_TAG
break
case $.GREATER_THAN_SIGN:this.se(),this.state=Yt.DATA,this.ae()
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.J(rt.missingWhitespaceBetweenAttributes),this.state=Yt.BEFORE_ATTRIBUTE_NAME,this.ei(t)}}li(t){switch(t){case $.GREATER_THAN_SIGN:this.Rt.Jt=!0,this.state=Yt.DATA,this.ae()
break
case $.EOF:this.J(rt.eofInTag),this.pe()
break
default:this.J(rt.unexpectedSolidusInTag),this.state=Yt.BEFORE_ATTRIBUTE_NAME,this.ei(t)}}Ai(t){const e=this.Rt
switch(t){case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.Ae(e)
break
case $.EOF:this.Ae(e),this.pe()
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.data+=X
break
default:e.data+=String.fromCodePoint(t)}}hi(t){this.zt("--",!0)?(this.Vt(3),this.state=Yt.COMMENT_START):this.zt("doctype",!1)?(this.Qt=this.Ot(8),this.state=Yt.DOCTYPE):this.zt("[CDATA[",!0)?this.Bt?this.state=Yt.CDATA_SECTION:(this.J(rt.cdataInHtmlContent),this.Vt(8),this.Rt.data="[CDATA[",this.state=Yt.BOGUS_COMMENT):this.Kt()||(this.J(rt.incorrectlyOpenedComment),this.Vt(2),this.state=Yt.BOGUS_COMMENT,this.Ai(t))}di(t){switch(t){case $.HYPHEN_MINUS:this.state=Yt.COMMENT_START_DASH
break
case $.GREATER_THAN_SIGN:{this.J(rt.abruptClosingOfEmptyComment),this.state=Yt.DATA
const t=this.Rt
this.Ae(t)
break}default:this.state=Yt.COMMENT,this.bi(t)}}fi(t){const e=this.Rt
switch(t){case $.HYPHEN_MINUS:this.state=Yt.COMMENT_END
break
case $.GREATER_THAN_SIGN:this.J(rt.abruptClosingOfEmptyComment),this.state=Yt.DATA,this.Ae(e)
break
case $.EOF:this.J(rt.eofInComment),this.Ae(e),this.pe()
break
default:e.data+="-",this.state=Yt.COMMENT,this.bi(t)}}bi(t){const e=this.Rt
switch(t){case $.HYPHEN_MINUS:this.state=Yt.COMMENT_END_DASH
break
case $.LESS_THAN_SIGN:e.data+="<",this.state=Yt.COMMENT_LESS_THAN_SIGN
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.data+=X
break
case $.EOF:this.J(rt.eofInComment),this.Ae(e),this.pe()
break
default:e.data+=String.fromCodePoint(t)}}mi(t){const e=this.Rt
switch(t){case $.EXCLAMATION_MARK:e.data+="!",this.state=Yt.COMMENT_LESS_THAN_SIGN_BANG
break
case $.LESS_THAN_SIGN:e.data+="<"
break
default:this.state=Yt.COMMENT,this.bi(t)}}pi(t){t===$.HYPHEN_MINUS?this.state=Yt.COMMENT_LESS_THAN_SIGN_BANG_DASH:(this.state=Yt.COMMENT,this.bi(t))}gi(t){t===$.HYPHEN_MINUS?this.state=Yt.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:(this.state=Yt.COMMENT_END_DASH,this.yi(t))}wi(t){t!==$.GREATER_THAN_SIGN&&t!==$.EOF&&this.J(rt.nestedComment),this.state=Yt.COMMENT_END,this.ki(t)}yi(t){const e=this.Rt
switch(t){case $.HYPHEN_MINUS:this.state=Yt.COMMENT_END
break
case $.EOF:this.J(rt.eofInComment),this.Ae(e),this.pe()
break
default:e.data+="-",this.state=Yt.COMMENT,this.bi(t)}}ki(t){const e=this.Rt
switch(t){case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.Ae(e)
break
case $.EXCLAMATION_MARK:this.state=Yt.COMMENT_END_BANG
break
case $.HYPHEN_MINUS:e.data+="-"
break
case $.EOF:this.J(rt.eofInComment),this.Ae(e),this.pe()
break
default:e.data+="--",this.state=Yt.COMMENT,this.bi(t)}}Ci(t){const e=this.Rt
switch(t){case $.HYPHEN_MINUS:e.data+="--!",this.state=Yt.COMMENT_END_DASH
break
case $.GREATER_THAN_SIGN:this.J(rt.incorrectlyClosedComment),this.state=Yt.DATA,this.Ae(e)
break
case $.EOF:this.J(rt.eofInComment),this.Ae(e),this.pe()
break
default:e.data+="--!",this.state=Yt.COMMENT,this.bi(t)}}Ii(t){switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.BEFORE_DOCTYPE_NAME
break
case $.GREATER_THAN_SIGN:this.state=Yt.BEFORE_DOCTYPE_NAME,this.Ei(t)
break
case $.EOF:{this.J(rt.eofInDoctype),this.Xt(null)
const t=this.Rt
t.$t=!0,this.de(t),this.pe()
break}default:this.J(rt.missingWhitespaceBeforeDoctypeName),this.state=Yt.BEFORE_DOCTYPE_NAME,this.Ei(t)}}Ei(t){if(Zt(t))this.Xt(String.fromCharCode(Lt(t))),this.state=Yt.DOCTYPE_NAME
else switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.NULL:this.J(rt.unexpectedNullCharacter),this.Xt(X),this.state=Yt.DOCTYPE_NAME
break
case $.GREATER_THAN_SIGN:{this.J(rt.missingDoctypeName),this.Xt(null)
const t=this.Rt
t.$t=!0,this.de(t),this.state=Yt.DATA
break}case $.EOF:{this.J(rt.eofInDoctype),this.Xt(null)
const t=this.Rt
t.$t=!0,this.de(t),this.pe()
break}default:this.Xt(String.fromCodePoint(t)),this.state=Yt.DOCTYPE_NAME}}Bi(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.AFTER_DOCTYPE_NAME
break
case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.de(e)
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.name+=X
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:e.name+=String.fromCodePoint(Zt(t)?Lt(t):t)}}xi(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.de(e)
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.zt("public",!1)?this.state=Yt.AFTER_DOCTYPE_PUBLIC_KEYWORD:this.zt("system",!1)?this.state=Yt.AFTER_DOCTYPE_SYSTEM_KEYWORD:this.Kt()||(this.J(rt.invalidCharacterSequenceAfterDoctypeName),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t))}}Si(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER
break
case $.QUOTATION_MARK:this.J(rt.missingWhitespaceAfterDoctypePublicKeyword),e.publicId="",this.state=Yt.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:this.J(rt.missingWhitespaceAfterDoctypePublicKeyword),e.publicId="",this.state=Yt.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED
break
case $.GREATER_THAN_SIGN:this.J(rt.missingDoctypePublicIdentifier),e.$t=!0,this.state=Yt.DATA,this.de(e)
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypePublicIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}Di(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.QUOTATION_MARK:e.publicId="",this.state=Yt.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:e.publicId="",this.state=Yt.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED
break
case $.GREATER_THAN_SIGN:this.J(rt.missingDoctypePublicIdentifier),e.$t=!0,this.state=Yt.DATA,this.de(e)
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypePublicIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}Mi(t){const e=this.Rt
switch(t){case $.QUOTATION_MARK:this.state=Yt.AFTER_DOCTYPE_PUBLIC_IDENTIFIER
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.publicId+=X
break
case $.GREATER_THAN_SIGN:this.J(rt.abruptDoctypePublicIdentifier),e.$t=!0,this.de(e),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:e.publicId+=String.fromCodePoint(t)}}Ti(t){const e=this.Rt
switch(t){case $.APOSTROPHE:this.state=Yt.AFTER_DOCTYPE_PUBLIC_IDENTIFIER
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.publicId+=X
break
case $.GREATER_THAN_SIGN:this.J(rt.abruptDoctypePublicIdentifier),e.$t=!0,this.de(e),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:e.publicId+=String.fromCodePoint(t)}}Ri(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS
break
case $.GREATER_THAN_SIGN:this.state=Yt.DATA,this.de(e)
break
case $.QUOTATION_MARK:this.J(rt.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers),e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:this.J(rt.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers),e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}Fi(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.GREATER_THAN_SIGN:this.de(e),this.state=Yt.DATA
break
case $.QUOTATION_MARK:e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}_i(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:this.state=Yt.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER
break
case $.QUOTATION_MARK:this.J(rt.missingWhitespaceAfterDoctypeSystemKeyword),e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:this.J(rt.missingWhitespaceAfterDoctypeSystemKeyword),e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED
break
case $.GREATER_THAN_SIGN:this.J(rt.missingDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.DATA,this.de(e)
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}Qi(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.QUOTATION_MARK:e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED
break
case $.APOSTROPHE:e.systemId="",this.state=Yt.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED
break
case $.GREATER_THAN_SIGN:this.J(rt.missingDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.DATA,this.de(e)
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.missingQuoteBeforeDoctypeSystemIdentifier),e.$t=!0,this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}Oi(t){const e=this.Rt
switch(t){case $.QUOTATION_MARK:this.state=Yt.AFTER_DOCTYPE_SYSTEM_IDENTIFIER
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.systemId+=X
break
case $.GREATER_THAN_SIGN:this.J(rt.abruptDoctypeSystemIdentifier),e.$t=!0,this.de(e),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:e.systemId+=String.fromCodePoint(t)}}Ni(t){const e=this.Rt
switch(t){case $.APOSTROPHE:this.state=Yt.AFTER_DOCTYPE_SYSTEM_IDENTIFIER
break
case $.NULL:this.J(rt.unexpectedNullCharacter),e.systemId+=X
break
case $.GREATER_THAN_SIGN:this.J(rt.abruptDoctypeSystemIdentifier),e.$t=!0,this.de(e),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:e.systemId+=String.fromCodePoint(t)}}qi(t){const e=this.Rt
switch(t){case $.SPACE:case $.LINE_FEED:case $.TABULATION:case $.FORM_FEED:break
case $.GREATER_THAN_SIGN:this.de(e),this.state=Yt.DATA
break
case $.EOF:this.J(rt.eofInDoctype),e.$t=!0,this.de(e),this.pe()
break
default:this.J(rt.unexpectedCharacterAfterDoctypeSystemIdentifier),this.state=Yt.BOGUS_DOCTYPE,this.ji(t)}}ji(t){const e=this.Rt
switch(t){case $.GREATER_THAN_SIGN:this.de(e),this.state=Yt.DATA
break
case $.NULL:this.J(rt.unexpectedNullCharacter)
break
case $.EOF:this.de(e),this.pe()}}Gi(t){switch(t){case $.RIGHT_SQUARE_BRACKET:this.state=Yt.CDATA_SECTION_BRACKET
break
case $.EOF:this.J(rt.eofInCdata),this.pe()
break
default:this.ve(t)}}Hi(t){t===$.RIGHT_SQUARE_BRACKET?this.state=Yt.CDATA_SECTION_END:(this.ye("]"),this.state=Yt.CDATA_SECTION,this.Gi(t))}Ki(t){switch(t){case $.GREATER_THAN_SIGN:this.state=Yt.DATA
break
case $.RIGHT_SQUARE_BRACKET:this.ye("]")
break
default:this.ye("]]"),this.state=Yt.CDATA_SECTION,this.Gi(t)}}Yi(){let t=this.Nt.write(this._t.html,this._t.D)
if(t<0){if(!this._t.F)return this.active=!1,this._t.D=this._t.html.length-1,this.Mt=0,void(this._t._=!0)
t=this.Nt.end()}0===t?(this._t.D=this.Dt,this.qt($.AMPERSAND),this.state=!this.Ce()&&Jt(this._t.it(1))?Yt.AMBIGUOUS_AMPERSAND:this.St):this.state=this.St}Wi(t){Jt(t)?this.qt(t):(t===$.SEMICOLON&&this.J(rt.unknownNamedCharacterReference),this.state=this.St,this.Yt(t))}}const $t=new Set([Mt.DD,Mt.DT,Mt.LI,Mt.OPTGROUP,Mt.OPTION,Mt.P,Mt.RB,Mt.RP,Mt.RT,Mt.RTC]),te=new Set([...$t,Mt.CAPTION,Mt.COLGROUP,Mt.TBODY,Mt.TD,Mt.TFOOT,Mt.TH,Mt.THEAD,Mt.TR]),ee=new Set([Mt.APPLET,Mt.CAPTION,Mt.HTML,Mt.MARQUEE,Mt.OBJECT,Mt.TABLE,Mt.TD,Mt.TEMPLATE,Mt.TH]),ie=new Set([...ee,Mt.OL,Mt.UL]),oe=new Set([...ee,Mt.BUTTON]),se=new Set([Mt.ANNOTATION_XML,Mt.MI,Mt.MN,Mt.MO,Mt.MS,Mt.MTEXT]),re=new Set([Mt.DESC,Mt.FOREIGN_OBJECT,Mt.TITLE]),ne=new Set([Mt.TR,Mt.TEMPLATE,Mt.HTML]),ae=new Set([Mt.TBODY,Mt.TFOOT,Mt.THEAD,Mt.TEMPLATE,Mt.HTML]),ce=new Set([Mt.TABLE,Mt.TEMPLATE,Mt.HTML]),le=new Set([Mt.TD,Mt.TH])
class Ae{get Zi(){return this.Ui()?this.Li.Ji(this.current):this.current}constructor(t,e,i){this.Li=e,this.C=i,this.items=[],this.Pi=[],this.Vi=-1,this.Xi=0,this.$i=Mt.UNKNOWN,this.current=t}eo(t){return this.items.lastIndexOf(t,this.Vi)}Ui(){return this.$i===Mt.TEMPLATE&&this.Li.io(this.current)===kt.HTML}oo(){this.current=this.items[this.Vi],this.$i=this.Pi[this.Vi]}push(t,e){this.Vi++,this.items[this.Vi]=t,this.current=t,this.Pi[this.Vi]=e,this.$i=e,this.Ui()&&this.Xi++,this.C.so(t,e,!0)}pop(){const t=this.current
this.Xi>0&&this.Ui()&&this.Xi--,this.Vi--,this.oo(),this.C.ro(t,!0)}replace(t,e){const i=this.eo(t)
this.items[i]=e,i===this.Vi&&(this.current=e)}no(t,e,i){const o=this.eo(t)+1
this.items.splice(o,0,e),this.Pi.splice(o,0,i),this.Vi++,o===this.Vi&&this.oo(),this.current&&void 0!==this.$i&&this.C.so(this.current,this.$i,o===this.Vi)}ao(t){let e=this.Vi+1
do{e=this.Pi.lastIndexOf(t,e-1)}while(e>0&&this.Li.io(this.items[e])!==kt.HTML)
this.co(Math.max(e,0))}co(t){for(;this.Vi>=t;){const e=this.current
this.Xi>0&&this.Ui()&&(this.Xi-=1),this.Vi--,this.oo(),this.C.ro(e,this.Vi<t)}}lo(t){const e=this.eo(t)
this.co(Math.max(e,0))}Ao(t,e){const i=this.ho(t,e)
this.co(Math.max(i,0))}do(){this.Ao(Ht,kt.HTML)}uo(){this.Ao(le,kt.HTML)}fo(){this.Xi=0,this.co(1)}ho(t,e){for(let i=this.Vi;i>=0;i--)if(t.has(this.Pi[i])&&this.Li.io(this.items[i])===e)return i
return-1}bo(t,e){const i=this.ho(t,e)
this.co(i+1)}mo(){this.bo(ce,kt.HTML)}po(){this.bo(ae,kt.HTML)}wo(){this.bo(ne,kt.HTML)}remove(t){const e=this.eo(t)
e>=0&&(e===this.Vi?this.pop():(this.items.splice(e,1),this.Pi.splice(e,1),this.Vi--,this.oo(),this.C.ro(t,!1)))}vo(){return this.Vi>=1&&this.Pi[1]===Mt.BODY?this.items[1]:null}contains(t){return this.eo(t)>-1}yo(t){const e=this.eo(t)-1
return e>=0?this.items[e]:null}ko(){return 0===this.Vi&&this.Pi[0]===Mt.HTML}Co(t,e){for(let i=this.Vi;i>=0;i--){const o=this.Pi[i]
switch(this.Li.io(this.items[i])){case kt.HTML:if(o===t)return!0
if(e.has(o))return!1
break
case kt.SVG:if(re.has(o))return!1
break
case kt.MATHML:if(se.has(o))return!1}}return!0}Io(t){return this.Co(t,ee)}Eo(t){return this.Co(t,ie)}Bo(t){return this.Co(t,oe)}xo(){for(let t=this.Vi;t>=0;t--){const e=this.Pi[t]
switch(this.Li.io(this.items[t])){case kt.HTML:if(Ht.has(e))return!0
if(ee.has(e))return!1
break
case kt.SVG:if(re.has(e))return!1
break
case kt.MATHML:if(se.has(e))return!1}}return!0}So(t){for(let e=this.Vi;e>=0;e--)if(this.Li.io(this.items[e])===kt.HTML)switch(this.Pi[e]){case t:return!0
case Mt.TABLE:case Mt.HTML:return!1}return!0}Do(){for(let t=this.Vi;t>=0;t--)if(this.Li.io(this.items[t])===kt.HTML)switch(this.Pi[t]){case Mt.TBODY:case Mt.THEAD:case Mt.TFOOT:return!0
case Mt.TABLE:case Mt.HTML:return!1}return!0}Mo(t){for(let e=this.Vi;e>=0;e--)if(this.Li.io(this.items[e])===kt.HTML)switch(this.Pi[e]){case t:return!0
case Mt.OPTION:case Mt.OPTGROUP:break
default:return!1}return!0}To(){for(;void 0!==this.$i&&$t.has(this.$i);)this.pop()}Ro(){for(;void 0!==this.$i&&te.has(this.$i);)this.pop()}Fo(t){for(;void 0!==this.$i&&this.$i!==t&&te.has(this.$i);)this.pop()}}var he,de;(de=he||(he={}))[de.Marker=0]="Marker",de[de.Element=1]="Element"
const ue={type:he.Marker}
class fe{constructor(t){this.Li=t,this.entries=[],this._o=null}Qo(t,e){const i=[],o=e.length,s=this.Li.Oo(t),r=this.Li.io(t)
for(let n=0;n<this.entries.length;n++){const t=this.entries[n]
if(t.type===he.Marker)break
const{element:e}=t
if(this.Li.Oo(e)===s&&this.Li.io(e)===r){const t=this.Li.No(e)
t.length===o&&i.push({qo:n,rt:t})}}return i}jo(t){if(this.entries.length<3)return
const e=this.Li.No(t),i=this.Qo(t,e)
if(i.length<3)return
const o=new Map(e.map(t=>[t.name,t.value]))
let s=0
for(let r=0;r<i.length;r++){const t=i[r]
t.rt.every(t=>o.get(t.name)===t.value)&&(s+=1,s>=3&&this.entries.splice(t.qo,1))}}Go(){this.entries.unshift(ue)}Ho(t,e){this.jo(t),this.entries.unshift({type:he.Element,element:t,token:e})}Ko(t,e){const i=this.entries.indexOf(this._o)
this.entries.splice(i,0,{type:he.Element,element:t,token:e})}removeEntry(t){const e=this.entries.indexOf(t);-1!==e&&this.entries.splice(e,1)}Yo(){const t=this.entries.indexOf(ue);-1===t?this.entries.length=0:this.entries.splice(0,t+1)}Wo(t){const e=this.entries.find(e=>e.type===he.Marker||this.Li.Oo(e.element)===t)
return e&&e.type===he.Element?e:null}zo(t){return this.entries.find(e=>e.type===he.Element&&e.element===t)}}const be={createDocument:()=>({nodeName:"#document",mode:Bt.NO_QUIRKS,childNodes:[]}),createDocumentFragment:()=>({nodeName:"#document-fragment",childNodes:[]}),createElement:(t,e,i)=>({nodeName:t,tagName:t,rt:i,namespaceURI:e,childNodes:[],parentNode:null}),Zo:t=>({nodeName:"#comment",data:t,parentNode:null}),createTextNode:t=>({nodeName:"#text",value:t,parentNode:null}),appendChild(t,e){t.childNodes.push(e),e.parentNode=t},insertBefore(t,e,i){const o=t.childNodes.indexOf(i)
t.childNodes.splice(o,0,e),e.parentNode=t},Uo(t,e){t.content=e},Ji:t=>t.content,Jo(t,e,i,o){const s=t.childNodes.find(t=>"#documentType"===t.nodeName)
if(s)s.name=e,s.publicId=i,s.systemId=o
else{const s={nodeName:"#documentType",name:e,publicId:i,systemId:o,parentNode:null}
be.appendChild(t,s)}},Lo(t,e){t.mode=e},Po:t=>t.mode,Vo(t){if(t.parentNode){const e=t.parentNode.childNodes.indexOf(t)
t.parentNode.childNodes.splice(e,1),t.parentNode=null}},Xo(t,e){if(t.childNodes.length>0){const i=t.childNodes[t.childNodes.length-1]
if(be.$o(i))return void(i.value+=e)}be.appendChild(t,be.createTextNode(e))},ts(t,e,i){const o=t.childNodes[t.childNodes.indexOf(i)-1]
o&&be.$o(o)?o.value+=e:be.insertBefore(t,be.createTextNode(e),i)},es(t,e){const i=new Set(t.rt.map(t=>t.name))
for(let o=0;o<e.length;o++)i.has(e[o].name)||t.rt.push(e[o])},ss:t=>t.childNodes[0],rs:t=>t.childNodes,ns:t=>t.parentNode,No:t=>t.rt,Oo:t=>t.tagName,io:t=>t.namespaceURI,cs:t=>t.value,ls:t=>t.data,As:t=>t.name,hs:t=>t.publicId,ds:t=>t.systemId,$o:t=>"#text"===t.nodeName,us:t=>"#comment"===t.nodeName,fs:t=>"#documentType"===t.nodeName,bs:t=>Object.prototype.hasOwnProperty.call(t,"tagName"),ps(t,e){t.gs=e},ws:t=>t.gs,vs(t,e){t.gs={...t.gs,...e}}},me="html",pe=["+//silmaril//dtd html pro v0r11 19970101//","-//as//dtd html 3.0 aswedit + extensions//","-//advasoft ltd//dtd html 3.0 aswedit + extensions//","-//ietf//dtd html 2.0 level 1//","-//ietf//dtd html 2.0 level 2//","-//ietf//dtd html 2.0 strict level 1//","-//ietf//dtd html 2.0 strict level 2//","-//ietf//dtd html 2.0 strict//","-//ietf//dtd html 2.0//","-//ietf//dtd html 2.1e//","-//ietf//dtd html 3.0//","-//ietf//dtd html 3.2 final//","-//ietf//dtd html 3.2//","-//ietf//dtd html 3//","-//ietf//dtd html level 0//","-//ietf//dtd html level 1//","-//ietf//dtd html level 2//","-//ietf//dtd html level 3//","-//ietf//dtd html strict level 0//","-//ietf//dtd html strict level 1//","-//ietf//dtd html strict level 2//","-//ietf//dtd html strict level 3//","-//ietf//dtd html strict//","-//ietf//dtd html//","-//metrius//dtd metrius presentational//","-//microsoft//dtd internet explorer 2.0 html strict//","-//microsoft//dtd internet explorer 2.0 html//","-//microsoft//dtd internet explorer 2.0 tables//","-//microsoft//dtd internet explorer 3.0 html strict//","-//microsoft//dtd internet explorer 3.0 html//","-//microsoft//dtd internet explorer 3.0 tables//","-//netscape comm. corp.//dtd html//","-//netscape comm. corp.//dtd strict html//","-//o'reilly and associates//dtd html 2.0//","-//o'reilly and associates//dtd html extended 1.0//","-//o'reilly and associates//dtd html extended relaxed 1.0//","-//sq//dtd html 2.0 hotmetal + extensions//","-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//","-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//","-//spyglass//dtd html 2.0 extended//","-//sun microsystems corp.//dtd hotjava html//","-//sun microsystems corp.//dtd hotjava strict html//","-//w3c//dtd html 3 1995-03-24//","-//w3c//dtd html 3.2 draft//","-//w3c//dtd html 3.2 final//","-//w3c//dtd html 3.2//","-//w3c//dtd html 3.2s draft//","-//w3c//dtd html 4.0 frameset//","-//w3c//dtd html 4.0 transitional//","-//w3c//dtd html experimental 19960712//","-//w3c//dtd html experimental 970421//","-//w3c//dtd w3 html//","-//w3o//dtd w3 html 3.0//","-//webtechs//dtd mozilla html 2.0//","-//webtechs//dtd mozilla html//"],ge=[...pe,"-//w3c//dtd html 4.01 frameset//","-//w3c//dtd html 4.01 transitional//"],we=new Set(["-//w3o//dtd w3 html strict 3.0//en//","-/w3c/dtd html 4.0 transitional/en","html"]),ve=["-//w3c//dtd xhtml 1.0 frameset//","-//w3c//dtd xhtml 1.0 transitional//"],ye=[...ve,"-//w3c//dtd html 4.01 frameset//","-//w3c//dtd html 4.01 transitional//"]
function ke(t,e){return e.some(e=>t.startsWith(e))}const Ce=new Map(["attributeName","attributeType","baseFrequency","baseProfile","calcMode","clipPathUnits","diffuseConstant","edgeMode","filterUnits","glyphRef","gradientTransform","gradientUnits","kernelMatrix","kernelUnitLength","keyPoints","keySplines","keyTimes","lengthAdjust","limitingConeAngle","markerHeight","markerUnits","markerWidth","maskContentUnits","maskUnits","numOctaves","pathLength","patternContentUnits","patternTransform","patternUnits","pointsAtX","pointsAtY","pointsAtZ","preserveAlpha","preserveAspectRatio","primitiveUnits","refX","refY","repeatCount","repeatDur","requiredExtensions","requiredFeatures","specularConstant","specularExponent","spreadMethod","startOffset","stdDeviation","stitchTiles","surfaceScale","systemLanguage","tableValues","targetX","targetY","textLength","viewBox","viewTarget","xChannelSelector","yChannelSelector","zoomAndPan"].map(t=>[t.toLowerCase(),t])),Ie=new Map([["xlink:actuate",{prefix:"xlink",name:"actuate",namespace:kt.XLINK}],["xlink:arcrole",{prefix:"xlink",name:"arcrole",namespace:kt.XLINK}],["xlink:href",{prefix:"xlink",name:"href",namespace:kt.XLINK}],["xlink:role",{prefix:"xlink",name:"role",namespace:kt.XLINK}],["xlink:show",{prefix:"xlink",name:"show",namespace:kt.XLINK}],["xlink:title",{prefix:"xlink",name:"title",namespace:kt.XLINK}],["xlink:type",{prefix:"xlink",name:"type",namespace:kt.XLINK}],["xml:lang",{prefix:"xml",name:"lang",namespace:kt.XML}],["xml:space",{prefix:"xml",name:"space",namespace:kt.XML}],["xmlns",{prefix:"",name:"xmlns",namespace:kt.XMLNS}],["xmlns:xlink",{prefix:"xmlns",name:"xlink",namespace:kt.XMLNS}]]),Ee=new Map(["altGlyph","altGlyphDef","altGlyphItem","animateColor","animateMotion","animateTransform","clipPath","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","foreignObject","glyphRef","linearGradient","radialGradient","textPath"].map(t=>[t.toLowerCase(),t])),Be=new Set([Mt.B,Mt.BIG,Mt.BLOCKQUOTE,Mt.BODY,Mt.BR,Mt.CENTER,Mt.CODE,Mt.DD,Mt.DIV,Mt.DL,Mt.DT,Mt.EM,Mt.EMBED,Mt.H1,Mt.H2,Mt.H3,Mt.H4,Mt.H5,Mt.H6,Mt.HEAD,Mt.HR,Mt.I,Mt.IMG,Mt.LI,Mt.LISTING,Mt.MENU,Mt.META,Mt.NOBR,Mt.OL,Mt.P,Mt.PRE,Mt.RUBY,Mt.S,Mt.SMALL,Mt.SPAN,Mt.STRONG,Mt.STRIKE,Mt.SUB,Mt.SUP,Mt.TABLE,Mt.TT,Mt.U,Mt.UL,Mt.VAR])
function xe(t){for(let e=0;e<t.rt.length;e++)if("definitionurl"===t.rt[e].name){t.rt[e].name="definitionURL"
break}}function Se(t){for(let e=0;e<t.rt.length;e++){const i=Ce.get(t.rt[e].name)
null!=i&&(t.rt[e].name=i)}}function De(t){for(let e=0;e<t.rt.length;e++){const i=Ie.get(t.rt[e].name)
i&&(t.rt[e].prefix=i.prefix,t.rt[e].name=i.name,t.rt[e].namespace=i.namespace)}}var Me,Te;(Te=Me||(Me={}))[Te.INITIAL=0]="INITIAL",Te[Te.BEFORE_HTML=1]="BEFORE_HTML",Te[Te.BEFORE_HEAD=2]="BEFORE_HEAD",Te[Te.IN_HEAD=3]="IN_HEAD",Te[Te.IN_HEAD_NO_SCRIPT=4]="IN_HEAD_NO_SCRIPT",Te[Te.AFTER_HEAD=5]="AFTER_HEAD",Te[Te.IN_BODY=6]="IN_BODY",Te[Te.TEXT=7]="TEXT",Te[Te.IN_TABLE=8]="IN_TABLE",Te[Te.IN_TABLE_TEXT=9]="IN_TABLE_TEXT",Te[Te.IN_CAPTION=10]="IN_CAPTION",Te[Te.IN_COLUMN_GROUP=11]="IN_COLUMN_GROUP",Te[Te.IN_TABLE_BODY=12]="IN_TABLE_BODY",Te[Te.IN_ROW=13]="IN_ROW",Te[Te.IN_CELL=14]="IN_CELL",Te[Te.IN_SELECT=15]="IN_SELECT",Te[Te.IN_SELECT_IN_TABLE=16]="IN_SELECT_IN_TABLE",Te[Te.IN_TEMPLATE=17]="IN_TEMPLATE",Te[Te.AFTER_BODY=18]="AFTER_BODY",Te[Te.IN_FRAMESET=19]="IN_FRAMESET",Te[Te.AFTER_FRAMESET=20]="AFTER_FRAMESET",Te[Te.AFTER_AFTER_BODY=21]="AFTER_AFTER_BODY",Te[Te.AFTER_AFTER_FRAMESET=22]="AFTER_AFTER_FRAMESET"
const Re={K:-1,W:-1,startOffset:-1,Y:-1,Z:-1,endOffset:-1},Fe=new Set([Mt.TABLE,Mt.TBODY,Mt.TFOOT,Mt.THEAD,Mt.TR]),_e={ys:!0,jt:!1,Li:be,L:null}
class Qe{constructor(t,e,i=null,o=null){this.ks=i,this.Cs=o,this.Rt=null,this.stopped=!1,this.Is=Me.INITIAL,this.Es=Me.INITIAL,this.Bs=null,this.xs=null,this.Ss=!1,this.Ds=[],this.Ms=[],this.Ts=!1,this.Rs=!0,this.R=!1,this.Fs=!1,this.options={..._e,...t},this.Li=this.options.Li,this.L=this.options.L,this.L&&(this.options.jt=!0),this.document=null!=e?e:this.Li.createDocument(),this._s=new Xt(this.options,this),this.Qs=new fe(this.Li),this.Os=i?qt(this.Li.Oo(i)):Mt.UNKNOWN,this.Ns(null!=i?i:this.document,this.Os),this.qs=new Ae(this.document,this.Li,this)}static parse(t,e){const i=new this(e)
return i._s.write(t,!0),i.document}static js(t,e){const i={..._e,...e}
null!=t||(t=i.Li.createElement(St.TEMPLATE,kt.HTML,[]))
const o=i.Li.createElement("documentmock",kt.HTML,[]),s=new this(i,o,t)
return s.Os===Mt.TEMPLATE&&s.Ds.unshift(Me.IN_TEMPLATE),s.Gs(),s.Hs(),s.Ks(),s.Ys(),s}Ws(){const t=this.Li.ss(this.document),e=this.Li.createDocumentFragment()
return this.zs(t,e),e}J(t,e,i){var o
if(!this.L)return
const s=null!==(o=t.location)&&void 0!==o?o:Re,r={code:e,K:s.K,W:s.W,startOffset:s.startOffset,Y:i?s.K:s.Y,Z:i?s.W:s.Z,endOffset:i?s.startOffset:s.endOffset}
this.L(r)}so(t,e,i){var o,s
null===(s=(o=this.Li).so)||void 0===s||s.call(o,t),i&&this.qs.Vi>0&&this.Ns(t,e)}ro(t,e){var i,o
if(this.options.jt&&this.Zs(t,this.Rt),null===(o=(i=this.Li).ro)||void 0===o||o.call(i,t,this.qs.current),e){let t,e
0===this.qs.Vi&&this.ks?(t=this.ks,e=this.Os):({current:t,$i:e}=this.qs),this.Ns(t,e)}}Ns(t,e){const i=t===this.document||t&&this.Li.io(t)===kt.HTML
this.Ss=!i,this._s.Bt=!i&&void 0!==t&&void 0!==e&&!this.Us(e,t)}Js(t,e){this.Ls(t,kt.HTML),this._s.state=e,this.Es=this.Is,this.Is=Me.TEXT}Ps(){this.Is=Me.TEXT,this.Es=Me.IN_BODY,this._s.state=zt.PLAINTEXT}Vs(){return 0===this.qs.Vi&&this.ks?this.ks:this.qs.current}Ys(){let t=this.ks
for(;t;){if(this.Li.Oo(t)===St.FORM){this.xs=t
break}t=this.Li.ns(t)}}Gs(){if(this.ks&&this.Li.io(this.ks)===kt.HTML)switch(this.Os){case Mt.TITLE:case Mt.TEXTAREA:this._s.state=zt.RCDATA
break
case Mt.STYLE:case Mt.XMP:case Mt.IFRAME:case Mt.NOEMBED:case Mt.NOFRAMES:case Mt.NOSCRIPT:this._s.state=zt.RAWTEXT
break
case Mt.SCRIPT:this._s.state=zt.SCRIPT_DATA
break
case Mt.PLAINTEXT:this._s.state=zt.PLAINTEXT}}Xs(t){const e=t.name||"",i=t.publicId||"",o=t.systemId||""
if(this.Li.Jo(this.document,e,i,o),t.location){const e=this.Li.rs(this.document).find(t=>this.Li.fs(t))
e&&this.Li.ps(e,t.location)}}$s(t,e){if(this.options.jt){const i=e&&{...e,startTag:e}
this.Li.ps(t,i)}if(this.tr())this.er(t)
else{const e=this.qs.Zi
this.Li.appendChild(null!=e?e:this.document,t)}}ir(t,e){const i=this.Li.createElement(t.tagName,e,t.rt)
this.$s(i,t.location)}Ls(t,e){const i=this.Li.createElement(t.tagName,e,t.rt)
this.$s(i,t.location),this.qs.push(i,t.Ut)}sr(t,e){const i=this.Li.createElement(t,kt.HTML,[])
this.$s(i,null),this.qs.push(i,e)}rr(t){const e=this.Li.createElement(t.tagName,kt.HTML,t.rt),i=this.Li.createDocumentFragment()
this.Li.Uo(e,i),this.$s(e,t.location),this.qs.push(e,t.Ut),this.options.jt&&this.Li.ps(i,null)}Hs(){const t=this.Li.createElement(St.HTML,kt.HTML,[])
this.options.jt&&this.Li.ps(t,null),this.Li.appendChild(this.qs.current,t),this.qs.push(t,Mt.HTML)}nr(t,e){const i=this.Li.Zo(t.data)
this.Li.appendChild(e,i),this.options.jt&&this.Li.ps(i,t.location)}ar(t){let e,i
if(this.tr()?(({parent:e,cr:i}=this.lr()),i?this.Li.ts(e,t.ee,i):this.Li.Xo(e,t.ee)):(e=this.qs.Zi,this.Li.Xo(e,t.ee)),!t.location)return
const o=this.Li.rs(e),s=i?o.lastIndexOf(i):o.length,r=o[s-1]
if(this.Li.ws(r)){const{Y:e,Z:i,endOffset:o}=t.location
this.Li.vs(r,{Y:e,Z:i,endOffset:o})}else this.options.jt&&this.Li.ps(r,t.location)}zs(t,e){for(let i=this.Li.ss(t);i;i=this.Li.ss(t))this.Li.Vo(i),this.Li.appendChild(e,i)}Zs(t,e){if(this.Li.ws(t)&&e.location){const i=e.location,o=this.Li.Oo(t),s=e.type===at.END_TAG&&o===e.tagName?{endTag:{...i},Y:i.Y,Z:i.Z,endOffset:i.endOffset}:{Y:i.K,Z:i.W,endOffset:i.startOffset}
this.Li.vs(t,s)}}Ar(t){if(!this.Ss)return!1
let e,i
return 0===this.qs.Vi&&this.ks?(e=this.ks,i=this.Os):({current:e,$i:i}=this.qs),(t.Ut!==Mt.SVG||this.Li.Oo(e)!==St.ANNOTATION_XML||this.Li.io(e)!==kt.MATHML)&&(this._s.Bt||(t.Ut===Mt.MGLYPH||t.Ut===Mt.MALIGNMARK)&&void 0!==i&&!this.Us(i,e,kt.HTML))}hr(t){switch(t.type){case at.CHARACTER:this.fe(t)
break
case at.NULL_CHARACTER:this.be(t)
break
case at.COMMENT:this.he(t)
break
case at.DOCTYPE:this.ue(t)
break
case at.START_TAG:this.dr(t)
break
case at.END_TAG:this.le(t)
break
case at.EOF:this.ge(t)
break
case at.WHITESPACE_CHARACTER:this.me(t)}}Us(t,e,i){return((t,e,i,o)=>(!o||o===kt.HTML)&&((t,e,i)=>{if(e===kt.MATHML&&t===Mt.ANNOTATION_XML)for(let o=0;o<i.length;o++)if(i[o].name===It.ENCODING){const t=i[o].value.toLowerCase()
return"text/html"===t||"application/xhtml+xml"===t}return e===kt.SVG&&(t===Mt.FOREIGN_OBJECT||t===Mt.DESC||t===Mt.TITLE)})(t,e,i)||(!o||o===kt.MATHML)&&((t,e)=>e===kt.MATHML&&(t===Mt.MI||t===Mt.MO||t===Mt.MN||t===Mt.MS||t===Mt.MTEXT))(t,e))(t,this.Li.io(e),this.Li.No(e),i)}ur(){const t=this.Qs.entries.length
if(t){const e=this.Qs.entries.findIndex(t=>t.type===he.Marker||this.qs.contains(t.element))
for(let i=-1===e?t-1:e-1;i>=0;i--){const t=this.Qs.entries[i]
this.Ls(t.token,this.Li.io(t.element)),t.element=this.qs.current}}}br(){this.qs.To(),this.qs.uo(),this.Qs.Yo(),this.Is=Me.IN_ROW}mr(){this.qs.Fo(Mt.P),this.qs.ao(Mt.P)}Ks(){for(let t=this.qs.Vi;t>=0;t--)switch(0===t&&this.ks?this.Os:this.qs.Pi[t]){case Mt.TR:return void(this.Is=Me.IN_ROW)
case Mt.TBODY:case Mt.THEAD:case Mt.TFOOT:return void(this.Is=Me.IN_TABLE_BODY)
case Mt.CAPTION:return void(this.Is=Me.IN_CAPTION)
case Mt.COLGROUP:return void(this.Is=Me.IN_COLUMN_GROUP)
case Mt.TABLE:return void(this.Is=Me.IN_TABLE)
case Mt.BODY:return void(this.Is=Me.IN_BODY)
case Mt.FRAMESET:return void(this.Is=Me.IN_FRAMESET)
case Mt.SELECT:return void this.pr(t)
case Mt.TEMPLATE:return void(this.Is=this.Ds[0])
case Mt.HTML:return void(this.Is=this.Bs?Me.AFTER_HEAD:Me.BEFORE_HEAD)
case Mt.TD:case Mt.TH:if(t>0)return void(this.Is=Me.IN_CELL)
break
case Mt.HEAD:if(t>0)return void(this.Is=Me.IN_HEAD)}this.Is=Me.IN_BODY}pr(t){if(t>0)for(let e=t-1;e>0;e--){const t=this.qs.Pi[e]
if(t===Mt.TEMPLATE)break
if(t===Mt.TABLE)return void(this.Is=Me.IN_SELECT_IN_TABLE)}this.Is=Me.IN_SELECT}gr(t){return Fe.has(t)}tr(){return this.Fs&&void 0!==this.qs.$i&&this.gr(this.qs.$i)}lr(){for(let t=this.qs.Vi;t>=0;t--){const e=this.qs.items[t]
switch(this.qs.Pi[t]){case Mt.TEMPLATE:if(this.Li.io(e)===kt.HTML)return{parent:this.Li.Ji(e),cr:null}
break
case Mt.TABLE:{const i=this.Li.ns(e)
return i?{parent:i,cr:e}:{parent:this.qs.items[t-1],cr:null}}}}return{parent:this.qs.items[0],cr:null}}er(t){const e=this.lr()
e.cr?this.Li.insertBefore(e.parent,t,e.cr):this.Li.appendChild(e.parent,t)}wr(t,e){const i=this.Li.io(t)
return Gt[i].has(e)}fe(t){if(this.R=!1,this._s.Bt)((t,e)=>{t.ar(e),t.Rs=!1})(this,t)
else switch(this.Is){case Me.INITIAL:ze(this,t)
break
case Me.BEFORE_HTML:Ze(this,t)
break
case Me.BEFORE_HEAD:Ue(this,t)
break
case Me.IN_HEAD:Pe(this,t)
break
case Me.IN_HEAD_NO_SCRIPT:Ve(this,t)
break
case Me.AFTER_HEAD:Xe(this,t)
break
case Me.IN_BODY:case Me.IN_CAPTION:case Me.IN_CELL:case Me.IN_TEMPLATE:ei(this,t)
break
case Me.TEXT:case Me.IN_SELECT:case Me.IN_SELECT_IN_TABLE:this.ar(t)
break
case Me.IN_TABLE:case Me.IN_TABLE_BODY:case Me.IN_ROW:Ai(this,t)
break
case Me.IN_TABLE_TEXT:bi(this,t)
break
case Me.IN_COLUMN_GROUP:wi(this,t)
break
case Me.AFTER_BODY:Si(this,t)
break
case Me.AFTER_AFTER_BODY:Di(this,t)}}be(t){if(this.R=!1,this._s.Bt)((t,e)=>{e.ee=X,t.ar(e)})(this,t)
else switch(this.Is){case Me.INITIAL:ze(this,t)
break
case Me.BEFORE_HTML:Ze(this,t)
break
case Me.BEFORE_HEAD:Ue(this,t)
break
case Me.IN_HEAD:Pe(this,t)
break
case Me.IN_HEAD_NO_SCRIPT:Ve(this,t)
break
case Me.AFTER_HEAD:Xe(this,t)
break
case Me.TEXT:this.ar(t)
break
case Me.IN_TABLE:case Me.IN_TABLE_BODY:case Me.IN_ROW:Ai(this,t)
break
case Me.IN_COLUMN_GROUP:wi(this,t)
break
case Me.AFTER_BODY:Si(this,t)
break
case Me.AFTER_AFTER_BODY:Di(this,t)}}he(t){if(this.R=!1,this.Ss)Ye(this,t)
else switch(this.Is){case Me.INITIAL:case Me.BEFORE_HTML:case Me.BEFORE_HEAD:case Me.IN_HEAD:case Me.IN_HEAD_NO_SCRIPT:case Me.AFTER_HEAD:case Me.IN_BODY:case Me.IN_TABLE:case Me.IN_CAPTION:case Me.IN_COLUMN_GROUP:case Me.IN_TABLE_BODY:case Me.IN_ROW:case Me.IN_CELL:case Me.IN_SELECT:case Me.IN_SELECT_IN_TABLE:case Me.IN_TEMPLATE:case Me.IN_FRAMESET:case Me.AFTER_FRAMESET:Ye(this,t)
break
case Me.IN_TABLE_TEXT:mi(this,t)
break
case Me.AFTER_BODY:((t,e)=>{t.nr(e,t.qs.items[0])})(this,t)
break
case Me.AFTER_AFTER_BODY:case Me.AFTER_AFTER_FRAMESET:((t,e)=>{t.nr(e,t.document)})(this,t)}}ue(t){switch(this.R=!1,this.Is){case Me.INITIAL:((t,e)=>{t.Xs(e)
const i=e.$t?Bt.QUIRKS:(t=>{if(t.name!==me)return Bt.QUIRKS
const{systemId:e}=t
if(e&&"http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd"===e.toLowerCase())return Bt.QUIRKS
let{publicId:i}=t
if(null!==i){if(i=i.toLowerCase(),we.has(i))return Bt.QUIRKS
let t=null===e?ge:pe
if(ke(i,t))return Bt.QUIRKS
if(t=null===e?ve:ye,ke(i,t))return Bt.LIMITED_QUIRKS}return Bt.NO_QUIRKS})(e);(t=>t.name===me&&null===t.publicId&&(null===t.systemId||"about:legacy-compat"===t.systemId))(e)||t.J(e,rt.nonConformingDoctype),t.Li.Lo(t.document,i),t.Is=Me.BEFORE_HTML})(this,t)
break
case Me.BEFORE_HEAD:case Me.IN_HEAD:case Me.IN_HEAD_NO_SCRIPT:case Me.AFTER_HEAD:this.J(t,rt.misplacedDoctype)
break
case Me.IN_TABLE_TEXT:mi(this,t)}}ce(t){this.R=!1,this.Rt=t,this.dr(t),t.Jt&&!t.Lt&&this.J(t,rt.nonVoidHtmlElementStartTagWithTrailingSolidus)}dr(t){this.Ar(t)?((t,e)=>{if((t=>{const e=t.Ut
return e===Mt.FONT&&t.rt.some(({name:t})=>t===It.COLOR||t===It.SIZE||t===It.FACE)||Be.has(e)})(e))Mi(t),t.vr(e)
else{const i=t.Vs(),o=t.Li.io(i)
o===kt.MATHML?xe(e):o===kt.SVG&&((t=>{const e=Ee.get(t.tagName)
null!=e&&(t.tagName=e,t.Ut=qt(t.tagName))})(e),Se(e)),De(e),e.Jt?t.ir(e,o):t.Ls(e,o),e.Lt=!0}})(this,t):this.vr(t)}vr(t){switch(this.Is){case Me.INITIAL:ze(this,t)
break
case Me.BEFORE_HTML:((t,e)=>{e.Ut===Mt.HTML?(t.Ls(e,kt.HTML),t.Is=Me.BEFORE_HEAD):Ze(t,e)})(this,t)
break
case Me.BEFORE_HEAD:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.HEAD:t.Ls(e,kt.HTML),t.Bs=t.qs.current,t.Is=Me.IN_HEAD
break
default:Ue(t,e)}})(this,t)
break
case Me.IN_HEAD:Je(this,t)
break
case Me.IN_HEAD_NO_SCRIPT:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.BASEFONT:case Mt.BGSOUND:case Mt.HEAD:case Mt.LINK:case Mt.META:case Mt.NOFRAMES:case Mt.STYLE:Je(t,e)
break
case Mt.NOSCRIPT:t.J(e,rt.nestedNoscriptInHead)
break
default:Ve(t,e)}})(this,t)
break
case Me.AFTER_HEAD:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.BODY:t.Ls(e,kt.HTML),t.Rs=!1,t.Is=Me.IN_BODY
break
case Mt.FRAMESET:t.Ls(e,kt.HTML),t.Is=Me.IN_FRAMESET
break
case Mt.BASE:case Mt.BASEFONT:case Mt.BGSOUND:case Mt.LINK:case Mt.META:case Mt.NOFRAMES:case Mt.SCRIPT:case Mt.STYLE:case Mt.TEMPLATE:case Mt.TITLE:t.J(e,rt.abandonedHeadElementChild),t.qs.push(t.Bs,Mt.HEAD),Je(t,e),t.qs.remove(t.Bs)
break
case Mt.HEAD:t.J(e,rt.misplacedStartTagForHeadElement)
break
default:Xe(t,e)}})(this,t)
break
case Me.IN_BODY:ni(this,t)
break
case Me.IN_TABLE:hi(this,t)
break
case Me.IN_TABLE_TEXT:mi(this,t)
break
case Me.IN_CAPTION:((t,e)=>{const i=e.Ut
pi.has(i)?t.qs.So(Mt.CAPTION)&&(t.qs.To(),t.qs.ao(Mt.CAPTION),t.Qs.Yo(),t.Is=Me.IN_TABLE,hi(t,e)):ni(t,e)})(this,t)
break
case Me.IN_COLUMN_GROUP:gi(this,t)
break
case Me.IN_TABLE_BODY:vi(this,t)
break
case Me.IN_ROW:ki(this,t)
break
case Me.IN_CELL:((t,e)=>{const i=e.Ut
pi.has(i)?(t.qs.So(Mt.TD)||t.qs.So(Mt.TH))&&(t.br(),ki(t,e)):ni(t,e)})(this,t)
break
case Me.IN_SELECT:Ii(this,t)
break
case Me.IN_SELECT_IN_TABLE:((t,e)=>{const i=e.Ut
i===Mt.CAPTION||i===Mt.TABLE||i===Mt.TBODY||i===Mt.TFOOT||i===Mt.THEAD||i===Mt.TR||i===Mt.TD||i===Mt.TH?(t.qs.ao(Mt.SELECT),t.Ks(),t.dr(e)):Ii(t,e)})(this,t)
break
case Me.IN_TEMPLATE:((t,e)=>{switch(e.Ut){case Mt.BASE:case Mt.BASEFONT:case Mt.BGSOUND:case Mt.LINK:case Mt.META:case Mt.NOFRAMES:case Mt.SCRIPT:case Mt.STYLE:case Mt.TEMPLATE:case Mt.TITLE:Je(t,e)
break
case Mt.CAPTION:case Mt.COLGROUP:case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:t.Ds[0]=Me.IN_TABLE,t.Is=Me.IN_TABLE,hi(t,e)
break
case Mt.COL:t.Ds[0]=Me.IN_COLUMN_GROUP,t.Is=Me.IN_COLUMN_GROUP,gi(t,e)
break
case Mt.TR:t.Ds[0]=Me.IN_TABLE_BODY,t.Is=Me.IN_TABLE_BODY,vi(t,e)
break
case Mt.TD:case Mt.TH:t.Ds[0]=Me.IN_ROW,t.Is=Me.IN_ROW,ki(t,e)
break
default:t.Ds[0]=Me.IN_BODY,t.Is=Me.IN_BODY,ni(t,e)}})(this,t)
break
case Me.AFTER_BODY:((t,e)=>{e.Ut===Mt.HTML?ni(t,e):Si(t,e)})(this,t)
break
case Me.IN_FRAMESET:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.FRAMESET:t.Ls(e,kt.HTML)
break
case Mt.FRAME:t.ir(e,kt.HTML),e.Lt=!0
break
case Mt.NOFRAMES:Je(t,e)}})(this,t)
break
case Me.AFTER_FRAMESET:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.NOFRAMES:Je(t,e)}})(this,t)
break
case Me.AFTER_AFTER_BODY:((t,e)=>{e.Ut===Mt.HTML?ni(t,e):Di(t,e)})(this,t)
break
case Me.AFTER_AFTER_FRAMESET:((t,e)=>{switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.NOFRAMES:Je(t,e)}})(this,t)}}le(t){this.R=!1,this.Rt=t,this.Ss?((t,e)=>{if(e.Ut===Mt.P||e.Ut===Mt.BR)return Mi(t),void t.yr(e)
for(let i=t.qs.Vi;i>0;i--){const o=t.qs.items[i]
if(t.Li.io(o)===kt.HTML){t.yr(e)
break}const s=t.Li.Oo(o)
if(s.toLowerCase()===e.tagName){e.tagName=s,t.qs.co(i)
break}}})(this,t):this.yr(t)}yr(t){switch(this.Is){case Me.INITIAL:ze(this,t)
break
case Me.BEFORE_HTML:((t,e)=>{const i=e.Ut
i!==Mt.HTML&&i!==Mt.HEAD&&i!==Mt.BODY&&i!==Mt.BR||Ze(t,e)})(this,t)
break
case Me.BEFORE_HEAD:((t,e)=>{const i=e.Ut
i===Mt.HEAD||i===Mt.BODY||i===Mt.HTML||i===Mt.BR?Ue(t,e):t.J(e,rt.endTagWithoutMatchingOpenElement)})(this,t)
break
case Me.IN_HEAD:((t,e)=>{switch(e.Ut){case Mt.HEAD:t.qs.pop(),t.Is=Me.AFTER_HEAD
break
case Mt.BODY:case Mt.BR:case Mt.HTML:Pe(t,e)
break
case Mt.TEMPLATE:Le(t,e)
break
default:t.J(e,rt.endTagWithoutMatchingOpenElement)}})(this,t)
break
case Me.IN_HEAD_NO_SCRIPT:((t,e)=>{switch(e.Ut){case Mt.NOSCRIPT:t.qs.pop(),t.Is=Me.IN_HEAD
break
case Mt.BR:Ve(t,e)
break
default:t.J(e,rt.endTagWithoutMatchingOpenElement)}})(this,t)
break
case Me.AFTER_HEAD:((t,e)=>{switch(e.Ut){case Mt.BODY:case Mt.HTML:case Mt.BR:Xe(t,e)
break
case Mt.TEMPLATE:Le(t,e)
break
default:t.J(e,rt.endTagWithoutMatchingOpenElement)}})(this,t)
break
case Me.IN_BODY:ci(this,t)
break
case Me.TEXT:((t,e)=>{var i
e.Ut===Mt.SCRIPT&&(null===(i=t.Cs)||void 0===i||i.call(t,t.qs.current)),t.qs.pop(),t.Is=t.Es})(this,t)
break
case Me.IN_TABLE:di(this,t)
break
case Me.IN_TABLE_TEXT:mi(this,t)
break
case Me.IN_CAPTION:((t,e)=>{const i=e.Ut
switch(i){case Mt.CAPTION:case Mt.TABLE:t.qs.So(Mt.CAPTION)&&(t.qs.To(),t.qs.ao(Mt.CAPTION),t.Qs.Yo(),t.Is=Me.IN_TABLE,i===Mt.TABLE&&di(t,e))
break
case Mt.BODY:case Mt.COL:case Mt.COLGROUP:case Mt.HTML:case Mt.TBODY:case Mt.TD:case Mt.TFOOT:case Mt.TH:case Mt.THEAD:case Mt.TR:break
default:ci(t,e)}})(this,t)
break
case Me.IN_COLUMN_GROUP:((t,e)=>{switch(e.Ut){case Mt.COLGROUP:t.qs.$i===Mt.COLGROUP&&(t.qs.pop(),t.Is=Me.IN_TABLE)
break
case Mt.TEMPLATE:Le(t,e)
break
case Mt.COL:break
default:wi(t,e)}})(this,t)
break
case Me.IN_TABLE_BODY:yi(this,t)
break
case Me.IN_ROW:Ci(this,t)
break
case Me.IN_CELL:((t,e)=>{const i=e.Ut
switch(i){case Mt.TD:case Mt.TH:t.qs.So(i)&&(t.qs.To(),t.qs.ao(i),t.Qs.Yo(),t.Is=Me.IN_ROW)
break
case Mt.TABLE:case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:case Mt.TR:t.qs.So(i)&&(t.br(),Ci(t,e))
break
case Mt.BODY:case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.HTML:break
default:ci(t,e)}})(this,t)
break
case Me.IN_SELECT:Ei(this,t)
break
case Me.IN_SELECT_IN_TABLE:((t,e)=>{const i=e.Ut
i===Mt.CAPTION||i===Mt.TABLE||i===Mt.TBODY||i===Mt.TFOOT||i===Mt.THEAD||i===Mt.TR||i===Mt.TD||i===Mt.TH?t.qs.So(i)&&(t.qs.ao(Mt.SELECT),t.Ks(),t.le(e)):Ei(t,e)})(this,t)
break
case Me.IN_TEMPLATE:((t,e)=>{e.Ut===Mt.TEMPLATE&&Le(t,e)})(this,t)
break
case Me.AFTER_BODY:xi(this,t)
break
case Me.IN_FRAMESET:((t,e)=>{e.Ut!==Mt.FRAMESET||t.qs.ko()||(t.qs.pop(),t.ks||t.qs.$i===Mt.FRAMESET||(t.Is=Me.AFTER_FRAMESET))})(this,t)
break
case Me.AFTER_FRAMESET:((t,e)=>{e.Ut===Mt.HTML&&(t.Is=Me.AFTER_AFTER_FRAMESET)})(this,t)
break
case Me.AFTER_AFTER_BODY:Di(this,t)}}ge(t){switch(this.Is){case Me.INITIAL:ze(this,t)
break
case Me.BEFORE_HTML:Ze(this,t)
break
case Me.BEFORE_HEAD:Ue(this,t)
break
case Me.IN_HEAD:Pe(this,t)
break
case Me.IN_HEAD_NO_SCRIPT:Ve(this,t)
break
case Me.AFTER_HEAD:Xe(this,t)
break
case Me.IN_BODY:case Me.IN_TABLE:case Me.IN_CAPTION:case Me.IN_COLUMN_GROUP:case Me.IN_TABLE_BODY:case Me.IN_ROW:case Me.IN_CELL:case Me.IN_SELECT:case Me.IN_SELECT_IN_TABLE:li(this,t)
break
case Me.TEXT:((t,e)=>{t.J(e,rt.eofInElementThatCanContainOnlyText),t.qs.pop(),t.Is=t.Es,t.ge(e)})(this,t)
break
case Me.IN_TABLE_TEXT:mi(this,t)
break
case Me.IN_TEMPLATE:Bi(this,t)
break
case Me.AFTER_BODY:case Me.IN_FRAMESET:case Me.AFTER_FRAMESET:case Me.AFTER_AFTER_BODY:case Me.AFTER_AFTER_FRAMESET:We(this,t)}}me(t){if(this.R&&(this.R=!1,t.ee.charCodeAt(0)===$.LINE_FEED)){if(1===t.ee.length)return
t.ee=t.ee.substr(1)}if(this._s.Bt)this.ar(t)
else switch(this.Is){case Me.IN_HEAD:case Me.IN_HEAD_NO_SCRIPT:case Me.AFTER_HEAD:case Me.TEXT:case Me.IN_COLUMN_GROUP:case Me.IN_SELECT:case Me.IN_SELECT_IN_TABLE:case Me.IN_FRAMESET:case Me.AFTER_FRAMESET:this.ar(t)
break
case Me.IN_BODY:case Me.IN_CAPTION:case Me.IN_CELL:case Me.IN_TEMPLATE:case Me.AFTER_BODY:case Me.AFTER_AFTER_BODY:case Me.AFTER_AFTER_FRAMESET:ti(this,t)
break
case Me.IN_TABLE:case Me.IN_TABLE_BODY:case Me.IN_ROW:Ai(this,t)
break
case Me.IN_TABLE_TEXT:fi(this,t)}}}function Oe(t,e){let i=t.Qs.Wo(e.tagName)
return i?t.qs.contains(i.element)?t.qs.Io(e.Ut)||(i=null):(t.Qs.removeEntry(i),i=null):ai(t,e),i}function Ne(t,e){let i=null,o=t.qs.Vi
for(;o>=0;o--){const s=t.qs.items[o]
if(s===e.element)break
t.wr(s,t.qs.Pi[o])&&(i=s)}return i||(t.qs.co(Math.max(o,0)),t.Qs.removeEntry(e)),i}function qe(t,e,i){let o=e,s=t.qs.yo(e)
for(let r=0,n=s;n!==i;r++,n=s){s=t.qs.yo(n)
const i=t.Qs.zo(n),a=i&&r>=3
!i||a?(a&&t.Qs.removeEntry(i),t.qs.remove(n)):(n=je(t,i),o===e&&(t.Qs._o=i),t.Li.Vo(o),t.Li.appendChild(n,o),o=n)}return o}function je(t,e){const i=t.Li.io(e.element),o=t.Li.createElement(e.token.tagName,i,e.token.rt)
return t.qs.replace(e.element,o),e.element=o,o}function Ge(t,e,i){const o=qt(t.Li.Oo(e))
if(t.gr(o))t.er(i)
else{const s=t.Li.io(e)
o===Mt.TEMPLATE&&s===kt.HTML&&(e=t.Li.Ji(e)),t.Li.appendChild(e,i)}}function He(t,e,i){const o=t.Li.io(i.element),{token:s}=i,r=t.Li.createElement(s.tagName,o,s.rt)
t.zs(e,r),t.Li.appendChild(e,r),t.Qs.Ko(r,s),t.Qs.removeEntry(i),t.qs.remove(i.element),t.qs.no(e,r,s.Ut)}function Ke(t,e){for(let i=0;i<8;i++){const i=Oe(t,e)
if(!i)break
const o=Ne(t,i)
if(!o)break
t.Qs._o=i
const s=qe(t,o,i.element),r=t.qs.yo(i.element)
t.Li.Vo(s),r&&Ge(t,r,s),He(t,o,i)}}function Ye(t,e){t.nr(e,t.qs.Zi)}function We(t,e){if(t.stopped=!0,e.location){const i=t.ks?0:2
for(let o=t.qs.Vi;o>=i;o--)t.Zs(t.qs.items[o],e)
if(!t.ks&&t.qs.Vi>=0){const i=t.qs.items[0],o=t.Li.ws(i)
if(o&&!o.endTag&&(t.Zs(i,e),t.qs.Vi>=1)){const i=t.qs.items[1],o=t.Li.ws(i)
o&&!o.endTag&&t.Zs(i,e)}}}}function ze(t,e){t.J(e,rt.missingDoctype,!0),t.Li.Lo(t.document,Bt.QUIRKS),t.Is=Me.BEFORE_HTML,t.hr(e)}function Ze(t,e){t.Hs(),t.Is=Me.BEFORE_HEAD,t.hr(e)}function Ue(t,e){t.sr(St.HEAD,Mt.HEAD),t.Bs=t.qs.current,t.Is=Me.IN_HEAD,t.hr(e)}function Je(t,e){switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.BASE:case Mt.BASEFONT:case Mt.BGSOUND:case Mt.LINK:case Mt.META:t.ir(e,kt.HTML),e.Lt=!0
break
case Mt.TITLE:t.Js(e,zt.RCDATA)
break
case Mt.NOSCRIPT:t.options.ys?t.Js(e,zt.RAWTEXT):(t.Ls(e,kt.HTML),t.Is=Me.IN_HEAD_NO_SCRIPT)
break
case Mt.NOFRAMES:case Mt.STYLE:t.Js(e,zt.RAWTEXT)
break
case Mt.SCRIPT:t.Js(e,zt.SCRIPT_DATA)
break
case Mt.TEMPLATE:t.rr(e),t.Qs.Go(),t.Rs=!1,t.Is=Me.IN_TEMPLATE,t.Ds.unshift(Me.IN_TEMPLATE)
break
case Mt.HEAD:t.J(e,rt.misplacedStartTagForHeadElement)
break
default:Pe(t,e)}}function Le(t,e){t.qs.Xi>0?(t.qs.Ro(),t.qs.$i!==Mt.TEMPLATE&&t.J(e,rt.closingOfElementWithOpenChildElements),t.qs.ao(Mt.TEMPLATE),t.Qs.Yo(),t.Ds.shift(),t.Ks()):t.J(e,rt.endTagWithoutMatchingOpenElement)}function Pe(t,e){t.qs.pop(),t.Is=Me.AFTER_HEAD,t.hr(e)}function Ve(t,e){const i=e.type===at.EOF?rt.openElementsLeftAfterEof:rt.disallowedContentInNoscriptInHead
t.J(e,i),t.qs.pop(),t.Is=Me.IN_HEAD,t.hr(e)}function Xe(t,e){t.sr(St.BODY,Mt.BODY),t.Is=Me.IN_BODY,$e(t,e)}function $e(t,e){switch(e.type){case at.CHARACTER:ei(t,e)
break
case at.WHITESPACE_CHARACTER:ti(t,e)
break
case at.COMMENT:Ye(t,e)
break
case at.START_TAG:ni(t,e)
break
case at.END_TAG:ci(t,e)
break
case at.EOF:li(t,e)}}function ti(t,e){t.ur(),t.ar(e)}function ei(t,e){t.ur(),t.ar(e),t.Rs=!1}function ii(t,e){t.ur(),t.ir(e,kt.HTML),t.Rs=!1,e.Lt=!0}function oi(t){const e=At(t,It.TYPE)
return null!=e&&"hidden"===e.toLowerCase()}function si(t,e){t.Js(e,zt.RAWTEXT)}function ri(t,e){t.ur(),t.Ls(e,kt.HTML)}function ni(t,e){switch(e.Ut){case Mt.I:case Mt.S:case Mt.B:case Mt.U:case Mt.EM:case Mt.TT:case Mt.BIG:case Mt.CODE:case Mt.FONT:case Mt.SMALL:case Mt.STRIKE:case Mt.STRONG:((t,e)=>{t.ur(),t.Ls(e,kt.HTML),t.Qs.Ho(t.qs.current,e)})(t,e)
break
case Mt.A:((t,e)=>{const i=t.Qs.Wo(St.A)
i&&(Ke(t,e),t.qs.remove(i.element),t.Qs.removeEntry(i)),t.ur(),t.Ls(e,kt.HTML),t.Qs.Ho(t.qs.current,e)})(t,e)
break
case Mt.H1:case Mt.H2:case Mt.H3:case Mt.H4:case Mt.H5:case Mt.H6:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),void 0!==t.qs.$i&&Ht.has(t.qs.$i)&&t.qs.pop(),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.P:case Mt.DL:case Mt.OL:case Mt.UL:case Mt.DIV:case Mt.DIR:case Mt.NAV:case Mt.MAIN:case Mt.MENU:case Mt.ASIDE:case Mt.CENTER:case Mt.FIGURE:case Mt.FOOTER:case Mt.HEADER:case Mt.HGROUP:case Mt.DIALOG:case Mt.DETAILS:case Mt.ADDRESS:case Mt.ARTICLE:case Mt.SEARCH:case Mt.SECTION:case Mt.SUMMARY:case Mt.FIELDSET:case Mt.BLOCKQUOTE:case Mt.FIGCAPTION:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.LI:case Mt.DD:case Mt.DT:((t,e)=>{t.Rs=!1
const i=e.Ut
for(let o=t.qs.Vi;o>=0;o--){const e=t.qs.Pi[o]
if(i===Mt.LI&&e===Mt.LI||(i===Mt.DD||i===Mt.DT)&&(e===Mt.DD||e===Mt.DT)){t.qs.Fo(e),t.qs.ao(e)
break}if(e!==Mt.ADDRESS&&e!==Mt.DIV&&e!==Mt.P&&t.wr(t.qs.items[o],e))break}t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.BR:case Mt.IMG:case Mt.WBR:case Mt.AREA:case Mt.EMBED:case Mt.KEYGEN:ii(t,e)
break
case Mt.HR:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),t.ir(e,kt.HTML),t.Rs=!1,e.Lt=!0})(t,e)
break
case Mt.RB:case Mt.RTC:((t,e)=>{t.qs.Io(Mt.RUBY)&&t.qs.To(),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.RT:case Mt.RP:((t,e)=>{t.qs.Io(Mt.RUBY)&&t.qs.Fo(Mt.RTC),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.PRE:case Mt.LISTING:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML),t.R=!0,t.Rs=!1})(t,e)
break
case Mt.XMP:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),t.ur(),t.Rs=!1,t.Js(e,zt.RAWTEXT)})(t,e)
break
case Mt.SVG:((t,e)=>{t.ur(),Se(e),De(e),e.Jt?t.ir(e,kt.SVG):t.Ls(e,kt.SVG),e.Lt=!0})(t,e)
break
case Mt.HTML:((t,e)=>{0===t.qs.Xi&&t.Li.es(t.qs.items[0],e.rt)})(t,e)
break
case Mt.BASE:case Mt.LINK:case Mt.META:case Mt.STYLE:case Mt.TITLE:case Mt.SCRIPT:case Mt.BGSOUND:case Mt.BASEFONT:case Mt.TEMPLATE:Je(t,e)
break
case Mt.BODY:((t,e)=>{const i=t.qs.vo()
i&&0===t.qs.Xi&&(t.Rs=!1,t.Li.es(i,e.rt))})(t,e)
break
case Mt.FORM:((t,e)=>{const i=t.qs.Xi>0
t.xs&&!i||(t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML),i||(t.xs=t.qs.current))})(t,e)
break
case Mt.NOBR:((t,e)=>{t.ur(),t.qs.Io(Mt.NOBR)&&(Ke(t,e),t.ur()),t.Ls(e,kt.HTML),t.Qs.Ho(t.qs.current,e)})(t,e)
break
case Mt.MATH:((t,e)=>{t.ur(),xe(e),De(e),e.Jt?t.ir(e,kt.MATHML):t.Ls(e,kt.MATHML),e.Lt=!0})(t,e)
break
case Mt.TABLE:((t,e)=>{t.Li.Po(t.document)!==Bt.QUIRKS&&t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML),t.Rs=!1,t.Is=Me.IN_TABLE})(t,e)
break
case Mt.INPUT:((t,e)=>{t.ur(),t.ir(e,kt.HTML),oi(e)||(t.Rs=!1),e.Lt=!0})(t,e)
break
case Mt.PARAM:case Mt.TRACK:case Mt.SOURCE:((t,e)=>{t.ir(e,kt.HTML),e.Lt=!0})(t,e)
break
case Mt.IMAGE:((t,e)=>{e.tagName=St.IMG,e.Ut=Mt.IMG,ii(t,e)})(t,e)
break
case Mt.BUTTON:((t,e)=>{t.qs.Io(Mt.BUTTON)&&(t.qs.To(),t.qs.ao(Mt.BUTTON)),t.ur(),t.Ls(e,kt.HTML),t.Rs=!1})(t,e)
break
case Mt.APPLET:case Mt.OBJECT:case Mt.MARQUEE:((t,e)=>{t.ur(),t.Ls(e,kt.HTML),t.Qs.Go(),t.Rs=!1})(t,e)
break
case Mt.IFRAME:((t,e)=>{t.Rs=!1,t.Js(e,zt.RAWTEXT)})(t,e)
break
case Mt.SELECT:((t,e)=>{t.ur(),t.Ls(e,kt.HTML),t.Rs=!1,t.Is=t.Is===Me.IN_TABLE||t.Is===Me.IN_CAPTION||t.Is===Me.IN_TABLE_BODY||t.Is===Me.IN_ROW||t.Is===Me.IN_CELL?Me.IN_SELECT_IN_TABLE:Me.IN_SELECT})(t,e)
break
case Mt.OPTION:case Mt.OPTGROUP:((t,e)=>{t.qs.$i===Mt.OPTION&&t.qs.pop(),t.ur(),t.Ls(e,kt.HTML)})(t,e)
break
case Mt.NOEMBED:case Mt.NOFRAMES:si(t,e)
break
case Mt.FRAMESET:((t,e)=>{const i=t.qs.vo()
t.Rs&&i&&(t.Li.Vo(i),t.qs.fo(),t.Ls(e,kt.HTML),t.Is=Me.IN_FRAMESET)})(t,e)
break
case Mt.TEXTAREA:((t,e)=>{t.Ls(e,kt.HTML),t.R=!0,t._s.state=zt.RCDATA,t.Es=t.Is,t.Rs=!1,t.Is=Me.TEXT})(t,e)
break
case Mt.NOSCRIPT:t.options.ys?si(t,e):ri(t,e)
break
case Mt.PLAINTEXT:((t,e)=>{t.qs.Bo(Mt.P)&&t.mr(),t.Ls(e,kt.HTML),t._s.state=zt.PLAINTEXT})(t,e)
break
case Mt.COL:case Mt.TH:case Mt.TD:case Mt.TR:case Mt.HEAD:case Mt.FRAME:case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:case Mt.CAPTION:case Mt.COLGROUP:break
default:ri(t,e)}}function ai(t,e){const i=e.tagName,o=e.Ut
for(let s=t.qs.Vi;s>0;s--){const e=t.qs.items[s],r=t.qs.Pi[s]
if(o===r&&(o!==Mt.UNKNOWN||t.Li.Oo(e)===i)){t.qs.Fo(o),t.qs.Vi>=s&&t.qs.co(s)
break}if(t.wr(e,r))break}}function ci(t,e){switch(e.Ut){case Mt.A:case Mt.B:case Mt.I:case Mt.S:case Mt.U:case Mt.EM:case Mt.TT:case Mt.BIG:case Mt.CODE:case Mt.FONT:case Mt.NOBR:case Mt.SMALL:case Mt.STRIKE:case Mt.STRONG:Ke(t,e)
break
case Mt.P:(t=>{t.qs.Bo(Mt.P)||t.sr(St.P,Mt.P),t.mr()})(t)
break
case Mt.DL:case Mt.UL:case Mt.OL:case Mt.DIR:case Mt.DIV:case Mt.NAV:case Mt.PRE:case Mt.MAIN:case Mt.MENU:case Mt.ASIDE:case Mt.BUTTON:case Mt.CENTER:case Mt.FIGURE:case Mt.FOOTER:case Mt.HEADER:case Mt.HGROUP:case Mt.DIALOG:case Mt.ADDRESS:case Mt.ARTICLE:case Mt.DETAILS:case Mt.SEARCH:case Mt.SECTION:case Mt.SUMMARY:case Mt.LISTING:case Mt.FIELDSET:case Mt.BLOCKQUOTE:case Mt.FIGCAPTION:((t,e)=>{const i=e.Ut
t.qs.Io(i)&&(t.qs.To(),t.qs.ao(i))})(t,e)
break
case Mt.LI:(t=>{t.qs.Eo(Mt.LI)&&(t.qs.Fo(Mt.LI),t.qs.ao(Mt.LI))})(t)
break
case Mt.DD:case Mt.DT:((t,e)=>{const i=e.Ut
t.qs.Io(i)&&(t.qs.Fo(i),t.qs.ao(i))})(t,e)
break
case Mt.H1:case Mt.H2:case Mt.H3:case Mt.H4:case Mt.H5:case Mt.H6:(t=>{t.qs.xo()&&(t.qs.To(),t.qs.do())})(t)
break
case Mt.BR:(t=>{t.ur(),t.sr(St.BR,Mt.BR),t.qs.pop(),t.Rs=!1})(t)
break
case Mt.BODY:((t,e)=>{if(t.qs.Io(Mt.BODY)&&(t.Is=Me.AFTER_BODY,t.options.jt)){const i=t.qs.vo()
i&&t.Zs(i,e)}})(t,e)
break
case Mt.HTML:((t,e)=>{t.qs.Io(Mt.BODY)&&(t.Is=Me.AFTER_BODY,xi(t,e))})(t,e)
break
case Mt.FORM:(t=>{const e=t.qs.Xi>0,{xs:i}=t
e||(t.xs=null),(i||e)&&t.qs.Io(Mt.FORM)&&(t.qs.To(),e?t.qs.ao(Mt.FORM):i&&t.qs.remove(i))})(t)
break
case Mt.APPLET:case Mt.OBJECT:case Mt.MARQUEE:((t,e)=>{const i=e.Ut
t.qs.Io(i)&&(t.qs.To(),t.qs.ao(i),t.Qs.Yo())})(t,e)
break
case Mt.TEMPLATE:Le(t,e)
break
default:ai(t,e)}}function li(t,e){t.Ds.length>0?Bi(t,e):We(t,e)}function Ai(t,e){if(void 0!==t.qs.$i&&Fe.has(t.qs.$i))switch(t.Ms.length=0,t.Ts=!1,t.Es=t.Is,t.Is=Me.IN_TABLE_TEXT,e.type){case at.CHARACTER:bi(t,e)
break
case at.WHITESPACE_CHARACTER:fi(t,e)}else ui(t,e)}function hi(t,e){switch(e.Ut){case Mt.TD:case Mt.TH:case Mt.TR:((t,e)=>{t.qs.mo(),t.sr(St.TBODY,Mt.TBODY),t.Is=Me.IN_TABLE_BODY,vi(t,e)})(t,e)
break
case Mt.STYLE:case Mt.SCRIPT:case Mt.TEMPLATE:Je(t,e)
break
case Mt.COL:((t,e)=>{t.qs.mo(),t.sr(St.COLGROUP,Mt.COLGROUP),t.Is=Me.IN_COLUMN_GROUP,gi(t,e)})(t,e)
break
case Mt.FORM:((t,e)=>{t.xs||0!==t.qs.Xi||(t.Ls(e,kt.HTML),t.xs=t.qs.current,t.qs.pop())})(t,e)
break
case Mt.TABLE:((t,e)=>{t.qs.So(Mt.TABLE)&&(t.qs.ao(Mt.TABLE),t.Ks(),t.dr(e))})(t,e)
break
case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:((t,e)=>{t.qs.mo(),t.Ls(e,kt.HTML),t.Is=Me.IN_TABLE_BODY})(t,e)
break
case Mt.INPUT:((t,e)=>{oi(e)?t.ir(e,kt.HTML):ui(t,e),e.Lt=!0})(t,e)
break
case Mt.CAPTION:((t,e)=>{t.qs.mo(),t.Qs.Go(),t.Ls(e,kt.HTML),t.Is=Me.IN_CAPTION})(t,e)
break
case Mt.COLGROUP:((t,e)=>{t.qs.mo(),t.Ls(e,kt.HTML),t.Is=Me.IN_COLUMN_GROUP})(t,e)
break
default:ui(t,e)}}function di(t,e){switch(e.Ut){case Mt.TABLE:t.qs.So(Mt.TABLE)&&(t.qs.ao(Mt.TABLE),t.Ks())
break
case Mt.TEMPLATE:Le(t,e)
break
case Mt.BODY:case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.HTML:case Mt.TBODY:case Mt.TD:case Mt.TFOOT:case Mt.TH:case Mt.THEAD:case Mt.TR:break
default:ui(t,e)}}function ui(t,e){const i=t.Fs
t.Fs=!0,$e(t,e),t.Fs=i}function fi(t,e){t.Ms.push(e)}function bi(t,e){t.Ms.push(e),t.Ts=!0}function mi(t,e){let i=0
if(t.Ts)for(;i<t.Ms.length;i++)ui(t,t.Ms[i])
else for(;i<t.Ms.length;i++)t.ar(t.Ms[i])
t.Is=t.Es,t.hr(e)}const pi=new Set([Mt.CAPTION,Mt.COL,Mt.COLGROUP,Mt.TBODY,Mt.TD,Mt.TFOOT,Mt.TH,Mt.THEAD,Mt.TR])
function gi(t,e){switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.COL:t.ir(e,kt.HTML),e.Lt=!0
break
case Mt.TEMPLATE:Je(t,e)
break
default:wi(t,e)}}function wi(t,e){t.qs.$i===Mt.COLGROUP&&(t.qs.pop(),t.Is=Me.IN_TABLE,t.hr(e))}function vi(t,e){switch(e.Ut){case Mt.TR:t.qs.po(),t.Ls(e,kt.HTML),t.Is=Me.IN_ROW
break
case Mt.TH:case Mt.TD:t.qs.po(),t.sr(St.TR,Mt.TR),t.Is=Me.IN_ROW,ki(t,e)
break
case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:t.qs.Do()&&(t.qs.po(),t.qs.pop(),t.Is=Me.IN_TABLE,hi(t,e))
break
default:hi(t,e)}}function yi(t,e){const i=e.Ut
switch(e.Ut){case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:t.qs.So(i)&&(t.qs.po(),t.qs.pop(),t.Is=Me.IN_TABLE)
break
case Mt.TABLE:t.qs.Do()&&(t.qs.po(),t.qs.pop(),t.Is=Me.IN_TABLE,di(t,e))
break
case Mt.BODY:case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.HTML:case Mt.TD:case Mt.TH:case Mt.TR:break
default:di(t,e)}}function ki(t,e){switch(e.Ut){case Mt.TH:case Mt.TD:t.qs.wo(),t.Ls(e,kt.HTML),t.Is=Me.IN_CELL,t.Qs.Go()
break
case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:case Mt.TR:t.qs.So(Mt.TR)&&(t.qs.wo(),t.qs.pop(),t.Is=Me.IN_TABLE_BODY,vi(t,e))
break
default:hi(t,e)}}function Ci(t,e){switch(e.Ut){case Mt.TR:t.qs.So(Mt.TR)&&(t.qs.wo(),t.qs.pop(),t.Is=Me.IN_TABLE_BODY)
break
case Mt.TABLE:t.qs.So(Mt.TR)&&(t.qs.wo(),t.qs.pop(),t.Is=Me.IN_TABLE_BODY,yi(t,e))
break
case Mt.TBODY:case Mt.TFOOT:case Mt.THEAD:(t.qs.So(e.Ut)||t.qs.So(Mt.TR))&&(t.qs.wo(),t.qs.pop(),t.Is=Me.IN_TABLE_BODY,yi(t,e))
break
case Mt.BODY:case Mt.CAPTION:case Mt.COL:case Mt.COLGROUP:case Mt.HTML:case Mt.TD:case Mt.TH:break
default:di(t,e)}}function Ii(t,e){switch(e.Ut){case Mt.HTML:ni(t,e)
break
case Mt.OPTION:t.qs.$i===Mt.OPTION&&t.qs.pop(),t.Ls(e,kt.HTML)
break
case Mt.OPTGROUP:t.qs.$i===Mt.OPTION&&t.qs.pop(),t.qs.$i===Mt.OPTGROUP&&t.qs.pop(),t.Ls(e,kt.HTML)
break
case Mt.HR:t.qs.$i===Mt.OPTION&&t.qs.pop(),t.qs.$i===Mt.OPTGROUP&&t.qs.pop(),t.ir(e,kt.HTML),e.Lt=!0
break
case Mt.INPUT:case Mt.KEYGEN:case Mt.TEXTAREA:case Mt.SELECT:t.qs.Mo(Mt.SELECT)&&(t.qs.ao(Mt.SELECT),t.Ks(),e.Ut!==Mt.SELECT&&t.dr(e))
break
case Mt.SCRIPT:case Mt.TEMPLATE:Je(t,e)}}function Ei(t,e){switch(e.Ut){case Mt.OPTGROUP:t.qs.Vi>0&&t.qs.$i===Mt.OPTION&&t.qs.Pi[t.qs.Vi-1]===Mt.OPTGROUP&&t.qs.pop(),t.qs.$i===Mt.OPTGROUP&&t.qs.pop()
break
case Mt.OPTION:t.qs.$i===Mt.OPTION&&t.qs.pop()
break
case Mt.SELECT:t.qs.Mo(Mt.SELECT)&&(t.qs.ao(Mt.SELECT),t.Ks())
break
case Mt.TEMPLATE:Le(t,e)}}function Bi(t,e){t.qs.Xi>0?(t.qs.ao(Mt.TEMPLATE),t.Qs.Yo(),t.Ds.shift(),t.Ks(),t.ge(e)):We(t,e)}function xi(t,e){var i
if(e.Ut===Mt.HTML){if(t.ks||(t.Is=Me.AFTER_AFTER_BODY),t.options.jt&&t.qs.Pi[0]===Mt.HTML){t.Zs(t.qs.items[0],e)
const o=t.qs.items[1]
o&&!(null===(i=t.Li.ws(o))||void 0===i?void 0:i.endTag)&&t.Zs(o,e)}}else Si(t,e)}function Si(t,e){t.Is=Me.IN_BODY,$e(t,e)}function Di(t,e){t.Is=Me.IN_BODY,$e(t,e)}function Mi(t){for(;t.Li.io(t.qs.current)!==kt.HTML&&void 0!==t.qs.$i&&!t.Us(t.qs.$i,t.qs.current);)t.qs.pop()}function Ti(t,e){return i=>{let o,s=0,r=""
for(;o=t.exec(i);)s!==o.index&&(r+=i.substring(s,o.index)),r+=e.get(o[0].charCodeAt(0)),s=o.index+1
return r+i.substring(s)}}const Ri=Ti(/["&\u00A0]/g,new Map([[34,"&quot;"],[38,"&amp;"],[160,"&nbsp;"]])),Fi=Ti(/[&<>\u00A0]/g,new Map([[38,"&amp;"],[60,"&lt;"],[62,"&gt;"],[160,"&nbsp;"]])),_i=new Set([St.AREA,St.BASE,St.BASEFONT,St.BGSOUND,St.BR,St.COL,St.EMBED,St.FRAME,St.HR,St.IMG,St.INPUT,St.KEYGEN,St.LINK,St.META,St.PARAM,St.SOURCE,St.TRACK,St.WBR])
function Qi(t,e){return e.Li.bs(t)&&e.Li.io(t)===kt.HTML&&_i.has(e.Li.Oo(t))}const Oi={Li:be,ys:!0}
function Ni(t,e){const i={...Oi,...e}
return Qi(t,i)?"":qi(t,i)}function qi(t,e){let i=""
const o=e.Li.bs(t)&&e.Li.Oo(t)===St.TEMPLATE&&e.Li.io(t)===kt.HTML?e.Li.Ji(t):t,s=e.Li.rs(o)
if(s)for(const r of s)i+=ji(r,e)
return i}function ji(t,e){return e.Li.bs(t)?((t,e)=>{const i=e.Li.Oo(t)
return`<${i}${((t,{Li:e})=>{let i=""
for(const o of e.No(t)){if(i+=" ",o.namespace)switch(o.namespace){case kt.XML:i+="xml:"+o.name
break
case kt.XMLNS:"xmlns"!==o.name&&(i+="xmlns:"),i+=o.name
break
case kt.XLINK:i+="xlink:"+o.name
break
default:i+=`${o.prefix}:${o.name}`}else i+=o.name
i+=`="${Ri(o.value)}"`}return i})(t,e)}>${Qi(t,e)?"":`${qi(t,e)}</${i}>`}`})(t,e):e.Li.$o(t)?((t,e)=>{const{Li:i}=e,o=i.cs(t),s=i.ns(t),r=s&&i.bs(s)&&i.Oo(s)
return r&&i.io(s)===kt.HTML&&(n=r,a=e.ys,Kt.has(n)||a&&n===St.NOSCRIPT)?o:Fi(o)
var n,a})(t,e):e.Li.us(t)?((t,{Li:e})=>`\x3c!--${e.ls(t)}--\x3e`)(t,e):e.Li.fs(t)?((t,{Li:e})=>`<!DOCTYPE ${e.As(t)}>`)(t,e):""}function Gi(t,e,i){return Object.freeze({column:e,line:t,offset:i})}function Hi(t){return Object.freeze({end:Gi(t.Y,t.Z,t.endOffset),start:Gi(t.K,t.W,t.startOffset)})}function Ki(t){return Object.freeze({...Hi(t),...void 0===t.endTag?{}:{endTag:Hi(t.endTag)},...void 0===t.startTag?{}:{startTag:Hi(t.startTag)}})}function Yi(t){return Hi(t)}function Wi(t){return Object.freeze({children:Object.freeze(t.childNodes.map(t=>(t=>be.fs(t)?(t=>{const e=t.gs
return Object.freeze({name:t.name,publicId:t.publicId,...null==e?{}:{source:Hi(e)},systemId:t.systemId,type:"doctype"})})(t):Zi(t))(t))),type:"document"})}function zi(t){return Object.freeze({children:Object.freeze(t.childNodes.map(t=>Zi(t))),type:"document-fragment"})}function Zi(t){if(be.bs(t))return(t=>{const e=t.gs,i=(t=>t.namespaceURI===kt.HTML&&"template"===t.tagName&&"content"in t)(t)?t.content.childNodes:t.childNodes
return Object.freeze({attributes:Object.freeze(t.rt.map(t=>((t,e)=>{const i=((t,e,i)=>{const o=t?.rt
if(void 0===o)return
const s=o[void 0===i?e:`${i}:${e}`]??o[e]
return void 0===s?void 0:Hi(s)})(e,t.name,t.prefix)
return Object.freeze({name:t.name,...void 0===t.namespace?{}:{namespace:t.namespace},...void 0===t.prefix?{}:{prefix:t.prefix},...void 0===i?{}:{source:i},value:t.value})})(t,e))),children:Object.freeze(i.map(t=>Zi(t))),namespace:Ui(t.namespaceURI),...null==e?{}:{source:Ki(e)},tagName:t.tagName,type:"element"})})(t)
if(be.$o(t))return(t=>{const e=t.gs
return Object.freeze({...null==e?{}:{source:Hi(e)},type:"text",value:t.value})})(t)
if(be.us(t))return(t=>{const e=t.gs
return Object.freeze({...null==e?{}:{source:Hi(e)},type:"comment",value:t.data})})(t)
throw Error(`Unexpected document type node outside a complete document: "${t.name}".`)}function Ui(t){switch(t){case kt.HTML:return"html"
case kt.SVG:return"svg"
case kt.MATHML:return"mathml"
default:throw Error(`Unsupported element namespace "${t}".`)}}function Ji(t){return Object.freeze({code:t.code,message:`HTML parse error: ${e=t.code,e.replaceAll("-"," ")}.`,severity:"error",source:Yi(t)})
var e}function Li(t,e){switch(e.type){case"element":return void((t,e)=>{const i=be.createElement(e.tagName,(t=>{switch(t){case"html":return kt.HTML
case"svg":return kt.SVG
case"mathml":return kt.MATHML
default:return Pi(t)}})(e.namespace),e.attributes.map(t=>({name:t.name,...void 0===t.namespace?{}:{namespace:t.namespace},...void 0===t.prefix?{}:{prefix:t.prefix},value:t.value})))
if(be.appendChild(t,i),"html"===e.namespace&&"template"===e.tagName){const t=i,o=be.createDocumentFragment()
be.Uo(t,o)
for(const i of e.children)Li(o,i)
return}for(const o of e.children)Li(i,o)})(t,e)
case"text":return void be.appendChild(t,be.createTextNode(e.value))
case"comment":return void be.appendChild(t,be.Zo(e.value))
default:Pi(e)}}function Pi(t){throw Error(`Unsupported HTML tree value: ${t+""}.`)}function Vi(t){const e=[],i=new Set(["script","style","textarea","title"]),o=t.toLowerCase()
let s,r=0
for(;r<t.length;){if(void 0!==s){const i=$i(o,s,r)
if(i<0){e.push(t.slice(r))
break}e.push(t.slice(r,i)),r=i,s=void 0
continue}if(t.startsWith("\x3c!--",r)){const i=t.indexOf("--\x3e",r+4),o=i<0?t.length:i+3
e.push(t.slice(r,o)),r=o
continue}if("<"!==t[r]){const i=t.indexOf("<",r),o=i<0?t.length:i
e.push(t.slice(r,o)),r=o
continue}const n=Xi(t,r+1)
if(n<0){e.push(t.slice(r))
break}const a=t.slice(r,n+1),c=/^<([A-Za-z][\w:-]*)([\s\S]*)>$/u.exec(a)
if(null===c){e.push(a),r=n+1
continue}const l=c[1]?.toLowerCase(),A=c[2]??""
if("br"!==l||/^\s*\//u.test(A))e.push(a)
else{const t=A.trim()
e.push(0===t.length?"<br />":`<br ${t} />`)}void 0!==l&&i.has(l)&&!/^\s*\//u.test(A)&&(s=l),r=n+1}return e.join("")}function Xi(t,e){let i
for(let o=e;o<t.length;o+=1){const e=t[o]
if(void 0!==i)e===i&&(i=void 0)
else if('"'===e||"'"===e)i=e
else if(">"===e)return o}return-1}function $i(t,e,i){const o="</"+e
let s=i
for(;;){const e=t.indexOf(o,s)
if(e<0)return-1
const i=t[e+o.length]
if(">"===i||"/"===i||void 0===i||/\s/u.test(i))return e
s=e+o.length}}const to=new class{parseDocument(t){const e=[],i=(o=t,s={L:t=>e.push(Ji(t)),jt:!0},Qe.parse(o,s))
var o,s
return Object.freeze({diagnostics:Object.freeze(e),document:Wi(i)})}parseFragment(t){const e=[],i=((t,e,i)=>{"string"==typeof t&&(i=e,e=t,t=null)
const o=Qe.js(t,i)
return o._s.write(e,!0),o.Ws()})(t,{L:t=>e.push(Ji(t)),jt:!0})
return Object.freeze({diagnostics:Object.freeze(e),document:zi(i)})}},eo=new class{serializeDocument(t){return Vi(Ni((t=>{const e=be.createDocument()
for(const i of t.children)"doctype"===i.type?be.Jo(e,i.name,i.publicId,i.systemId):Li(e,i)
return e})(t)))}serializeFragment(t){return Vi(Ni((t=>{const e=be.createDocumentFragment()
for(const i of t.children)Li(e,i)
return e})(t)))}}
function io(t){return to.parseFragment(t)}function oo(t){return eo.serializeFragment(t)}const so=J("soeditor.projection-coordinator")
class ro extends Error{constructor(){super("The projection coordinator has been destroyed."),this.name="ProjectionCoordinatorDestroyedError"}}class no extends Error{constructor(t){super(`Projection "${t}" is already attached.`),this.name="ProjectionAlreadyAttachedError"}}class ao extends Error{constructor(t){super(`Projection "${t}" is not attached.`),this.name="ProjectionNotAttachedError"}}class co extends Error{constructor(t,e){super(`Projection "${t}" is incompatible with "${e}" documents.`),this.name="IncompatibleProjectionError"}}class lo extends Error{constructor(t){super(t),this.name="InvalidProjectionTransitionError"}}const Ao=Object.freeze(["visual","wysiwyg","source","markdown","preview"])
function ho(t){return"markdown"===t?"markdown":"visual"}function uo(t,e){return"html"===e?"visual"===t||"wysiwyg"===t||"source"===t:"markdown"===t}function fo(t,e){if(1!==e.length)throw new TypeError(`Command "${t}" requires one projection ID.`)
return bo(e[0]),e[0]}function bo(t){if(!Ao.some(e=>e===t))throw new TypeError(`Unknown projection ID "${t+""}".`)}const mo=J("soeditor.structured-editing-registry")
class po extends Error{constructor(t,e){super(`Structured editing contribution ${t} "${e}" is already registered.`),this.name="StructuredEditingContributionAlreadyRegisteredError"}}class go extends Error{constructor(){super("Structured editing contributions cannot change after an editing engine has attached."),this.name="StructuredEditingRegistrySealedError"}}const wo=new WeakMap
class vo extends U{static id="structured-editing"
#y
init(){const t={kr:new Map,Cr:new Map,destroyed:!1,nodeViews:new Map,Ir:!1},e=Object.freeze({registerBlock:e=>((t,e)=>{if(ko(t),t.Ir)throw new go
const i=(t=>{if("object"!=typeof t||null===t)throw new TypeError("A structured block conversion is required.")
if(yo("contribution ID",t.id),yo("structured node type",t.type),"atomic"!==t.behavior&&"readonly"!==t.behavior)throw new TypeError(`Structured editing contribution "${t.id}" requires behavior "atomic" or "readonly".`)
if("function"!=typeof t.matches||"function"!=typeof t.fromHtml||"function"!=typeof t.toHtml)throw new TypeError(`Structured editing contribution "${t.id}" requires matches, fromHtml, and toHtml functions.`)
return Object.freeze({...t})})(e)
if(t.kr.has(i.id))throw new po("ID",i.id)
if(t.Cr.has(i.type))throw new po("node type",i.type)
t.kr.set(i.id,i),t.Cr.set(i.type,i)
let o=!0
return()=>{o&&(t.Ir||t.kr.get(i.id)===i&&(t.kr.delete(i.id),t.Cr.delete(i.type)),o=!1)}})(t,e),registerNodeView:(e,i)=>((t,e,i)=>{if(ko(t),t.Ir)throw new go
if(yo("structured node type",e),!t.Cr.has(e))throw new TypeError(`Structured node view "${e}" requires a registered block conversion.`)
if("function"!=typeof i)throw new TypeError(`Structured node view "${e}" requires a factory.`)
if(t.nodeViews.has(e))throw new po("node view",e)
t.nodeViews.set(e,i)
let o=!0
return()=>{o&&(t.Ir||t.nodeViews.get(e)!==i||t.nodeViews.delete(e),o=!1)}})(t,e,i)})
wo.set(e,t),this.#y=e,this.editor.services.register(mo,e)}destroy(){const t=this.#y
if(void 0!==t){const o=(t=>{const e=wo.get(t)
if(void 0===e)throw new TypeError("The structured editing registry was not created by SoEditor.")
return e})(t)
o.destroyed=!0,o.kr.clear(),o.Cr.clear(),o.nodeViews.clear()
try{this.editor.services.tryGet(mo)===t&&this.editor.services.unregister(mo)}catch(i){if(!(i instanceof e))throw i}}this.#y=void 0}}function yo(t,e){if("string"!=typeof e||0===e.trim().length)throw new TypeError(`A structured editing ${t} must not be empty.`)}function ko(t){if(t.destroyed)throw Error("The structured editing registry has been destroyed.")}function Co(t){return Object.freeze({anchor:Object.freeze({...t.anchor}),focus:Object.freeze({...t.focus})})}const Io="soeditor.history.group",Eo="soeditor.history.replay"
function Bo(t){if("object"!=typeof t||null===t)return
const e=t,i=xo(e.anchor),o=xo(e.focus)
return void 0===i||void 0===o?void 0:Co({anchor:i,focus:o})}function xo(t){if("object"!=typeof t||null===t)return
const e=t
return"number"==typeof e.block&&Number.isInteger(e.block)&&e.block>=0&&"number"==typeof e.offset&&Number.isInteger(e.offset)&&e.offset>=0?{block:e.block,offset:e.offset}:void 0}class So extends Error{diagnostic
constructor(t){super(t.message),this.name="PasteRejectedError",this.diagnostic=t}}const Do=J("soeditor.paste-pipeline"),Mo="application/x-soeditor-html"
class To extends U{static id="paste-pipeline"
#k=new Set
#C=new Map
#I=!1
#E=1e6
#B=1e6
#x
#S="semantic"
#D
#M
init(){this.#S=(t=>{if(void 0===t)return"semantic"
if("preserve"===t||"semantic"===t||"plain-text"===t)return t
throw new TypeError('cms.paste.policy must be "preserve", "semantic", or "plain-text".')})(this.editor.config.get("cms.paste.policy")),this.#x=Ro(this.editor.config.get("cms.paste.officePolicy"),"cms.paste.officePolicy"),this.#M=Ro(this.editor.config.get("cms.paste.webPolicy"),"cms.paste.webPolicy"),this.#E=Fo(this.editor.config.get("cms.paste.maxInputCharacters"),1e6,"cms.paste.maxInputCharacters"),this.#B=Fo(this.editor.config.get("cms.paste.maxOutputCharacters"),1e6,"cms.paste.maxOutputCharacters")
const t={process:t=>this.#T(t),register:t=>this.#R(t),subscribe:t=>this.#F(t)}
this.#D=Object.freeze(t),this.editor.services.register(Do,this.#D)}destroy(){this.#I=!0,this.#k.clear(),this.#C.clear(),this.editor.services.tryGet(Do)===this.#D&&this.editor.services.unregister(Do),this.#D=void 0}#T(t){this.#g(),(t=>{if("object"!=typeof t||null===t||"string"!=typeof t.html||"string"!=typeof t.text||"paste"!==t.source&&"drop"!==t.source||!Array.isArray(t.types)||!t.types.every(t=>"string"==typeof t)||!Array.isArray(t.files)||!t.files.every(t=>"object"==typeof t&&null!==t&&"string"==typeof t.name&&"string"==typeof t.type&&Number.isFinite(t.size)&&t.size>=0)||void 0!==t.internalHtml&&"string"!=typeof t.internalHtml)throw new TypeError("Paste pipeline input is malformed.")})(t)
const e=(t=>t.files.length>0?"files":void 0!==t.internalHtml?"internal":t.types.includes(Mo)?"cross-editor":/docs-internal-guid|id="docs-internal-guid/iu.test(t.html)?"google-docs":/libreoffice|urn:org:documentfoundation/iu.test(t.html)?"libreoffice":/mso-|urn:schemas-microsoft-com:office|microsoft\s+(?:word|excel)/iu.test(t.html)?"office":t.html.length>0?"web":"plain-text")(t)
t.html.length+t.text.length+(t.internalHtml?.length??0)>this.#E&&this.#_({classification:e,code:"input-too-large",message:`Paste input exceeds ${this.#E+""} characters.`})
let i=Object.freeze({...t,classification:e,consumed:!1,policy:"internal"===e?"preserve":this.#Q(e)})
for(const r of[...this.#C.values()].sort((t,e)=>(e.priority??0)-(t.priority??0)||t.id.localeCompare(e.id)))try{const t=r.process(i)
if(void 0!==t&&(i=Object.freeze({...i,...void 0===t.html?{}:{html:t.html},...void 0===t.text?{}:{text:t.text},...void 0===t.policy?{}:{policy:t.policy},...void 0===t.consumed?{}:{consumed:t.consumed}})),i.consumed)break}catch(s){this.#_({classification:e,code:"processor-failed",message:`Paste processor "${r.id}" failed: ${_o(s)}`,processorId:r.id})}const o="internal"===e&&void 0!==t.internalHtml?t.internalHtml:i.html
return o.length+i.text.length>this.#B&&this.#_({classification:e,code:"output-too-large",message:`Paste output exceeds ${this.#B+""} characters.`}),Object.freeze({classification:e,consumed:i.consumed,html:o,policy:i.policy,text:i.text})}#R(t){if(this.#g(),"object"!=typeof t||null===t||!/^[a-z][a-z0-9.-]{0,95}$/u.test(t.id)||"function"!=typeof t.process||void 0!==t.priority&&!Number.isFinite(t.priority))throw new TypeError("A paste processor requires a valid id and process function.")
if(this.#C.has(t.id))throw Error(`Paste processor "${t.id}" is already registered.`)
this.#C.set(t.id,t)
let e=!0
return()=>{e&&(e=!1,this.#C.delete(t.id))}}#Q(t){return"office"===t||"google-docs"===t||"libreoffice"===t?this.#x??this.#S:"web"===t||"cross-editor"===t?this.#M??this.#S:this.#S}#F(t){return this.#g(),this.#k.add(t),()=>this.#k.delete(t)}#_(t){const e=Object.freeze({...t})
for(const i of[...this.#k])i(e)
throw new So(e)}#g(){if(this.#I)throw Error("The paste pipeline has been destroyed.")}}function Ro(t,e){if(void 0!==t&&"inherit"!==t){if("preserve"===t||"semantic"===t||"plain-text"===t)return t
throw new TypeError(e+' must be "inherit", "preserve", "semantic", or "plain-text".')}}function Fo(t,e,i){if(void 0===t)return e
if(!Number.isInteger(t)||Number(t)<1||Number(t)>5e6)throw new TypeError(i+" must be an integer from 1 to 5000000.")
return Number(t)}function _o(t){return t instanceof Error?t.message:t+""}const Qo=J("soeditor.visual-editing"),Oo=J("soeditor.nested-editing")
class No extends TypeError{constructor(t,e){super(`Command "${t}" ${e}`),this.name="RichTextArgumentError"}}class qo extends U{static requires=[vo]
register(t,e,i,o,s=()=>!0){this.editor.commands.register({id:t,...void 0===o?{}:{label:o},canExecute:({editor:e})=>{const i=Xo(e,t)
return!0===i?.canEdit()&&s(i)},execute:(i,...o)=>e(((t,e)=>{const i=Xo(t.editor,e)
if(void 0===i)throw Error(`Command "${e}" requires an editable rich-text selection.`)
return i})(i,t),o),...void 0===i?{}:{isActive:({editor:e})=>{const o=Xo(e,t)
return void 0!==o&&i(o)}}})}}class jo extends qo{Er(t,e){this.register(t,(i,o)=>{$o(t,o),i.toggleMark(e)},t=>t.isMarkActive(e),(t=>{switch(t){case"strong":return"Toggle bold"
case"em":return"Toggle italic"
case"u":return"Toggle underline"
case"s":return"Toggle strikethrough"
case"code":return"Toggle inline code"
case"sub":return"Toggle subscript"
case"sup":return"Toggle superscript"}})(e))}}class Go extends TypeError{constructor(t){super("Invalid CMS style configuration: "+t),this.name="SemanticStyleConfigurationError"}}class Ho extends qo{registerBlock(t,e){this.register(t,(i,o)=>{$o(t,o),i.setBlock(i.isBlockActive(e)?"p":e)},t=>t.isBlockActive(e),"blockquote"===e?"Toggle blockquote":"Toggle code block")}}class Ko extends qo{Br(t,e){const i="ol"===e?["decimal","decimal-leading-zero","lower-roman","upper-roman","lower-alpha","upper-alpha"]:["disc","circle","square"]
for(const o of i){const i=`${t}.${o}`
this.register(i,(t,s)=>{$o(i,s),Po(t.setListStyle,i)(e,o)},t=>t.isListStyleActive?.(e,o)??!1,"Set list style "+o,t=>void 0!==t.setListStyle&&!Yo(t))}this.register(t,(i,o)=>{$o(t,o),i.toggleList(e)},t=>t.isListActive(e),"ol"===e?"Toggle ordered list":"Toggle unordered list",t=>!Yo(t))}}function Yo(t){const e=t.getStructuredSelection?.("soeditor.table")
if("object"!=typeof e||null===e)return!1
const i=Reflect.get(e,"anchor"),o=Reflect.get(e,"focus")
return"object"==typeof i&&null!==i&&"object"==typeof o&&null!==o&&(Reflect.get(i,"row")!==Reflect.get(o,"row")||Reflect.get(i,"column")!==Reflect.get(o,"column"))}const Wo=J("soeditor.link-target-provider"),zo=Object.freeze([...["download","hreflang","type","id","class","lang","role","tabindex","aria-label","aria-describedby"].map(t=>Object.freeze({name:t})),Object.freeze({name:"referrerpolicy",values:Object.freeze(["no-referrer","no-referrer-when-downgrade","origin","origin-when-cross-origin","same-origin","strict-origin","strict-origin-when-cross-origin","unsafe-url"])}),Object.freeze({name:"dir",values:Object.freeze(["ltr","rtl","auto"])}),Object.freeze({name:"aria-current",values:Object.freeze(["page","step","location","date","time","true","false"])})])
function Zo(t,e,i){const o=t[e]
if("string"!=typeof o||0===o.length||o.length>128)throw new Go(`entry ${i+""} requires a bounded string "${e}".`)
return o}function Uo(t){return Object.freeze(t.map(({name:t,value:e})=>Object.freeze({name:t,value:e})))}function Jo(t,e){const i=Uo(e.attributes)
if("inline"===e.target)Po(t.applyInlineStyle,"style."+e.id)({attributes:i,tagName:e.element})
else if("block"===e.target)void 0!==e.element&&t.setBlock(e.element),Po(t.applyBlockAttributes,"style."+e.id)(i)
else{const o=t.getSelectedStructuredBlock(e.objectType)
if(void 0===o)return
t.setStructuredBlockAttributes(e.objectType,((t,e)=>{const i=new Set(e.map(({name:t})=>t))
return Object.freeze([...t.filter(({name:t})=>!i.has(t)),...e])})(o.attributes,i))}}function Lo(t,e){const i=Uo(e.attributes)
if("inline"===e.target)return t.isInlineStyleActive?.({attributes:i,tagName:e.element})??!1
if("block"===e.target)return(void 0===e.element||t.isBlockActive(e.element))&&(t.areBlockAttributesActive?.(i)??!1)
const o=t.getSelectedStructuredBlock(e.objectType)
return void 0!==o&&i.every(t=>o.attributes.some(e=>e.name===t.name&&e.value===t.value))}function Po(t,e){if(void 0===t)throw Error(`Command "${e}" requires the CMS formatting engine capability.`)
return t}function Vo(t,e){const i=t.editor.services.tryGet(Qo)
if(void 0===i)throw Error(`Command "${e}" requires an attached visual editing engine.`)
return i}function Xo(t,e){const i=t.services.tryGet(Oo)
if(void 0!==i){const t=i.getActive(e)
if(void 0!==t)return t
if(void 0!==i.getActive("*"))return}return t.services.tryGet(Qo)}function $o(t,e){if(0!==e.length)throw new No(t,"does not accept arguments.")}function ts(t,e){if(1!==e.length)throw new No(t,"requires exactly one argument.")
return e[0]}function es(t,e){const i=ts(t,e)
if("object"!=typeof i||null===i||Array.isArray(i))throw new No(t,"requires an options object.")
return i}function is(t,e){if("object"!=typeof t||null===t||"string"!=typeof t.href||void 0!==t.title&&("string"!=typeof t.title||t.title.length>512||ls(t.title))||void 0!==t.target&&"string"!=typeof t.target||void 0!==t.rel&&("string"!=typeof t.rel||t.rel.length>512)||void 0!==t.customAttributes&&!Array.isArray(t.customAttributes))throw new No("link.set","requires bounded string properties.")
const i=t.href.trim()
if(!cs(i,e))throw new No("link.set","requires a safe URL allowed by cms.links policy.")
const o=(t=>{if(void 0===t||0===t.trim().length)return
const e=t.trim()
if(!new Set(["_blank","_parent","_self","_top"]).has(e)&&!/^[A-Za-z][A-Za-z0-9_.:-]{0,127}$/u.test(e))throw new No("link.set","requires _self, _blank, _parent, _top, or a custom target name beginning with a letter.")
return e})(t.target),s=((t,e)=>{const i=(t??"").split(/\s+/u).filter(t=>t.length>0).map(t=>t.toLowerCase())
if(i.some(t=>!/^[a-z][a-z0-9.-]{0,63}$/u.test(t)))throw new No("link.set","contains an invalid rel token.")
"_blank"===e&&i.push("noopener","noreferrer")
const o=[...new Set(i)].sort().join(" ")
return 0===o.length?void 0:o})(t.rel,o),r=as(t.customAttributes,e)
return Object.freeze({href:i,...void 0===o?{}:{target:o},...void 0===s?{}:{rel:s},...void 0===t.title?{}:{title:t.title},...void 0===r?{}:{customAttributes:r}})}const os=new Set(["href","rel","target","title"]),ss=new Set(["is","nonce","srcdoc","style","xmlns"]),rs=new Set(["","no-referrer","no-referrer-when-downgrade","origin","origin-when-cross-origin","same-origin","strict-origin","strict-origin-when-cross-origin","unsafe-url"])
function ns(t,e,i){return Object.hasOwn(e,"customAttributes")?{customAttributes:as(e.customAttributes,i,t)}:{}}function as(t,e,i="link.set"){if(void 0===t)return
if(!Array.isArray(t)||t.length>32)throw new No(i,"customAttributes must be an array with at most 32 entries.")
const o=new Set
return Object.freeze(t.map((t,s)=>{if("object"!=typeof t||null===t||Array.isArray(t))throw new No(i,`customAttributes[${s+""}] must contain a name and value.`)
const r=t
if(Object.keys(r).some(t=>"name"!==t&&"value"!==t)||"string"!=typeof r.name||"string"!=typeof r.value)throw new No(i,`customAttributes[${s+""}] must contain only string name and value properties.`)
const n=r.name.trim().toLowerCase(),a=r.value
if(!/^[a-z][a-z0-9_.:-]{0,63}$/u.test(n))throw new No(i,`custom attribute name "${n}" is invalid.`)
if(os.has(n)||ss.has(n)||n.startsWith("on")||n.startsWith("data-soeditor-"))throw new No(i,`custom attribute name "${n}" is reserved or unsafe.`)
if(!zo.some(({name:t})=>t===n)&&!/^data-[a-z0-9_.:-]+$/u.test(n))throw new No(i,`custom attribute name "${n}" is not supported for links.`)
if(o.has(n))throw new No(i,`custom attribute name "${n}" is duplicated.`)
if(a.length>4096||ls(a))throw new No(i,`custom attribute "${n}" requires a bounded value without control characters.`)
return((t,e,i,o)=>{const s=i=>{throw new No(t,`custom attribute "${e}" ${i}.`)}
if("referrerpolicy"!==e||rs.has(i)||s("requires a standard referrer policy value"),"dir"!==e||["auto","ltr","rtl"].includes(i)||s("requires auto, ltr, or rtl"),"tabindex"===e){const t=Number(i);(!/^-?\d{1,5}$/u.test(i)||!Number.isInteger(t)||t<-32768||t>32767)&&s("requires an integer from -32768 to 32767")}if("id"!==e||0!==i.length&&!/\s/u.test(i)||s("requires a non-empty value without whitespace"),("lang"===e||"hreflang"===e)&&i.length>0&&!/^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/u.test(i)&&s("requires a valid language tag"),"type"===e&&i.length>0&&!/^[a-zA-Z0-9!#$&^_.+-]+\/[a-zA-Z0-9!#$&^_.+-]+(?:\s*;\s*[a-zA-Z0-9!#$&^_.+-]+=[^;\r\n]+)*$/u.test(i)&&s("requires a MIME type"),"aria-current"!==e||["page","step","location","date","time","true","false"].includes(i)||s("requires a standard aria-current value"),"role"!==e||/^[a-z][a-z0-9-]*(?:\s+[a-z][a-z0-9-]*)*$/u.test(i)||s("requires one or more lowercase role tokens"),"ping"===e){const t=i.trim().split(/\s+/u).filter(Boolean);(0===t.length||t.length>8||t.some(t=>!cs(t,o)))&&s("requires at most 8 safe URLs allowed by cms.links policy")}})(i,n,a,e),o.add(n),Object.freeze({name:n,value:a})}))}function cs(t,e){if(0===t.length||t.length>2048||ls(t)||t.includes("\\"))return!1
const i=/^([a-z][a-z0-9+.-]*):/iu.exec(t)?.[1]?.toLowerCase()
if(void 0!==i){if(!e.Sr.includes(i))return!1
if("http"===i||"https"===i)try{const e=new URL(t)
return e.protocol===i+":"&&e.hostname.length>0&&0===e.username.length&&0===e.password.length}catch{return!1}return!0}return e.Dr&&!t.startsWith("//")&&/^(?:#|\?|\/|\.\.?(?:\/|$)|[^\s:]+(?:\/[^\s]*)?)$/u.test(t)}function ls(t){return Array.from(t).some(t=>{const e=t.codePointAt(0)
return void 0!==e&&(e<32||127===e)})}function As(t,e){const i=t.trim(),o=/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(i)?"mailto:"+i:/^\+?[\d(). -]{7,32}$/u.test(i)?"tel:"+i.replace(/[().\s-]/gu,""):/^www\./iu.test(i)?"https://"+i:i
if(!cs(o,e))throw new No("link.auto","could not derive a safe link.")
return o}function hs(t,e,i){const o=Object.keys(e).find(t=>!i.includes(t))
if(void 0!==o)throw new No(t,`does not support option "${o}".`)}function ds(t,e,i){const o=e[i]
if("string"!=typeof o||0===o.length)throw new No(t,`requires a non-empty string "${i}".`)
return o}function us(t,e,i){const o={}
for(const s of i){const i=e[s]
if(void 0!==i&&"string"!=typeof i)throw new No(t,`requires string option "${s}" when provided.`)
"string"==typeof i&&(o[s]=i)}return o}function fs(t,e,i){return void 0===e[i]?void 0:((t,e,i)=>{const o=e[i]
if(!Number.isInteger(o)||Number(o)<=0)throw new No(t,`requires a positive integer "${i}".`)
return Number(o)})(t,e,i)}function bs(t,e){return Object.freeze({name:t,value:e})}function ms(t,e=[],i=[]){return Object.freeze({attributes:Object.freeze([...e]),children:Object.freeze([...i]),namespace:"html",tagName:t,type:"element"})}function ps(t){return oo(Object.freeze({children:Object.freeze([...t]),type:"document-fragment"}))}function gs(t,e){if(!t.canEdit()||void 0===t.applyInlineStyle)throw Error(`Command "${e}" requires an editable visual surface.`)
return t}function ws(t,e){if("string"!=typeof e)throw new No(t,"requires a CSS color string.")
const i=e.trim().toLowerCase()
if(0===i.length||i.length>80||!(/^#[\da-f]{3,8}$/u.test(i)||/^(?:rgb|hsl)a?\([\d.% ,+-]+\)$/u.test(i)||/^[a-z]+$/u.test(i)))throw new No(t,"received an unsafe CSS color.")
return i}const vs=new Set(["inherit","arial","courier new","georgia","lucida sans unicode","tahoma","times new roman","trebuchet ms","verdana","sans-serif","serif","monospace"])
function ys(t,e){const i="string"==typeof e?e.trim().toLowerCase():""
if(vs.has(i))return i
throw new No(t,"requires one of the supported font-family presets.")}function ks(t,e){const i="number"==typeof e&&Number.isFinite(e)?e+"px":"string"==typeof e?e.trim().toLowerCase():"",o=/^(\d+(?:\.\d+)?)px$/u.exec(i)
if(void 0!==o?.[1]){const t=Number(o[1])
if(t>=8&&t<=96)return t+"px"}const s=/^(\d+(?:\.\d+)?)(em|rem|%)$/u.exec(i)
if(void 0!==s?.[1]&&void 0!==s[2]){const t=Number(s[1])
if("%"===s[2]&&t>=50&&t<=400||"%"!==s[2]&&t>=.5&&t<=6)return`${t+""}${s[2]}`}if(["xx-small","x-small","small","medium","large","x-large","xx-large"].includes(i))return i
throw new No(t,"requires 8–96px, 0.5–6em/rem, 50–400%, or a standard size keyword.")}const Cs=new Set(["base","button","embed","form","iframe","input","link","meta","object","script","select","style","textarea"]),Is=new Set(["a","blockquote","br","caption","code","col","colgroup","div","em","h1","h2","h3","h4","h5","h6","hr","img","li","mark","ol","p","pre","s","small","span","strong","sub","sup","table","tbody","td","tfoot","th","thead","tr","u","ul"]),Es=new Set(["#root","colgroup","ol","table","tbody","tfoot","thead","tr","ul"])
class Bs extends U{static id="cms-paste"
static requires=[To]
#O
init(){const t=(t=>{if(void 0===t)return!1
if("boolean"!=typeof t)throw new TypeError("cms.paste.retainStyles must be boolean.")
return t})(this.editor.config.get("cms.paste.retainStyles"))
this.#O=this.editor.services.get(Do).register({id:"soeditor.cms.external-html",priority:0,process:e=>Ds(e,t)})}destroy(){this.#O?.(),this.#O=void 0}}function xs(t,e){return"trusted"===e?t:Ds({classification:"web",html:t,policy:"strict"===e?"semantic":"preserve",text:""},"balanced"===e)?.html??t}function Ss(t){if("balanced"===t||"strict"===t||"trusted"===t)return t
throw new TypeError('HTML cleanup profile must be "strict", "balanced", or "trusted".')}function Ds(t,e=!1){const i=t.policy
if("internal"===t.classification)return
if("files"===t.classification)throw Error("File paste and drop require an UploadService.")
if("plain-text"===i)return Object.freeze({html:"",policy:"plain-text",text:t.text})
if(0===t.html.length)return Object.freeze({html:"",policy:i,text:t.text})
if(/<!doctype\s|<\/?(?:html|head|body)(?:\s|>)/iu.test(t.html))throw Error("Complete HTML documents are not valid paste fragments.")
const o=io(t.html).document.children.flatMap(t=>Ms(t,i,e)),s="semantic"===i?Ts(o,"#root"):o
return Object.freeze({html:oo(Object.freeze({children:Object.freeze(s),type:"document-fragment"})),policy:i,text:t.text})}function Ms(t,e,i){if("text"===t.type)return[Object.freeze({...t})]
if("comment"===t.type)return"preserve"===e?[Object.freeze({...t})]:[]
const o=(t=>{switch(t.toLowerCase()){case"b":return"strong"
case"i":return"em"
case"del":case"strike":return"s"
default:return t.toLowerCase()}})(t.tagName)
if(Cs.has(o))return[]
const s=t.children.flatMap(t=>Ms(t,e,i)),r="semantic"===e&&"pre"!==o&&"code"!==o?Ts(s,o):s
if("semantic"===e&&(!Is.has(o)||o.includes(":")))return r
const n=((t,e,i,o)=>{const s=[]
for(const r of e){const e=r.name.toLowerCase()
if(void 0===r.namespace&&!e.startsWith("on")&&"srcdoc"!==e&&"contenteditable"!==e&&("href"!==e&&"src"!==e&&"action"!==e||_s(r.value,"src"===e))){if("style"===e){const t=Fs(r.value,o)
t.length>0&&s.push({name:e,value:t})
continue}if("class"!==e)("preserve"===i||Rs(t,e,r.value))&&s.push({name:e,value:r.value})
else if("preserve"===i){const t=r.value.split(/\s+/u).filter(t=>t.length>0&&!/^mso/iu.test(t)).join(" ")
t.length>0&&s.push({name:e,value:t})}}}return Object.freeze(s.map(t=>Object.freeze(t)))})(o,t.attributes,e,i)
return"semantic"===e&&"span"===o&&0===n.length?r:[Object.freeze({attributes:n,children:Object.freeze(r),namespace:"html",tagName:"semantic"===e&&"div"===o?"p":o,type:"element"})]}function Ts(t,e){const i=t.map(t=>"text"===t.type?Object.freeze({...t,value:t.value.replace(/\s+/gu," ")}):t)
if(Es.has(e))return i.filter(t=>"text"!==t.type||" "!==t.value)
const o=i.at(0),s=i.at(-1)
return i.map((t,e)=>{if("text"!==t.type)return t
let r=t.value
return t!==o&&0!==e||(r=r.trimStart()),t!==s&&e!==i.length-1||(r=r.trimEnd()),Object.freeze({...t,value:r})}).filter(t=>"text"!==t.type||t.value.length>0)}function Rs(t,e,i){return"title"===e||"lang"===e||"dir"===e||!!/^aria-[a-z0-9-]+$/u.test(e)||("a"===t?["href","rel","target"].includes(e):"img"===t?"src"===e||"alt"===e||("width"===e||"height"===e)&&/^\d{1,5}$/u.test(i):"ol"===t?"start"===e&&/^-?\d{1,6}$/u.test(i)||"type"===e&&/^(?:1|a|A|i|I)$/u.test(i):"ul"===t?"type"===e&&/^(?:disc|circle|square)$/u.test(i):"td"===t||"th"===t?("rowspan"===e||"colspan"===e)&&/^\d{1,3}$/u.test(i)||"scope"===e&&/^(?:row|col|rowgroup|colgroup)$/u.test(i):("colgroup"===t||"col"===t)&&("span"===e&&/^\d{1,3}$/u.test(i)||"col"===t&&"width"===e&&/^(?:\d{1,4}|\d{1,4}px|100%|\d{1,2}%)$/u.test(i)))}function Fs(t,e){const i=e?new Set(["background-color","color","font-family","font-size","font-style","font-weight","text-align","text-decoration"]):new Set(["text-align"]),o=[]
for(const s of t.split(";")){const t=s.indexOf(":")
if(t<1)continue
const e=s.slice(0,t).trim().toLowerCase(),r=s.slice(t+1).trim()
i.has(e)&&r.length>0&&r.length<=128&&!/url\s*\(|expression\s*\(|javascript:/iu.test(r)&&o.push(`${e}: ${r}`)}return 0===o.length?"":o.join("; ")+";"}function _s(t,e){const i=Array.from(t.trim()).filter(t=>(t.codePointAt(0)??0)>32).join("")
return!(!i.startsWith("#")&&!/^(?:\.?\.?\/|\/)/u.test(i))||!/^[a-z][a-z0-9+.-]*:/iu.test(i)||!!/^(?:https?):/iu.test(i)||!(e||!/^(?:mailto|tel):/iu.test(i))||e&&/^data:image\/(?:gif|jpeg|png|webp);base64,/iu.test(i)}const Qs=J("soeditor.cms-embed-provider"),Os="soeditor.cms-embed"
function Ns(t,e,i){if("object"!=typeof i||null===i||Array.isArray(i))throw new No(t,"requires a properties object.")
const o=Object.entries(i)
if(o.some(([t,i])=>!e.properties.includes(t)||"string"!=typeof i||i.length>2048||zs(i)))throw new No(t,"contains an invalid property.")
return Object.freeze([{name:"data-soeditor-object",value:e.id},...o.map(([t,e])=>({name:"data-"+t,value:e+""}))])}function qs(t,e){const i=t.document.createElement("div")
i.className="soeditor-cms-object",i.setAttribute("role","group"),i.setAttribute("aria-label",e.label)
const o=t.document.createElement("strong")
o.textContent=e.label
const s=t.document.createElement("dl")
for(const r of e.properties){const e=Zs(t.node.attributes,"data-"+r)
if(void 0===e)continue
const i=t.document.createElement("dt")
i.textContent=r
const o=t.document.createElement("dd")
o.textContent=e,s.append(i,o)}return i.append(o,s),{element:i}}function js(t){const e=t.document.createElement("div")
e.className="soeditor-cms-embed",e.setAttribute("role","group"),e.setAttribute("aria-label","Embedded content metadata")
const i=Zs(t.node.attributes,"data-title")??"Embed",o=Zs(t.node.attributes,"data-soeditor-embed")
return e.textContent=void 0===o?i:`${i} — ${o}`,{element:e}}function Gs(t){return t.services.tryGet(Qo)?.canEdit()??!1}function Hs(t){return"soeditor.cms-object."+t}function Ks(t,e){if("string"!=typeof e||!/^[A-Za-z][A-Za-z0-9_.:-]{0,127}$/u.test(e))throw new No(t,"requires a safe name.")
return e}function Ys(t,e){if(0!==e.length)throw new No(t,"does not accept arguments.")}function Ws(t){return t.length<=2048&&!zs(t)&&/^https?:\/\/[^\s]+$/iu.test(t)}function zs(t){return Array.from(t).some(t=>{const e=t.codePointAt(0)
return void 0!==e&&(e<32||127===e)})}function Zs(t,e){return t.find(t=>t.name===e)?.value}function Us(t){return Object.freeze({children:Object.freeze([...t]),type:"document-fragment"})}function Js(t,e,i){return Object.freeze({attributes:Object.freeze([...e]),children:Object.freeze([...i]),namespace:"html",tagName:t,type:"element"})}function Ls(t){return Object.freeze({type:"text",value:t})}const Ps=J("soeditor.table-editor"),Vs="soeditor.table",Xs=100,$s=100,tr=1e3,er=1e6,ir=new Set(["format.bold","format.inlineCode","format.italic","format.remove","format.strike","format.subscript","format.superscript","format.underline","font.backgroundColor","font.color","font.family","font.highlight","font.size","image.insert","link.auto","link.inspect","link.pick","link.remove","link.set","link.setText","specialCharacter.insert"])
function or(t){const e=t.getStructuredSelection?.(Vs)
return void 0===e?void 0:An(e)}function sr(t){return!t.children.some(t=>yn(t,"tr")||"element"===t.type&&["thead","tbody","tfoot"].includes(t.tagName)&&t.children.some(t=>yn(t,"tr")))}function rr(t){return!!sr(t)&&t.children.every(t=>kn(t)||"element"===t.type&&(["caption","colgroup"].includes(t.tagName)||["thead","tbody","tfoot"].includes(t.tagName)&&t.children.every(kn)))}function nr(t){const e=(t=>{const e=[]
for(const i of t)if(yn(i,"tr"))e.push(i)
else if("element"===i.type&&["thead","tbody","tfoot"].includes(i.tagName)){if(i.children.some(t=>!yn(t,"tr")&&!ar(t)))throw Error("table sections may contain only rows")
e.push(...i.children.filter(t=>yn(t,"tr")))}else if(!(ar(i)||"element"===i.type&&["caption","colgroup"].includes(i.tagName)))throw Error("unsupported table child")
return e})(t.children)
if(0===e.length||e.length>Xs)throw Error("table requires between 1 and 100 rows")
const i=[],o=[]
let s=0
for(let r=0;r<e.length;r+=1){const t=e[r]
if(void 0===t)continue
const n=t.children.filter(vn)
if(0===n.length&&0===(i[r]?.length??0)||t.children.some(t=>!vn(t)&&!ar(t)))throw Error("rows may contain only table cells")
i[r]??=[]
const a=[]
let c=0
for(let o=0;o<n.length;o+=1){for(;void 0!==i[r]?.[c];)c+=1
const t=n[o]
if(void 0===t)continue
const s=fn(t.attributes,"rowspan"),l=fn(t.attributes,"colspan")
if(r+s>e.length)throw Error("rowspan exceeds table bounds")
const A={cellIndex:o,column:c,Mr:l,element:t,row:r,Tr:s}
for(let e=0;e<s;e+=1){const t=i[r+e]??=[]
for(let e=0;e<l;e+=1){if(void 0!==t[c+e])throw Error("overlapping row or column spans")
t[c+e]=A}}a.push(A),c+=l}s=Math.max(s,i[r]?.length??0),o.push({cells:a,element:t,row:r})}if(0===s||s>$s||o.length*s>tr||i.some(t=>t.length!==s||Array.from({length:s},(e,i)=>t[i]).some(t=>void 0===t)))throw Error("table grid must be rectangular and at most 1000 cells")
return{columns:s,grid:i,rows:o}}function ar(t){return"comment"===t.type||kn(t)}function cr(t,e){let i=0
return t.flatMap(t=>yn(t,"tr")?e(t,i++):"element"===t.type&&["thead","tbody","tfoot"].includes(t.tagName)?[{...t,children:t.children.flatMap(t=>yn(t,"tr")?e(t,i++):[t])}]:[t])}function lr(t,e,i){const o=rn(e),s=t.grid[o.top]?.[o.left]
return void 0!==s&&o.top===o.bottom&&o.left===o.right&&"rows"!==e.kind&&"columns"!==e.kind?"row"===i?s.row+s.Tr:s.column+s.Mr:"row"===i?o.bottom+1:o.right+1}function Ar(t,e,i,o=new Map){return{...t,children:cr(t.children,(t,s)=>{const r=e.rows[s]?.cells??[],n=[...o.get(s)??[]].sort((t,e)=>t.column-e.column),a=[]
for(const e of t.children){const t=r.find(t=>t.element===e)
if(void 0===t){a.push(e)
continue}for(;void 0!==n[0]&&n[0].column<=t.column;)a.push(n.shift().cell)
const o=i(t)
void 0!==o&&a.push(o)}return a.push(...n.map(t=>t.cell)),[{...t,children:a}]})}}function hr(t,e,i,o){if(e.rows.length>=Xs||(e.rows.length+1)*e.columns>tr)throw new No(o,"would exceed table limits.")
const s=Math.max(0,Math.min(e.rows.length-1,o.endsWith("After")?i-1:i)),r=i=>{const o=e.rows[i]?.element
return void 0===o?void 0:t.children.find(t=>"element"===t.type&&t.children.includes(o))},n=Math.min(i,e.rows.length-1),a=r(n)===r(s)?n:s,c=new Set,l=[]
for(let d=0;d<e.columns;d++){const t=e.grid[i-1]?.[d]
if(void 0!==t&&t.row<i&&t.row+t.Tr>i)c.add(t)
else{const t=e.grid[a]?.[d],i="th"===t?.element.tagName
l.push(pn(i?"th":"td",i?t.element.attributes.filter(t=>"scope"===t.name):[],[]))}}const A=Ar(t,e,t=>c.has(t)?{...t.element,attributes:bn(t.element.attributes,t.Tr+1,t.Mr)}:t.element),h=pn("tr",[],l)
return{...A,children:cr(A.children,(t,e)=>e===s?i<=s?[h,t]:[t,h]:[t])}}function dr(t,e,i,o,s){let r=t,n=e
for(let a=0;a<o;a+=1)r=hr(r,n,i,s),n=nr(r)
return r}function ur(t,e,i,o){if(e.columns>=$s||e.rows.length*(e.columns+1)>tr)throw new No(o,"would exceed table limits.")
const s=new Map
for(const r of e.rows){const t=e.grid[r.row]?.[Math.min(i,e.columns-1)]
if(void 0!==t&&t.column<i&&t.column+t.Mr>i)continue
const o="th"===t?.element.tagName
s.set(r.row,[{column:i,cell:pn(o?"th":"td",o?t.element.attributes.filter(t=>"scope"===t.name):[],[])}])}return br(Ar(t,e,t=>t.column<i&&t.column+t.Mr>i?{...t.element,attributes:bn(t.element.attributes,t.Tr,t.Mr+1)}:t.element,s),e.columns,i,0)}function fr(t,e,i,o,s){let r=t,n=e
for(let a=0;a<o;a+=1)r=ur(r,n,i,s),n=nr(r)
return r}function br(t,e,i,o){let s=0,r=!1
const n=t=>{const r=Number(wn(t.attributes,"span")??1)
if(!Number.isInteger(r)||r<1||r>$s)throw new No("table.column","invalid column metadata span.")
const n=s
s+=r
const a=0===o?r+(i>=n&&(i<s||i===e&&s===e)?1:0):r-Math.max(0,Math.min(s,i+o)-Math.max(n,i))
return a===r?t:0===a?void 0:{...t,attributes:jr(t.attributes,"span",1===a?null:a+"")}},a=t.children.flatMap(t=>{if(!yn(t,"colgroup"))return[t]
if(r=!0,!t.children.some(t=>yn(t,"col"))){const e=n(t)
return void 0===e?t.children:[e]}const a=t.children.flatMap(t=>{if(!yn(t,"col"))return[t]
const r=Number(wn(t.attributes,"span")??1)
if(!Number.isInteger(r)||r<1||r>$s)throw new No("table.column","invalid column metadata span.")
if(0===o&&(i===s||i===e&&s+r===e)){const e=i===s
s+=r
const o=pn("col",[],[])
return e?[o,t]:[t,o]}const a=n(t)
return void 0===a?[]:[a]})
return a.some(t=>yn(t,"col"))?[{...t,children:a}]:a})
if(r&&s!==e)throw new No("table.column","requires column metadata to match the table grid.")
return{...t,children:a}}function mr(t,e,i="table.column.resize"){const o=t.children.filter(t=>yn(t,"colgroup"))
if(0===o.length)return Array.from({length:e},()=>{})
const s=o[0]
if(1!==o.length||void 0===s||s.children.some(t=>!yn(t,"col")&&!kn(t)))throw new No(i,"requires one simple colgroup with one col per logical column.")
const r=s.children.filter(t=>yn(t,"col"))
if(r.length!==e)throw new No(i,"requires column metadata to match the table grid.")
return r.map(t=>{const e=wn(t.attributes,"width")
if(void 0===e)return
const o=/^(\d{1,4})(?:px)?$/u.exec(e),s=Number(o?.[1])
if(null===o||!Number.isInteger(s)||s<40||s>1200)throw new No(i,"found invalid owned column width metadata.")
return s})}function pr(t){return{...t,children:t.children.map(t=>{if(!yn(t,"colgroup"))return t
const e=t.children.some(t=>yn(t,"col"))?t.children:[...t.children,pn("col",[{name:"span",value:wn(t.attributes,"span")??"1"}],[])]
return{...t,attributes:jr(t.attributes,"span",null),children:e.flatMap(t=>{if(!yn(t,"col"))return[t]
const e=wn(t.attributes,"span"),i=void 0===e?1:Br(e)
if(void 0===i||i>100)throw new No("table.column.resize","requires a bounded column span.")
if(1===i)return[t]
const o=jr(t.attributes,"span",null)
return Array.from({length:i},(e,i)=>({...t,attributes:0===i?o:jr(o,"id",null)}))})}})}}function gr(t){if(0===t.length)return!0
if(1===t.length&&"boolean"==typeof t[0])return t[0]
throw new No("table.header","requires an optional boolean.")}function wr(t,e,i,o=!0){const s=new Set(e.grid[0]??[]),r=new Set(e.grid.map(t=>t[0]).filter(t=>void 0!==t)),n="row"===i?s:r,a="row"===i?r:s,c="row"===i?"row":"col",l=[...a].filter(t=>!n.has(t)),A=l.length>0?l.every(t=>"th"===t.element.tagName):[...a].every(t=>"th"===t.element.tagName&&wn(t.element.attributes,"scope")===c)
return Ar(t,e,t=>{if(!n.has(t))return t.element
const e=A&&a.has(t),s=o||e
return{...t.element,tagName:s?"th":"td",attributes:jr(t.element.attributes,"scope",o?"row"===i?"col":"row":e?c:null)}})}function vr(t,e,i){if(i.top===i.bottom&&i.left===i.right)throw new No("table.cells.merge","requires multiple cells.")
if(!ln(t,e,i))throw new No("table.cells.merge","cannot merge cells across table sections.")
const o=un(e,i)
if(o.length<2||o.some(t=>t.row<i.top||t.column<i.left||t.row+t.Tr-1>i.bottom||t.column+t.Mr-1>i.right))throw new No("table cell merge","requires complete cells in a rectangular range.")
const s=e.grid[i.top]?.[i.left]
if(void 0===s)throw Error("Selected table cell was not found.")
const r=[]
for(const c of o)c.element.children.length>0&&(r.length>0&&r.push(pn("br",[],[])),r.push(...c.element.children))
const n={...s.element,attributes:bn(s.element.attributes,i.bottom-i.top+1,i.right-i.left+1),children:r},a=new Set(o.filter(t=>t!==s))
return Gr(t,new Map([[s,n]]),a)}function yr(t,e,i,o="all"){if(i.top!==i.bottom||i.left!==i.right)throw new No("table.cell.split","requires one cell.")
const s=e.grid[i.top]?.[i.left]
if(void 0!==s&&("rows"===o&&1===s.Tr||"columns"===o&&1===s.Mr))return((t,e,i,o)=>{const s=e.rows.length+("rows"===o?1:0),r=e.columns+("columns"===o?1:0)
if(s>Xs||r>$s||s*r>tr)throw new No("table.cell.split","would exceed table limits.")
const n=pn(i.element.tagName,i.element.attributes.filter(t=>"id"!==t.name),[])
if("columns"===o){const o={...t,children:cr(t.children,(t,o)=>{const s=e.rows[o]?.cells??[]
return[{...t,children:t.children.flatMap(t=>{const e=s.find(e=>e.element===t)
return void 0===e?[t]:e===i?[e.element,n]:e.column<=i.column&&e.column+e.Mr>i.column?[{...e.element,attributes:bn(e.element.attributes,e.Tr,e.Mr+1)}]:[t]})}]})}
let s=0
const r=t=>{const e=Number(wn(t.attributes,"span")??1),o=s<=i.column&&i.column<s+e
return s+=e,o?{...t,attributes:jr(t.attributes,"span",e+1+"")}:t}
return{...o,children:o.children.map(t=>yn(t,"colgroup")?t.children.some(t=>yn(t,"col"))?{...t,children:t.children.map(t=>yn(t,"col")?r(t):t)}:r(t):t)}}const a=new Map
for(const l of new Set(e.grid[i.row]??[]))l!==i&&a.set(l,{...l.element,attributes:bn(l.element.attributes,l.Tr+1,l.Mr)})
const c=new Map([...a].map(([t,e])=>[t.element,e]))
return{...t,children:cr(t.children,(t,e)=>{const o={...t,children:t.children.map(t=>"element"===t.type?c.get(t)??t:t)}
return e===i.row?[o,pn("tr",[],[n])]:[o]})}})(t,e,s,o)
if(void 0===s||("rows"===o?1===s.Tr:("columns"===o||1===s.Tr)&&1===s.Mr))throw new No("table.cell.split","requires a merged cell.")
const r=new Map,n="columns"===o?s.row+1:s.row+s.Tr,a="rows"===o?s.column+1:s.column+s.Mr
for(let l=s.row;l<n;l+=1)for(let t=s.column;t<a;t+=1){if(l===s.row&&t===s.column)continue
const e=r.get(l)??[]
e.push({cell:pn(s.element.tagName,bn(s.element.attributes.filter(t=>"id"!==t.name),"columns"===o?s.Tr:1,"rows"===o?s.Mr:1),[]),column:t}),r.set(l,e)}const c={...s.element,attributes:bn(s.element.attributes,"columns"===o?s.Tr:1,"rows"===o?s.Mr:1)}
return((t,e)=>((t,e)=>({...t,children:cr(t.children,(t,i)=>[{...t,children:e(t.children.filter(vn),i)}])}))(t,(t,i)=>{const o=e.rows[i]
return void 0===o?[]:(t=>{const e=t.cells.map(t=>t===s?c:t.element),i=t.cells.map((t,i)=>({cell:e[i],column:t.column}))
return i.push(...r.get(t.row)??[]),i.sort((t,e)=>t.column-e.column),i.map(({cell:t})=>t)})(o)}))(t,e)}function kr(t,e,i,o){const s=un(e,i)
return Gr(t,new Map(s.map(t=>[t,{...t.element,children:o(t,t.row-i.top,t.column-i.left)}])))}function Cr(t){return t.children.filter(t=>"element"===t.type&&["thead","tbody","tfoot"].includes(t.tagName))}function Ir(t){return t.children.filter(t=>yn(t,"colgroup"))}function Er(t,e){const i=gn(t.children,"caption"),o=[]
let s=0
const r=Ir(t).map((t,e)=>{const i=t.children.filter(t=>yn(t,"col")),r=t.children.some(t=>"element"===t.type&&!yn(t,"col")),n=wn(t.attributes,"span"),a=Br(n)
let c,l
r?(c="列组包含不支持的子元素，只能在源码模式中修改。",l="unknown-column-child"):void 0!==n&&i.length>0?(c="列组不能同时使用 span 和 col 子项。",l="conflicting-column-definition"):(void 0!==n&&void 0===a||i.some(t=>void 0!==wn(t.attributes,"span")&&void 0===Br(wn(t.attributes,"span"))))&&(c="列组包含无效的 span。",l="invalid-column-span")
const A=i.map(t=>{const e=wn(t.attributes,"width")
return{attributes:Or(t.attributes),span:Br(wn(t.attributes,"span"))??1,...void 0===e?{}:{width:e}}}),h=i.length>0?A.reduce((t,e)=>t+e.span,0):a??1
void 0!==l&&void 0!==c&&o.push({code:l,message:c,repairable:!1,severity:"warning"})
const d={attributes:Or(t.attributes),columnCount:h,columns:A,editable:void 0===c,index:e,...void 0===c?{}:{reason:c},...void 0===a?{}:{span:a},startColumn:s}
return s+=h,Object.freeze(d)})
r.length>0&&s!==e.columns&&o.push({code:"column-coverage-mismatch",message:`列组覆盖 ${s+""} 列，但表格有 ${e.columns+""} 个逻辑列。`,repairable:!1,severity:"warning"}),t.children.some(t=>yn(t,"tr"))&&o.push({code:"direct-table-rows",message:"部分 tr 直接位于 table 下，可安全放入显式 tbody。",repairable:!0,repairId:"wrap-direct-rows",severity:"info"})
const n=new Map,a=Cr(t).some(t=>{const e=n.get(t.tagName)??0
return n.set(t.tagName,e+1),e>0&&0===t.attributes.length&&0===t.children.length}),c=Cr(t).filter(t=>yn(t,"tbody")),l=c.some(t=>c.length>1&&0===t.attributes.length&&0===t.children.length)
return(a||l)&&o.push({code:"empty-duplicate-section",message:"存在无属性、无内容的重复空分区，可安全移除。",repairable:!0,repairId:"remove-empty-duplicate-sections",severity:"info"}),Object.freeze({caption:Object.freeze({attributes:Or(i?.attributes??[]),exists:void 0!==i,hasRichContent:i?.children.some(t=>"text"!==t.type)??!1,text:Cn(i?.children??[])??""}),columnGroups:Object.freeze(r),diagnostics:Object.freeze(o),sections:Object.freeze(Cr(t).map((t,e)=>Object.freeze({attributes:Or(t.attributes),editable:!0,index:e,kind:"thead"===t.tagName?"head":"tfoot"===t.tagName?"foot":"body",rowCount:t.children.filter(t=>yn(t,"tr")).length})))})}function Br(t){if(void 0===t)return
if(!/^[1-9][0-9]*$/u.test(t))return
const e=Number(t)
return Number.isSafeInteger(e)&&e<=$s?e:void 0}function xr(t,e){const i=gn(t.children,"caption"),o=t.children.filter(t=>!yn(t,"caption"))
if(null===e)return{...t,children:o}
const s=pn("caption",i?.attributes??[],[Object.freeze({type:"text",value:e})])
return{...t,children:[s,...o]}}function Sr(t,e,i){const o=Er(t,e),s=o.diagnostics.find(t=>"column-coverage-mismatch"!==t.code)
if(void 0!==s)throw new No(i,s.message)
return o.columnGroups}function Dr(t){return pn("col",Nr(_r([],[["span",1===t.span?null:t.span+""],["width",t.width]]),t.attributes),[])}function Mr(t,e){const i=[...e].map(Dr)
return[...t.flatMap(t=>{if(!yn(t,"col"))return[t]
const e=i.shift()
return void 0===e?[]:[e]}),...i]}function Tr(t,e){return t.children.find(t=>"element"===t.type&&["thead","tbody","tfoot"].includes(t.tagName)&&t.children.includes(e))}function Rr(t){const e=[]
for(const i of t)if(yn(i,"tr"))e.push("body")
else if("element"===i.type&&("thead"===i.tagName||"tbody"===i.tagName||"tfoot"===i.tagName)){const t="thead"===i.tagName?"head":"tfoot"===i.tagName?"foot":"body"
for(const o of i.children)yn(o,"tr")&&e.push(t)}return e}function Fr(t){return"head"===t?"thead":"foot"===t?"tfoot":"tbody"}function _r(t,e){let i=t
for(const[o,s]of e)void 0!==s&&(i=jr(i,o,s))
return i}const Qr=new Set(["align","aria-label","border","cellpadding","cellspacing","class","colspan","height","rowspan","scope","span","style","summary","valign","width"])
function Or(t){return Object.freeze(t.filter(({name:t})=>!Qr.has(t)&&!t.startsWith("data-soeditor-")))}function Nr(t,e){return void 0===e?t:Object.freeze([...t.filter(({name:t})=>Qr.has(t)||t.startsWith("data-soeditor-")),...e])}function qr(t,e){if(!Object.hasOwn(e,"customAttributes"))return{}
const i=e.customAttributes
if(!Array.isArray(i)||i.length>32)throw new No(t,"customAttributes must be an array with at most 32 entries.")
const o=["contenteditable","dir","draggable","hidden","id","lang","role","spellcheck","tabindex","title","translate"],s="table.properties"===t?new Set([...o,"aria-describedby","aria-labelledby","aria-colcount","aria-rowcount"]):"table.section.properties"===t?new Set([...o,"aria-describedby","aria-labelledby"]):"table.row.properties"===t?new Set([...o,"aria-describedby","aria-labelledby","aria-rowindex","aria-selected"]):new Set([...o,"abbr","headers","aria-colindex","aria-describedby","aria-labelledby","aria-rowindex","aria-selected"]),r=new Set,n=i.map((e,i)=>{if("object"!=typeof e||null===e||Array.isArray(e))throw new No(t,`customAttributes[${i+""}] is invalid.`)
const o=Reflect.get(e,"name"),n=Reflect.get(e,"value"),a="string"==typeof o?o.trim().toLowerCase():""
if("string"!=typeof n||n.length>4096||Array.from(n).some(t=>{const e=t.codePointAt(0)
return void 0!==e&&(e<32||127===e)})||!/^[a-z][a-z0-9_.:-]{0,63}$/u.test(a)||!s.has(a)&&!/^data-[a-z0-9_.:-]+$/u.test(a)||a.startsWith("data-soeditor-")||r.has(a))throw new No(t,`custom attribute "${a}" is invalid or reserved.`)
if("id"===a&&!/^[A-Za-z][\w:.-]*$/u.test(n)||["headers","aria-describedby","aria-labelledby"].includes(a)&&!/^(?:[A-Za-z][\w:.-]*)(?:\s+[A-Za-z][\w:.-]*)*$/u.test(n)||"role"===a&&!/^[a-z][a-z0-9-]*(?:\s+[a-z][a-z0-9-]*)*$/u.test(n)||["aria-colcount","aria-colindex","aria-rowcount","aria-rowindex"].includes(a)&&!/^[1-9][0-9]*$/u.test(n)||"aria-selected"===a&&!["false","true"].includes(n)||"dir"===a&&!["auto","ltr","rtl"].includes(n)||["contenteditable","draggable","spellcheck"].includes(a)&&!["false","true"].includes(n)||"translate"===a&&!["no","yes"].includes(n)||"tabindex"===a&&!/^-?[0-9]+$/u.test(n))throw new No(t,`custom attribute "${a}" has an invalid value.`)
return r.add(a),Object.freeze({name:a,value:n})})
return{customAttributes:Object.freeze(n)}}function jr(t,e,i){return[...t.filter(t=>t.name!==e),...null===i?[]:[{name:e,value:i}]]}function Gr(t,e,i=new Set){return{...t,children:cr(t.children,(t,o)=>{if(void 0===[...e.keys(),...i].find(t=>t.row===o))return[t]
const s=t.children.filter(vn)
return[{...t,children:s.flatMap((t,s)=>{const r=[...e.keys(),...i].find(t=>t.row===o&&t.cellIndex===s)
return void 0===r?[t]:i.has(r)?[]:[e.get(r)??t]})}]})}}function Hr(t){const e=Zr("table.section.properties",t,["customAttributes"])
return Object.freeze({...qr("table.section.properties",e)})}function Kr(t,e,i){if("number"==typeof i){if(!Number.isInteger(i)||i<1||i>9999)throw new No(t,`requires ${e} from 1px to 9999px, or 1% to 100%.`)
return i+""}const o=Lr(t,i,16)
if(null==o)return o
const s=/^([1-9][0-9]{0,3})(px|%)?$/u.exec(o),r=Number(s?.[1]),n=s?.[2]??"px"
if(null===s||r>("%"===n?100:9999))throw new No(t,`requires ${e} from 1px to 9999px, or 1% to 100%.`)
return"%"===n?r+"%":r+""}function Yr(t,e){const i=Zr(t,[e],["columns","customAttributes","span"]),o=i.span
if(null!=o&&(!Number.isInteger(o)||Number(o)<1||Number(o)>$s))throw new No(t,"span must be from 1 to 100 or null.")
const s=i.columns
if(void 0!==s&&(!Array.isArray(s)||s.length>$s))throw new No(t,"columns must contain at most 100 column definitions.")
return{...void 0===s?{}:{columns:Object.freeze(s.map(e=>((t,e)=>{const i=Zr(t,[e],["attributes","span","width"]),o=Wr(t,i.span,1,$s),s=Lr(t,i.width,16)
if(null!=s&&!/^(?:[4-9][0-9]|[1-9][0-9]{2}|1[01][0-9]{2}|1200)(?:px)?$/u.test(s))throw new No(t,"column width must be from 40px to 1200px.")
const r=void 0===i.attributes?void 0:qr(t,{customAttributes:i.attributes}).customAttributes
return Object.freeze({attributes:r??[],span:o,...null==s?{}:{width:s}})})(t,e)))},...qr(t,i),...void 0===o?{}:{span:null===o?null:Number(o)}}}function Wr(t,e,i,o){if(!Number.isInteger(e)||Number(e)<i||Number(e)>o)throw new No(t,`requires an integer from ${i+""} to ${o+""}.`)
return Number(e)}function zr(t,e,i,o){if(1!==e.length)throw new No(t,"requires one integer.")
return Wr(t,e[0],i,o)}function Zr(t,e,i){if(1!==e.length||"object"!=typeof e[0]||null===e[0]||Array.isArray(e[0]))throw new No(t,"requires one properties object.")
const o=e[0]
if(Object.keys(o).some(t=>!i.includes(t)))throw new No(t,"received an unknown property.")
return o}function Ur(t,e,i,o){const s=Lr(t,e[i],o)
return void 0===s?{}:{[i]:s}}function Jr(t,e,i){const o=e[i]
if(null==o)return void 0===o?{}:{[i]:null}
if("string"!=typeof o||!/^\d{1,3}$/u.test(o))throw new No(t,i+" requires a whole number from 0 to 999.")
return{[i]:Number(o)+""}}function Lr(t,e,i){if(null==e)return e
if("string"!=typeof e||e.length>i||(t=>Array.from(t).some(t=>{const e=t.codePointAt(0)
return void 0!==e&&(e<32||127===e)}))(e))throw new No(t,"requires a bounded string property.")
return e}function Pr(t,e){const i=Lr(t,e,256)
if("string"==typeof i&&(0===i.length||i.split(/\s+/u).length>8||!i.split(/\s+/u).every(t=>/^[A-Za-z_][A-Za-z0-9_-]{0,63}$/u.test(t))))throw new No(t,"requires bounded CSS class tokens.")
return i}function Vr(t,e,i){if(void 0!==e){if("string"!=typeof e||!i.includes(e))throw new No(t,"contains an unsupported property value.")
return e}}function Xr(t,e,i){return null===e?null:Vr(t,e,i)}function $r(){return new No("table.cells.commitHtml","contains an invalid edited cell.")}function tn(){return new No("table.cells.paste","requires a valid matrix bounded to 100 rows, 100 columns, and 1000 cells.")}function en(t,e,i){if(e.Rr-=1,e.Rr<0||i>64||"object"!=typeof t||null===t||Array.isArray(t))return!1
const o=t
return"text"===o.type||"comment"===o.type?"string"==typeof o.value&&(e.Fr-=o.value.length,e.Fr>=0):!!("element"===o.type&&"string"==typeof o.tagName&&["html","svg","mathml"].includes(o.namespace+"")&&Array.isArray(o.attributes)&&Array.isArray(o.children))&&o.attributes.every(t=>((t,e)=>{if("object"!=typeof t||null===t||Array.isArray(t))return!1
const i=t,o=i.name,s=i.value
return!("string"!=typeof o||"string"!=typeof s||void 0!==i.namespace&&"string"!=typeof i.namespace||void 0!==i.prefix&&"string"!=typeof i.prefix)&&(e.Fr-=o.length+s.length,e.Fr>=0)})(t,e))&&o.children.every(t=>en(t,e,i+1))}function on(t){return{attributes:t.attributes,children:t.children,namespace:"html",tagName:"table",type:"element"}}function sn(t,e){if(void 0===t)throw new No(e,"requires the visual editor.")
return t}function rn(t){return{bottom:Math.max(t.anchor.row,t.focus.row),left:Math.min(t.anchor.column,t.focus.column),right:Math.max(t.anchor.column,t.focus.column),top:Math.min(t.anchor.row,t.focus.row)}}function nn(t,e){const i=rn(e)
if(i.top===i.bottom&&i.left===i.right)return"caret"
if(void 0!==e.kind)return e.kind
const o=0===i.top&&i.bottom===t.rows.length-1,s=0===i.left&&i.right===t.columns-1
return o&&s?"table":s?"rows":o?"columns":"cells"}function an(t,e,i){const o=rn(e)
return{anchor:"table"===i?{column:0,row:0}:"row"===i?{column:0,row:o.top}:{column:o.left,row:0},focus:"table"===i?{column:t.columns-1,row:t.rows.length-1}:"row"===i?{column:t.columns-1,row:o.bottom}:{column:o.right,row:t.rows.length-1},kind:"row"===i?"rows":"column"===i?"columns":"table"}}function cn(t,e,i){const o=rn(i),s=o.top!==o.bottom||o.left!==o.right
let r,n
if(s)if(ln(t,e,o))try{vr(t,e,o)}catch{r="所选区域包含跨度冲突，请选择完整矩形单元格。"}else r="不能跨越表头、表体或表尾分区合并。"
else r="请选择至少两个相邻单元格。"
if(s)n="拆分操作一次只能处理一个单元格。"
else{const t=e.grid[o.top]?.[o.left];(void 0===t||1===t.Tr&&1===t.Mr)&&(n="当前单元格没有可拆分的跨度。")}return Object.freeze({clear:Object.freeze({enabled:!0}),merge:Object.freeze({enabled:void 0===r,...void 0===r?{}:{reason:r}}),split:Object.freeze({enabled:void 0===n,...void 0===n?{}:{reason:n}})})}function ln(t,e,i){const o=new Map
for(const s of t.children)if(yn(s,"tr"))o.set(s,t)
else if("element"===s.type&&["thead","tbody","tfoot"].includes(s.tagName))for(const t of s.children)yn(t,"tr")&&o.set(t,s)
return 1===new Set(e.rows.slice(i.top,i.bottom+1).map(t=>o.get(t.element))).size}function An(t){if("object"!=typeof t||null===t||Array.isArray(t))return
const e=t,i=hn(e.anchor),o=hn(e.focus)
if(void 0===i||void 0===o)return
const s=e.kind
return["cells","columns","rows","table"].includes(s+"")?{anchor:i,focus:o,kind:s}:{anchor:i,focus:o}}function hn(t){if("object"!=typeof t||null===t||Array.isArray(t))return
const e=t
return Bn(e.row)&&Bn(e.column)?{column:e.column,row:e.row}:void 0}function dn(t,e,i){const o=rn(e)
if(o.top<0||o.left<0||o.bottom>=t.rows.length||o.right>=t.columns)throw new No(i,"received a cell range outside the table.")}function un(t,e){const i=new Set
for(let o=e.top;o<=e.bottom;o+=1)for(let s=e.left;s<=e.right;s+=1){const e=t.grid[o]?.[s]
void 0!==e&&i.add(e)}return[...i]}function fn(t,e){const i=t.find(t=>t.name===e)?.value
if(void 0===i)return 1
const o=Number(i)
if(!Number.isInteger(o)||o<1||o>100)throw Error(e+" must be an integer from 1 to 100")
return o}function bn(t,e,i){return[...mn(t),...1===e?[]:[{name:"rowspan",value:e+""}],...1===i?[]:[{name:"colspan",value:i+""}]]}function mn(t){return t.filter(t=>"rowspan"!==t.name&&"colspan"!==t.name)}function pn(t,e,i){return Object.freeze({attributes:Object.freeze([...e]),children:Object.freeze([...i]),namespace:"html",tagName:t,type:"element"})}function gn(t,e){return t.find(t=>yn(t,e))}function wn(t,e){return t.find(t=>t.name===e)?.value}function vn(t){return yn(t,"td")||yn(t,"th")}function yn(t,e){return"element"===t.type&&"html"===t.namespace&&t.tagName===e}function kn(t){return"text"===t.type&&0===t.value.trim().length}function Cn(t){return t.map(t=>"text"===t.type?t.value:"element"===t.type?Cn(t.children):"").join("")}function In(t,e){for(const i of t)if("element"===i.type){if("html"===i.namespace&&i.tagName===e)return i
const t=In(i.children,e)
if(void 0!==t)return t}}function En(t){return"number"==typeof t&&Number.isInteger(t)&&t>0?t:void 0}function Bn(t){return"number"==typeof t&&Number.isInteger(t)&&t>=0}function xn(t,e){if(0!==e.length)throw new No(t,"does not accept arguments.")}function Sn(t,e){if(0===e.length)return 1
const i=e[0]
if(1!==e.length||"object"!=typeof i||null===i||Array.isArray(i))throw new No(t,"accepts an optional { count } object.")
const o=Reflect.get(i,"count")
if(!Number.isInteger(o)||Number(o)<1||Number(o)>100)throw new No(t,"count must be from 1 to 100.")
return Number(o)}function Dn(t,e){if(1!==e.length||"string"!=typeof e[0])throw new No(t,"requires one string.")
return e[0]}const Mn=new Set("address article aside blockquote caption dd div dl dt fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 header hr li main nav ol p pre section table tbody td tfoot th thead tr ul".split(" ")),Tn=new Set(["script","style","template","noscript","iframe"]),Rn="[\\p{Script=Han}\\p{Script=Hiragana}\\p{Script=Katakana}]",Fn=`(?!${Rn})[\\p{L}\\p{N}](?:(?!${Rn})[\\p{L}\\p{M}\\p{N}])*`,_n=RegExp(`${Rn}|${Fn}(?:['’]${Fn})*`,"gu")
function Qn(t){let e=0
for(let i=0;i<t.length;e+=1){const e=t.codePointAt(i)
i+=void 0!==e&&e>65535?2:1}return e}function On(t,e){const i=t.createElement("template")
i.innerHTML=e
let o=0,s=0,r=[]
const n=t=>{const e=r.join(""),i=t?e:e.replace(/[ \t\r\n\f]+/gu," ").trim()
i.trim().length>0&&(o+=Qn(i),s+=(t=>{let e=0
for(const i of t.matchAll(_n))i[0].length>0&&(e+=1)
return e})(i)),r=[]},a=[{node:i.content,_r:!1}]
for(;a.length>0;){const t=a.pop()
if(void 0===t)break
if("Qr"in t){n(t.Qr)
continue}const{node:e,_r:i}=t
if(3===e.nodeType){r.push(e.nodeValue??"")
continue}if(1!==e.nodeType&&11!==e.nodeType)continue
const o=1===e.nodeType?e:void 0
if(void 0!==o&&(Tn.has(o.localName)||o.hasAttribute("hidden")||"none"===o.style?.display||"hidden"===o.style?.visibility))continue
if("br"===o?.localName){i?r.push("\n"):n(!1)
continue}const s=void 0!==o&&Mn.has(o.localName),c=i||"pre"===o?.localName
s&&(n(i),a.push({Qr:c}))
for(let r=e.childNodes.length-1;r>=0;r-=1){const t=e.childNodes[r]
void 0!==t&&a.push({node:t,_r:c})}}return n(!1),Object.freeze({Fr:o,Or:s,Nr:Qn(e)})}function Nn(t,e,i,o,s){const r=s?i?.status??"unavailable":"unavailable"
t.dataset.qr=r
const n="uniform"===r&&"uniform"===i?.status?i.value:""
t.dataset.jr=n
const a="mixed"===r?o.translate("Mixed formatting"):"unavailable"===r?o.translate("Formatting unavailable"):n
t.setAttribute("aria-description",a),t.title=`${o.translate(e)}: ${a}`}const qn=[["left","Align left"],["center","Align center"],["right","Align right"],["justify","Justify"]],jn=[["decimal","Decimal","1.","2.","3."],["decimal-leading-zero","Decimal with leading zero","01.","02.","03."],["lower-roman","Lowercase Roman","i.","ii.","iii."],["upper-roman","Uppercase Roman","I.","II.","III."],["lower-alpha","Lowercase letters","a.","b.","c."],["upper-alpha","Uppercase letters","A.","B.","C."]],Gn=[["disc","Filled circle","•","•","•"],["circle","Hollow circle","◦","◦","◦"],["square","Square","▪","▪","▪"]]
function Hn(t){return({document:e,editor:i,ui:o})=>{const s="alignment"===t,r=s?"format.alignment":"list."+t,n=s?"Alignment":"ordered"===t?"Ordered list":"Unordered list",a=e.createElement("span")
a.className="soeditor-ui__format-control"
const c=e.createElement("details")
c.className="soeditor-ui__menu"
const l=e.createElement("summary")
l.className="soeditor-ui__button",l.title=o.translate(s?n:n+" styles"),l.setAttribute("aria-label",l.title),l.setAttribute("aria-haspopup","menu")
const A=e.createElement("button")
A.type="button",A.className="soeditor-ui__button",A.title=o.translate(n),A.setAttribute("aria-label",A.title),o.setIcon(A,r,n),s&&o.setIcon(l,"format.alignment.left",n)
const h=e.createElement("span")
h.className="soeditor-ui__format-arrow",h.textContent="⌄",h.setAttribute("aria-hidden","true"),l.append(h)
const d=e.createElement("div")
d.className="soeditor-ui__menu-items soeditor-ui__format-choices"+(s?" soeditor-ui__alignment-choices":""),d.setAttribute("role","menu"),d.setAttribute("aria-label",o.translate(n))
const u=t=>{o.restoreEditingSelection()
try{i.execute(t),c.open=!1}catch(e){o.notifications.show({severity:"error",message:e instanceof Error?e.message:e+""})}},f=(s?qn:"ordered"===t?jn:Gn).map(([i,n,...a])=>{const c=e.createElement("button")
c.type="button",c.className="soeditor-ui__button soeditor-ui__format-choice",c.title=o.translate(n),c.setAttribute("aria-label",c.title),c.setAttribute("role","menuitemradio")
const l=`${r}.${i}`
if(c.dataset.Gr=l,s)o.setIcon(c,l,n)
else{const o=e.createElement("span")
o.className="soeditor-ui__list-preview",o.setAttribute("aria-hidden","true")
for(const s of a){const r=e.createElement("span"),n=e.createElement("span")
"unordered"===t?n.dataset.marker=i:n.textContent=s,r.append(n,e.createElement("i")),o.append(r)}c.append(o)}return c.addEventListener("click",()=>u(l)),d.append(c),c}),b=t=>i.commands.has(t)&&i.commands.canExecute(t),m=t=>i.commands.has(t)&&i.commands.isActive(t)
return A.addEventListener("click",()=>u(r)),l.addEventListener("click",t=>{"true"===l.getAttribute("aria-disabled")&&t.preventDefault()}),c.append(l,d),s||a.append(A),a.append(c),{element:a,update:()=>{A.disabled=!b(r)
const e=o.getEditingFormatState?.(s?"alignment":"list"),i="ordered"===t?"ol:":"ul:",a=!A.disabled&&("uniform"===e?.status?e.value.startsWith(i):void 0===e&&m(r))
A.classList.toggle("is-active",a),A.setAttribute("aria-pressed",a+""),Nn(l,n,e,o,!A.disabled)
let d="mixed"===e?.status?"":"format.alignment.left"
for(const t of f){const o=t.dataset.Gr??""
t.disabled=!b(o)
const n=o.slice(r.length+1),a=!t.disabled&&("uniform"===e?.status?e.value===(s?n:i+n):void 0===e&&m(o))
t.setAttribute("aria-checked",a+""),t.classList.toggle("is-active",a),a&&(d=o)}l.setAttribute("aria-disabled",f.every(t=>t.disabled)+""),f.every(t=>t.disabled)&&(c.open=!1),s&&l.dataset.Hr!==d&&(o.setIcon(l,d,""===d?"—":n),l.append(h),l.dataset.Hr=d)},destroy:()=>{c.open=!1}}}}const Kn=()=>Promise.resolve().then(()=>Bc),Yn=Object.freeze(["undo","redo","|","heading","|","bold","italic","underline","strike","fontFamily","fontSize","fontColor","fontBackgroundColor","highlight","link","|","image","table"]),Wn=Object.freeze([Fa("undo","Mod+Z","editor.undo"),Fa("redo","Mod+Shift+Z","editor.redo"),Fa("bold","Mod+B","format.bold"),Fa("italic","Mod+I","format.italic"),Fa("underline","Mod+U","format.underline")])
function zn(t,e,i=[],o=t,s=e){return({document:r,editor:n,ui:a})=>{const c=r.createElement("button")
c.type="button",c.className="soeditor-ui__button",a.setIcon(c,s,o),c.title=t,c.setAttribute("aria-label",t)
const l=()=>{Ta(n,a,e,i)}
return c.addEventListener("click",l),{element:c,update:()=>Sa(c,n,e),destroy:()=>c.removeEventListener("click",l)}}}const Zn=Object.freeze([{label:"Same window (_self)",value:"_self"},{label:"New window or tab (_blank)",value:"_blank"},{label:"Parent frame (_parent)",value:"_parent"},{label:"Top frame (_top)",value:"_top"}]),Un=Object.freeze(["nofollow","sponsored","ugc","noopener","noreferrer","external"]),Jn=Object.freeze(["©","®","™","€","£","¥","¢","§","¶","•","…","–","—","«","»","“","”","‘","’","°","±","×","÷","≈","≠","≤","≥","∞","√","Ω","→","←","↑","↓","✓","★","♥","◆","½","¼"]),Ln=Ia("Named anchor","anchor.insert","Anchor name","text","⌖"),Pn=Ia("CMS placeholder","placeholder.insert","Placeholder name"),Vn=Ea("Image","image.insert",(t,e)=>{let i,o
return{content:e=>{e.closest(".soeditor-ui__dialog")?.classList.add("soeditor-ui__image-dialog"),i=Ba(t,e,"Image URL","url",!0),o=Ba(t,e,"Alternative text","text")},run:()=>e({src:i.value,alt:o.value})}},"▣")
function Xn(t,e,i,o){const s=t.createElement("button")
s.type="button",s.className="soeditor-ui__menu-item",s.setAttribute("role","menuitem"),e.setIcon(s,i,o)
const r=t.createElement("span")
return r.textContent=o,s.append(r),s}const $n=[{name:"id"},{name:"title"},{name:"role"},{name:"aria-describedby"},{name:"aria-labelledby"}],ta=$n,ea=[...$n,{name:"aria-rowindex"},{name:"aria-selected",values:["true","false"]}],ia=[...$n,{name:"headers"},{name:"aria-colindex"},{name:"aria-rowindex"},{name:"aria-selected",values:["true","false"]}]
function oa(t,e,i,o,s,r){return Ea(t,e,async(t,e,n)=>{const{Kr:a,Yr:c}=await Kn(),l=new Map
let A
return{content:e=>{const h=((t,e)=>{if(!t.commands.has(e)||!t.commands.canExecute(e))return{}
const i=t.execute(e)
return"object"==typeof i&&null!==i?i:{}})(n,i)
for(const i of o){const o=Ba(t,e,i.label,i.numeric?"number":"text",!1,xa(h[i.key]))
i.numeric&&(o.min="20",o.max="2000"),l.set(i,o)}A=c(t,e,a(h),s,t=>t,r)},run:()=>{const t=A.value()
if(void 0===t)return
const i={}
for(const[e,o]of l)0===o.value.length&&e.Wr||(i[e.key]=0===o.value.length?null:e.numeric?Number(o.value):o.value)
e({...i,customAttributes:t})}}})}const sa=oa("Table properties","table.properties","table.inspect",[{key:"caption",label:"Caption"},{key:"width",label:"Width (px or %)"},{key:"alignment",label:"Alignment (left, center, right)"},{key:"responsiveClass",label:"Responsive classes"},{key:"ariaLabel",label:"Accessible label"}],ta,["aria-label","class","style","width"]),ra=oa("Table row properties","table.row.properties","table.row.inspect",[{key:"section",label:"Section (head, body, foot)",Wr:!0},{key:"className",label:"Row classes"},{key:"height",label:"Height",numeric:!0}],ea,["aria-label","class","height","style"]),na=oa("Table cell properties","table.cell.properties","table.cell.inspect",[{key:"horizontalAlignment",label:"Alignment (left, center, right)"},{key:"verticalAlignment",label:"Vertical alignment"},{key:"scope",label:"Header scope"},{key:"className",label:"Cell classes"}],ia,["aria-label","class","colspan","rowspan","scope","style"]),aa=Object.freeze([["Black","#000000"],["Dark gray","#344054"],["Gray","#667085"],["Red","#dc2626"],["Rose","#e11d48"],["Orange","#ea580c"],["Amber","#d97706"],["Yellow","#ca8a04"],["Lime","#65a30d"],["Green","#16a34a"],["Teal","#0d9488"],["Cyan","#0891b2"],["Blue","#2563eb"],["Indigo","#4f46e5"],["Purple","#7c3aed"],["White","#ffffff"]]),ca=Object.freeze([["Light gray","#f2f4f7"],["Light slate","#e2e8f0"],["Light red","#fee2e2"],["Light rose","#ffe4e6"],["Light orange","#ffedd5"],["Light amber","#fef3c7"],["Light yellow","#fef9c3"],["Light lime","#ecfccb"],["Light green","#dcfce7"],["Light teal","#ccfbf1"],["Light cyan","#cffafe"],["Light blue","#dbeafe"],["Light indigo","#e0e7ff"],["Light purple","#ede9fe"],["Dark","#1f2937"],["White","#ffffff"]]),la=Object.freeze([["Classic yellow marker","#ffff66"],["Yellow marker","#fef08a"],["Green marker","#bbf7d0"],["Pink marker","#fecaca"],["Blue marker","#bae6fd"],["Orange marker","#fed7aa"],["Violet marker","#ddd6fe"],["Strong yellow marker","#fde047"],["Strong green marker","#86efac"],["Strong pink marker","#fda4af"],["Strong blue marker","#7dd3fc"],["Strong orange marker","#fdba74"],["Strong violet marker","#c4b5fd"],["Gray marker","#d1d5db"],["Cyan marker","#a5f3fc"],["Red marker","#fca5a5"],["Lime marker","#bef264"]]),Aa=Object.freeze([["Default","inherit"],["Arial","arial"],["Courier New","courier new"],["Georgia","georgia"],["Lucida Sans Unicode","lucida sans unicode"],["Tahoma","tahoma"],["Times New Roman","times new roman"],["Trebuchet MS","trebuchet ms"],["Verdana","verdana"]]),ha=Object.freeze([["Default","medium"],["9 px","9px"],["10 px","10px"],["11 px","11px"],["12 px","12px"],["14 px","14px"],["15 px","15px"],["18 px","18px"],["20 px","20px"],["24 px","24px"],["28 px","28px"],["32 px","32px"],["36 px","36px"],["48 px","48px"],["72 px","72px"]]),da=wa("Text color","font.color","A̲",aa,{zr:"font.color.remove",Zr:"Remove text color"}),ua=wa("Background color","font.backgroundColor","A■",ca,{zr:"font.backgroundColor.remove",Zr:"Remove background color"}),fa=wa("Highlight","font.highlight","▁̸",la,{zr:"font.highlight.remove",Zr:"Remove highlight"}),ba=ka("Font family","font.family","Aƒ",Aa),ma=ka("Font size","font.size","A↕",ha),pa="soeditor.ui.recent-colors.v1",ga=16
function wa(t,e,i,o,s={}){return({document:r,editor:n,ui:a})=>{const c=r.createElement("details")
c.className="soeditor-ui__menu soeditor-ui__color-menu"
const l=r.createElement("summary")
l.className="soeditor-ui__button",a.setIcon(l,e,i),l.title=t,l.setAttribute("aria-label",t)
const A=r.createElement("div")
A.className="soeditor-ui__color-panel",A.setAttribute("aria-label",t)
const h=t=>{t.composedPath().some(t=>t instanceof Element&&t.matches("a[href],button,input,label,select,textarea"))||(t.preventDefault(),a.restoreEditingSelection())}
A.addEventListener("pointerdown",h)
const d=r.createElement("span")
d.className="soeditor-ui__color-section-label",d.textContent="Preset colors"
const u=r.createElement("div")
u.className="soeditor-ui__color-grid soeditor-ui__preset-colors"
const f=r.createElement("section")
f.className="soeditor-ui__recent-colors"
const b=r.createElement("span")
b.className="soeditor-ui__color-section-label",b.textContent="Recent colors"
const m=r.createElement("div")
m.className="soeditor-ui__color-grid soeditor-ui__recent-color-grid",f.append(b,m)
const p=void 0===s.Zr||void 0===s.zr?void 0:r.createElement("button"),g=()=>{void 0!==p&&void 0!==s.zr&&(Ta(n,a,s.zr,[]),c.open=!1)}
if(void 0!==p){p.type="button",p.className="soeditor-ui__menu-item soeditor-ui__color-remove",a.setIcon(p,e+".remove","Remove")
const t=r.createElement("span")
t.textContent=s.Zr??"",p.append(t),p.addEventListener("click",g),A.append(p)}const w=o.map(([t,e])=>{const i=r.createElement("button")
i.type="button",i.className="soeditor-ui__color-choice",i.title=t,i.setAttribute("aria-label",t),i.dataset.value=e,i.style.setProperty("--soeditor-choice-color",e)
const o=()=>{O(e)}
return i.addEventListener("click",o),u.append(i),{button:i,click:o}}),v=r.createElement("div")
v.className="soeditor-ui__custom-color"
const y=r.createElement("label")
y.className="soeditor-ui__color-section-label",y.textContent="Color value"
const k=r.createElement("input")
k.type="text",k.className="soeditor-ui__color-value",k.placeholder="#2563eb or rgb(37, 99, 235)",k.autocomplete="off",k.spellcheck=!1,k.setAttribute("aria-label","Color value"),y.append(k)
const C=r.createElement("div")
C.className="soeditor-ui__color-controls"
const I=r.createElement("label")
I.className="soeditor-ui__native-color",I.title="Choose color"
const E=r.createElement("input")
E.type="color",E.value=o[0]?.[1]??"#000000",E.setAttribute("aria-label","Choose color"),I.append(E)
const B=r.createElement("button")
B.type="button",B.className="soeditor-ui__menu-item soeditor-ui__color-apply",B.textContent="Apply color"
const x=r.createElement("span")
x.className="soeditor-ui__color-feedback",x.setAttribute("role","status"),x.setAttribute("aria-live","polite")
const S="Invalid color. Use #2563eb, rgb(37, 99, 235), hsl(217, 91%, 60%), or a color name.",D=()=>{const t=(()=>{const t=va(k.value),e=void 0!==t
return k.setAttribute("aria-invalid",!e+""),x.textContent=e?"":S,t})()
void 0!==t?O(t):k.focus()},M=()=>{const t=va(k.value)
if(void 0===t)return k.setAttribute("aria-invalid","true"),void(x.textContent=S)
Q(t),k.setAttribute("aria-invalid","false"),x.textContent=""},T=()=>{_(E.value)}
B.addEventListener("click",D),k.addEventListener("input",M),E.addEventListener("input",T),E.addEventListener("change",T),C.append(I,B),v.append(y,C,x),A.append(d,u,f,v),c.append(l,A)
let R=[]
function F(){for(const{button:e,click:i}of R)e.removeEventListener("click",i)
R=[],m.replaceChildren()
const t=ya(r)
f.hidden=0===t.length
for(const e of t){const t=r.createElement("button")
t.type="button",t.className="soeditor-ui__color-choice",t.title=e,t.setAttribute("aria-label","Recent color "+e),t.dataset.Ur=e,t.style.setProperty("--soeditor-choice-color",e)
const i=()=>O(e)
t.addEventListener("click",i),R.push({button:t,click:i}),m.append(t)}}function _(t){const e=va(t)
void 0!==e&&(k.value=e,k.setAttribute("aria-invalid","false"),x.textContent="",Q(e))}function Q(t){I.style.setProperty("--soeditor-current-color",t)
const e=(t=>{const e=/^#([\da-f])([\da-f])([\da-f])$/u.exec(t)
return null!==e?`#${e[1]}${e[1]}${e[2]}${e[2]}${e[3]}${e[3]}`:/^#[\da-f]{6}$/u.test(t)?t:void 0})(t)
void 0!==e&&(E.value=e)}function O(t){Ta(n,a,e,[t])&&(((t,e)=>{const i=va(e)
if(void 0===i)return
const o=[i,...ya(t).filter(t=>t!==i)].slice(0,ga)
try{t.defaultView?.localStorage.setItem(pa,JSON.stringify(o))}catch{}})(r,t),F(),c.open=!1)}const N=()=>{if(!c.open)return
F()
const t=a.getEditingFormatState?.(e)
"uniform"===t?.status?_(t.value):"mixed"===t?.status&&(k.value=""),a.refresh()}
return c.addEventListener("toggle",N),F(),_(o[0]?.[1]??"#000000"),{element:c,update:()=>{const i=Ma(n,e)
l.setAttribute("aria-disabled",!i+"")
const o=a.getEditingFormatState?.(e)
Nn(l,t,o,a,i),"uniform"===o?.status?l.style.setProperty("--soeditor-selected-color",o.value):l.style.removeProperty("--soeditor-selected-color")
for(const{button:t}of w){const e=i&&c.open&&"uniform"===o?.status&&r.defaultView?.getComputedStyle(t).backgroundColor===o.value
t.setAttribute("aria-pressed",e+"")}for(const{button:t}of w)t.disabled=!i
void 0!==p&&(p.disabled=!Ma(n,s.zr??"")),k.disabled=!i,E.disabled=!i,B.disabled=!i
for(const{button:t}of R)t.disabled=!i},destroy:()=>{for(const{button:t,click:e}of w)t.removeEventListener("click",e)
for(const{button:t,click:e}of R)t.removeEventListener("click",e)
p?.removeEventListener("click",g),B.removeEventListener("click",D),k.removeEventListener("input",M),E.removeEventListener("input",T),E.removeEventListener("change",T),A.removeEventListener("pointerdown",h),c.removeEventListener("toggle",N)}}}}function va(t){const e=t.trim().toLowerCase()
if(!(0===e.length||e.length>80)&&(/^#[\da-f]{3,8}$/u.test(e)||/^(?:rgb|hsl)a?\([\d.% ,+-]+\)$/u.test(e)||/^[a-z]+$/u.test(e)))return e}function ya(t){try{const e=t.defaultView?.localStorage.getItem(pa)
if(null==e)return[]
const i=JSON.parse(e)
return Array.isArray(i)?i.map(t=>"string"==typeof t?va(t):void 0).filter(t=>void 0!==t).slice(0,ga):[]}catch{return[]}}function ka(t,e,i,o){return({document:s,editor:r,ui:n})=>{const a=s.createElement("details")
a.className="soeditor-ui__menu soeditor-ui__choice-menu"
const c=s.createElement("summary")
c.className="soeditor-ui__button"
const l=s.createElement("span")
l.className="soeditor-ui__current-value","font.size"===e?(c.classList.add("soeditor-ui__value-control"),c.append(l)):n.setIcon(c,e,i),c.title=t,c.setAttribute("aria-label",t)
const A=s.createElement("div")
A.className="soeditor-ui__menu-items soeditor-ui__size-choices",A.dataset.command=e
const h=o.map(([t,i])=>{const o=s.createElement("button")
o.type="button",o.className="soeditor-ui__menu-item",o.textContent=t,o.dataset.value=i,"font.family"===e&&(o.style.fontFamily=i)
const c=()=>{Ta(r,n,e,[i]),a.open=!1}
return o.addEventListener("click",c),A.append(o),{button:o,click:c}})
return a.append(c,A),{element:a,update:()=>{const i=Ma(r,e)
c.setAttribute("aria-disabled",!i+"")
const o=n.getEditingFormatState?.(e)
Nn(c,t,o,n,i)
const s="uniform"===o?.status?o.value:n.translate("mixed"===o?.status?"Mixed":t)
l.textContent!==s&&(l.textContent=s)
for(const{button:t}of h){t.disabled=!i
const e=i&&"uniform"===o?.status&&o.value.toLowerCase().replaceAll('"',"")===t.dataset.value?.toLowerCase().replaceAll('"',"")
t.setAttribute("aria-pressed",e+""),t.classList.toggle("is-active",e)}},destroy:()=>{for(const{button:t,click:e}of h)t.removeEventListener("click",e)}}}}const Ca=new Map([["undo",zn("Undo","editor.undo")],["redo",zn("Redo","editor.redo")],["heading",({document:t,editor:e,ui:i})=>{const o=t.createElement("details")
o.className="soeditor-ui__menu"
const s=t.createElement("summary")
s.className="soeditor-ui__button",s.classList.add("soeditor-ui__value-control")
const r=t.createElement("span")
r.className="soeditor-ui__current-value",s.append(r),s.setAttribute("aria-label","Choose block style")
const n=t.createElement("div")
n.className="soeditor-ui__menu-items soeditor-ui__heading-choices"
const a=[["Paragraph","paragraph.set",[]],...Array.from({length:6},(t,e)=>["Heading "+(e+1),"paragraph.heading",[e+1]]),["DIV","block.div",[]],["Preformatted","codeBlock.toggle",[]],["Code","format.inlineCode",[]]].map(([s,r,a])=>{const c=t.createElement("button")
c.type="button",c.className="soeditor-ui__menu-item soeditor-ui__heading-choice","paragraph.set"===r?c.dataset.block="p":"paragraph.heading"===r&&(c.dataset.block="h"+a[0])
const l=t.createElement("span")
l.textContent=s,c.append(l)
const A=()=>{o.open=!1,Ta(e,i,r,a)}
return c.addEventListener("click",A),n.append(c),{button:c,click:A,command:r}})
return o.append(s,n),{element:o,update:()=>{const t=a.some(({command:t})=>Ma(e,t))
s.setAttribute("aria-disabled",!t+"")
const o=i.getEditingFormatState?.("heading")
Nn(s,"Heading",o,i,t)
const n="uniform"===o?.status?o.value:"",c=i.translate("mixed"===o?.status?"Mixed":"uniform"!==o?.status?"Heading":/^h[1-6]$/u.test(n)?"Heading "+n.slice(1):"div"===n?"DIV":"pre"===n?"Preformatted":"Paragraph")
r.textContent!==c&&(r.textContent=c)
for(const{button:i,command:s}of a)if(Sa(i,e,s),"unavailable"!==o?.status&&void 0!==o&&i.dataset.block){const e=t&&"uniform"===o.status&&o.value===i.dataset.block
i.classList.toggle("is-active",e),i.setAttribute("aria-pressed",e+"")}},destroy:()=>{for(const{button:t,click:e}of a)t.removeEventListener("click",e)}}}],["moreFormatting",({document:t,editor:e,ui:i})=>{const o=t.createElement("details")
o.className="soeditor-ui__menu"
const s=t.createElement("summary")
s.className="soeditor-ui__button",s.setAttribute("aria-label","More text styles"),s.title="More text styles",i.setIcon(s,"format.more","⋯")
const r=t.createElement("div")
r.className="soeditor-ui__menu-items"
const n=[["strike","Strikethrough","format.strike"],["subscript","Subscript","format.subscript"],["superscript","Superscript","format.superscript"],["removeFormat","Remove format","format.remove"]].map(([s,n,a])=>{const c=t.createElement("button")
c.type="button",c.className="soeditor-ui__menu-item",c.textContent=n,c.dataset.Jr=s
const l=()=>{Ta(e,i,a,[])&&(o.open=!1)}
return c.addEventListener("click",l),r.append(c),{button:c,id:a,click:l}})
return o.append(s,r),{element:o,update:()=>{for(const{button:t,id:i}of n)Sa(t,e,i)
s.setAttribute("aria-disabled",n.every(({button:t})=>t.disabled)+"")},destroy:()=>{for(const{button:t,click:e}of n)t.removeEventListener("click",e)}}}],["bold",zn("Bold","format.bold",void 0,"B")],["italic",zn("Italic","format.italic",void 0,"I")],["underline",zn("Underline","format.underline",[],"U")],["strike",zn("Strike","format.strike",[],"S")],["fontFamily",ba],["fontSize",ma],["fontColor",da],["fontBackgroundColor",ua],["highlight",fa],["subscript",zn("Subscript","format.subscript",[],"X₂")],["superscript",zn("Superscript","format.superscript",[],"X²")],["removeFormat",zn("Remove format","format.remove",[],"Tₓ")],["blockquote",zn("Block quote","blockquote.toggle")],["div",zn("DIV block","block.div",[],"DIV")],["alignment",Hn("alignment")],["orderedList",Hn("ordered")],["unorderedList",Hn("unordered")],["outdent",zn("Outdent","format.outdent")],["indent",zn("Indent","format.indent")],["alignLeft",zn("Align left","format.alignment",["left"],"≡←","format.alignment.left")],["alignCenter",zn("Align center","format.alignment",["center"],"≡↔","format.alignment.center")],["alignRight",zn("Align right","format.alignment",["right"],"→≡","format.alignment.right")],["alignJustify",zn("Justify","format.alignment",["justify"],"≣","format.alignment.justify")],["horizontalRule",zn("Horizontal rule","horizontalRule.insert")],["link",({document:t,editor:e,ui:i})=>{const o=t.createElement("button")
o.type="button",o.className="soeditor-ui__button",i.setIcon(o,"link.set","Link"),o.title="Link",o.setAttribute("aria-label","Link")
const s=async()=>{i.restoreEditingSelection()
const s=e.commands.has("link.inspect")&&e.commands.canExecute("link.inspect")?e.execute("link.inspect"):void 0,r="object"==typeof s&&null!==s?s:{},n=i.getEditingSelectionText(),a=await Kn().catch(t=>{Ra(i,t)})
if(void 0===a)return
if(!o.isConnected)return
const{Lr:c,Kr:l}=a,A=e.commands.has("link.attributes.catalog")?e.execute("link.attributes.catalog"):[],h="string"==typeof r.href,d=t.createElement("div")
d.className="soeditor-ui__link-dialog-form"
const u=t.createElement("div")
u.className="soeditor-ui__link-essentials"
const f=Ba(t,u,"Displayed text","text",!1,n),b=Ba(t,u,"Link URL","text",!0,"string"==typeof r.href?r.href:"")
f.autocomplete="off",f.placeholder="Text shown to readers",b.setAttribute("autocomplete","url"),b.inputMode="url",b.placeholder="https://example.com/page",b.spellcheck=!1
const m=t.createElement("details")
m.className="soeditor-ui__link-advanced",m.open=["title","target","rel"].some(t=>"string"==typeof r[t]&&r[t].trim().length>0)||l(r).length>0
const p=t.createElement("summary")
p.textContent="Advanced settings"
const g=t.createElement("div")
g.className="soeditor-ui__link-advanced-fields"
const w=Ba(t,g,"Title","text",!1,"string"==typeof r.title?r.title:"")
w.autocomplete="off",w.placeholder="Optional tooltip"
const v=((t,e,i)=>{const o=t.createElement("div")
o.className="soeditor-ui__field"
const s=t.createElement("span")
s.textContent="Target"
const r=t.createElement("div")
r.className="soeditor-ui__link-target-controls"
const n=t.createElement("select")
n.setAttribute("aria-label","Common target")
const a=t.createElement("option")
a.value="",a.textContent="Choose a common target",n.append(a)
for(const l of Zn){const e=t.createElement("option")
e.value=l.value,e.textContent=l.label,n.append(e)}const c=t.createElement("input")
return c.type="text",c.value=i,c.placeholder="Custom target name",c.setAttribute("aria-label","Target"),c.autocomplete="off",n.addEventListener("change",()=>{0!==n.value.length&&(c.value=n.value,c.dispatchEvent(new Event("input",{bubbles:!0})))}),r.append(n,c),o.append(s,r),e.append(o),c})(t,g,"string"==typeof r.target?r.target:""),y=((t,e,i)=>{const o=t.createElement("div")
o.className="soeditor-ui__field"
const s=t.createElement("span")
s.textContent="Relationship"
const r=t.createElement("div")
r.className="soeditor-ui__link-rel-choices",r.setAttribute("role","group"),r.setAttribute("aria-label","Common relationships")
const n=new Set(i.split(/\s+/u).map(t=>t.trim().toLowerCase()).filter(t=>t.length>0)),a=new Map,c=t=>{const e=a.get(t)
if(void 0===e)return
const i=n.has(t)
e.classList.toggle("is-selected",i),e.setAttribute("aria-pressed",i+"")},l=e=>{const i=t.createElement("button")
i.type="button",i.className="soeditor-ui__link-rel-tag",i.textContent=e,i.title="Toggle relationship "+e,i.setAttribute("aria-label","Relationship "+e),i.addEventListener("click",()=>{n.has(e)?n.delete(e):n.add(e),c(e)}),a.set(e,i),r.append(i),c(e)}
for(const f of Un)l(f)
for(const f of n)a.has(f)||l(f)
const A=t.createElement("div")
A.className="soeditor-ui__link-rel-custom"
const h=t.createElement("input")
h.type="text",h.placeholder="Custom relationship",h.autocomplete="off",h.setAttribute("aria-label","Add relationship")
const d=t.createElement("button")
d.type="button",d.className="soeditor-ui__dialog-action",d.textContent="Add"
const u=()=>{const t=h.value.trim().toLowerCase()
if(!/^[a-z][a-z0-9.-]{0,63}$/u.test(t))return h.setCustomValidity("Use one relationship token beginning with a letter; letters, numbers, dots, and hyphens are supported."),void h.reportValidity()
h.setCustomValidity(""),n.add(t),a.has(t)?c(t):l(t),h.value="",h.focus()}
return h.addEventListener("input",()=>h.setCustomValidity("")),h.addEventListener("keydown",t=>{"Enter"===t.key&&(t.preventDefault(),u())}),d.addEventListener("click",u),A.append(h,d),o.append(s,r,A),e.append(o),{value:()=>[...n].sort().join(" ")}})(t,g,"string"==typeof r.rel?r.rel:""),k=c(t,g,l(r),A,i.translate)
m.append(p,g),d.append(u,m)
const C=()=>{if(b.value=b.value.trim(),!b.reportValidity())return
const t=k.value()
if(void 0===t)return
const o=f.value||b.value,s={href:b.value,customAttributes:t,...0===w.value.length?{}:{title:w.value},...0===v.value.length?{}:{target:v.value},...0===y.value().length?{}:{rel:y.value()}},r=o===n?"link.set":"link.setText"
Ta(e,i,r,["link.set"===r?s:{...s,text:o}])&&I.close()},I=i.dialogs.open({title:h?"Edit link":"Link",returnFocus:o,content:d,actions:[...h?[{kind:"danger",label:"Remove link",run:()=>{Ta(e,i,"link.remove",[])&&I.close()}}]:[],{kind:"primary",label:h?"Update link":"Insert link",run:C}]})
I.element.classList.add("soeditor-ui__link-dialog"),d.addEventListener("keydown",e=>{const i=t.defaultView,o=null!==i&&e.target instanceof i.HTMLInputElement
"Enter"!==e.key||e.isComposing||e.defaultPrevented||!o||(e.preventDefault(),C())}),b.focus(),b.select()}
return o.addEventListener("click",s),{element:o,update:()=>Sa(o,e,"link.set"),destroy:()=>o.removeEventListener("click",s)}}],["unlink",zn("Remove link","link.remove",[],"⌁̸")],["link-internal",zn("Choose internal link","link.pick",["internal"])],["link-file",zn("Choose file link","link.pick",["file"])],["specialCharacter",({document:t,editor:e,ui:i})=>{const o=t.createElement("details")
o.className="soeditor-ui__menu"
const s=t.createElement("summary")
s.className="soeditor-ui__button",i.setIcon(s,"specialCharacter.insert","Special character"),s.title="Special character",s.setAttribute("aria-label","Choose special character")
const r=t.createElement("div")
r.className="soeditor-ui__menu-items soeditor-ui__character-grid"
const n=(t=>{if(!1===t)return!1
if(void 0===t)return Jn
if(!Array.isArray(t)||t.length>200)throw new TypeError("cms.specialCharacters must be false or an array of at most 200 characters.")
return Object.freeze(t.map((t,e)=>{if("string"!=typeof t||0===t.length||Array.from(t).length>4||Array.from(t).some(t=>{const e=t.codePointAt(0)??0
return e<=31||127===e}))throw new TypeError(`cms.specialCharacters[${e+""}] must be one bounded printable value.`)
return t}))})(e.config.get("cms.specialCharacters")),a=[]
for(const A of!1===n?[]:n){const s=t.createElement("button")
s.type="button",s.className="soeditor-ui__menu-item",s.textContent=A,s.title="Insert "+A,s.setAttribute("aria-label","Insert "+A)
const n=()=>{Ta(e,i,"specialCharacter.insert",[A]),o.open=!1}
s.addEventListener("click",n),a.push({button:s,click:n}),r.append(s)}const c=t.createElement("button")
c.type="button",c.className="soeditor-ui__menu-item soeditor-ui__character-custom",c.textContent="Custom…"
const l=()=>{let s
const r=i.dialogs.open({title:"Special character",content:e=>{s=Ba(t,e,"Character","text",!0)},actions:[{label:"Insert character",kind:"primary",run:()=>{Ta(e,i,"specialCharacter.insert",[s.value])&&(r.close(),o.open=!1)}}]})}
return c.addEventListener("click",l),r.append(c),o.append(s,r),o.hidden=!1===n,{element:o,update:()=>{const t=Ma(e,"specialCharacter.insert")
s.setAttribute("aria-disabled",!t+"")
for(const{button:e}of a)e.disabled=!t
c.disabled=!t},destroy:()=>{for(const{button:t,click:e}of a)t.removeEventListener("click",e)
c.removeEventListener("click",l)}}}],["anchor",Ln],["pageBreak",zn("Page break","pageBreak.insert")],["placeholder",Pn],["image",Vn],["image-actions",({document:t,editor:e,ui:i})=>{const o=t.createElement("details")
o.className="soeditor-ui__menu soeditor-ui__image-menu"
const s=t.createElement("summary")
s.className="soeditor-ui__button",i.setIcon(s,"image.actions","Insert image"),s.title="Insert image",s.setAttribute("aria-label","Choose image insertion method")
const r=t.createElement("div")
r.className="soeditor-ui__menu-items",r.setAttribute("role","menu")
const n=t.createElement("input")
n.type="file",n.accept="image/*",n.hidden=!0
const a=Xn(t,i,"image.upload","Upload from computer"),c=Xn(t,i,"image.browse","Insert with file manager"),l=Xn(t,i,"image.insert","Insert via URL"),A=()=>{o.open=!1},h=()=>{A(),n.click()},d=()=>{const t=n.files?.item(0)
n.value="",null!=t&&(A(),Ta(e,i,"image.upload",[{file:t,name:t.name,type:t.type}]))},u=()=>{A(),Ta(e,i,"image.browse",[])},f=()=>{let o,s
A()
const r=i.dialogs.open({title:"Insert image via URL",content:e=>{e.closest(".soeditor-ui__dialog")?.classList.add("soeditor-ui__image-dialog"),o=Ba(t,e,"Image URL","url",!0),s=Ba(t,e,"Alternative text","text")},actions:[{kind:"primary",label:"Insert image",run:()=>{Ta(e,i,"image.insert",[{alt:s.value,src:o.value}])&&r.close()}}]})}
return a.addEventListener("click",h),n.addEventListener("change",d),c.addEventListener("click",u),l.addEventListener("click",f),r.append(a,c,l,n),o.append(s,r),{element:o,update:()=>{const t=Ma(e,"image.upload"),i=Ma(e,"image.browse"),o=Ma(e,"image.insert")
a.disabled=!t,c.disabled=!i,l.disabled=!o,s.setAttribute("aria-disabled",(!t&&!i&&!o)+"")},destroy:()=>{a.removeEventListener("click",h),n.removeEventListener("change",d),c.removeEventListener("click",u),l.removeEventListener("click",f)}}}],["table",({document:t,editor:e,ui:i})=>{const o=t.createElement("button")
let s
o.type="button",o.className="soeditor-ui__button",i.setIcon(o,"table.insert","Table"),o.title="Insert table",o.setAttribute("aria-label","Insert table"),o.setAttribute("aria-expanded","false")
const r=()=>{s?.close(),s=void 0,o.setAttribute("aria-expanded","false")},n=()=>{if(void 0!==s){const t=s.element.isConnected
if(r(),t)return}s=i.balloons.show({anchor:o,content:s=>{s.classList.add("soeditor-ui__table-picker"),s.setAttribute("aria-label","Choose table size")
const n=t.createElement("span")
n.className="soeditor-ui__table-picker-status",n.setAttribute("aria-live","polite"),n.textContent="Choose table size"
const a=t.createElement("div")
a.className="soeditor-ui__table-picker-grid",a.setAttribute("role","grid")
for(let c=1;c<=10;c+=1)for(let s=1;s<=10;s+=1){const l=t.createElement("button")
l.type="button",l.className="soeditor-ui__table-picker-cell",l.dataset.row=c+"",l.dataset.column=s+"",l.setAttribute("role","gridcell"),l.setAttribute("aria-label",`Insert ${c+""} by ${s+""} table`)
const A=()=>{n.textContent=`${c+""} × ${s+""} table`
for(const t of Array.from(a.children))t.classList.toggle("is-selected",Number(t.getAttribute("data-row"))<=c&&Number(t.getAttribute("data-column"))<=s)}
l.addEventListener("pointerenter",A),l.addEventListener("focus",A),l.addEventListener("keydown",t=>{const e="ArrowUp"===t.key?[-1,0]:"ArrowDown"===t.key?[1,0]:"ArrowLeft"===t.key?[0,-1]:"ArrowRight"===t.key?[0,1]:void 0
if(void 0===e)return void("Escape"===t.key&&(t.preventDefault(),r(),o.focus()))
t.preventDefault()
const i=Math.max(1,Math.min(10,c+(e[0]??0))),n=Math.max(1,Math.min(10,s+(e[1]??0)))
a.querySelector(`[data-row="${i+""}"][data-column="${n+""}"]`)?.focus()}),l.addEventListener("click",()=>{Ta(e,i,"table.insert",[{columns:s,rows:c}])&&r()}),a.append(l)}s.append(n,a),Kn().then(({Pr:o})=>{s.isConnected&&o(t,s,n,(t,o)=>Ta(e,i,"table.insert",[{columns:o,rows:t}]),r)}).catch(t=>Ra(i,t))}}),o.setAttribute("aria-expanded","true"),s.element.querySelector('.soeditor-ui__table-picker-cell[data-row="3"][data-column="3"]')?.focus()}
return o.addEventListener("click",n),{element:o,update:()=>{Sa(o,e,"table.insert"),o.disabled&&r()},destroy:()=>{r(),o.removeEventListener("click",n)}}}],["tableProperties",sa],["tableRowProperties",ra],["tableCellProperties",na],["cleanHtml",zn("Clean HTML","html.cleanup")]])
function Ia(t,e,i,o="text",s=t){return Ea(t,e,(t,e)=>{let s
return{content:e=>{s=Ba(t,e,i,o,!0)},run:()=>e(s.value)}},s)}function Ea(t,e,i,o=t){return({document:s,editor:r,ui:n})=>{const a=s.createElement("button")
a.type="button",a.className="soeditor-ui__button",n.setIcon(a,e,o),a.title=t,a.setAttribute("aria-label",t)
const c=async()=>{const o={},c=await Promise.resolve(i(s,(...t)=>{Ta(r,n,e,t)&&o.Vr?.close()},r)).catch(t=>{Ra(n,t)})
void 0!==c&&a.isConnected&&(o.Vr=n.dialogs.open({title:t,content:c.content,actions:[{label:"Insert "+t.toLowerCase(),kind:"primary",run:()=>c.run()}]}))}
return a.addEventListener("click",c),{element:a,update:()=>Da(a,r,e),destroy:()=>a.removeEventListener("click",c)}}}function Ba(t,e,i,o,s=!1,r=""){const n=t.createElement("label")
n.className="soeditor-ui__field"
const a=t.createElement("span")
a.textContent=i
const c=t.createElement("input")
return c.type=o,c.required=s,c.value=r,"number"===o&&(c.min="1",c.max="20"),n.append(a,c),e.append(n),c}function xa(t){return"string"==typeof t||"number"==typeof t?t+"":""}function Sa(t,e,i){Da(t,e,i)
const o=!(t.disabled||!e.commands.has(i))&&e.commands.isActive(i)
t.setAttribute("aria-pressed",o+""),t.classList.toggle("is-active",o)}function Da(t,e,i){t.disabled=!Ma(e,i)}function Ma(t,e){return t.commands.has(e)&&t.commands.canExecute(e)}function Ta(t,e,i,o){try{e.restoreEditingSelection()
const r=t.execute(i,...o)
return("object"==typeof(s=r)&&null!==s||"function"==typeof s)&&"function"==typeof Reflect.get(s,"then")&&Promise.resolve(r).catch(t=>Ra(e,t)),!0}catch(r){return Ra(e,r),!1}var s}function Ra(t,e){try{t.notifications.show({message:e instanceof Error?e.message:e+"",severity:"error"})}catch{}}function Fa(t,e,i){return Object.freeze({id:"default."+t,chord:e,command:i})}class _a extends Error{constructor(){super("Editor UI has been destroyed."),this.name="EditorUiDestroyedError"}}function Qa(t="en",e=[],i){const o=Oa(t)
for(const l of e)Na(l)
if(void 0!==i&&"ltr"!==i&&"rtl"!==i)throw new TypeError("Editor UI direction must be ltr or rtl.")
const s=o.split("-")[0]??o,r=[o,s,"en"].find(t=>e.some(e=>Oa(e.locale)===t)),n=e.filter(t=>Oa(t.locale)===r),a=Object.assign({},...n.map(({messages:t})=>t)),c=i??n.at(-1)?.direction??(t=>/^(?:ar|fa|he|ur)(?:-|$)/iu.test(t)?"rtl":"ltr")(o)
return Object.freeze({direction:c,locale:o,translate:t=>a[t]??t})}function Oa(t){if("string"!=typeof t||0===t.trim().length)throw new TypeError("Editor UI locale must not be empty.")
const e=t.trim().replaceAll("_","-").toLowerCase()
return"zh"===e||e.startsWith("zh-cn")||e.startsWith("zh-hans")?"zh-CN":e.startsWith("zh-tw")||e.startsWith("zh-hk")||e.startsWith("zh-hant")?"zh-TW":"en"===e||e.startsWith("en-")?"en":t.trim()}function Na(t){if("object"!=typeof t||null===t)throw new TypeError("An editor UI translation resource must be an object.")
if(Oa(t.locale),void 0!==t.direction&&"ltr"!==t.direction&&"rtl"!==t.direction)throw new TypeError("Translation resource direction must be ltr or rtl.")
if("object"!=typeof t.messages||null===t.messages||Array.isArray(t.messages))throw new TypeError("Translation resource messages must be an object.")
for(const[e,i]of Object.entries(t.messages))if(0===e.length||"string"!=typeof i)throw new TypeError("Translation resource messages require non-empty string keys and string values.")}function qa(t,e){void 0!==e&&("string"==typeof e?t.textContent=e:"function"==typeof e?e(t):t.append(e))}function ja(t){let e=!0
return()=>{e&&(e=!1,t())}}function Ga(t){return t instanceof Error?t.message:t+""}const Ha=new Set(["Alt","Mod","Shift"])
function Ka(t,e){const i=e.ctrlKey||e.metaKey
return!e.isComposing&&Ya(e.key)===t.key&&e.altKey===t.alt&&e.shiftKey===t.shift&&i===t.mod}function Ya(t){return 1===t.length?t.toLowerCase():t}const Wa=new WeakMap,za=J("soeditor.ui-registry")
class Za extends Error{constructor(t,e){super(`UI ${t} "${e}" is already registered.`),this.name="UiContributionAlreadyRegisteredError"}}function Ua(t){const e=Wa.get(t)
if(void 0===e)throw Error("UI registry storage is unavailable.")
return e}const Ja="http://www.w3.org/2000/svg"
function La(t,e="0 0 1792 1792"){return{Xr:[t],variant:"solid",viewBox:e}}const Pa=Object.freeze({"format.more":{Xr:["M5 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"],variant:"solid"},"block.div":{text:"DIV",variant:"solid"},"view.blocks":{Xr:["M3 3h18v5H3Zm2 2v1h14V5ZM3 10h8v11H3Zm2 2v7h4v-7Zm8-2h8v11h-8Zm2 2v7h4v-7Z"],variant:"solid"},"font.color.remove":{Xr:["m3 19 7-17h4l5.25 12.75-2.5 2.5L15.9 15H8.1l-1.4 4Zm6.25-7h5.35L12 5ZM2.1 3.9 3.9 2.1l18 18-1.8 1.8Z"],variant:"solid"},"font.backgroundColor.remove":{Xr:["m12 2 7 14H8.8L5.5 12.7ZM3 19h18v4H3ZM2.1 3.9 3.9 2.1l18 18-1.8 1.8Z"],variant:"solid"},"font.highlight.remove":{Xr:["m14.1 2 5.2 4-4.45 5.8-2.15-2.15L16 5.4l-1.65-1.25-3.3 4.55-2.1-2.1ZM4 15l1 2.5h5.5l.95-1.25L5.9 10.7ZM3 20h18v3H3ZM2.1 3.9 3.9 2.1l18 18-1.8 1.8Z"],variant:"solid"},"link.edit":{Xr:["M4 20h4L19 9l-4-4L4 16Z","m13-13 4 4"]},"link.pick":{Xr:["M2 3h20v18H2Zm3 4v2h14V7Zm0 4v2h10v-2Zm0 4v2h12v-2Z"],variant:"solid"},"link.file.browse":{Xr:["M1 5h8l2 2h12v13H1Zm12 5v3h-3v2h3v3l5-4Z"],variant:"solid"},"anchor.insert":{Xr:["M10.5 2h3v3H17v2h-3.5v9.75c2.7-.53 4.45-2.05 5.25-4.55L22 13.25C20.7 18.6 17.37 21.5 12 22c-5.37-.5-8.7-3.4-10-8.75l3.25-1.05c.8 2.5 2.55 4.02 5.25 4.55V7H7V5h3.5Z"],variant:"solid"},"image.browse":{Xr:["M1 5h8l2 2h12v13H1Zm14 5v4h-3l5 5 5-5h-3v-4Z"],variant:"solid"},"image.upload":{Xr:["M2 4h20v16H2Zm8 13h4v-5h3l-5-5-5 5h3Z"],variant:"solid"},"blockquote.toggle":{Xr:["M5 6h6v6H7v5H4v-7a4 4 0 0 1 4-4","M14 6h6v6h-4v5h-3v-7a4 4 0 0 1 4-4"],variant:"solid"},"editor.preview.close":{Xr:["m10 4 2.2 2.2L7.9 10.5H22v3H7.9l4.3 4.3L10 20l-8-8Z"],variant:"solid"},"editor.markdown":{text:"M↓"},"html.cleanup":{Xr:["m3 15 8.5-11a2 2 0 0 1 2.8-.35l5.9 4.55a2 2 0 0 1 .35 2.8L13 21H6.5a2 2 0 0 1-1.22-.42L3.35 19A2 2 0 0 1 3 15Zm3.2 1.45L8.1 18H12l3.55-4.65-4.7-3.6Z"],variant:"solid"},"email.analyze":{Xr:["M2 4h20v16H2Zm2 3v1l8 5 8-5V7l-8 5Zm12 8h3v3h-3Z"],variant:"solid"},"email.optimize":{Xr:["M2 4h20v16H2Zm2 3v1l8 5 8-5V7l-8 5Zm10.2 9.4 2.2 2.2 4.4-5 1.8 1.6-6.1 6.8-4-4Z"],variant:"solid"},"ui.accessibility.help":{Xr:["M12 1a11 11 0 1 1 0 22 11 11 0 0 1 0-22Zm0 17.2a1.4 1.4 0 1 0 0 2.8 1.4 1.4 0 0 0 0-2.8ZM8.1 8.7h3c0-1.3.5-2 1.6-2 1 0 1.6.5 1.6 1.35 0 .65-.38 1.1-1.35 1.85-1.53 1.17-2.4 2.25-2.35 4.3v1.05h2.85v-.8c0-1.15.4-1.7 1.75-2.73 1.4-1.07 2.25-2.13 2.25-3.82 0-2.35-1.87-3.9-4.7-3.9-3.03 0-4.7 1.75-4.7 4.7Z"],variant:"solid"},"ui.toolbar.toggle":{Xr:["M5.4 8.4 12 15l6.6-6.6 2.1 2.1-8.7 8.7-8.7-8.7Z"],variant:"solid"},"editor.maximize.restore":{Xr:["M7 2h15v15h-4V6H7ZM2 7h13v15H2Zm4 4v7h5v-7Z"],variant:"solid"},"editor.save":{Xr:["M3 2h15l3 3v17H3Zm4 2v6h10V4Zm0 10v6h10v-6Zm2-10h6v4H9Z"],variant:"solid"},"pageBreak.insert":{Xr:["M2 5h20v3H2Zm0 11h20v3H2Zm3-5h3v2H5Zm5 0h4v2h-4Zm6 0h3v2h-3Z"],variant:"solid"},"placeholder.insert":{text:"{}",variant:"solid"},"table.properties":{Xr:["M3 5h14v14H3z","M3 10h14","M8 5v14","M19 15h3","M20.5 13.5v3"]},"table.row.properties":{Xr:["M3 5h14v14H3z","M3 10h14","M3 14h14","M19 12h3","M20.5 10.5v3"]},"table.cell.properties":{Xr:["M3 5h14v14H3z","M3 10h14","M8 5v14","M19 12h3","M20.5 10.5v3"]},"table.row.insertAfter":{Xr:["M3 4h14v14H3z","M3 9h14","M3 14h14","M20 13v7","M17 16.5h6"]},"table.row.remove":{Xr:["M3 4h14v14H3z","M3 9h14","M3 14h14","M17 17h6"]},"table.column.insertAfter":{Xr:["M3 4h14v14H3z","M8 4v14","M13 4v14","M20 13v7","M17 16.5h6"]},"table.column.remove":{Xr:["M3 4h14v14H3z","M8 4v14","M13 4v14","M17 17h6"]},"table.header.toggle":{Xr:["M3 4h18v16H3z","M3 9h18","M9 4v16","M15 4v16"]},"table.cells.merge":{Xr:["M3 5h18v14H3z","m8 12 3-3","m-3 3 3 3","m8-3-3-3","m3 3-3 3"]},"table.cell.split":{Xr:["M3 5h18v14H3z","M12 5v14","m9 12-3-3","m3 3-3 3","m6-3 3-3","m-3 3 3 3"]},"table.cells.clear":{Xr:["M3 5h18v14H3z","m7 8 4 4","m0-4-4 4"]},"table.remove":{Xr:["M3 5h18v14H3z","m8 8 8 8","m0-8-8 8"]},"editor.undo":La("M1664 896q0 156-61 298t-164 245-245 164-298 61q-172 0-327-72.5t-264-204.5q-7-10-6.5-22.5t8.5-20.5l137-138q10-9 25-9 16 2 23 12 73 95 179 147t225 52q104 0 198.5-40.5t163.5-109.5 109.5-163.5 40.5-198.5-40.5-198.5-109.5-163.5-163.5-109.5-198.5-40.5q-98 0-188 35.5t-160 101.5l137 138q31 30 14 69-17 40-59 40h-448q-26 0-45-19t-19-45v-448q0-42 40-59 39-17 69 14l130 129q107-101 244.5-156.5t284.5-55.5q156 0 298 61t245 164 164 245 61 298z"),"editor.redo":La("M1664 256v448q0 26-19 45t-45 19h-448q-42 0-59-40-17-39 14-69l138-138q-148-137-349-137-104 0-198.5 40.5t-163.5 109.5-109.5 163.5-40.5 198.5 40.5 198.5 109.5 163.5 163.5 109.5 198.5 40.5q119 0 225-52t179-147q7-10 23-12 14 0 25 9l137 138q9 8 9.5 20.5t-7.5 22.5q-109 132-264 204.5t-327 72.5q-156 0-298-61t-245-164-164-245-61-298 61-298 164-245 245-164 298-61q147 0 284.5 55.5t244.5 156.5l130-129q29-31 70-14 39 17 39 59z"),"format.bold":La("M747 1521q74 32 140 32 376 0 376-335 0-114-41-180-27-44-61.5-74t-67.5-46.5-80.5-25-84-10.5-94.5-2q-73 0-101 10 0 53-.5 159t-.5 158q0 8-1 67.5t-.5 96.5 4.5 83.5 12 66.5zm-14-746q42 7 109 7 82 0 143-13t110-44.5 74.5-89.5 25.5-142q0-70-29-122.5t-79-82-108-43.5-124-14q-50 0-130 13 0 50 4 151t4 152q0 27-.5 80t-.5 79q0 46 1 69zm-541 889 2-94q15-4 85-16t106-27q7-12 12.5-27t8.5-33.5 5.5-32.5 3-37.5.5-34v-65.5q0-982-22-1025-4-8-22-14.5t-44.5-11-49.5-7-48.5-4.5-30.5-3l-4-83q98-2 340-11.5t373-9.5q23 0 68.5.5t67.5.5q70 0 136.5 13t128.5 42 108 71 74 104.5 28 137.5q0 52-16.5 95.5t-39 72-64.5 57.5-73 45-84 40q154 35 256.5 134t102.5 248q0 100-35 179.5t-93.5 130.5-138 85.5-163.5 48.5-176 14q-44 0-132-3t-132-3q-106 0-307 11t-231 12z"),"format.italic":La("M384 1662l17-85q6-2 81.5-21.5t111.5-37.5q28-35 41-101 1-7 62-289t114-543.5 52-296.5v-25q-24-13-54.5-18.5t-69.5-8-58-5.5l19-103q33 2 120 6.5t149.5 7 120.5 2.5q48 0 98.5-2.5t121-7 98.5-6.5q-5 39-19 89-30 10-101.5 28.5t-108.5 33.5q-8 19-14 42.5t-9 40-7.5 45.5-6.5 42q-27 148-87.5 419.5t-77.5 355.5q-2 9-13 58t-20 90-16 83.5-6 57.5l1 18q17 4 185 31-3 44-16 99-11 0-32.5 1.5t-32.5 1.5q-29 0-87-10t-86-10q-138-2-206-2-51 0-143 9t-121 11z"),"format.underline":La("M176 223q-37-2-45-4l-3-88q13-1 40-1 60 0 112 4 132 7 166 7 86 0 168-3 116-4 146-5 56 0 86-2l-1 14 2 64v9q-60 9-124 9-60 0-79 25-13 14-13 132 0 13 .5 32.5t.5 25.5l1 229 14 280q6 124 51 202 35 59 96 92 88 47 177 47 104 0 191-28 56-18 99-51 48-36 65-64 36-56 53-114 21-73 21-229 0-79-3.5-128t-11-122.5-13.5-159.5l-4-59q-5-67-24-88-34-35-77-34l-100 2-14-3 2-86h84l205 10q76 3 196-10l18 2q6 38 6 51 0 7-4 31-45 12-84 13-73 11-79 17-15 15-15 41 0 7 1.5 27t1.5 31q8 19 22 396 6 195-15 304-15 76-41 122-38 65-112 123-75 57-182 89-109 33-255 33-167 0-284-46-119-47-179-122-61-76-83-195-16-80-16-237v-333q0-188-17-213-25-36-147-39zm1488 1409v-64q0-14-9-23t-23-9h-1472q-14 0-23 9t-9 23v64q0 14 9 23t23 9h1472q14 0 23-9t9-23z"),"format.strike":La("M1760 896q14 0 23 9t9 23v64q0 14-9 23t-23 9h-1728q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h1728zm-1277-64q-28-35-51-80-48-97-48-188 0-181 134-309 133-127 393-127 50 0 167 19 66 12 177 48 10 38 21 118 14 123 14 183 0 18-5 45l-12 3-84-6-14-2q-50-149-103-205-88-91-210-91-114 0-182 59-67 58-67 146 0 73 66 140t279 129q69 20 173 66 58 28 95 52h-743zm507 256h411q7 39 7 92 0 111-41 212-23 55-71 104-37 35-109 81-80 48-153 66-80 21-203 21-114 0-195-23l-140-40q-57-16-72-28-8-8-8-22v-13q0-108-2-156-1-30 0-68l2-37v-44l102-2q15 34 30 71t22.5 56 12.5 27q35 57 80 94 43 36 105 57 59 22 132 22 64 0 139-27 77-26 122-86 47-61 47-129 0-84-81-157-34-29-137-71z"),"format.subscript":La("M1025 1369v167h-248l-159-252-24-42q-8-9-11-21h-3l-9 21q-10 20-25 44l-155 250h-258v-167h128l197-291-185-272h-137v-168h276l139 228q2 4 23 42 8 9 11 21h3q3-9 11-21l25-42 140-228h257v168h-125l-184 267 204 296h109zm639 217v206h-514l-4-27q-3-45-3-46 0-64 26-117t65-86.5 84-65 84-54.5 65-54 26-64q0-38-29.5-62.5t-70.5-24.5q-51 0-97 39-14 11-36 38l-105-92q26-37 63-66 80-65 188-65 110 0 178 59.5t68 158.5q0 66-34.5 118.5t-84 86-99.5 62.5-87 63-41 73h232v-80h126z"),"format.superscript":La("M1025 1369v167h-248l-159-252-24-42q-8-9-11-21h-3l-9 21q-10 20-25 44l-155 250h-258v-167h128l197-291-185-272h-137v-168h276l139 228q2 4 23 42 8 9 11 21h3q3-9 11-21l25-42 140-228h257v168h-125l-184 267 204 296h109zm637-679v206h-514l-3-27q-4-28-4-46 0-64 26-117t65-86.5 84-65 84-54.5 65-54 26-64q0-38-29.5-62.5t-70.5-24.5q-51 0-97 39-14 11-36 38l-105-92q26-37 63-66 83-65 188-65 110 0 178 59.5t68 158.5q0 56-24.5 103t-62 76.5-81.5 58.5-82 50.5-65.5 51.5-30.5 63h232v-80h126z"),"format.remove":La("M832 1408l336-384h-768l-336 384h768zm1013-1077q15 34 9.5 71.5t-30.5 65.5l-896 1024q-38 44-96 44h-768q-38 0-69.5-20.5t-47.5-54.5q-15-34-9.5-71.5t30.5-65.5l896-1024q38-44 96-44h768q38 0 69.5 20.5t47.5 54.5z"),"paragraph.heading":La("M1534 189v73q0 29-18.5 61t-42.5 32q-50 0-54 1-26 6-32 31-3 11-3 64v1152q0 25-18 43t-43 18h-108q-25 0-43-18t-18-43v-1218h-143v1218q0 25-17.5 43t-43.5 18h-108q-26 0-43.5-18t-17.5-43v-496q-147-12-245-59-126-58-192-179-64-117-64-259 0-166 88-286 88-118 209-159 111-37 417-37h479q25 0 43 18t18 43z"),"image.insert":La("M576 576q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm1024 384v448h-1408v-192l320-320 160 160 512-512zm96-704h-1600q-13 0-22.5 9.5t-9.5 22.5v1216q0 13 9.5 22.5t22.5 9.5h1600q13 0 22.5-9.5t9.5-22.5v-1216q0-13-9.5-22.5t-22.5-9.5zm160 32v1216q0 66-47 113t-113 47h-1600q-66 0-113-47t-47-113v-1216q0-66 47-113t113-47h1600q66 0 113 47t47 113z"),"image.actions":La("M576 576q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm1024 384v448h-1408v-192l320-320 160 160 512-512zm96-704h-1600q-13 0-22.5 9.5t-9.5 22.5v1216q0 13 9.5 22.5t22.5 9.5h1600q13 0 22.5-9.5t9.5-22.5v-1216q0-13-9.5-22.5t-22.5-9.5zm160 32v1216q0 66-47 113t-113 47h-1600q-66 0-113-47t-47-113v-1216q0-66 47-113t113-47h1600q66 0 113 47t47 113z"),"table.insert":La("M576 1376v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm0-384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm512 384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm-512-768v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm512 384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm512 384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm-512-768v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm512 384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm0-384v-192q0-14-9-23t-23-9h-320q-14 0-23 9t-9 23v192q0 14 9 23t23 9h320q14 0 23-9t9-23zm128-320v1088q0 66-47 113t-113 47h-1344q-66 0-113-47t-47-113v-1088q0-66 47-113t113-47h1344q66 0 113 47t47 113z"),"horizontalRule.insert":La("M1600 736v192q0 40-28 68t-68 28h-1216q-40 0-68-28t-28-68v-192q0-40 28-68t68-28h1216q40 0 68 28t28 68z"),"specialCharacter.insert":La("m240.443652 220.45085h-47.410809v-10.342138c13.89973-8.43655 25.752896-19.844464 34.686646-33.469923 11.445525-17.455846 17.496072-37.709239 17.496072-58.570077C245.215561 58.479515 196.007045 10 135.522003 10S25.829373 58.479517 25.829373 118.069626c0 20.860839 6.050547 41.113316 17.497001 58.570077 8.93375 13.625459 20.787845 25.032458 34.686646 33.469008v10.342138H30.600354c-10.256959 0-18.571354 8.191376-18.571354 18.296574 0 10.105198 8.314395 18.296574 18.571354 18.296574h65.98402c10.256959 0 18.571354-8.191376 18.571354-18.296574v-39.496814c0-7.073455-4.137698-13.51202-10.626529-16.537358-25.24497-11.772016-41.557118-37.145704-41.557118-64.643625 0-39.411735 32.545369-71.476481 72.549922-71.476481 40.004553 0 72.550851 32.064746 72.550851 71.476481 0 27.497006-16.312149 52.87161-41.557118 64.643625-6.487902 3.026253-10.6256 9.464818-10.6256 16.537358v39.496814c0 10.105198 8.314395 18.296574 18.571354 18.296574h65.982163c10.256959 0 18.571354-8.191376 18.571354-18.296574 0-10.105198-8.314395-18.296574-18.571354-18.296574z","0 0 270 270"),"link.set":La("M1520 1216q0-40-28-68l-208-208q-28-28-68-28-42 0-72 32 3 3 19 18.5t21.5 21.5 15 19 13 25.5 3.5 27.5q0 40-28 68t-68 28q-15 0-27.5-3.5t-25.5-13-19-15-21.5-21.5-18.5-19q-33 31-33 73 0 40 28 68l206 207q27 27 68 27 40 0 68-26l147-146q28-28 28-67zm-703-705q0-40-28-68l-206-207q-28-28-68-28-39 0-68 27l-147 146q-28 28-28 67 0 40 28 68l208 208q27 27 68 27 42 0 72-31-3-3-19-18.5t-21.5-21.5-15-19-13-25.5-3.5-27.5q0-40 28-68t68-28q15 0 27.5 3.5t25.5 13 19 15 21.5 21.5 18.5 19q33-31 33-73zm895 705q0 120-85 203l-147 146q-83 83-203 83-121 0-204-85l-206-207q-83-83-83-203 0-123 88-209l-88-88q-86 88-208 88-120 0-204-84l-208-208q-84-84-84-204t85-203l147-146q83-83 203-83 121 0 204 85l206 207q83 83 83 203 0 123-88 209l88 88q86-88 208-88 120 0 204 84l208 208q84 84 84 204z"),"link.remove":La("M503 1271l-256 256q-10 9-23 9-12 0-23-9-9-10-9-23t9-23l256-256q10-9 23-9t23 9q9 10 9 23t-9 23zm169 41v320q0 14-9 23t-23 9-23-9-9-23v-320q0-14 9-23t23-9 23 9 9 23zm-224-224q0 14-9 23t-23 9h-320q-14 0-23-9t-9-23 9-23 23-9h320q14 0 23 9t9 23zm1264 128q0 120-85 203l-147 146q-83 83-203 83-121 0-204-85l-334-335q-21-21-42-56l239-18 273 274q27 27 68 27.5t68-26.5l147-146q28-28 28-67 0-40-28-68l-274-275 18-239q35 21 56 42l336 336q84 86 84 204zm-617-724-239 18-273-274q-28-28-68-28-39 0-68 27l-147 146q-28 28-28 67 0 40 28 68l274 274-18 240q-35-21-56-42l-336-336q-84-86-84-204 0-120 85-203l147-146q83-83 203-83 121 0 204 85l334 335q21 21 42 56zm633 84q0 14-9 23t-23 9h-320q-14 0-23-9t-9-23 9-23 23-9h320q14 0 23 9t9 23zm-544-544v320q0 14-9 23t-23 9-23-9-9-23v-320q0-14 9-23t23-9 23 9 9 23zm407 151-256 256q-11 9-23 9t-23-9q-9-10-9-23t9-23l256-256q10-9 23-9t23 9q9 10 9 23t-9 23z"),"list.unordered":La("M384 1408q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm0-512q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm1408 416v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-13 9.5-22.5t22.5-9.5h1216q13 0 22.5 9.5t9.5 22.5zm-1408-928q0 80-56 136t-136 56-136-56-56-136 56-136 136-56 136 56 56 136zm1408 416v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-13 9.5-22.5t22.5-9.5h1216q13 0 22.5 9.5t9.5 22.5zm0-512v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-13 9.5-22.5t22.5-9.5h1216q13 0 22.5 9.5t9.5 22.5z"),"list.ordered":La("M381 1620q0 80-54.5 126t-135.5 46q-106 0-172-66l57-88q49 45 106 45 29 0 50.5-14.5t21.5-42.5q0-64-105-56l-26-56q8-10 32.5-43.5t42.5-54 37-38.5v-1q-16 0-48.5 1t-48.5 1v53h-106v-152h333v88l-95 115q51 12 81 49t30 88zm2-627v159h-362q-6-36-6-54 0-51 23.5-93t56.5-68 66-47.5 56.5-43.5 23.5-45q0-25-14.5-38.5t-39.5-13.5q-46 0-81 58l-85-59q24-51 71.5-79.5t105.5-28.5q73 0 123 41.5t50 112.5q0 50-34 91.5t-75 64.5-75.5 50.5-35.5 52.5h127v-60h105zm1409 319v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-14 9-23t23-9h1216q13 0 22.5 9.5t9.5 22.5zm-1408-899v99h-335v-99h107q0-41 .5-122t.5-121v-12h-2q-8 17-50 54l-71-76 136-127h106v404h108zm1408 387v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-14 9-23t23-9h1216q13 0 22.5 9.5t9.5 22.5zm0-512v192q0 13-9.5 22.5t-22.5 9.5h-1216q-13 0-22.5-9.5t-9.5-22.5v-192q0-13 9.5-22.5t22.5-9.5h1216q13 0 22.5 9.5t9.5 22.5z"),"format.indent":La("M352 832q0 14-9 23l-288 288q-9 9-23 9-13 0-22.5-9.5T0 1120V544q0-13 9.5-22.5T32 512q14 0 23 9l288 288q9 9 9 23zm1440 480v192q0 13-9.5 22.5t-22.5 9.5H32q-13 0-22.5-9.5T0 1504v-192q0-13 9.5-22.5T32 1280h1728q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H672q-13 0-22.5-9.5T640 1120V928q0-13 9.5-22.5T672 896h1088q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H672q-13 0-22.5-9.5T640 736V544q0-13 9.5-22.5T672 512h1088q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H32q-13 0-22.5-9.5T0 352V160q0-13 9.5-22.5T32 128h1728q13 0 22.5 9.5t9.5 22.5z"),"format.outdent":La("M384 544v576q0 13-9.5 22.5T352 1152q-14 0-23-9L41 855q-9-9-9-23t9-23l288-288q9-9 23-9 13 0 22.5 9.5T384 544zm1408 768v192q0 13-9.5 22.5t-22.5 9.5H32q-13 0-22.5-9.5T0 1504v-192q0-13 9.5-22.5T32 1280h1728q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H672q-13 0-22.5-9.5T640 1120V928q0-13 9.5-22.5T672 896h1088q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H672q-13 0-22.5-9.5T640 736V544q0-13 9.5-22.5T672 512h1088q13 0 22.5 9.5t9.5 22.5zm0-384v192q0 13-9.5 22.5t-22.5 9.5H32q-13 0-22.5-9.5T0 352V160q0-13 9.5-22.5T32 128h1728q13 0 22.5 9.5t9.5 22.5z"),"format.alignment.left":La("M1792 1344v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1664q26 0 45 19t19 45zm-384-384v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45V960q0-26 19-45t45-19h1280q26 0 45 19t19 45zm256-384v128q0 26-19 45t-45 19H64q-26 0-45-19T0 704V576q0-26 19-45t45-19h1536q26 0 45 19t19 45zm-384-384v128q0 26-19 45t-45 19H64q-26 0-45-19T0 320V192q0-26 19-45t45-19h1152q26 0 45 19t19 45z"),"format.alignment.center":La("M1792 1344v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1664q26 0 45 19t19 45zm-384-384v128q0 26-19 45t-45 19H448q-26 0-45-19t-19-45V960q0-26 19-45t45-19h896q26 0 45 19t19 45zm256-384v128q0 26-19 45t-45 19H192q-26 0-45-19t-19-45V576q0-26 19-45t45-19h1408q26 0 45 19t19 45zm-384-384v128q0 26-19 45t-45 19H576q-26 0-45-19t-19-45V192q0-26 19-45t45-19h640q26 0 45 19t19 45z"),"format.alignment.right":La("M1792 1344v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1664q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H448q-26 0-45-19t-19-45V960q0-26 19-45t45-19h1280q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H192q-26 0-45-19t-19-45V576q0-26 19-45t45-19h1536q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H576q-26 0-45-19t-19-45V192q0-26 19-45t45-19h1152q26 0 45 19t19 45z"),"format.alignment.justify":La("M1792 1344v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1664q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H64q-26 0-45-19t-19-45V960q0-26 19-45t45-19h1664q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H64q-26 0-45-19T0 704V576q0-26 19-45t45-19h1664q26 0 45 19t19 45zm0-384v128q0 26-19 45t-45 19H64q-26 0-45-19T0 320V192q0-26 19-45t45-19h1664q26 0 45 19t19 45z"),"font.family":La("M789 559 619 1009q33 0 136.5 2t160.5 2q19 0 57-2-87-253-184-452zM64 1664l2-79q23-7 56-12.5t57-10.5 49.5-14.5 44.5-29 31-50.5l237-616 280-724h128q8 14 11 21l205 480q33 78 106 257.5t114 274.5q15 34 58 144.5t72 168.5q20 45 35 57 19 15 88 29.5t84 20.5q6 38 6 57 0 4-.5 13t-.5 13q-63 0-190-8t-191-8q-76 0-215 7t-178 8 4-78l131-28q1 0 12.5-2.5t15.5-3.5 14.5-4.5 15-6.5 11-8 9-11 2.5-14q0-16-31-96.5t-72-177.5-42-100l-450-2q-26 58-76.5 195.5t-50.5 162.5q0 22 14 37.5t43.5 24.5 48.5 13.5 57 8.5 41 4q1 19 1 58 0 9-2 27-58 0-174.5-10t-174.5-10q-8 0-26.5 4t-21.5 4q-80 14-188 14z"),"font.size":La("M1744 1408q33 0 42 18.5t-11 44.5l-126 162q-20 26-49 26t-49-26l-126-162q-20-26-11-44.5t42-18.5h80V384h-80q-33 0-42-18.5t11-44.5l126-162q20-26 49-26t49 26l126 162q20 26 11 44.5t-42 18.5h-80v1024h80zM81 129l54 27q12 5 211 5 44 0 132-2t132-2q36 0 107.5.5t107.5.5h293q6 0 21 .5t20.5 0 16-3 17.5-9 15-17.5l42-1q4 0 14 .5t14 .5q2 112 2 336 0 80-5 109-39 14-68 18-25-44-54-128-3-9-11-48t-14.5-73.5-7.5-35.5q-6-8-12-12.5t-15.5-6-13-2.5-18-.5-16.5.5q-17 0-66.5-.5t-74.5-.5-64 2-71 6q-9 81-8 136 0 94 2 388t2 455q0 16-2.5 71.5t0 91.5 12.5 69q40 21 124 42.5t120 37.5q5 40 5 50 0 14-3 29l-34 1q-76 2-218-8t-207-10q-50 0-151 9t-152 9-3-52v-9q17-27 61.5-43t98.5-29 78-27q19-42 19-383 0-101-3-303t-3-303V437q0-2 .5-15.5t.5-25-1-25.5-3-24-5-14q-11-12-162-12-33 0-93 12t-80 26q-19 13-34 72.5t-31.5 111-42.5 53.5q-42-26-56-44V169z"),"font.color":La("M3 18 9.65 2h4.7L21 18h-4.2l-1.45-4H8.5l-1.4 4h-4.1Zm6.7-7.4h4.45L12 4.55 9.7 10.6ZM2 20h20v3H2Z","0 0 24 24"),"font.backgroundColor":La("M896 1152q0-36-20-69-1-1-15.5-22.5t-25.5-38-25-44-21-50.5q-4-16-21-16t-21 16q-7 23-21 50.5t-25 44-25.5 38-15.5 22.5q-20 33-20 69 0 53 37.5 90.5t90.5 37.5 90.5-37.5 37.5-90.5zm512-128q0 212-150 362t-362 150-362-150-150-362q0-145 81-275 6-9 62.5-90.5t101-151 99.5-178 83-201.5q9-30 34-47t51-17 51.5 17 33.5 47q28 93 83 201.5t99.5 178 101 151 62.5 90.5q81 127 81 275z"),"font.highlight":La("m14.2 2 6.1 4.7-9 11.7H5.4L3.7 15l10.5-13Zm-7.7 13.4h3.35l6.75-8.7-2.05-1.6-8.05 10.3ZM2 20h20v3H2Z","0 0 24 24"),"editor.preview":La("M1664 960q-152-236-381-353 61 104 61 225 0 185-131.5 316.5T896 1280t-316.5-131.5T448 832q0-121 61-225Q280 724 128 960q133 205 333.5 326.5T896 1408t434.5-121.5T1664 960zM944 576q0-20-14-34t-34-14q-125 0-214.5 89.5T592 832q0 20 14 34t34 14 34-14 14-34q0-86 61-147t147-61q20 0 34-14t14-34zm848 384q0 34-20 69-140 230-376.5 368.5T896 1536t-499.5-139T20 1029q-20-35-20-69t20-69q140-229 376.5-368T896 384t499.5 139 376.5 368q20 35 20 69z"),"editor.maximize":La("M22 20.6 3.4 2H8V0H0v8h2V3.4L20.6 22H16v2h8v-8h-2v4.6zM16 0v2h4.7l-6.3 6.3 1.4 1.4L22 3.5V8h2V0H16zM8.3 14.3 2 20.6V16H0v8h8v-2H3.5l6.3-6.3-1.5-1.4z","0 0 24 24")}),Va=new WeakMap
class Xa extends Error{constructor(t){super(`Toolbar item "${t}" is not registered.`),this.name="ToolbarItemNotRegisteredError"}}class $a extends Error{constructor(){super("An editor UI is already attached to this host."),this.name="EditorUiAlreadyAttachedError"}}const tc=Object.freeze({$r:"--soeditor-accent",tn:"--soeditor-accent-contrast",background:"--soeditor-bg",border:"--soeditor-border",en:"--soeditor-control-size",sn:"--soeditor-danger",rn:"--soeditor-focus-ring",muted:"--soeditor-muted",nn:"--soeditor-panel-bg",radius:"--soeditor-radius",text:"--soeditor-text"})
function ec(t){if(void 0===t)return new Map
if("object"!=typeof t||null===t||Array.isArray(t))throw new TypeError("Editor UI theme variables must be a plain object.")
const e=new Map
for(const[i,o]of Object.entries(t)){const t=Reflect.get(tc,i)
if("string"!=typeof t)throw new TypeError(`Editor UI theme variable "${i}" is unsupported.`)
e.set(t,ic(o,`theme variable "${i}"`,256))}return e}function ic(t,e,i){if("string"!=typeof t||0===t.length||t.length>i||Array.from(t).some(t=>{const e=t.codePointAt(0)
return e<32||127===e}))throw new TypeError(`Editor UI ${e} must be bounded printable text.`)
return t}function oc(t,e,i){for(const o of Object.values(tc)){i.has(o)||i.set(o,Object.freeze({priority:t.style.getPropertyPriority(o),value:t.style.getPropertyValue(o)}))
const s=e.get(o)
if(void 0===s){const e=i.get(o)
0===e.value.length?t.style.removeProperty(o):t.style.setProperty(o,e.value,e.priority)}else t.style.setProperty(o,s)}}function sc(t,e){try{e()}catch(i){t.push(i)}}function rc(t,e){const i=hc(t)
return void 0!==i&&nc(e,i)}function nc(t,e){let i=e
for(;;){if(t.contains(i))return!0
const e=i.getRootNode()
if(!(e instanceof ShadowRoot))return!1
i=e.host}}function ac(t,e){return lc(t.getRootNode(),e)}function cc(t,e){const i=Ac(t.getRootNode(),e),o=i?.startContainer,s=i?.endContainer
if(void 0!==i&&null!=o&&null!=s)return Object.freeze({anchor:o,anchorOffset:i.startOffset,focus:s,focusOffset:i.endOffset})}function lc(t,e){const i=Reflect.get(t,"getSelection")
if("function"==typeof i){const o=Reflect.apply(i,t,[]),s=e.defaultView?.Selection
if(void 0!==s&&o instanceof s)return o}return e.getSelection()}function Ac(t,e){const i=lc(t,e)
if(null===i)return
if(i.rangeCount>0)try{const e=i.getRangeAt(0)
if(!(t instanceof ShadowRoot)||e.commonAncestorContainer.getRootNode()===t)return e.cloneRange()}catch{}if(!(t instanceof ShadowRoot))return
const o=Reflect.get(i,"getComposedRanges")
if("function"!=typeof o)return
let s
try{s=Reflect.apply(o,i,[{an:[t]}])}catch{return}if(!Array.isArray(s)||0===s.length)return
const r=s[0]
if("object"!=typeof r||null===r)return
const n=Reflect.get(r,"startContainer"),a=Reflect.get(r,"endContainer"),c=Reflect.get(r,"startOffset"),l=Reflect.get(r,"endOffset"),A=e.defaultView?.Node
if(!(void 0!==A&&n instanceof A&&a instanceof A&&"number"==typeof c&&"number"==typeof l))return
const h=e.createRange()
try{return h.setStart(n,c),h.setEnd(a,l),h}catch{return}}function hc(t){const e=1===t.nodeType?t:t.parentElement,i=e?.closest('[contenteditable="true"]')
return i??void 0}function dc(t){let e=t.activeElement
for(;null!=e?.shadowRoot;){const t=e.shadowRoot.activeElement
if(null===t)break
e=t}return e}function uc(t){return Array.from(t.querySelectorAll('button:not(:disabled), summary:not([aria-disabled="true"])')).filter(t=>{if(t.closest("[hidden]"))return!1
const e=t.closest("details:not([open])")
return null===e||t===e.querySelector("summary")})}function fc(t,e){if(null!==t.parentElement?.closest("[data-soeditor-no-translate]")||t instanceof Element&&null!==t.closest("[data-soeditor-no-translate]"))return
if(3===t.nodeType){const i=t.nodeValue??"",o=i.trim()
if(0===o.length)return
const s=e(o)
return void(s!==o&&(t.nodeValue=i.replace(o,s)))}const i=t.ownerDocument?.defaultView
if(null!=i&&t instanceof i.Element){for(const i of["aria-label","placeholder","title"]){const o=t.getAttribute(i)
if(null!==o){const s=e(o)
s!==o&&t.setAttribute(i,s)}}for(const i of Array.from(t.childNodes))fc(i,e)}}function bc(t){if("auto"!==t&&"light"!==t&&"dark"!==t)throw new TypeError("Editor UI theme must be auto, light, or dark.")
return t}function mc(t){return("object"==typeof t&&null!==t||"function"==typeof t)&&"function"==typeof Reflect.get(t,"then")}const pc=[["Image tools","图片工具","圖片工具"],["Uploading","正在上传","正在上傳"],["Upload failed","上传失败","上傳失敗"],["Upload complete","上传完成","上傳完成"],["Upload cancelled","已取消上传","已取消上傳"],["Retry","重试","重試"],["Close","关闭","關閉"],["Mixed","混合","混合"],["More text styles","更多文字格式","更多文字格式"],["Mixed formatting","混合格式","混合格式"],["Formatting unavailable","格式不可用","格式無法使用"],["Ordered list styles","编号列表样式","編號清單樣式"],["Unordered list styles","符号列表样式","項目符號清單樣式"],["Decimal","数字编号","數字編號"],["Decimal with leading zero","带前导零的数字","含前導零的數字"],["Lowercase Roman","小写罗马数字","小寫羅馬數字"],["Uppercase Roman","大写罗马数字","大寫羅馬數字"],["Lowercase letters","小写字母","小寫字母"],["Uppercase letters","大写字母","大寫字母"],["Filled circle","实心圆","實心圓"],["Hollow circle","空心圆","空心圓"],["Square","方块","方塊"],["Add attribute","添加属性","新增屬性"],["Additional attributes","附加属性","附加屬性"],["Added attributes","已添加属性","已新增屬性"],["Add standard or CMS attributes. Reserved names are blocked.","可添加标准或 CMS 属性；保留属性名会被阻止。","可新增標準或 CMS 屬性；保留屬性名稱會被阻擋。"],["Attribute name","属性名","屬性名稱"],["Attribute value","属性值","屬性值"],["Choose or enter an attribute name","选择或输入属性名","選擇或輸入屬性名稱"],["No additional attributes.","暂无附加属性。","尚無附加屬性。"],["Remove attribute","移除属性","移除屬性"],["Invalid attribute.","属性无效。","屬性無效。"],["Accessibility help","无障碍帮助","無障礙說明"],["Accessible label","无障碍标签","無障礙標籤"],["Align center","居中对齐","置中對齊"],["Align left","左对齐","靠左對齊"],["Align right","右对齐","靠右對齊"],["Add","添加","新增"],["Add relationship","添加链接关系","新增連結關係"],["Advanced settings","高级设置","進階設定"],["Alignment","对齐方式","對齊方式"],["Automatic","自动","自動"],["Body","表体","表體"],["Bottom","底部","底部"],["Center","居中","置中"],["Cell","单元格","儲存格"],["Cell classes","单元格类名","儲存格類別"],["Cell height unit","单元格高度单位","儲存格高度單位"],["Cell width unit","单元格宽度单位","儲存格寬度單位"],["Custom","自定义","自訂"],["Custom width","自定义宽度","自訂寬度"],["Default","默认","預設"],["Header","表头","表頭"],["Left","左对齐","靠左"],["Right","右对齐","靠右"],["Section","分区","區段"],["Summary","摘要","摘要"],["Table height unit","表格高度单位","表格高度單位"],["Table width unit","表格宽度单位","表格寬度單位"],["Top","顶部","頂端"],["Width unit","宽度单位","寬度單位"],["Alternative text","替代文本","替代文字"],["Anchor name","锚点名称","錨點名稱"],["Background color","背景色","背景色"],["Block quote","块引用","區塊引言"],["Bold","粗体","粗體"],["Bold: Control or Command plus B","粗体：Control 或 Command 加 B","粗體：Control 或 Command 加 B"],["Cancel","取消","取消"],["Changes saved","更改已保存","變更已儲存"],["Caption","标题","標題"],["Character","字符","字元"],["Choose a common target","选择常用目标","選擇常用目標"],["Choose block style","选择段落样式","選擇段落樣式"],["Choose color","选择颜色","選擇顏色"],["Choose file link","选择文件链接","選擇檔案連結"],["Choose internal link","选择内部链接","選擇內部連結"],["Close preview","关闭预览","關閉預覽"],["Close a dialog or menu: Escape","关闭对话框或菜单：Escape","關閉對話框或選單：Escape"],["CMS placeholder","CMS 占位符","CMS 佔位符"],["Collapse editor toolbar","折叠编辑器工具栏","收合編輯器工具列"],["Context menu: Shift plus F10","上下文菜单：Shift 加 F10","內容功能表：Shift 加 F10"],["Columns","列数","欄數"],["Common relationships","常用链接关系","常用連結關係"],["Common target","常用目标","常用目標"],["Color value","颜色值","顏色值"],["Custom color","自定义颜色","自訂顏色"],["Custom relationship","自定义链接关系","自訂連結關係"],["Custom target name","自定义目标名称","自訂目標名稱"],["Apply color","应用颜色","套用顏色"],["document","文档","文件"],["Displayed text","显示文本","顯示文字"],["Edit","编辑","編輯"],["Edit link","编辑链接","編輯連結"],["Editing view","编辑视图","編輯檢視"],["Embed","嵌入内容","嵌入內容"],["Enter 1–9999 px (px is optional) or 1%–100%.","请输入 1–9999 px（px 可省略）或 1%–100%。","請輸入 1–9999 px（px 可省略）或 1%–100%。"],["Editor context menu","编辑器上下文菜单","編輯器內容功能表"],["Editor notifications","编辑器通知","編輯器通知"],["Editor toolbar","编辑器工具栏","編輯器工具列"],["Expand editor toolbar","展开编辑器工具栏","展開編輯器工具列"],["Format HTML","格式化 HTML","格式化 HTML"],["Clear selected cells","清空所选单元格","清空所選儲存格"],["Font size","字号","字體大小"],["For example: 640, 640px, or 70%","例如：640、640px 或 70%","例如：640、640px 或 70%"],["Header scope","表头范围","表頭範圍"],["Heading","标题","標題"],["Apply","应用","套用"],["Help","帮助","說明"],["Height","高度","高度"],["Horizontal rule","水平线","水平線"],["Image","图片","圖片"],["Image and description","图片与说明","圖片與說明"],["Image properties","图片属性","圖片屬性"],["Image title","图片标题","圖片標題"],["Image URL","图片地址","圖片網址"],["Indent","增加缩进","增加縮排"],["Insert link","插入链接","插入連結"],["Column","列","欄"],["Row","行","列"],["Insert column after","在后面插入列","在後方插入欄"],["Insert column before","在前面插入列","在前方插入欄"],["Insert row after","在后面插入行","在後方插入列"],["Insert row before","在前面插入行","在前方插入列"],["Italic","斜体","斜體"],["Italic: Control or Command plus I","斜体：Control 或 Command 加 I","斜體：Control 或 Command 加 I"],["Line break without a new paragraph: Shift plus Enter","段内换行（不新建段落）：Shift 加 Enter","段內換行（不新增段落）：Shift 加 Enter"],["Invalid color. Use #2563eb, rgb(37, 99, 235), hsl(217, 91%, 60%), or a color name.","颜色格式不正确。请输入 #2563eb、rgb(37, 99, 235)、hsl(217, 91%, 60%) 或颜色名称。","顏色格式不正確。請輸入 #2563eb、rgb(37, 99, 235)、hsl(217, 91%, 60%) 或顏色名稱。"],["Justify","两端对齐","左右對齊"],["Link","链接","連結"],["Link URL","链接地址","連結網址"],["Link target","链接打开位置","連結開啟位置"],["Lock aspect ratio","锁定宽高比","鎖定寬高比"],["Resize image","调整图片尺寸","調整圖片尺寸"],["Block tools failed to load. Please try again.","区块工具加载失败，请重试。","區塊工具載入失敗，請重試。"],["Insert paragraph before this block","在此区块前插入段落","在此區塊前插入段落"],["Insert paragraph after this block","在此区块后插入段落","在此區塊後插入段落"],["Maximize","最大化","最大化"],["Maximize editor","最大化编辑器","最大化編輯器"],["Named anchor","命名锚点","命名錨點"],["New paragraph: Enter","新建段落：Enter","新增段落：Enter"],["New window or tab (_blank)","新窗口或标签页（_blank）","新視窗或分頁（_blank）"],["Same window","当前窗口","目前視窗"],["Ordered list","有序列表","有序清單"],["Optional tooltip","可选提示文字","選填提示文字"],["Outdent","减少缩进","減少縮排"],["Page break","分页符","分頁符號"],["Paragraph","段落","段落"],["Preset colors","预设颜色","預設顏色"],["Remove image","移除图片","移除圖片"],["Responsive CSS classes","响应式 CSS 类","響應式 CSS 類別"],["Responsive image settings","响应式图片设置","響應式圖片設定"],["Responsive sizes","响应式尺寸规则","響應式尺寸規則"],["Responsive sources","响应式图片源","響應式圖片來源"],["Size and placement","尺寸与位置","尺寸與位置"],["Placeholder name","占位符名称","佔位符名稱"],["Redo","重做","重做"],["Recent colors","最近使用的颜色","最近使用的顏色"],["Same window (_self)","当前窗口（_self）","目前視窗（_self）"],["Relationship","链接关系","連結關係"],["Remove format","清除格式","清除格式"],["Remove link","移除链接","移除連結"],["Remove media","移除媒体","移除媒體"],["Delete selected columns","删除所选列","刪除所選欄"],["Delete selected rows","删除所选行","刪除所選列"],["Resize editor height","调整编辑器高度","調整編輯器高度"],["Responsive classes","响应式类名","響應式類別"],["Restore","还原","還原"],["Restore editor size","还原编辑器大小","還原編輯器大小"],["Rich text editor","富文本编辑器","RTF 編輯器"],["Row classes","行类名","列類別"],["Rows","行数","列數"],["Saved","已保存","已儲存"],["Save","保存","儲存"],["Save conflict","保存冲突","儲存衝突"],["Save failed","保存失败","儲存失敗"],["Saving","正在保存","正在儲存"],["Show or hide editor toolbar","显示或隐藏编辑器工具栏","顯示或隱藏編輯器工具列"],["Select table","选择表格","選取表格"],["Source","源码","原始碼"],["Special character","特殊字符","特殊字元"],["Strike","删除线","刪除線"],["Strikethrough","删除线","刪除線"],["Subscript","下标","下標"],["Superscript","上标","上標"],["Table","表格","表格"],["Table cell properties","单元格属性","儲存格屬性"],["Table properties","表格属性","表格屬性"],["Table row properties","表格行属性","表格列屬性"],["Target","目标","目標"],["Parent frame (_parent)","父级框架（_parent）","父層框架（_parent）"],["Top frame (_top)","顶级框架（_top）","頂層框架（_top）"],["Text color","文字颜色","文字顏色"],["Text shown to readers","向读者显示的文字","向讀者顯示的文字"],["Title","标题","標題"],["Toolbar","工具栏","工具列"],["Underline","下划线","底線"],["Undo","撤销","復原"],["Undo: Control or Command plus Z","撤销：Control 或 Command 加 Z","復原：Control 或 Command 加 Z"],["Redo: Control or Command plus Shift plus Z","重做：Control 或 Command 加 Shift 加 Z","重做：Control 或 Command 加 Shift 加 Z"],["Select multiple table cells: Shift plus click another cell","多选表格单元格：按住 Shift 再单击另一个单元格","多選表格儲存格：按住 Shift 再按一下另一個儲存格"],["Unordered list","无序列表","無序清單"],["Unsaved","未保存","未儲存"],["Retry save","重试保存","重試儲存"],["URL","地址","網址"],["Update link","更新链接","更新連結"],["Update image","更新图片","更新圖片"],["Vertical alignment","垂直对齐","垂直對齊"],["Visible caption","可见说明文字","可見說明文字"],["Visual","可视化","視覺化"],["Width","宽度","寬度"],["Width must be 1–9999 px or 1%–100%.","宽度必须是 1–9999 px 或 1%–100%。","寬度必須是 1–9999 px 或 1%–100%。"],["Width (px or %)","宽度（px 或 %）","寬度（px 或 %）"],["characters","字符","字元"],["source characters","源码字符","原始碼字元"],["words","词","詞"],["Use Tab to enter controls and Arrow keys to move within toolbars and menus.","使用 Tab 进入控件，并使用方向键在工具栏和菜单中移动。","使用 Tab 進入控制項，並使用方向鍵在工具列和選單中移動。"],["Describe the image for people who cannot see it.","为无法看到图片的用户描述图片内容。","為無法看到圖片的使用者描述圖片內容。"]],gc=Object.freeze(Object.fromEntries(pc.map(([t,e])=>[t,e]))),wc=Object.freeze(Object.fromEntries(pc.map(([t,,e])=>[t,e]))),vc=Object.freeze([Object.freeze({direction:"ltr",locale:"en",messages:{}}),Object.freeze({direction:"ltr",locale:"zh-CN",messages:gc}),Object.freeze({direction:"ltr",locale:"zh-TW",messages:wc})]),yc=((t,e)=>{const i=new Set
for(const o of e){if("function"!=typeof o||0===o.id.trim().length)throw new TypeError("Preset plugins require a non-empty static ID.")
if(i.has(o.id))throw new TypeError(`Preset plugin ID "${o.id}" is duplicated.`)
i.add(o.id)}return Object.freeze({format:"html",plugins:Object.freeze([...e]),toolbar:Object.freeze(["heading","fontFamily","fontSize","bold","italic","underline","fontColor","fontBackgroundColor","highlight","moreFormatting","|","alignment","orderedList","unorderedList","outdent","indent","blockquote","|","link","unlink","link-internal","image-actions","table","horizontalRule","anchor"])})})(0,[class extends U{static id="editing-history"
#N=[]
#q=[]
#j
get canUndo(){return this.#q.length>0}get canRedo(){return this.#N.length>0}init(){this.editor.commands.register({id:"editor.undo",label:"Undo",canExecute:()=>this.canUndo,execute:()=>this.#G()}),this.editor.commands.register({id:"editor.redo",label:"Redo",canExecute:()=>this.canRedo,execute:()=>this.#H()}),this.#j=this.editor.events.on("document:change",t=>this.#K(t))}#G(){const t=this.#q.at(-1)
if(void 0===t)return!1
const e=this.#Y(t.cn,t.beforeSelection)
if(this.#q.pop(),this.#N.push(t),e.ln)throw e.value
return!0}#H(){const t=this.#N.at(-1)
if(void 0===t)return!1
const e=this.#Y(t.An,t.afterSelection)
if(this.#N.pop(),this.#q.push(t),e.ln)throw e.value
return!0}destroy(){this.#j?.(),this.#j=void 0,this.#q.length=0,this.#N.length=0}#K(t){if(!0===t.transaction.getMeta(Eo))return
const e=(t=>{const e=Bo(t.getMeta("soeditor.history.beforeSelection")),i=Bo(t.getMeta("soeditor.history.afterSelection")),o=t.getMeta(Io)
return Object.freeze({...void 0===e?{}:{beforeSelection:e},...void 0===i?{}:{afterSelection:i},..."string"==typeof o?{group:o}:{}})})(t.transaction),i=e.group,o=Object.freeze({An:t.current.source,cn:t.previous.source,hn:Date.now(),...void 0===e.afterSelection?{}:{afterSelection:e.afterSelection},...void 0===e.beforeSelection?{}:{beforeSelection:e.beforeSelection},...void 0===i?{}:{group:i}}),s=this.#q.at(-1)
if(void 0!==s&&((t,e)=>{return void 0!==t.group&&t.group===e.group&&e.hn-t.hn>=0&&e.hn-t.hn<=1e3&&t.An===e.cn&&(i=t.afterSelection,o=e.beforeSelection,void 0===i||void 0===o?i===o:i.anchor.block===o.anchor.block&&i.anchor.offset===o.anchor.offset&&i.focus.block===o.focus.block&&i.focus.offset===o.focus.offset)
var i,o})(s,o)){const{afterSelection:t,...e}=s
this.#q[this.#q.length-1]=Object.freeze({...e,An:o.An,hn:o.hn,...void 0===o.afterSelection?{}:{afterSelection:o.afterSelection}})}else this.#q.push(o),this.#q.length>100&&this.#q.shift()
this.#N.length=0}#Y(t,e){let i,o=!1
try{this.editor.update(i=>{i.replaceDocument(t),((t,e)=>{t.setMeta(Eo,!0),void 0!==e&&t.setMeta("soeditor.history.replaySelection",Co(e))})(i,e)},{origin:"command"})}catch(s){if(o=!0,i=s,this.editor.getData()!==t)throw s}return o?{ln:o,value:i}:{ln:o}}},class extends U{static id="projection-coordinator"
#W=new Map
#k=new Set
#z=new Set
#I=!1
#Z
#U
#J="visual"
#L=!1
init(){const t=this.editor.state.document.format
this.#J=ho(t)
const e=this.editor.state.mode
"preview"===e?(this.#z.add(this.#J),this.#z.add("preview")):uo(e,t)?(this.#J=e,this.#z.add(e)):this.#z.add(this.#J)
const i=()=>this.#P(),o=Object.freeze({get snapshot(){return i()},attach:t=>this.#V(t),get:t=>this.#X(t),isAttached:t=>this.#$(t),subscribe:t=>this.#F(t)})
this.editor.services.register(so,o),this.editor.commands.register({id:"projection.activate",execute:(t,...e)=>this.#tt(fo("projection.activate",e))}),this.editor.commands.register({id:"projection.show",execute:(t,...e)=>this.#et(fo("projection.show",e),!0)}),this.editor.commands.register({id:"projection.hide",execute:(t,...e)=>this.#et(fo("projection.hide",e),!1)}),this.#Z=this.editor.events.on("mode:change",({current:t})=>this.#it(t)),this.#U=this.editor.events.on("state:change",({current:t,previous:e})=>{t.readonly!==e.readonly&&this.#ot()})}destroy(){this.#I=!0,this.#Z?.(),this.#Z=void 0,this.#U?.(),this.#U=void 0,this.#W.clear(),this.#k.clear(),this.#z.clear()}#V(t){this.#g(),(t=>{if("object"!=typeof t||null===t)throw new TypeError("A projection adapter must be an object.")
if(bo(t.id),"function"!=typeof t.update)throw new TypeError(`Projection adapter "${t.id}" requires an update function.`)})(t)
const e=this.editor.state.document.format
if(!((t,e)=>"preview"===t||uo(t,e))(t.id,e))throw new co(t.id,e)
if(this.#W.has(t.id))throw new no(t.id)
this.#W.set(t.id,t)
try{t.update(this.#st(t.id))}catch(o){throw this.#W.delete(t.id),o}let i=!0
return()=>{i&&!this.#I?(this.#W.get(t.id)===t&&(this.#W.delete(t.id),this.#rt(t.id),this.#ot()),i=!1):i=!1}}#tt(t){if(this.#nt(t),!uo(t,this.editor.state.document.format))throw new lo(`Projection "${t}" cannot become a writable primary.`)
if(!this.#z.has(t))throw new lo(`Projection "${t}" must be visible before activation.`)
this.#L=!0
try{this.editor.state.mode!==t&&this.editor.update(e=>e.setMode(t),{origin:"command"})}finally{this.#L=!1,this.editor.state.mode===t&&(this.#J=t,this.#ot())}}#et(t,e){if(this.#nt(t),!(e||t!==this.#J||"preview"===this.editor.state.mode&&this.#z.has("preview")))throw new lo(`Primary projection "${t}" cannot be hidden.`);(e?!this.#z.has(t):this.#z.has(t))&&(e?this.#z.add(t):this.#z.delete(t),this.#ot())}#it(t){this.#L||("preview"!==t?uo(t,this.editor.state.document.format)&&this.#W.has(t)&&(this.#z.add(t),this.#J=t,this.#ot()):this.#W.has("preview")&&(this.#z.add("preview"),this.#ot()))}#rt(t){if(t!==this.#J)return
const e=this.editor.state.document.format,i=Ao.find(t=>this.#W.has(t)&&this.#z.has(t)&&uo(t,e))??Ao.find(t=>this.#W.has(t)&&uo(t,e))
this.#J=i??ho(e),void 0!==i&&this.#z.add(i)}#X(t){return this.#g(),bo(t),this.#st(t)}#$(t){return this.#g(),bo(t),this.#W.has(t)}#F(t){if(this.#g(),"function"!=typeof t)throw new TypeError("A projection listener must be a function.")
this.#k.add(t)
let e=!0
return()=>{e&&this.#k.delete(t),e=!1}}#st(t){const e=t===this.#J
return Object.freeze({id:t,primary:e,readonly:this.editor.state.readonly||!e,visible:this.#z.has(t)})}#P(){return this.#g(),Object.freeze({activities:Object.freeze(Ao.map(t=>this.#st(t))),primary:this.#J})}#ot(){const t=this.#P(),e=[]
for(const o of t.activities){const t=this.#W.get(o.id)
if(void 0!==t)try{t.update(o)}catch(i){e.push(i)}}for(const o of[...this.#k])try{o(t)}catch(i){e.push(i)}if(e.length>0)throw new AggregateError(e,"Projection activity notification failed.")}#nt(t){if(this.#g(),bo(t),!this.#W.has(t))throw new ao(t)}#g(){if(this.#I)throw new ro}},To,Bs,class extends qo{static id="div"
init(){this.register("block.div",(t,e)=>{$o("block.div",e),t.setBlock(t.isBlockActive("div")?"p":"div")},t=>t.isBlockActive("div"),"Toggle div block")}},class extends U{static id="html-cleanup"
static requires=[Bs]
init(){this.editor.commands.register({id:"html.cleanup",label:"Clean HTML",canExecute:({editor:t})=>"html"===t.state.document.format&&!t.state.readonly,execute:({editor:t},e="balanced")=>{const i=Ss(e),o=t.getData(),s=xs(o,i)
return s!==o&&t.update(t=>t.replaceDocument(s).setMeta("html.cleanup.profile",i),{origin:"command"}),Object.freeze({changed:s!==o,profile:i,source:s})}}),this.editor.commands.register({id:"html.cleanup.inspect",label:"Inspect HTML cleanup",canExecute:({editor:t})=>"html"===t.state.document.format,execute:({editor:t},e="balanced")=>{const i=Ss(e),o=t.getData(),s=xs(o,i)
return Object.freeze({changed:s!==o,profile:i,source:s})}})}},class extends qo{static id="paragraph"
init(){this.register("paragraph.set",(t,e)=>{$o("paragraph.set",e),t.setBlock("p")},t=>t.isBlockActive("p"),"Set paragraph")}},class extends qo{static id="heading"
init(){this.register("paragraph.heading",(t,e)=>{const i=ts("paragraph.heading",e)
if(!Number.isInteger(i)||Number(i)<1||Number(i)>6)throw new No("paragraph.heading","requires an integer heading level from 1 to 6.")
t.setBlock("h"+i)})}},class extends jo{static id="bold"
init(){this.Er("format.bold","strong")}},class extends jo{static id="italic"
init(){this.Er("format.italic","em")}},class extends jo{static id="underline"
init(){this.Er("format.underline","u")}},class extends jo{static id="strike"
init(){this.Er("format.strike","s")}},class extends jo{static id="subscript"
init(){this.Er("format.subscript","sub")}},class extends jo{static id="superscript"
init(){this.Er("format.superscript","sup")}},class extends qo{static id="remove-format"
init(){this.register("format.remove",(t,e)=>{$o("format.remove",e),Po(t.removeFormat,"format.remove")()})}},class extends U{static id="font"
static requires=[vo]
init(){this.#R("font.color","color",ws),this.#R("font.backgroundColor","background-color",ws),this.#at(),this.#R("font.family","font-family",ys),this.#R("font.size","font-size",ks),this.#ct("font.color.remove","color"),this.#ct("font.backgroundColor.remove","background-color"),this.#lt()}#R(t,e,i){this.editor.commands.register({id:t,label:"font.color"===t?"Text color":"font.backgroundColor"===t?"Background color":"font.highlight"===t?"Highlight":"font.family"===t?"Font family":"Font size",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&void 0!==e.applyInlineStyle},execute:({editor:o},...s)=>{if(1!==s.length)throw new No(t,"requires exactly one value.")
const r=i(t,s[0])
gs(o.services.get(Qo),t).applyInlineStyle?.({attributes:Object.freeze([Object.freeze({name:"style",value:`${e}: ${r};`})]),tagName:"span"})}})}#at(){this.editor.commands.register({id:"font.highlight",label:"Highlighter",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&void 0!==e.applyInlineStyle},execute:({editor:t},...e)=>{if(1!==e.length)throw new No("font.highlight","requires exactly one value.")
const i=ws("font.highlight",e[0])
gs(t.services.get(Qo),"font.highlight").applyInlineStyle?.({attributes:Object.freeze([Object.freeze({name:"style",value:`background: linear-gradient(transparent 60%, ${i} 0);`})]),tagName:"mark"})}})}#lt(){this.editor.commands.register({id:"font.highlight.remove",label:"Remove highlight",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&void 0!==e.removeInlineStyleProperty},execute:({editor:t})=>{const e=gs(t.services.get(Qo),"font.highlight")
e.removeInlineStyleProperty?.("background")}})}#ct(t,e){this.editor.commands.register({id:t,label:"color"===e?"Remove text color":"Remove background color",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&void 0!==e.removeInlineStyleProperty},execute:({editor:i})=>{const o=i.services.get(Qo)
if(!o.canEdit()||void 0===o.removeInlineStyleProperty)throw Error(`Command "${t}" requires removable inline styles.`)
o.removeInlineStyleProperty(e)}})}},class extends qo{static id="alignment"
init(){for(const t of["left","center","right","justify"]){const e="format.alignment."+t
this.register(e,(i,o)=>{$o(e,o),Po(i.setAlignment,e)(t)},e=>e.isAlignmentActive?.(t)??!1)}this.register("format.alignment",(t,e)=>{const i=ts("format.alignment",e)
if("left"!==i&&"center"!==i&&"right"!==i&&"justify"!==i)throw new No("format.alignment","requires left, center, right, or justify.")
Po(t.setAlignment,"format.alignment")(i)})}},class extends qo{static id="indentation"
init(){this.register("format.indent",(t,e)=>{$o("format.indent",e),Po(t.adjustIndent,"format.indent")(1)}),this.register("format.outdent",(t,e)=>{$o("format.outdent",e),Po(t.adjustIndent,"format.outdent")(-1)})}},class extends qo{static id="horizontal-rule"
init(){this.register("horizontalRule.insert",(t,e)=>{$o("horizontalRule.insert",e),t.insertHtml("<hr>")})}},class extends U{static id="cms-objects"
static requires=[vo]
#O=[]
init(){const t=this.editor.services.get(mo),e=(t=>{if(void 0===t)return[]
if(!Array.isArray(t)||t.length>64)throw new TypeError("cms.objects must be an array of at most 64 definitions.")
const e=new Set
return Object.freeze(t.map(t=>{if("object"!=typeof t||null===t)throw new TypeError("Each cms.objects definition must be an object.")
const i=t,o=i.id,s=i.label,r=i.element??"div",n=i.properties??[]
if("string"!=typeof o||!/^[a-z][a-z0-9-]{0,63}$/u.test(o)||e.has(o)||"string"!=typeof s||0===s.length||s.length>128||"string"!=typeof r||!/^[a-z][a-z0-9-]{0,31}$/u.test(r)||!Array.isArray(n)||n.length>32||!n.every(t=>"string"==typeof t&&/^[a-z][a-z0-9-]{0,31}$/u.test(t)))throw new TypeError("cms.objects contains an invalid definition.")
return e.add(o),Object.freeze({element:r,id:o,label:s,properties:Object.freeze([...new Set(n)])})}))})(this.editor.config.get("cms.objects"))
for(const i of e){const e=Hs(i.id)
this.#O.push(t.registerBlock({behavior:"atomic",fromHtml:t=>({attributes:t.attributes,children:t.children}),id:e,matches:t=>"html"===t.namespace&&t.tagName===i.element&&Zs(t.attributes,"data-soeditor-object")===i.id,toHtml:t=>({attributes:t.attributes,children:t.children,namespace:"html",tagName:i.element,type:"element"}),type:e}),t.registerNodeView(e,t=>qs(t,i))),this.dn(i,e)}this.#O.push(t.registerBlock({behavior:"atomic",fromHtml:t=>({attributes:t.attributes,children:t.children}),id:Os,matches:t=>"html"===t.namespace&&"figure"===t.tagName&&void 0!==Zs(t.attributes,"data-soeditor-embed"),toHtml:t=>({attributes:t.attributes,children:t.children,namespace:"html",tagName:"figure",type:"element"}),type:Os}),t.registerNodeView(Os,js)),this.un()}destroy(){for(const t of this.#O.reverse())t()
this.#O=[]}dn(t,e){const i=`cmsObject.${t.id}.insert`,o=`cmsObject.${t.id}.update`,s=`cmsObject.${t.id}.remove`
this.editor.commands.register({id:i,label:"Insert "+t.label,canExecute:({editor:t})=>Gs(t),execute:({editor:e},o={})=>{const s=Ns(i,t,o)
e.services.get(Qo).insertHtml(oo(Us([Js(t.element,s,[])])))}}),this.editor.commands.register({id:o,label:"Update "+t.label,canExecute:({editor:t})=>Gs(t)&&t.services.get(Qo).isStructuredBlockSelected(e),execute:({editor:i},s={})=>{const r=i.services.get(Qo),n=((t,e)=>{if(void 0===t)throw new No(e,"requires a selected object.")
return t})(r.getSelectedStructuredBlock(e),o),a=new Map(Ns(o,t,s).filter(t=>"data-soeditor-object"!==t.name).map(t=>[t.name,t.value])),c=n.attributes.filter(t=>!a.has(t.name)).concat([...a].map(([t,e])=>({name:t,value:e})))
r.setStructuredBlockAttributes(e,c)}}),this.editor.commands.register({id:s,label:"Remove "+t.label,canExecute:({editor:t})=>Gs(t)&&t.services.get(Qo).isStructuredBlockSelected(e),execute:({editor:t},...i)=>{Ys(s,i)
const o=t.services.get(Qo).removeSelectedStructuredBlock
if(void 0===o)throw new No(s,"requires structured-block removal support.")
o(e)}})}un(){this.editor.commands.register({id:"specialCharacter.insert",label:"Insert special character",canExecute:({editor:t})=>Gs(t),execute:({editor:t},e)=>{if("string"!=typeof e||0===e.length||Array.from(e).length>4||zs(e))throw new No("specialCharacter.insert","requires one bounded printable value.")
t.services.get(Qo).insertHtml(oo(Us([Ls(e)])))}}),this.editor.commands.register({id:"anchor.insert",label:"Insert named anchor",canExecute:({editor:t})=>Gs(t),execute:({editor:t},e)=>{const i=Ks("anchor.insert",e)
t.services.get(Qo).insertHtml(oo(Us([Js("a",[{name:"id",value:i}],[])])),{placement:"selection-start"})}}),this.editor.commands.register({id:"pageBreak.insert",label:"Insert page break",canExecute:({editor:t})=>Gs(t),execute:({editor:t},...e)=>{Ys("pageBreak.insert",e),t.services.get(Qo).insertHtml('<hr data-page-break="true">')}}),this.editor.commands.register({id:"placeholder.insert",label:"Insert CMS placeholder",canExecute:({editor:t})=>Gs(t),execute:({editor:t},e)=>{const i=Ks("placeholder.insert",e)
t.services.get(Qo).insertHtml(oo(Us([Js("span",[{name:"data-soeditor-placeholder",value:i}],[Ls(`{{${i}}}`)])])))}}),this.editor.commands.register({id:"embed.insert",label:"Insert safe embed metadata",canExecute:({editor:t})=>Gs(t)&&t.services.has(Qs),execute:async({editor:t},e)=>{if("string"!=typeof e||!Ws(e))throw new No("embed.insert","requires a safe HTTP(S) URL.")
const i=(t=>{if("object"!=typeof t||null===t||Array.isArray(t))throw new TypeError("Embed provider returned an invalid result.")
const e=t
if("string"!=typeof e.provider||!/^[a-z][a-z0-9-]{0,63}$/u.test(e.provider)||"string"!=typeof e.title||0===e.title.length||e.title.length>512||"string"!=typeof e.url||!Ws(e.url)||void 0!==e.thumbnailUrl&&("string"!=typeof e.thumbnailUrl||!Ws(e.thumbnailUrl)))throw new TypeError("Embed provider returned unsafe metadata.")
return Object.freeze({provider:e.provider,title:e.title,url:e.url,..."string"==typeof e.thumbnailUrl?{thumbnailUrl:e.thumbnailUrl}:{}})})(await t.services.get(Qs).resolve(e))
return t.services.get(Qo).insertHtml(oo((t=>Us([Js("figure",[{name:"data-soeditor-embed",value:t.provider},{name:"data-title",value:t.title},{name:"data-url",value:t.url},...void 0===t.thumbnailUrl?[]:[{name:"data-thumbnail-url",value:t.thumbnailUrl}]],[Js("a",[{name:"href",value:t.url}],[Ls(t.title)]),Js("figcaption",[],[Ls(t.provider)])])]))(i))),i}})}},class extends U{static id="semantic-styles"
static requires=[vo]
init(){const t=(t=>{if(void 0===t)return[]
if(!Array.isArray(t)||t.length>64)throw new Go("cms.styles must be an array with at most 64 entries.")
const e=new Set
return Object.freeze(t.map((t,i)=>{if("object"!=typeof t||null===t||Array.isArray(t))throw new Go(`entry ${i+""} must be an object.`)
const o=t,s=Zo(o,"id",i),r=Zo(o,"label",i)
if(!/^[a-z][a-z0-9-]{0,47}$/u.test(s)||e.has(s))throw new Go(`entry ${i+""} has an invalid or duplicate id.`)
e.add(s)
const n=((t,e)=>{if(!Array.isArray(t)||0===t.length||t.length>8)throw new Go(`entry ${e+""} requires 1 to 8 attributes.`)
return Object.freeze(t.map(t=>{if("object"!=typeof t||null===t||Array.isArray(t))throw new Go(`entry ${e+""} contains an invalid attribute.`)
const i=t,o=i.name,s=i.value
if("string"!=typeof o||"string"!=typeof s||!/^(?:class|dir|lang|style|title|data-[a-z0-9-]+)$/u.test(o)||0===s.length||s.length>512||"style"===o&&!(t=>/^(?:(?:color|background-color|font-family|font-size)\s*:\s*[-#(),.%\w\s"']+;?\s*)+$/iu.test(t))(s))throw new Go(`entry ${e+""} contains an unsafe attribute.`)
return Object.freeze({name:o,value:s})}))})(o.attributes,i)
if("inline"===o.target){if("span"!==o.element&&"mark"!==o.element&&"small"!==o.element&&"kbd"!==o.element)throw new Go(`inline entry "${s}" requires span, mark, small, or kbd.`)
return Object.freeze({attributes:n,element:o.element,id:s,label:r,target:"inline"})}if("block"===o.target){const t=o.element
if(void 0!==t&&!(t=>"p"===t||"div"===t||"blockquote"===t||"pre"===t||"string"==typeof t&&/^h[1-6]$/u.test(t))(t))throw new Go(`block entry "${s}" has an unsupported element.`)
return Object.freeze({attributes:n,...void 0===t?{}:{element:t},id:s,label:r,target:"block"})}if("structured"===o.target){const t=Zo(o,"objectType",i)
return Object.freeze({attributes:n,id:s,label:r,objectType:t,target:"structured"})}throw new Go(`entry "${s}" has an unsupported target.`)}))})(this.editor.config.get("cms.styles"))
for(const e of t){const t="style."+e.id
this.editor.commands.register({id:t,label:e.label,canExecute:({editor:t})=>{const i=t.services.tryGet(Qo)
return!0===i?.canEdit()&&("structured"!==e.target||i.isStructuredBlockSelected(e.objectType))},execute:(i,...o)=>{$o(t,o),Jo(Vo(i,t),e)},isActive:({editor:t})=>{const i=t.services.tryGet(Qo)
return void 0!==i&&Lo(i,e)}})}}},class extends qo{static id="link"
init(){const t=(t=>{if(void 0===t)return Object.freeze({Dr:!0,Sr:Object.freeze(["http","https","mailto","tel"])})
if("object"!=typeof t||null===t||Array.isArray(t))throw new TypeError("cms.links must be an object.")
const e=t,i=e.Dr??!0,o=e.Sr??["http","https","mailto","tel"]
if("boolean"!=typeof i)throw new TypeError("cms.links.allowRelative must be boolean.")
if(!Array.isArray(o)||o.length<1||o.length>16||!o.every(t=>"string"==typeof t&&/^[a-z][a-z0-9+.-]{0,31}$/u.test(t)&&!["data","file","javascript","vbscript"].includes(t)))throw new TypeError("cms.links.protocols contains an unsafe protocol.")
return Object.freeze({Dr:i,Sr:Object.freeze([...new Set(o)])})})(this.editor.config.get("cms.links"))
this.editor.commands.register({id:"link.attributes.catalog",label:"List supported link attributes",canExecute:()=>!0,execute:(t,...e)=>($o("link.attributes.catalog",e),zo)}),this.register("link.set",(e,i)=>e.setLink(((t,e)=>{const i=es("link.set",t)
return hs("link.set",i,["customAttributes","href","target","rel","title"]),is({href:ds("link.set",i,"href"),...ns("link.set",i,e),...us("link.set",i,["target","rel","title"])},e)})(i,t)),t=>t.isLinkActive()),this.register("link.setText",(e,i)=>{const o=es("link.setText",i)
hs("link.setText",o,["customAttributes","href","rel","target","text","title"])
const s=ds("link.setText",o,"text")
if(s.length>1e5||ls(s))throw new No("link.setText","requires bounded single-line displayed text.")
const r=is({href:ds("link.setText",o,"href"),...ns("link.setText",o,t),...us("link.setText",o,["target","rel","title"])},t)
var n
e.insertHtml(ps([ms("a",(n=r,Object.freeze([bs("href",n.href),...void 0===n.target?[]:[bs("target",n.target)],...void 0===n.rel?[]:[bs("rel",n.rel)],...void 0===n.title?[]:[bs("title",n.title)],...n.customAttributes??[]])),[Object.freeze({type:"text",value:s})])]))}),this.register("link.remove",(t,e)=>{$o("link.remove",e),t.setLink(void 0)},t=>t.isLinkActive(),"Remove link"),this.register("link.auto",(e,i)=>{const o=((t,e)=>{const i=ts(t,e)
if("string"!=typeof i)throw new No(t,"requires a string.")
return i})("link.auto",i)
e.setLink({href:As(o,t)})}),this.editor.commands.register({id:"link.inspect",label:"Inspect selected link",canExecute:({editor:t})=>Xo(t,"link.inspect")?.isLinkActive()??!1,execute:({editor:t},...e)=>($o("link.inspect",e),Xo(t,"link.inspect")?.getLinkAttributes?.())}),this.editor.commands.register({id:"link.pick",label:"Select a CMS link target",canExecute:({editor:t})=>t.services.has(Wo)&&(Xo(t,"link.pick")?.canEdit()??!1),execute:async({editor:e},i)=>{if("file"!==i&&"internal"!==i)throw new No("link.pick",'requires "file" or "internal".')
const o=await e.services.get(Wo).select(i)
if(null===o)return null
const s=is(o,t)
return Xo(e,"link.pick")?.setLink(s),s}})}},class extends Ko{static id="ordered-list"
init(){this.Br("list.ordered","ol")}},class extends Ko{static id="unordered-list"
init(){this.Br("list.unordered","ul")}},class extends Ho{static id="blockquote"
init(){this.registerBlock("blockquote.toggle","blockquote")}},class extends qo{static id="image"
init(){this.register("image.insert",(t,e)=>{const i=(t=>{const e=es("image.insert",t)
hs("image.insert",e,["src","alt","width","height"])
const i=ds("image.insert",e,"src"),o=us("image.insert",e,["alt"]),s=fs("image.insert",e,"width"),r=fs("image.insert",e,"height")
return{src:i,...o,...void 0===s?{}:{width:s},...void 0===r?{}:{height:r}}})(e),o=[bs("src",i.src)]
void 0!==i.alt&&o.push(bs("alt",i.alt)),void 0!==i.width&&o.push(bs("width",i.width+"")),void 0!==i.height&&o.push(bs("height",i.height+"")),t.insertHtml(ps([ms("img",o)]))})}},class extends U{static id="table"
static requires=[vo,To]
#O=[]
#At
#ht=Object.freeze({getActive:t=>"*"===t||ir.has(t)?this.#At:void 0})
#dt=new WeakMap
#ut=Object.freeze({executeStructuralAction:t=>this.editor.execute((t=>({"add-column":"table.column.insertAfter","add-row":"table.row.insertAfter","clear-cells":"table.cells.clear","delete-column":"table.column.remove","delete-row":"table.row.remove","delete-table":"table.remove","merge-cells":"table.cells.merge","split-columns":"table.cell.splitColumns","split-rows":"table.cell.splitRows","split-cell":"table.cell.split","toggle-header":"table.header.toggle"}[t]))(t)),inspect:()=>this.#ft(),inspectStructure:()=>this.editor.execute("table.structure.inspect"),updateCaption:t=>this.editor.execute(null===t?"table.caption.remove":"table.caption.set",...null===t?[]:[t]),createSection:(t,e)=>this.editor.execute("table.section.create",{kind:t,position:e}),removeSection:t=>this.editor.execute("table.section.remove",t),moveRows:t=>this.editor.execute("table.section.moveRows",t),reorderBodySection:(t,e)=>this.editor.execute("table.section.reorderBody",{fn:t,bn:e}),recover:()=>this.#bt(),updateCells:t=>this.editor.execute("table.cell.properties",t),updateRows:t=>this.editor.execute("table.row.properties",t),updateSection:(t,e)=>"number"==typeof t?this.editor.execute("table.section.properties",{fn:t,properties:e}):this.editor.execute("table.section.properties",t),createColumnGroup:t=>this.editor.execute("table.colgroup.create",t),updateColumnGroup:(t,e)=>this.editor.execute("table.colgroup.properties",{mn:t,properties:e}),removeColumnGroup:t=>this.editor.execute("table.colgroup.remove",t),repairStructure:t=>this.editor.execute("table.structure.repair",t),updateTable:t=>this.editor.execute("table.properties",t)})
init(){this.editor.services.register(Oo,this.#ht),this.editor.services.register(Ps,this.#ut)
const t=this.editor.services.get(mo)
this.#O.push(t.registerBlock({behavior:"atomic",fromHtml:t=>({attributes:t.attributes,children:t.children}),id:Vs,matches:t=>"html"===t.namespace&&"table"===t.tagName,toHtml:t=>({attributes:t.attributes,children:t.children,namespace:"html",tagName:"table",type:"element"}),type:Vs})),this.#mt()
for(const[e,i]of[["table.selection.row","row"],["table.selection.column","column"],["table.selection.table","table"]])this.editor.commands.register({id:e,label:"Select table "+i,canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&e.isStructuredBlockSelected(Vs)&&void 0!==e.setStructuredSelection},execute:({editor:t},...o)=>{xn(e,o)
const s=sn(t.services.tryGet(Qo),e),r=s.getSelectedStructuredBlock(Vs),n=or(s)
if(void 0===r||void 0===n||void 0===s.setStructuredSelection)throw new No(e,"requires a selected table cell.")
const a=an(nr(on(r)),n,i)
if(!s.setStructuredSelection(Vs,a))throw new No(e,"could not update the table selection.")}})
this.#pt("table.row.insertBefore","Insert table row before",(t,e,i,o)=>dr(t,e,rn(i).top,Sn("table.row.insertBefore",o),"table.row.insertBefore")),this.#pt("table.row.insertAfter","Insert table row after",(t,e,i,o)=>dr(t,e,lr(e,i,"row"),Sn("table.row.insertAfter",o),"table.row.insertAfter")),this.#pt("table.row.remove","Remove table rows",(t,e,i,o)=>(xn("table.row.remove",o),((t,e,i)=>{if(i.bottom-i.top+1>=e.rows.length)throw new No("table.row.remove","cannot remove every row.")
const o=new Map,s=[]
for(const n of e.rows)for(const t of n.cells){const e=Math.max(0,Math.min(t.row+t.Tr-1,i.bottom)-Math.max(t.row,i.top)+1)
if(0===e)continue
const r=t.Tr-e,n=0===r?void 0:{...t.element,attributes:bn(t.element.attributes,r,t.Mr)}
o.set(t,n),void 0!==n&&t.row>=i.top&&s.push({column:t.column,cell:n})}const r=Ar(t,e,t=>o.has(t)?o.get(t):t.element,new Map([[i.bottom+1,s]]))
return{...r,children:cr(r.children,(t,e)=>e>=i.top&&e<=i.bottom?[]:[t])}})(t,e,rn(i)))),this.#pt("table.column.insertBefore","Insert table column before",(t,e,i,o)=>fr(t,e,rn(i).left,Sn("table.column.insertBefore",o),"table.column.insertBefore")),this.#pt("table.column.insertAfter","Insert table column after",(t,e,i,o)=>fr(t,e,lr(e,i,"column"),Sn("table.column.insertAfter",o),"table.column.insertAfter")),this.#pt("table.column.remove","Remove table columns",(t,e,i,o)=>(xn("table.column.remove",o),((t,e,i)=>{const o=i.right-i.left+1
if(o>=e.columns)throw new No("table.column.remove","cannot remove every column.")
return br(Ar(t,e,t=>{const e=Math.max(0,Math.min(t.column+t.Mr-1,i.right)-Math.max(t.column,i.left)+1),o=t.Mr-e
return 0===o?void 0:0===e?t.element:{...t.element,attributes:bn(t.element.attributes,t.Tr,o)}}),e.columns,i.left,o)})(t,e,rn(i)))),this.#pt("table.header.toggle","Toggle table headers",(t,e,i,o)=>(xn("table.header.toggle",o),((t,e,i)=>{const o=un(e,i),s=o.some(t=>"th"!==t.element.tagName)
return Gr(t,new Map(o.map(t=>[t,{...t.element,tagName:s?"th":"td",attributes:s?t.element.attributes:jr(t.element.attributes,"scope",null)}])))})(t,e,rn(i)))),this.#pt("table.header.firstRow","Set first row as column headers",(t,e,i,o)=>wr(t,e,"row",gr(o))),this.#pt("table.header.firstColumn","Set first column as row headers",(t,e,i,o)=>wr(t,e,"column",gr(o))),this.#pt("table.cells.merge","Merge table cells",(t,e,i,o)=>(xn("table.cells.merge",o),vr(t,e,rn(i)))),this.editor.commands.register({id:"table.cells.canMerge",label:"Check whether table cells can merge",canExecute:({editor:t})=>!0===t.services.tryGet(Qo)?.isStructuredBlockSelected(Vs),execute:({editor:t},e)=>{const i=sn(t.services.tryGet(Qo),"table.cells.canMerge"),o=i.getSelectedStructuredBlock(Vs),s=An(e)??or(i)??(void 0===o?void 0:this.#dt.get(o))
if(void 0===o||void 0===s)return!1
try{const t=on(o),e=nr(t)
return dn(e,s,"table.cells.canMerge"),vr(t,e,rn(s)),!0}catch{return!1}}}),this.editor.commands.register({id:"table.cell.canSplit",label:"Check whether a table cell can split",canExecute:({editor:t})=>!0===t.services.tryGet(Qo)?.isStructuredBlockSelected(Vs),execute:({editor:t},e,i="all")=>{if("all"!==i&&"rows"!==i&&"columns"!==i)return!1
const o=sn(t.services.tryGet(Qo),"table.cell.canSplit"),s=o.getSelectedStructuredBlock(Vs),r=An(e)??or(o)??(void 0===s?void 0:this.#dt.get(s))
if(void 0===s||void 0===r)return!1
try{const t=on(s),e=nr(t)
dn(e,r,"table.cell.canSplit")
const o=rn(r)
if("all"===i){const t=e.grid[o.top]?.[o.left]
if(void 0===t||1===t.Tr&&1===t.Mr)return!1}return yr(t,e,o,i),!0}catch{return!1}}}),this.#pt("table.cell.split","Split table cell",(t,e,i,o)=>(xn("table.cell.split",o),yr(t,e,rn(i)))),this.#pt("table.cell.splitRows","Split table cell into rows",(t,e,i,o)=>(xn("table.cell.splitRows",o),yr(t,e,rn(i),"rows"))),this.#pt("table.cell.splitColumns","Split table cell into columns",(t,e,i,o)=>(xn("table.cell.splitColumns",o),yr(t,e,rn(i),"columns"))),this.#pt("table.cells.clear","Clear table cells",(t,e,i,o)=>(xn("table.cells.clear",o),kr(t,e,rn(i),()=>[]))),this.#pt("table.cell.setText","Set table cell text",(t,e,i,o)=>{const s=Dn("table.cell.setText",o)
return kr(t,e,rn(i),()=>[Object.freeze({type:"text",value:s})])}),this.#pt("table.cell.setHtml","Set rich table cell HTML",(t,e,i,o)=>{const s=io(Dn("table.cell.setHtml",o)).document
if(void 0!==In(s.children,"table"))throw new No("table.cell.setHtml","does not allow nested tables.")
return kr(t,e,rn(i),()=>s.children.map(t=>t))}),this.#pt("table.cells.commitHtml","Commit edited table cell HTML",(t,e,i,o)=>((t,e,i)=>{const o=new Map
for(const s of i){const t=e.grid[s.row]?.[s.column]
if(void 0===t)throw new No("table.cells.commitHtml","contains a cell outside the table.")
const i=io(s.html).document
if(void 0!==In(i.children,"table"))throw new No("table.cells.commitHtml","does not allow nested tables.")
o.set(t,{...t.element,children:i.children.map(t=>t)})}return Gr(t,o)})(t,e,(t=>{if(1!==t.length||!Array.isArray(t[0]))throw new No("table.cells.commitHtml","requires an array of edited cells.")
if(0===t[0].length||t[0].length>tr)throw new No("table.cells.commitHtml","requires between 1 and 1,000 edited cells.")
return t[0].map(t=>{if("object"!=typeof t||null===t)throw $r()
const e=Reflect.get(t,"row"),i=Reflect.get(t,"column"),o=Reflect.get(t,"html")
if(!Number.isInteger(e)||!Number.isInteger(i)||"number"!=typeof e||"number"!=typeof i||e<0||i<0||"string"!=typeof o||o.length>er)throw $r()
return Object.freeze({column:i,html:o,row:e})})})(o))),this.#pt("table.cells.paste","Paste table cells",(t,e,i,o)=>((t,e,i,o)=>{const s=Math.max(...o.map(t=>t.length))
if(i.top+o.length>e.rows.length||i.left+s>e.columns)throw new No("table.cells.paste","clipboard matrix does not fit the table and automatic expansion is disabled.")
const r={bottom:i.top+o.length-1,left:i.left,right:i.left+s-1,top:i.top}
if(un(e,r).some(t=>1!==t.Tr||1!==t.Mr))throw new No("table.cells.paste","clipboard matrix conflicts with a spanned table cell.")
return kr(t,e,r,(t,e,i)=>o[e]?.[i]??[])})(t,e,rn(i),(t=>{if(1!==t.length||!Array.isArray(t[0]))throw new No("table.cells.paste","requires a cell matrix.")
const e=t[0]
if(0===e.length||e.length>Xs)throw tn()
const i=[]
let o=0
const s={Fr:er,Rr:1e4}
for(const r of e){if(!Array.isArray(r)||0===r.length||r.length>$s||o+r.length>tr)throw tn()
const t=[]
for(const e of r){if(!Array.isArray(e)||!e.every(t=>en(t,s,0)))throw tn()
t.push([...e])}i.push(t),o+=r.length}return i})(o))),this.#pt("table.properties","Set table properties",(t,e,i,o)=>((t,e)=>{let i=t.attributes
void 0!==e.alignment&&(i=jr(i,"align",e.alignment)),void 0!==e.width&&(i=jr(i,"width",e.width)),void 0!==e.height&&(i=jr(i,"height",e.height))
for(const[s,r]of[["border",e.border],["cellpadding",e.cellPadding],["cellspacing",e.cellSpacing],["summary",e.summary]])void 0!==r&&(i=jr(i,s,r))
void 0!==e.responsiveClass&&(i=jr(i,"class",e.responsiveClass)),void 0!==e.ariaLabel&&(i=jr(i,"aria-label",e.ariaLabel)),void 0!==e.customAttributes&&(i=Nr(i,e.customAttributes))
let o=t.children
if(void 0!==e.caption){const t=gn(o,"caption")
o=o.filter(t=>!yn(t,"caption")),null!==e.caption&&(o=[pn("caption",t?.attributes??[],[Object.freeze({type:"text",value:e.caption})]),...o])}return{...t,attributes:i,children:o}})(t,(t=>{const e=Zr("table.properties",t,["alignment","ariaLabel","border","caption","cellPadding","cellSpacing","responsiveClass","summary","width","height","customAttributes"]),i=Xr("table.properties",e.alignment,["center","left","right"]),o=Kr("table.properties","width",e.width),s=Kr("table.properties","height",e.height),r=Pr("table.properties",e.responsiveClass)
return Object.freeze({...void 0===i?{}:{alignment:i},...Ur("table.properties",e,"ariaLabel",512),...Jr("table.properties",e,"border"),...Ur("table.properties",e,"caption",2048),...Jr("table.properties",e,"cellPadding"),...Jr("table.properties",e,"cellSpacing"),...void 0===r?{}:{responsiveClass:r},...Ur("table.properties",e,"summary",2048),...void 0===o?{}:{width:o},...void 0===s?{}:{height:s},...qr("table.properties",e)})})(o))),this.#pt("table.caption.set","Set table caption",(t,e,i,o)=>xr(t,Dn("table.caption.set",o))),this.#pt("table.caption.remove","Remove table caption",(t,e,i,o)=>(xn("table.caption.remove",o),xr(t,null))),this.#pt("table.section.create","Create table section",(t,e,i,o)=>((t,e)=>{const i=Cr(t)
if("body"!==e.kind&&i.some(t=>t.tagName===Fr(e.kind)))throw new No("table.section.create",`table already contains a ${Fr(e.kind)}.`)
const o=pn(Fr(e.kind),[],[]),s=[...t.children]
let r
if("head"===e.kind)r=s.findIndex(t=>yn(t,"tbody")||yn(t,"tfoot")||yn(t,"tr"))
else if("foot"===e.kind){let t=-1
for(let e=s.length-1;e>=0;e-=1){const i=s[e]
if(void 0!==i&&(yn(i,"thead")||yn(i,"tbody")||yn(i,"tfoot")||yn(i,"tr"))){t=e
break}}r=t<0?s.length:t+1}else{const t=i.filter(t=>"tbody"===t.tagName),o=t[e.position??t.length]
r=void 0===o?s.findIndex(t=>yn(t,"tfoot")):s.indexOf(o)}return s.splice(r<0?s.length:r,0,o),{...t,children:s}})(t,(t=>{const e=Zr("table.section.create",t,["kind","position"])
if(!["body","foot","head"].includes(e.kind+""))throw new No("table.section.create","kind must be body, foot, or head.")
const i=e.position
if(void 0!==i&&(!Number.isInteger(i)||Number(i)<0||Number(i)>100))throw new No("table.section.create","position must be from 0 to 100.")
return{kind:e.kind,...void 0===i?{}:{position:Number(i)}}})(o))),this.#pt("table.section.remove","Remove empty table section",(t,e,i,o)=>((t,e)=>{const i=Cr(t),o=i[e]
if(void 0===o)throw new No("table.section.remove","section does not exist.")
if(o.children.some(t=>yn(t,"tr")))throw new No("table.section.remove","cannot remove a section that contains rows.")
if("tbody"===o.tagName&&i.filter(t=>"tbody"===t.tagName).length<=1)throw new No("table.section.remove","cannot remove the last tbody.")
return{...t,children:t.children.filter(t=>t!==o)}})(t,zr("table.section.remove",o,0,1024))),this.#pt("table.section.moveRows","Move rows to table section",(t,e,i,o)=>((t,e,i)=>{const o=rn(i.range)
dn(e,i.range,"table.section.moveRows")
const s=Cr(t)[i.targetSectionIndex]
if(void 0===s)throw new No("table.section.moveRows","target section does not exist.")
const r=e.rows.slice(o.top,o.bottom+1),n=new Set(r.map(e=>Tr(t,e.element)))
if(1!==n.size||n.has(void 0))throw new No("table.section.moveRows","selected rows must belong to one explicit section.")
const a=new Set(r.map(t=>t.element))
for(const c of e.rows.flatMap(t=>t.cells)){const t=c.row+c.Tr-1
if(c.row<=o.bottom&&t>=o.top&&(c.row<o.top||t>o.bottom))throw new No("table.section.moveRows",`rowspan at row ${c.row+1+""}, column ${c.column+1+""} crosses the move boundary.`)}return{...t,children:t.children.map(t=>{if(t===s){const e=t.children.filter(t=>!a.has(t))
return{...t,children:"start"===i.placement?[...r.map(t=>t.element),...e]:[...e,...r.map(t=>t.element)]}}return"element"===t.type&&["thead","tbody","tfoot"].includes(t.tagName)?{...t,children:t.children.filter(t=>!a.has(t))}:t})}})(t,e,(t=>{const e=Zr("table.section.moveRows",t,["placement","range","targetSectionIndex"]),i=An(e.range)
if(void 0===i||!["start","end"].includes(e.placement+""))throw new No("table.section.moveRows","requires a range and start or end placement.")
return{placement:e.placement,range:i,targetSectionIndex:Wr("table.section.moveRows",e.targetSectionIndex,0,1024)}})(o))),this.#pt("table.section.reorderBody","Reorder table body section",(t,e,i,o)=>((t,e)=>{const i=Cr(t),o=i[e.fn],s=i[e.bn]
if("tbody"!==o?.tagName||"tbody"!==s?.tagName)throw new No("table.section.reorderBody","source and target must both be tbody sections.")
const r=[...t.children],n=r.indexOf(o),a=r.indexOf(s)
return r[n]=s,r[a]=o,{...t,children:r}})(t,(t=>{const e=Zr("table.section.reorderBody",t,["sectionIndex","targetIndex"])
return{fn:Wr("table.section.reorderBody",e.fn,0,1024),bn:Wr("table.section.reorderBody",e.bn,0,1024)}})(o))),this.#pt("table.colgroup.create","Create table column group",(t,e,i,o)=>((t,e,i)=>{const o=Sr(t,e,"table.colgroup.create").reduce((t,e)=>t+e.columnCount,0),s=e.columns-o,r=i.columns,n=r?.reduce((t,e)=>t+e.span,0)??0,a=void 0===r?i.span??s:null
if(void 0!==r&&(n<1||n>s)||void 0===r&&(null===a||a<1||a>s))throw new No("table.colgroup.create","column group coverage must fit the remaining logical columns.")
const c=pn("colgroup",Nr(null===a?[]:[{name:"span",value:a+""}],i.customAttributes),r?.map(Dr)??[]),l=[...t.children],A=Ir(t),h=A[i.position??A.length],d=void 0===h?l.findIndex(t=>"element"===t.type&&["thead","tbody","tfoot","tr"].includes(t.tagName)):l.indexOf(h)
return l.splice(d<0?l.length:d,0,c),{...t,children:l}})(t,e,(t=>{const e=Zr("table.colgroup.create",t,["columns","customAttributes","position","span"]),i=Yr("table.colgroup.create",{...void 0===e.columns?{}:{columns:e.columns},...void 0===e.customAttributes?{}:{customAttributes:e.customAttributes},...void 0===e.span?{}:{span:e.span}}),o=e.position
if(void 0!==o&&(!Number.isInteger(o)||Number(o)<0||Number(o)>$s))throw new No("table.colgroup.create","position must be from 0 to 100.")
return{...i,...void 0===o?{}:{position:Number(o)}}})(o))),this.#pt("table.colgroup.properties","Set table column group properties",(t,e,i,o)=>{const s=(t=>{const e=Zr("table.colgroup.properties",t,["groupIndex","properties"])
return{mn:Wr("table.colgroup.properties",e.mn,0,1024),properties:Yr("table.colgroup.properties",e.properties)}})(o)
return((t,e,i,o)=>{const s=Sr(t,e,"table.colgroup.properties"),r=Ir(t)[i],n=s[i]
if(void 0===r||void 0===n)throw new No("table.colgroup.properties","column group does not exist.")
if(r.children.some(t=>yn(t,"col"))&&void 0!==o.span)throw new No("table.colgroup.properties","span cannot be set on a group containing col elements.")
if(void 0!==o.columns&&void 0!==o.span)throw new No("table.colgroup.properties","columns and group span cannot be updated together.")
const a=Nr(_r(r.attributes,[["span",void 0===o.span?void 0:null===o.span?null:o.span+""]]),o.customAttributes)
return{...t,children:t.children.map(t=>t===r?{...r,attributes:void 0===o.columns?a:jr(a,"span",null),children:void 0===o.columns?r.children:Mr(r.children,o.columns)}:t)}})(t,e,s.mn,s.properties)}),this.#pt("table.colgroup.remove","Remove empty table column group",(t,e,i,o)=>((t,e,i)=>{Sr(t,e,"table.colgroup.remove")
const o=Ir(t)[i]
if(void 0===o)throw new No("table.colgroup.remove","column group does not exist.")
if(o.children.some(t=>yn(t,"col"))||void 0!==wn(o.attributes,"span"))throw new No("table.colgroup.remove","only an empty column group can be removed.")
return{...t,children:t.children.filter(t=>t!==o)}})(t,e,zr("table.colgroup.remove",o,0,1024))),this.#pt("table.structure.repair","Repair table structure",(t,e,i,o)=>{const s=Dn("table.structure.repair",o)
if("wrap-direct-rows"!==s&&"remove-empty-duplicate-sections"!==s)throw new No("table.structure.repair","unknown or unsafe repair.")
return"wrap-direct-rows"===s?(t=>{const e=[]
let i=[]
const o=()=>{0!==i.length&&(e.push(pn("tbody",[],i)),i=[])}
for(const s of t.children)yn(s,"tr")?i.push(s):(o(),e.push(s))
return o(),{...t,children:e}})(t):(t=>{let e=Cr(t).filter(t=>yn(t,"tbody")).length
const i=new Set
return{...t,children:t.children.filter(t=>{if("element"!==t.type||!["thead","tbody","tfoot"].includes(t.tagName))return!0
const o=i.has(t.tagName)
return i.add(t.tagName),!(0===t.attributes.length&&0===t.children.length)||("tbody"===t.tagName?e<=1||(e-=1,!1):!o)})}})(t)}),this.#pt("table.row.properties","Set table row properties",(t,e,i,o)=>((t,e,i,o)=>{let s={...t,children:cr(t.children,(t,e)=>[e<i.top||e>i.bottom?t:{...t,attributes:Nr(_r(t.attributes,[["aria-label",o.ariaLabel],["class",o.className],["height","number"==typeof o.height?o.height+"":o.height]]),o.customAttributes)}])}
return void 0!==o.section&&(s=((t,e,i,o)=>{const s=[]
for(const a of t.children)if(yn(a,"tr"))s.push({element:a,section:"body"})
else if("element"===a.type&&("thead"===a.tagName||"tbody"===a.tagName||"tfoot"===a.tagName)){if(a.attributes.length>0)throw new No("table.row.properties","does not move rows from attributed table sections.")
const t="thead"===a.tagName?"head":"tfoot"===a.tagName?"foot":"body"
for(const e of a.children)yn(e,"tr")&&s.push({element:e,section:t})}if(s.length!==e.rows.length)throw new No("table.row.properties","could not map every row to a table section.")
for(let a=i.top;a<=i.bottom;a+=1){const t=s[a]
void 0!==t&&(s[a]={...t,section:o})}const r=[]
for(const a of s){const t=Fr(a.section),e=r.at(-1)
e?.tagName===t?r[r.length-1]={...e,children:[...e.children,a.element]}:r.push(pn(t,[],[a.element]))}const n=t.children.filter(t=>yn(t,"caption")||yn(t,"colgroup"))
return{...t,children:[...n,...r]}})(s,e,i,o.section)),s})(t,e,rn(i),(t=>{const e=Zr("table.row.properties",t,["ariaLabel","className","height","section","customAttributes"]),i=Kr("table.row.properties","height",e.height),o=Vr("table.row.properties",e.section,["body","foot","head"]),s=Pr("table.row.properties",e.className)
return Object.freeze({...Ur("table.row.properties",e,"ariaLabel",512),...void 0===s?{}:{className:s},...void 0===i?{}:{height:i},...void 0===o?{}:{section:o},...qr("table.row.properties",e)})})(o))),this.#pt("table.cell.properties","Set table cell properties",(t,e,i,o)=>((t,e,i,o)=>{const s=un(e,i)
if((void 0!==o.scope&&null!==o.scope||!0===o.customAttributes?.some(({name:t})=>"abbr"===t))&&s.some(t=>"th"!==t.element.tagName))throw new No("table.cell.properties","applies scope and abbr only to header cells.")
return Gr(t,new Map(s.map(t=>[t,{...t.element,attributes:Nr(_r(t.element.attributes,[["aria-label",o.ariaLabel],["class",o.className],["align",o.horizontalAlignment],["valign",o.verticalAlignment],["scope",o.scope],["height",o.height],["width",o.width]]),o.customAttributes)}])))})(t,e,rn(i),(t=>{const e=Zr("table.cell.properties",t,["ariaLabel","className","horizontalAlignment","scope","verticalAlignment","customAttributes","height","width"]),i=Pr("table.cell.properties",e.className),o=Xr("table.cell.properties",e.horizontalAlignment,["center","left","right"]),s=Xr("table.cell.properties",e.scope,["col","colgroup","row","rowgroup"]),r=Xr("table.cell.properties",e.verticalAlignment,["baseline","bottom","middle","top"]),n=Kr("table.cell.properties","height",e.height),a=Kr("table.cell.properties","width",e.width)
return Object.freeze({...Ur("table.cell.properties",e,"ariaLabel",512),...void 0===i?{}:{className:i},...void 0===o?{}:{horizontalAlignment:o},...void 0===s?{}:{scope:s},...void 0===r?{}:{verticalAlignment:r},...void 0===n?{}:{height:n},...void 0===a?{}:{width:a},...qr("table.cell.properties",e)})})(o))),this.#pt("table.section.properties","Set table section properties",(t,e,i,o)=>{const s=(t=>{if(1!==t.length||"object"!=typeof t[0]||null===t[0]||Array.isArray(t[0])||!Object.hasOwn(t[0],"sectionIndex"))return
const e=Zr("table.section.properties",t,["properties","sectionIndex"])
return{properties:Hr([e.properties]),fn:Wr("table.section.properties",e.fn,0,1024)}})(o)
return void 0===s?((t,e,i,o)=>{const s=e.rows[i.top]?.element,r=void 0===s?void 0:Tr(t,s)
if(void 0===r)throw new No("table.section.properties","requires an explicit thead, tbody, or tfoot section.")
return{...t,children:t.children.map(t=>t===r?{...r,attributes:Nr(r.attributes,o.customAttributes)}:t)}})(t,e,rn(i),Hr(o)):((t,e,i)=>{const o=Cr(t)[e]
if(void 0===o)throw new No("table.section.properties","section does not exist.")
return{...t,children:t.children.map(t=>t===o?{...o,attributes:Nr(o.attributes,i.customAttributes)}:t)}})(t,s.fn,s.properties)}),this.#pt("table.column.resize","Resize table columns",(t,e,i,o)=>((t,e,i,o)=>{if(Ir(t).length>0)return((t,e)=>{const i=Ir(pr(t))
if(0===i.length)return mr(t,e)
if(i.flatMap(t=>t.children.filter(t=>yn(t,"col")).map(t=>{const e=wn(t.attributes,"width")
if(void 0===e||/^\d{1,4}%$/u.test(e))return
const i=/^(\d{1,4})(?:px)?$/u.exec(e),o=Number(i?.[1])
if(null===i||!Number.isInteger(o)||o<40||o>1200)throw new No("table.column.resize","found a column width that cannot be mapped safely.")
return o})).length!==e)throw new No("table.column.resize","requires column groups to match the logical table grid.")})(t,e.columns),((t,e,i)=>{let o=0
const s=pr(t)
return{...s,children:s.children.map(t=>yn(t,"colgroup")?{...t,children:t.children.map(t=>{if(!yn(t,"col"))return t
const s=o>=e.left&&o<=e.right
return o+=1,s?{...t,attributes:jr(t.attributes,"width",null===i?null:i+"px")}:t})}:t)}})(t,i,o.width)
const s=[...mr(t,e.columns,"table.column.resize")]
for(let r=i.left;r<=i.right;r+=1)s[r]=o.width??void 0
return((t,e)=>{const i=t.children.filter(t=>!yn(t,"colgroup"))
if(e.every(t=>void 0===t))return{...t,children:i}
const o=pn("colgroup",[],e.map(t=>pn("col",void 0===t?[]:[{name:"width",value:t+""}],[]))),s=i.findIndex(t=>!yn(t,"caption")),r=[...i]
return r.splice(s<0?r.length:s,0,o),{...t,children:r}})(t,s)})(t,e,rn(i),(t=>{const e=Zr("table.column.resize",t,["width"]).width
if(null!==e&&(!Number.isInteger(e)||Number(e)<40||Number(e)>1200))throw new No("table.column.resize","requires width from 40 to 1200 pixels or null.")
return Object.freeze({width:null===e?null:Number(e)})})(o))),this.#gt("table.inspect","Inspect table properties",t=>Object.freeze({alignment:wn(t.attributes,"align")??"",ariaLabel:wn(t.attributes,"aria-label")??"",border:wn(t.attributes,"border")??"",caption:Cn(gn(t.children,"caption")?.children??[])??"",responsiveClass:wn(t.attributes,"class")??"",cellPadding:wn(t.attributes,"cellpadding")??"",cellSpacing:wn(t.attributes,"cellspacing")??"",summary:wn(t.attributes,"summary")??"",width:wn(t.attributes,"width")??"",height:wn(t.attributes,"height")??"",customAttributes:Or(t.attributes)})),this.#gt("table.structure.inspect","Inspect table structure",(t,e)=>Er(t,e)),this.#gt("table.row.inspect","Inspect table row properties",(t,e,i)=>{const o=rn(i),s=e.rows[o.top]
return Object.freeze({ariaLabel:wn(s?.element.attributes??[],"aria-label")??"",className:wn(s?.element.attributes??[],"class")??"",height:wn(s?.element.attributes??[],"height")??"",section:Rr(t.children)[o.top]??"body",customAttributes:Or(s?.element.attributes??[])})}),this.#gt("table.cell.inspect","Inspect table cell properties",(t,e,i)=>{const o=rn(i),s=e.grid[o.top]?.[o.left],r=s?.element.attributes??[]
return Object.freeze({tagName:s?.element.tagName??"",ariaLabel:wn(r,"aria-label")??"",className:wn(r,"class")??"",horizontalAlignment:wn(r,"align")??"",scope:wn(r,"scope")??"",verticalAlignment:wn(r,"valign")??"",height:wn(r,"height")??"",width:wn(r,"width")??"",Tr:wn(r,"rowspan")??"1",Mr:wn(r,"colspan")??"1",pn:void 0===s?"":oo({children:s.element.children,type:"document-fragment"}),customAttributes:Or(r)})}),this.#gt("table.section.inspect","Inspect table section properties",(t,e,i)=>((t,e,i)=>{const o=e.rows[i.top]?.element,s=void 0===o?void 0:Tr(t,o)
return Object.freeze({gn:void 0!==s,tagName:s?.tagName??"",customAttributes:Or(s?.attributes??[])})})(t,e,rn(i))),this.editor.commands.register({id:"table.recover",label:"Repair empty table",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo),i=e?.getSelectedStructuredBlock(Vs)
return!0===e?.canEdit()&&void 0!==i&&rr(on(i))},execute:(t,...e)=>{xn("table.recover",e),this.#bt()}}),this.editor.commands.register({id:"table.remove",label:"Remove table",canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&e.isStructuredBlockSelected(Vs)&&void 0!==e.removeSelectedStructuredBlock},execute:({editor:t},...e)=>{xn("table.remove",e)
const i=sn(t.services.tryGet(Qo),"table.remove")
if(void 0===i.removeSelectedStructuredBlock)throw new No("table.remove","requires structured-block removal support.")
i.removeSelectedStructuredBlock(Vs)}})}wn(t){const e=this.editor.services.get(mo)
this.#O.push(e.registerNodeView(Vs,e=>t(e,t=>{this.#dt.set(e.node,t)},this.editor.services.get(Do),t=>{this.#At=t},t=>{this.#At===t&&(this.#At=void 0)})))}destroy(){for(const t of this.#O.reverse())t()
this.#O=[],this.#At=void 0,this.editor.services.tryGet(Oo)===this.#ht&&this.editor.services.unregister(Oo),this.editor.services.tryGet(Ps)===this.#ut&&this.editor.services.unregister(Ps),this.#dt=new WeakMap}#ft(){const t=this.editor.services.tryGet(Qo),e=t?.getSelectedStructuredBlock(Vs)
if(void 0===t||void 0===e)return{editable:!1}
const i=on(e)
try{const o=nr(i),s=or(t)??this.#dt.get(e)
return void 0===s?{editable:t.canEdit()}:(dn(o,s,"table editor"),Object.freeze({cell:this.editor.execute("table.cell.inspect"),editable:t.canEdit(),capabilities:cn(i,o,s),row:this.editor.execute("table.row.inspect"),section:this.editor.execute("table.section.inspect"),selection:s,selectionKind:nn(o,s),table:this.editor.execute("table.inspect")}))}catch{const e=sr(i)
return Object.freeze({diagnostic:Object.freeze({code:e?"no-rows":"invalid-structure",message:e?"表格没有可编辑的行。":"表格结构异常，请使用源码模式修复或删除表格。",recoverable:e&&rr(i)}),editable:t.canEdit()})}}#bt(){const t=sn(this.editor.services.tryGet(Qo),"table.recover"),e=t.getSelectedStructuredBlock(Vs)
if(void 0===e)throw new No("table.recover","requires a selected table.")
const i=on(e)
if(!rr(i))throw new No("table.recover","cannot safely repair this table.")
const o=pn("tr",[],[pn("td",[],[])]),s=gn(i.children,"tbody"),r=void 0===s?[...i.children,pn("tbody",[],[o])]:i.children.map(t=>t===s?{...s,children:[o]}:t)
t.replaceStructuredBlockContent(Vs,{attributes:i.attributes,children:r})}#mt(){this.editor.commands.register({id:"table.insert",label:"Insert table",canExecute:({editor:t})=>t.services.tryGet(Qo)?.canEdit()??!1,execute:({editor:t},e)=>{const i=(t=>{if("object"!=typeof t||null===t||Array.isArray(t))throw new No("table.insert","requires an options object.")
const e=t
if(Object.keys(e).some(t=>"rows"!==t&&"columns"!==t))throw new No("table.insert","received an unknown option.")
const i=En(e.rows),o=En(e.columns)
if(void 0===i||void 0===o||i>Xs||o>$s||i*o>tr)throw new No("table.insert","supports 1–100 rows, 1–100 columns, and at most 1000 cells.")
return{columns:o,rows:i}})(e)
t.services.get(Qo).insertHtml(oo((t=>{return e=Array.from({length:t.rows},()=>pn("tr",[],Array.from({length:t.columns},()=>pn("td",[],[Object.freeze({type:"text",value:" "})])))),Object.freeze({children:Object.freeze([pn("table",[],[pn("tbody",[],e)])]),type:"document-fragment"})
var e})(i)))}})}#pt(t,e,i){this.editor.commands.register({id:t,label:e,canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.canEdit()&&e.isStructuredBlockSelected(Vs)},execute:({editor:e},...o)=>{const s=sn(e.services.tryGet(Qo),t),r=s.getSelectedStructuredBlock(Vs),n=An(o[0]),a=n??or(s)??(void 0===r?void 0:this.#dt.get(r))
if(void 0===r||void 0===a)throw new No(t,"requires a selected table cell.")
const c=on(r),l=nr(c)
dn(l,a,t)
const A=i(c,l,a,void 0===n?o:o.slice(1))
s.replaceStructuredBlockContent(Vs,{attributes:A.attributes,children:A.children})
const h=s.getSelectedStructuredBlock(Vs)
if(void 0!==h){let e=a
if("table.row.remove"===t||"table.column.remove"===t){const t=nr(A),i=e=>({row:Math.min(e.row,t.rows.length-1),column:Math.min(e.column,t.columns-1)})
e={...a,anchor:i(a.anchor),focus:i(a.focus)},s.setStructuredSelection?.(Vs,e)}this.#dt.set(h,e)}}})}#gt(t,e,i){this.editor.commands.register({id:t,label:e,canExecute:({editor:t})=>{const e=t.services.tryGet(Qo)
return!0===e?.isStructuredBlockSelected(Vs)},execute:({editor:e},...o)=>{xn(t,o)
const s=sn(e.services.tryGet(Qo),t),r=s.getSelectedStructuredBlock(Vs),n=or(s)??(void 0===r?void 0:this.#dt.get(r))
if(void 0===r||void 0===n)throw new No(t,"requires a selected table cell.")
const a=on(r)
return i(a,nr(a),n)}})}},class extends U{static id="editor-ui"
#I=!1
#D
init(){const t={vn:new Map,yn:new Map,kn:new Map,Cn:new Map,In:new Map},e=Object.freeze({registerContextMenuItem:(e,i)=>this.#wt(t,e,i),registerShortcut:e=>this.#vt(t,e),registerStatusItem:(e,i)=>this.#yt(t,e,i),registerToolbarItem:(e,i)=>this.#kt(t,e,i)})
Wa.set(e,t),this.#D=e
for(const[i,o]of Ca)this.#kt(t,i,o)
for(const i of Wn)this.#vt(t,i)
this.editor.services.register(za,e)}destroy(){this.#I=!0
const t=this.#D
if(void 0!==t){const e=Ua(t)
e.vn.clear(),e.yn.clear(),e.kn.clear(),e.Cn.clear(),e.In.clear()}this.#D=void 0}#kt(t,e,i){if(this.#g(),"string"!=typeof e||0===e.trim().length)throw new TypeError("A toolbar item ID must not be empty.")
if("function"!=typeof i)throw new TypeError(`Toolbar item "${e}" requires a factory.`)
if(t.In.has(e))throw new Za("toolbar item",e)
t.In.set(e,i)
let o=!0
return()=>{o&&t.In.get(e)===i&&t.In.delete(e),o=!1}}#wt(t,e,i){if(this.#g(),"object"!=typeof i||null===i)throw new TypeError(`Context menu item "${e}" requires a definition.`)
if("string"!=typeof i.label||0===i.label.trim().length||"string"!=typeof i.command||0===i.command.trim().length||void 0!==i.group&&("string"!=typeof i.group||0===i.group.trim().length)||void 0!==i.tone&&"default"!==i.tone&&"danger"!==i.tone||void 0!==i.when&&"function"!=typeof i.when)throw new TypeError(`Context menu item "${e}" is invalid.`)
if("string"!=typeof e||0===e.trim().length)throw new TypeError("A context menu item ID must not be empty.")
if(t.vn.has(e))throw new Za("context menu item",e)
const o=Object.freeze({...i,...void 0===i.args?{}:{args:Object.freeze([...i.args])}})
t.vn.set(e,o)
let s=!0
return()=>{s&&t.vn.get(e)===o&&t.vn.delete(e),s=!1}}#yt(t,e,i){return this.#Ct(t.Cn,"status item",e,i)}#Ct(t,e,i,o){if(this.#g(),"string"!=typeof i||0===i.trim().length)throw new TypeError(`A ${e} ID must not be empty.`)
if("function"!=typeof o)throw new TypeError(`${e} "${i}" requires a factory.`)
if(t.has(i))throw new Za(e,i)
t.set(i,o)
let s=!0
return()=>{s&&t.get(i)===o&&t.delete(i),s=!1}}#vt(t,e){this.#g()
const i=(t=>{if("object"!=typeof t||null===t||"string"!=typeof t.id||0===t.id.trim().length)throw new TypeError("A keyboard shortcut ID must not be empty.")
if("string"!=typeof t.command||0===t.command.trim().length)throw new TypeError("A keyboard shortcut command must not be empty.")
if(void 0!==t.args&&!Array.isArray(t.args))throw new TypeError("Keyboard shortcut arguments must be an array.")
if("string"!=typeof t.chord)throw new TypeError("A keyboard shortcut chord must be a string.")
const e=(t=>{const e=t.split("+").map(t=>t.trim()).filter(t=>t.length>0),i=e.at(-1)
if(void 0===i||Ha.has(i))throw new TypeError(`Keyboard shortcut chord "${t}" must include a non-modifier key.`)
const o=e.slice(0,-1)
if(o.some(t=>!Ha.has(t))||new Set(o).size!==o.length)throw new TypeError(`Keyboard shortcut chord "${t}" is invalid.`)
const s=Ya(i),r=o.includes("Alt"),n=o.includes("Mod"),a=o.includes("Shift")
return Object.freeze({alt:r,chord:[...n?["Mod"]:[],...r?["Alt"]:[],...a?["Shift"]:[],1===s.length?s.toUpperCase():s].join("+"),key:s,mod:n,shift:a})})(t.chord)
return Object.freeze({id:t.id,chord:e.chord,command:t.command,args:Object.freeze([...t.args??[]]),En:e})})(e)
if(t.kn.has(i.id))throw new Za("shortcut ID",i.id)
if(t.yn.has(i.chord))throw new Za("shortcut chord",i.chord)
t.kn.set(i.id,i),t.yn.set(i.chord,i)
let o=!0
return()=>{o&&t.kn.get(i.id)===i&&(t.kn.delete(i.id),t.yn.delete(i.chord)),o=!1}}#g(){if(this.#I)throw new e}}]),kc=Object.freeze({Bn:L,xn:P,create:t=>W.create(t),createClassicEditor:async(t,e)=>{if(!0===e?.editingModes?.includes("source"))throw new TypeError("The standalone CMS global does not bundle HTML Source. Use the ESM @soeditor/editor/cms/optional entry for Source support.")
if(void 0!==e?.preview&&!1!==e.preview)throw new TypeError("The standalone CMS global does not bundle Preview. Use the ESM @soeditor/editor/cms/optional entry for Preview support.")
if(void 0!==e?.save)throw new TypeError("The standalone CMS global does not bundle save adapters. Use native form submission or the ESM @soeditor/editor/cms/optional entry for save workflows.")
return(await Promise.resolve().then(()=>Fl)).createClassicEditor(t,{...e,preset:e?.preset??yc})}}),Cc=new Set(["is","nonce","srcdoc","style","xmlns"])
function Ic(t,e,i,o,s,r){const n=Array.isArray(o)?o.flatMap(t=>{if("object"!=typeof t||null===t)return[]
const e=Reflect.get(t,"name"),i=Reflect.get(t,"values")
return"string"==typeof e&&(void 0===i||Array.isArray(i)&&i.every(t=>"string"==typeof t))?[{name:e,...void 0===i?{}:{values:i}}]:[]}):[],a=new Set(n.map(({name:t})=>t)),c=new Set(r),l=new Map(i.map(({name:t,value:e})=>[t,e])),A="soeditor-link-attribute-"+t.querySelectorAll(".soeditor-ui__link-attributes").length,h=t.createElement("section")
h.className="soeditor-ui__link-attributes",h.innerHTML=`\n<div><strong>Additional attributes</strong><p>Add standard or CMS attributes. Reserved names are blocked.</p></div>\n<div class="soeditor-ui__link-attribute-row">\n<label class="soeditor-ui__field"><span>Attribute name</span><input data-role="name" aria-label="Attribute name" list="${A}-names" maxlength="64" autocomplete="off" placeholder="Choose or enter an attribute name"></label>\n<label class="soeditor-ui__field"><span>Attribute value</span><input data-role="value" aria-label="Attribute value" maxlength="4096" autocomplete="off"></label>\n<button data-role="add" type="button" class="soeditor-ui__dialog-action">Add attribute</button>\n</div>\n<div class="soeditor-ui__link-rel-custom">\n<label class="soeditor-ui__field"><span>Added attributes</span><select data-role="list"></select></label>\n<button data-role="remove" type="button" class="soeditor-ui__dialog-action is-danger">Remove attribute</button>\n</div>\n<p data-role="empty" class="soeditor-ui__link-attributes-empty">No additional attributes.</p>\n<datalist id="${A}-names"></datalist><datalist id="${A}-values"></datalist>`
const d=Ec(h,'[data-role="name"]'),u=Ec(h,'[data-role="value"]'),f=Ec(h,'[data-role="add"]'),b=Ec(h,'[data-role="list"]'),m=Ec(h,".soeditor-ui__link-rel-custom"),p=Ec(h,'[data-role="remove"]'),g=Ec(h,'[data-role="empty"]'),w=Ec(h,`#${A}-names`),v=Ec(h,`#${A}-values`)
for(const I of n){const e=t.createElement("option")
e.value=I.name,w.append(e)}d.spellcheck=!1,e.append(h)
const y=()=>{b.replaceChildren(...Array.from(l,([e,i])=>{const o=t.createElement("option")
return o.value=e,o.textContent=`${e} = ${i||'""'}`,o})),g.hidden=l.size>0,m.hidden=0===l.size},k=()=>{const e=n.find(({name:t})=>t===d.value.trim())?.values
v.replaceChildren(...(e??[]).map(e=>{const i=t.createElement("option")
return i.value=e,i})),void 0===e?u.removeAttribute("list"):u.setAttribute("list",v.id)},C=()=>{const t=d.value.trim().toLowerCase(),e=a.has(t)||/^data-[a-z0-9_.:-]+$/u.test(t),i=!/^[a-z][a-z0-9_.:-]{0,63}$/u.test(t)||c.has(t)||Cc.has(t)||t.startsWith("on")||t.startsWith("data-soeditor-")||!e||l.size>=32&&!l.has(t)
if(d.setCustomValidity(i?s("Invalid attribute."):""),!d.reportValidity())return!1
const o=n.find(({name:e})=>e===t)?.values
return u.setCustomValidity(void 0===o||o.includes(u.value)?"":s("Invalid attribute.")),!!u.reportValidity()&&(l.set(t,u.value),d.value=u.value="",k(),y(),!0)}
return d.addEventListener("input",()=>{d.setCustomValidity(""),k()}),u.addEventListener("input",()=>u.setCustomValidity("")),d.addEventListener("change",()=>{d.value=d.value.trim().toLowerCase(),k()}),f.addEventListener("click",C),b.addEventListener("click",()=>{d.value=b.value,u.value=l.get(b.value)??"",k()}),p.addEventListener("click",()=>{l.delete(b.value),d.value=u.value="",k(),y()}),y(),{value:()=>{if(!(d.value.length>0)||C())return Object.freeze(Array.from(l,([t,e])=>({name:t,value:e})))}}}function Ec(t,e){const i=t.querySelector(e)
if(null===i)throw Error("Link attribute UI is incomplete.")
return i}const Bc=Object.freeze(Object.defineProperty({__proto__:null,Pr:(t,e,i,o,s)=>{const r=t.createElement("fieldset")
r.className="soeditor-ui__table-picker-exact",r.innerHTML='<legend>Exact size</legend><input type=number min=1 max=100 value=3 aria-label="Table rows"><input type=number min=1 max=100 value=3 aria-label="Table columns"><button type=button>Insert</button>'
const n=r.getElementsByTagName("input"),a=n.item(0),c=n.item(1),l=r.querySelector("button")
a&&c&&l&&(l.addEventListener("click",()=>{const t=+a.value,e=+c.value
!a.checkValidity()||!c.checkValidity()||t*e>1e3?i.textContent="Limits: 1–100 each; 1000 cells.":o(t,e)&&s()}),e.append(r))},Lr:(t,e,i,o,s)=>Ic(t,e,i,o,s,["href","rel","target","title"]),Kr:t=>Array.isArray(t.customAttributes)?t.customAttributes.flatMap(t=>{const e="object"==typeof t&&null!==t?Reflect.get(t,"name"):void 0,i="object"==typeof t&&null!==t?Reflect.get(t,"value"):void 0
return"string"==typeof e&&"string"==typeof i?[{name:e,value:i}]:[]}):[],Yr:Ic},Symbol.toStringTag,{value:"Module"})),xc=["alignment","heading","list","font.size","font.family","font.color","font.backgroundColor","font.highlight"]
function Sc(t,e){const i=new Map(xc.map(t=>[t,new Set])),o=new Set,s=e=>{const i=1===e.nodeType?e:e.parentElement
i&&t.contains(i)&&o.add(i)}
if(e&&t.contains(e.startContainer)&&t.contains(e.endContainer))if(e.collapsed)s(e.startContainer)
else{const i=e.commonAncestorContainer
if(3===i.nodeType)s(i)
else{const o=e.cloneRange()
o.collapse(!0)
const r=e.cloneRange()
r.collapse(!1)
const n=t.ownerDocument.createTreeWalker(i,NodeFilter.SHOW_TEXT),a=t.ownerDocument.createRange()
for(let t=n.nextNode();t;t=n.nextNode()){if(!t.textContent?.length)continue
if(!t.textContent.trim()&&!t.parentElement?.closest("p,li,h1,h2,h3,h4,h5,h6,td,th"))continue
a.selectNodeContents(t)
const e=a.cloneRange()
e.collapse(!0),a.collapse(!1),r.compareBoundaryPoints(Range.START_TO_START,e)>0&&o.compareBoundaryPoints(Range.START_TO_START,a)<0&&s(t)}}}const r=t.ownerDocument.defaultView,n=new Map,a=t=>(!n.has(t)&&r&&n.set(t,r.getComputedStyle(t)),n.get(t))
for(const l of o){const e=a(l)
if(!e)continue
let o=e.textAlign
"start"!==o&&"end"!==o||(o="start"===o==("rtl"!==e.direction)?"left":"right"),i.get("alignment")?.add(o||"left"),i.get("heading")?.add(l.closest("p,h1,h2,h3,h4,h5,h6,pre,div")?.tagName.toLowerCase()??"p")
const s=l.closest("ol,ul")
i.get("list")?.add(s?`${s.tagName.toLowerCase()}:${a(s)?.listStyleType??""}`:"none"),i.get("font.size")?.add(e.fontSize),i.get("font.family")?.add(e.fontFamily),i.get("font.color")?.add(e.color)
let r="transparent"
for(let i=l;i&&i!==t&&t.contains(i);i=i.parentElement){const t=a(i)?.backgroundColor
if(t&&"transparent"!==t&&"rgba(0, 0, 0, 0)"!==t){r=t
break}}i.get("font.backgroundColor")?.add(r)
const n=l.closest("mark")
i.get("font.highlight")?.add(n?a(n)?.backgroundColor??"transparent":"transparent")}const c={}
for(const l of xc){const t=i.get(l)
c[l]=0===t.size?{status:"unavailable"}:t.size>1?{status:"mixed"}:{status:"uniform",value:[...t][0]}}return c}function Dc(t,e){const i=new Set,o=e=>{const o=1===e.nodeType?e:e.parentElement,s=o?.closest("li")??o?.closest("p,h1,h2,h3,h4,h5,h6,pre,blockquote,div,td,th,figcaption")
s&&s!==t&&t.contains(s)&&i.add(s)}
if(e.collapsed)o(e.startContainer)
else{const i=e.cloneRange()
i.collapse(!0)
const s=e.cloneRange()
s.collapse(!1)
const r=t.ownerDocument.createRange(),n=t.ownerDocument.createTreeWalker(t,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT)
for(let t=n.nextNode();t;t=n.nextNode()){if(3!==t.nodeType&&!(t instanceof Element&&t.matches("br,img,hr")))continue
3===t.nodeType?r.selectNodeContents(t):r.selectNode(t)
const e=r.cloneRange()
e.collapse(!0),r.collapse(!1),s.compareBoundaryPoints(Range.START_TO_START,e)>0&&i.compareBoundaryPoints(Range.START_TO_START,r)<0&&o(t)}}return[...i].filter(t=>![...i].some(e=>e!==t&&e.contains(t)))}function Mc(t){const e=Array.from(t.children).filter(t=>"LI"===t.tagName),i=t.hasAttribute("reversed")
let o=Number.parseInt(t.getAttribute("start")??"",10)
Number.isFinite(o)||(o=i?e.length:1)
const s=new Map
for(const r of e){const t=Number.parseInt(r.getAttribute("value")??"",10)
Number.isFinite(t)&&(o=t),s.set(r,o),o+=i?-1:1}return s}function Tc(t,e,i){const o=t.ownerDocument,s=Mc(t),r=o.createDocumentFragment()
let n,a,c=!1
for(const l of Array.from(t.childNodes)){if(!(l instanceof HTMLElement)||"LI"!==l.tagName){(n??r).append(l)
continue}const A=e.has(l)
if(A&&void 0===i){const t=o.createElement("div")
for(const e of Array.from(l.attributes))"value"!==e.name&&t.setAttribute(e.name,e.value)
t.append(...Array.from(l.childNodes)),r.append(t),n=void 0}else{const e=A?i:t.tagName.toLowerCase()
if(void 0===n||a!==A){n=o.createElement(e)
for(const i of Array.from(t.attributes))"id"===i.name&&c||e!==t.tagName.toLowerCase()&&["type","start","reversed"].includes(i.name)||n.setAttribute(i.name,i.value)
c=!0,e!==t.tagName.toLowerCase()&&n.style.removeProperty("list-style-type"),"ol"===e&&"OL"===t.tagName&&n.setAttribute("start",(s.get(l)??1)+""),r.append(n)}n.append(l)}a=A}t.replaceWith(r)}function Rc(t,e){if(!["browser","minimal","article","email","custom"].includes(e))throw new TypeError(`Unknown WYSIWYG content style preset "${e}".`)
t.dataset.Sn=e}class Fc extends Error{constructor(){super("The WYSIWYG editing engine has been destroyed."),this.name="WysiwygEditingEngineDestroyedError"}}const _c="address,article,aside,blockquote,div,figcaption,figure,footer,h1,h2,h3,h4,h5,h6,header,li,main,nav,p,pre,section,td,th",Qc="address,article,aside,blockquote,caption,dd,details,div,dl,dt,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hr,li,main,menu,nav,ol,p,pre,section,table,tbody,td,tfoot,th,thead,tr,ul,video",Oc=new Set(["h1","h2","h3","h4","h5","h6","p","pre"]),Nc=new Set(["a","abbr","address","article","aside","b","bdi","bdo","blockquote","br","caption","cite","code","col","colgroup","data","dd","del","details","dfn","div","dl","dt","em","figcaption","figure","footer","h1","h2","h3","h4","h5","h6","header","hr","i","img","ins","kbd","li","main","mark","nav","ol","p","picture","pre","q","rp","rt","ruby","s","samp","section","small","source","span","strong","sub","summary","sup","table","tbody","td","tfoot","th","thead","time","tr","u","ul","var","video","wbr"]),qc=new Set(["base","embed","iframe","link","meta","noscript","object","script","style","template"]),jc=new Set(["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"])
class Gc{editor
element
#It
#Et
#Bt
#xt
#D
#j
#St
#Z
#U
#Dt
#Mt=new WeakMap
#Tt=new WeakMap
#Rt=new Map
#Ft=new WeakMap
#_t=new WeakMap
#Qt
#Ot
#Nt=0
#I=!1
#qt
#jt
#Gt=0
#Ht=!1
#Kt
#Yt
#Wt
#zt
#Zt=0
#Ut=!1
#Jt
#Lt
#Pt
#Vt
#Xt
#$t
#te
#ee
#ie=!1
constructor(t){this.editor=t.editor,this.element=t.element,this.#Et=t.element.ownerDocument
const e=t.element.getRootNode()
if(this.#Xt=e===this.#Et?this.#Et:e,this.#It=t.activateOnFocus??!1,"html"!==this.editor.state.document.format)throw new TypeError("WYSIWYG requires an HTML document.")
if(this.editor.services.has(Qo))throw new m(Qo.id)
this.#xt=this.element.hidden,this.#Bt=new Map(["contenteditable","role","aria-label","aria-multiline","aria-readonly"].map(t=>[t,this.element.getAttribute(t)])),this.element.setAttribute("role","textbox"),this.element.setAttribute("aria-label",t.ariaLabel?.trim()||"WYSIWYG editor"),this.element.setAttribute("aria-multiline","true"),this.#oe(this.editor.getData())
const i={adjustIndent:t=>this.#se(t),applyBlockAttributes:t=>this.#re(t),applyInlineStyle:t=>this.#ne(t),areBlockAttributesActive:t=>this.#ae(t),canEdit:()=>this.#ce(),getFormatStates:()=>Sc(this.element,this.#le()),getLinkAttributes:()=>this.#Ae(),getSelectedStructuredBlock:t=>this.#he(t),getSelection:()=>this.#de(),getStructuredSelection:t=>"soeditor.table"===t?this.#ue():void 0,setStructuredSelection:(t,e)=>this.#fe(t,e),insertHtml:(t,e)=>this.#be(t,e),isAlignmentActive:t=>this.#me(t),isBlockActive:t=>this.#pe(t),isInlineStyleActive:t=>this.#ge(t),isLinkActive:()=>void 0!==this.#we("a"),isListActive:t=>this.#ve(t),isMarkActive:t=>this.#ye(t),isStructuredBlockSelected:t=>void 0!==this.#ke(t),removeFormat:()=>this.#Ce(),removeInlineStyleProperty:t=>this.#Ie(t),removeSelectedStructuredBlock:t=>this.#Ee(t),replaceStructuredBlockContent:(t,e)=>this.#Be(t,e),setAlignment:t=>this.#xe(t),setBlock:t=>this.#Se(t),setLink:t=>this.#De(t),setListProperties:t=>this.#Me(t),setSelection:(t,e)=>this.setSelection(t,e),setStructuredBlockAttributes:(t,e)=>this.#Te(t,e),toggleList:t=>this.#Re(t),setListStyle:(t,e)=>this.#Fe(t,e),isListStyleActive:(t,e)=>this.#_e(t,e),toggleMark:t=>this.#Qe(t)}
this.#D=Object.freeze(i),this.editor.services.register(Qo,this.#D),this.element.addEventListener("beforeinput",this.#Oe),this.element.addEventListener("input",this.#Ne),this.element.addEventListener("compositionstart",this.#qe),this.element.addEventListener("compositionend",this.#je),this.element.addEventListener("keydown",this.#Ge),this.element.addEventListener("paste",this.#He),this.element.addEventListener("drop",this.#Ke),this.element.addEventListener("focusin",this.#Ye),this.element.addEventListener("pointerdown",this.#We),this.element.addEventListener("pointerover",this.#ze),this.element.addEventListener("pointerup",this.#Ze),this.element.addEventListener("dblclick",this.#Ue),this.#Et.addEventListener("selectionchange",this.#Je),this.#Xt!==this.#Et&&this.#Xt.addEventListener("selectionchange",this.#Je)
const o=this.#Et.defaultView?.MutationObserver
this.#Dt=void 0===o?void 0:new o(t=>{this.#Le(t),t.some(t=>!(t.target===this.element&&"attributes"===t.type)&&(t.target===this.element||this.element.contains(t.target))&&!(t=>{if("attributes"!==t.type||!(t.target instanceof Element))return!1
if(t.target.matches(".soeditor-table-column-resize, .soeditor-table-row-resize"))return!0
if("aria-selected"===t.attributeName&&t.target.matches("td,th"))return!0
if("class"!==t.attributeName)return!1
const e=t=>(t??"").split(/\s+/u).filter(t=>t.length>0&&!t.startsWith("soeditor-")&&"is-editing"!==t&&"is-structurally-selected"!==t).sort().join(" ")
return e(t.oldValue)===e(t.target.getAttribute("class"))})(t))&&this.#Pe()}),this.#Dt?.observe(this.element,{attributeOldValue:!0,attributes:!0,characterData:!0,childList:!0,subtree:!0}),this.#j=this.editor.events.on("document:change",({current:t})=>this.#Ve(t.source)),this.#St=this.editor.events.on("editor:destroy",()=>this.destroy()),this.#Z=this.editor.events.on("mode:change",()=>{void 0===this.#Jt&&this.#Xe()}),this.#U=this.editor.events.on("state:change",({current:t,previous:e})=>{t.readonly!==e.readonly&&void 0===this.#Jt&&this.#Xe()}),this.#Lt=this.editor.services.tryGet(so)?.attach({id:"wysiwyg",update:t=>{this.#Jt=t,this.#Xe()}})
for(const s of["before","after"])this.editor.commands.register({id:"block.paragraph."+s,canExecute:()=>this.#ce()&&void 0!==this.#$e(),execute:(t,...e)=>{if(0!==e.length)throw new TypeError("Block paragraph commands take no arguments.")
const i=this.#$e()
void 0!==i&&(this.#ti(()=>{const t=this.#Et.createElement("p")
t.append(this.#Et.createElement("br")),i[s](t),this.#Qt?.classList.remove("is-editing"),this.#Qt=void 0,this.#te=void 0,this.#$t=void 0,this.#ei()
const e=this.#Et.createRange()
return e.setStart(t,0),e.collapse(!0),e}),this.element.focus({Dn:!0}))}})
this.#Xe()}#$e(t=this.#$t){if(void 0===t||!this.element.contains(t))return
const e=t.closest("img")
let i
if(null!==e){const t=e.closest("figure")
i=null!==t&&t.closest("table")===e.closest("table")?t:e.closest("p,h1,h2,h3,h4,h5,h6,pre")??e.closest("a")??e}else{const e=t.closest("table")
i="FIGURE"===e?.parentElement?.tagName?e.parentElement:e}for(;null!=i?.parentElement&&i.parentElement!==this.element&&i.parentElement.matches("a,span,strong,b,em,i,u,s,small,mark,code,sub,sup");)i=i.parentElement
return null!=i&&i!==this.element&&this.element.contains(i)?i:void 0}#ii(t){return e=>{if(!this.element.contains(t)||!this.#ce(!1))return
this.#oi()
const i=this.#Et.createRange()
i.selectNodeContents(t),i.collapse(!0),this.#si(i),this.#$t=t
const o="block.paragraph."+e
this.editor.commands.canExecute(o)&&this.editor.execute(o)}}focus(){this.#g(),this.#Ut=!0
try{this.element.focus(),this.#ri()}finally{this.#Ut=!1}}setSelection(t,e=!0){if(this.#g(),void 0!==this.#Pt&&(o=t,(i=this.#Pt).anchor.block===o.anchor.block&&i.anchor.offset===o.anchor.offset&&i.focus.block===o.focus.block&&i.focus.offset===o.focus.offset)&&!0===this.#Vt?.startContainer.isConnected)return e&&this.element.focus({Dn:!0}),this.#ri()
var i,o
const s=this.#ni(),r=s[t.anchor.block],n=s[t.focus.block]
if(void 0===r||void 0===n)return!1
const a=pl(r,t.anchor.offset),c=pl(n,t.focus.offset)
if(void 0===a||void 0===c)return!1
const l=sl(this.element,this.#Et)
return null!==l&&(e&&this.element.focus({Dn:!0}),l.setBaseAndExtent(a.node,a.offset,c.node,c.offset),this.#ai(),!0)}destroy(){if(!this.#I){this.#I=!0,this.element.removeEventListener("beforeinput",this.#Oe),this.element.removeEventListener("input",this.#Ne),this.element.removeEventListener("compositionstart",this.#qe),this.element.removeEventListener("compositionend",this.#je),this.element.removeEventListener("keydown",this.#Ge),this.element.removeEventListener("paste",this.#He),this.element.removeEventListener("drop",this.#Ke),this.element.removeEventListener("focusin",this.#Ye),this.element.removeEventListener("pointerdown",this.#We),this.element.removeEventListener("pointerover",this.#ze),this.element.removeEventListener("pointerup",this.#Ze),this.element.removeEventListener("dblclick",this.#Ue),this.#Et.removeEventListener("selectionchange",this.#Je),this.#Xt!==this.#Et&&this.#Xt.removeEventListener("selectionchange",this.#Je),this.#Dt?.disconnect(),this.#Ft=new WeakMap,this.#_t=new WeakMap,this.#Lt?.(),this.#Lt=void 0,this.#j(),this.#St(),this.#Z(),this.#U()
try{this.editor.commands.unregister("block.paragraph.before"),this.editor.commands.unregister("block.paragraph.after"),this.editor.services.tryGet(Qo)===this.#D&&this.editor.services.unregister(Qo)}catch(t){if(!(t instanceof e))throw t}this.element.replaceChildren(),this.element.hidden=this.#xt
for(const[t,e]of this.#Bt)null===e?this.element.removeAttribute(t):this.element.setAttribute(t,e)}}#Oe=t=>{if("historyUndo"===t.inputType)return t.preventDefault(),void this.#ci("editor.undo")
if("historyRedo"===t.inputType)return t.preventDefault(),void this.#ci("editor.redo")
if(("deleteContentBackward"===t.inputType||"deleteContentForward"===t.inputType)&&this.#li("deleteContentBackward"===t.inputType))return t.preventDefault(),void this.#Ai()
if("insertParagraph"===t.inputType&&this.#hi())return t.preventDefault(),void this.#Ai()
if(("insertLineBreak"===t.inputType||"insertParagraph"===t.inputType)&&this.#di())return t.preventDefault(),void this.#Ai()
if("insertText"===t.inputType&&null!==t.data&&!t.isComposing&&this.#ui(t.data))return t.preventDefault(),void this.#Ai()
if(this.#fi(t),void 0!==this.#Yt&&"insertText"===t.inputType&&null!==t.data){const e=this.#bi()
if(void 0===e||!e.collapsed)return
t.preventDefault()
const i=this.#Et.createElement(this.#Yt),o=this.#Et.createTextNode(t.data)
i.append(o),e.insertNode(i),e.setStart(o,o.data.length),e.collapse(!0),this.#si(e),this.#Yt=void 0
const s=this.#Kt
this.#Kt=void 0,this.#mi(s)}}
#Ne=t=>{const e="isComposing"in t&&!0===t.isComposing||void 0!==this.#Ot?this.#Ot:this.#Kt
this.#Kt=void 0,this.#ai(),this.#mi(e)}
#qe=()=>{this.#Ai(),this.#Wt=void 0,this.#Ot=this.#pi()}
#je=()=>{const t=this.#Ot
this.#ai(),this.#mi(t),queueMicrotask(()=>{this.#Ot===t&&(this.#Ot=void 0)})}
#pi(){return this.#Nt+=1,"wysiwyg-composition-"+this.#Nt}#Ge=t=>{if((1!==t.key.length||t.ctrlKey||t.metaKey||t.altKey)&&(this.#Ai(),this.#Wt=void 0),"Escape"===t.key&&void 0!==this.#te&&(this.#te.range.anchor.row!==this.#te.range.focus.row||this.#te.range.anchor.column!==this.#te.range.focus.column)){t.preventDefault(),t.stopPropagation()
const{focus:e}=this.#te.range,i=dl(this.#te.table,e.row,e.column)
void 0!==i&&(this.#te={range:{anchor:e,focus:e},table:this.#te.table},this.#ei(),this.#gi(i))}"Tab"===t.key&&this.#wi(t.shiftKey)?t.preventDefault():"Tab"!==t.key||t.ctrlKey||t.metaKey||t.altKey||void 0===this.#we("li")||(t.preventDefault(),this.#se(t.shiftKey?-1:1))}
#He=t=>{if(this.#Ai(),!this.#ce()||null===t.clipboardData)return
t.preventDefault()
const e=t.clipboardData,i=e.getData(Mo),o=i.startsWith("soeditor/1\n")?i.slice(11):void 0,s=this.editor.services.tryGet(Do)?.process({files:Object.freeze(Array.from(e.files,t=>Object.freeze({data:t,name:t.name,size:t.size,type:t.type}))),html:e.getData("text/html"),...void 0===o?{}:{internalHtml:o},source:"paste",text:e.getData("text/plain"),types:Object.freeze(Array.from(e.types))})
if(!0===s?.consumed)return
const r=s?.html??o??e.getData("text/html"),n=s?.text??e.getData("text/plain")
this.#be("plain-text"===s?.policy||0===r.length?this.#vi(n):r)}
#Ke=t=>{this.#Ai()
const e=t.dataTransfer
if(this.#I||this.#Ht||!this.element.isContentEditable||null===e)return
let i=this.#Et.caretRangeFromPoint?.(t.clientX,t.clientY)??void 0
if(void 0===i||!this.element.contains(i.commonAncestorContainer)){const e=t.target
i=e instanceof Element&&this.element.contains(e)?cl(this.#Et,e):void 0}if(void 0!==i&&this.#si(i),void 0===this.#bi())return
const o={files:Object.freeze(Array.from(e.files,t=>Object.freeze({data:t,name:t.name,size:t.size,type:t.type}))),html:e.getData("text/html"),source:"drop",text:e.getData("text/plain"),types:Object.freeze(Array.from(e.types))},s=this.editor.services.tryGet(Do)?.process(o)
if(!0===s?.consumed)return void t.preventDefault()
const r=s?.html??o.html,n=s?.text??o.text
0===r.length&&0===n.length||(t.preventDefault(),this.#be("plain-text"===s?.policy||0===r.length?this.#vi(n):r))}
#Ye=()=>{this.#oi(),this.#ai()}
#We=t=>{this.#Ai(),this.#Yt=void 0,this.#Wt=void 0,this.#oi()
const e=t.target
this.#ee=0===t.button&&e instanceof Element?e.closest("td,th")??void 0:void 0,this.#ie=!1,0===t.button&&e instanceof Element&&null===e.closest("td,th")&&(this.#Qt?.classList.remove("is-editing"),this.#Qt=void 0,this.#te=void 0,!0===this.#$t?.matches("td,th")&&(this.#$t=void 0),this.#ei()),void 0===this.#ee||t.shiftKey||this.#yi(this.#ee,!1,!1)}
#ze=t=>{const e=this.#ee,i=t.target
if(0===t.buttons&&i instanceof Element&&this.#ce(!1)){const t=i.closest("img,figcaption,table"),e=!0===t?.matches("figcaption")?t.closest("figure")?.querySelector("img"):t,o=null==e?void 0:this.#$e(e)
if(void 0!==o&&null!=e){const t=this.#Et.defaultView?.CustomEvent??CustomEvent
e.dispatchEvent(new t("soeditor:block-hover",{bubbles:!0,detail:{block:o,insertParagraph:this.#ii(e)}}))}}const o=i instanceof Element?i.closest("td,th"):null
void 0===e||null===o||o===e||1&~t.buttons||e.closest("table")!==o.closest("table")||(this.#ie||this.#yi(e),this.#ie=!0,this.#yi(o,!0))}
#Ze=t=>{this.#ai()
const e=t.target,i=e instanceof Element?e.closest("img"):null
if(null!==i&&this.element.contains(i))return this.#$t=i,this.#ki(i,"soeditor:image-select"),this.#ee=void 0,void(this.#ie=!1)
const o=e instanceof Element?e.closest("td,th"):null
if(2===t.button&&!0===o?.classList.contains("is-structurally-selected")&&this.#te?.table===o.closest("table"))return this.#gi(o),this.#ee=void 0,void(this.#ie=!1)
!this.#ie&&null!==o&&this.element.contains(o)&&this.#yi(o,t.shiftKey),this.#ee=void 0,this.#ie=!1}
#Ue=t=>{const e=t.target
if(!(e instanceof Element))return
const i=e.closest("img")
return null!==i&&this.element.contains(i)?(t.preventDefault(),this.#$t=i,void this.#ki(i,"soeditor:image-activate")):void 0}
#ki(t,e){const i=this.#Et.createRange()
i.selectNode(t),this.#si(i)
const o=this.#Et.defaultView?.CustomEvent??CustomEvent
t.dispatchEvent(new o(e,{bubbles:!0,detail:Object.freeze({element:t,block:this.#$e(t),insertParagraph:this.#ii(t),remove:()=>{t.remove(),this.#$t=void 0,this.#mi()},update:e=>this.#Ci(t,e)})}))}#Je=()=>this.#ai()
#oi(){this.#It&&!this.#Ut&&!0===this.#Jt?.visible&&!1===this.#Jt.primary&&this.editor.execute("projection.activate","wysiwyg")}#fi(t){const e="insertText"===t.inputType?"insertText":"deleteContentBackward"===t.inputType?"deleteContentBackward":"deleteContentForward"===t.inputType?"deleteContentForward":void 0
void 0===e||t.isComposing?this.#Ai():(void 0!==this.#qt&&this.#jt===e||(this.#Gt+=1,this.#qt=`wysiwyg-${e}-${this.#Gt+""}`,this.#jt=e),this.#Kt=this.#qt)}#di(){if(!this.#ce())return!1
const t=this.#bi()
if(void 0===t)return!1
const e=ol(t.startContainer,"pre"),i=ol(t.endContainer,"pre")
if(void 0===e||e!==i)return!1
let o,s
return this.#ti(()=>{t.deleteContents()
const e=this.#Et.createTextNode("\n")
s=e,t.insertNode(e)
const i=this.#Et.createTextNode("")
e.after(i)
const r=this.#Et.createRange()
return r.setStart(i,0),r.collapse(!0),o=r.cloneRange(),r}),void 0!==s&&(this.#Wt={Mn:s,Tn:e}),void 0!==o&&queueMicrotask(()=>{!this.#I&&o?.startContainer.isConnected&&this.#si(o)}),!0}#ui(t){const e=this.#Wt
if(this.#Wt=void 0,void 0===e||!e.Tn.isConnected||!e.Tn.contains(e.Mn))return!1
const i=this.#Et.createRange()
return i.setStartAfter(e.Mn),i.collapse(!0),this.#ti(()=>{const e=this.#Et.createTextNode(t)
i.insertNode(e)
const o=this.#Et.createRange()
return o.setStart(e,e.data.length),o.collapse(!0),o}),!0}#vi(t){const e=this.#bi()
return void 0===(void 0===e?void 0:ol(e.commonAncestorContainer,"pre"))?wl(t).replaceAll("\n","<br />"):wl(t)}#Ai(){this.#qt=void 0,this.#jt=void 0,this.#Kt=void 0}#li(t){const e=this.#bi()
if(void 0===e||!e.collapsed)return!1
const i=ol(e.startContainer,"p")
if(void 0===i||i.parentElement!==this.element)return!1
const o=this.#Et.createRange()
if(o.selectNodeContents(i),t?o.setEnd(e.startContainer,e.startOffset):o.setStart(e.startContainer,e.startOffset),0!==o.toString().length)return!1
const s=t?i.previousElementSibling:i.nextElementSibling
if(!(s instanceof HTMLParagraphElement))return!1
const r=t?s:i,n=t?i:s,a=r.textContent?.length??0
return this.#ti(()=>{r.append(...Array.from(n.childNodes)),n.remove()
const t=pl(r,a)
if(void 0===t)return cl(this.#Et,r)
const e=this.#Et.createRange()
return e.setStart(t.node,t.offset),e.collapse(!0),e}),!0}#yi(t,e=!1,i=!0){this.#Qt?.classList.remove("is-editing"),this.#Qt=t,t.classList.add("is-editing"),this.#$t=t
const o=t.closest("table"),s=null===o?void 0:((t,e)=>{for(const[i,o]of ul(t).entries()){const t=o.indexOf(e)
if(t>=0)return{column:t,row:i}}})(o,t)
if(null!==o&&void 0!==s){const t=e&&this.#te?.table===o?this.#te.range.anchor:s
this.#te={range:{anchor:t,focus:s,...t.row===s.row&&t.column===s.column?{}:{kind:"cells"}},table:o},this.#ei()}const r=this.#Vt?.cloneRange()
i&&this.#gi(t,()=>{void 0!==r&&t.contains(r.commonAncestorContainer)&&(this.element.focus({Dn:!0}),this.#si(r))})}#gi(t,e=()=>{this.element.focus({Dn:!0})}){const i=this.#ue(),o=this.#Et.defaultView?.CustomEvent??CustomEvent
t.dispatchEvent(new o("soeditor:table-selection",{bubbles:!0,detail:Object.freeze({...i?.focus??{column:0,row:0},Rn:e,block:this.#$e(t),insertParagraph:this.#ii(t),range:void 0===i?void 0:Object.freeze({anchor:Object.freeze({...i.anchor}),focus:Object.freeze({...i.focus}),...void 0===i.kind?{}:{kind:i.kind}})})}))}#fe(t,e){if("soeditor.table"!==t)return!1
const i=(t=>{if("object"!=typeof t||null===t)return
const e=Reflect.get(t,"anchor"),i=Reflect.get(t,"focus"),o=t=>{if("object"!=typeof t||null===t)return
const e=Reflect.get(t,"row"),i=Reflect.get(t,"column")
return Number.isInteger(e)&&Number(e)>=0&&Number.isInteger(i)&&Number(i)>=0?{column:Number(i),row:Number(e)}:void 0},s=o(e),r=o(i)
if(void 0===s||void 0===r)return
const n=Reflect.get(t,"kind")
return["cells","columns","rows","table"].includes(n+"")?{anchor:s,focus:r,kind:n}:{anchor:s,focus:r}})(e),o=this.#Qt?.closest("table")??this.#$t?.closest("table")
if(void 0===i||null==o)return!1
const s=dl(o,i.focus.row,i.focus.column)
return void 0!==dl(o,i.anchor.row,i.anchor.column)&&void 0!==s&&(this.#te={range:i,table:o},this.#Qt=s,this.#$t=s,this.#ei(),this.#gi(s),!0)}#wi(t){const e=this.#bi(),i=void 0===e?void 0:ol(e.commonAncestorContainer,"td,th"),o=i?.closest("table")
if(!(void 0!==i&&i instanceof HTMLTableCellElement&&null!=o&&this.element.contains(o)))return!1
const s=Array.from(o.querySelectorAll("th,td")),r=s.indexOf(i)
let n=s[r+(t?-1:1)]
if(void 0===n&&!t&&r===s.length-1&&this.editor.commands.has("table.row.insertAfter")&&(this.editor.execute("table.row.insertAfter"),n=Array.from(o.querySelectorAll("th,td"))[s.length],void 0===n))return this.#Et.defaultView?.setTimeout(()=>{const t=Array.from(this.element.querySelectorAll("table th,table td")).at(-1)
if(void 0===t)return
this.#yi(t)
const e=this.#Et.createRange()
e.selectNodeContents(t),e.collapse(!0),this.#si(e)},0),!0
if(void 0===n)return!1
this.#yi(n)
const a=this.#Et.createRange()
return a.selectNodeContents(n),a.collapse(t),this.#si(a),!0}#ei(){for(const r of Array.from(this.element.querySelectorAll(".is-structurally-selected")))r.classList.remove("is-structurally-selected"),r.removeAttribute("aria-selected")
const t=this.#te
if(void 0===t)return
const e=Math.min(t.range.anchor.row,t.range.focus.row),i=Math.max(t.range.anchor.row,t.range.focus.row),o=Math.min(t.range.anchor.column,t.range.focus.column),s=Math.max(t.range.anchor.column,t.range.focus.column)
if(e!==i||o!==s)for(let r=e;r<=i;r+=1)for(let e=o;e<=s;e+=1){const i=dl(t.table,r,e)
i?.classList.add("is-structurally-selected"),i?.setAttribute("aria-selected","true")}}#oe(t){this.#Ft=new WeakMap,this.#_t=new WeakMap
const e=io(t)
if(e.diagnostics.some(t=>"error"===t.severity))return this.#Ht=!0,void this.#Xe()
const i=this.#Ii()
this.#Yt=void 0,this.#Wt=void 0,this.#Ht=!1,this.#Qt?.classList.remove("is-editing"),this.#Qt=void 0
const o=this.#$t?.closest("table")
if(null!=o&&(this.#$t=void 0),this.#te=void 0,this.#ee=void 0,this.#ie=!1,this.#Rt.clear(),this.#Zt=0,this.element.replaceChildren(...e.document.children.map(t=>this.#Ei(t))),0===this.element.childNodes.length){const t=this.#Et.createElement("p")
t.append(this.#Et.createElement("br")),this.element.append(t)}this.#Bi(),void 0!==i&&this.#xi(i),this.#Xe(),this.#Dt?.takeRecords()}#Ei(t){if("text"===t.type)return this.#Et.createTextNode(t.value)
if("comment"===t.type)return this.#Et.createComment(t.value)
if("html"!==t.namespace||qc.has(t.tagName)||!Nc.has(t.tagName))return this.#Si(t)
const e=this.#Et.createElement(t.tagName),i=[]
for(const o of t.attributes)Hc(t.tagName,o)?e.setAttribute(o.name,o.value):i.push({name:o.name,value:o.value})
return i.length>0&&this.#Mt.set(e,Object.freeze(i)),jc.has(t.tagName)||e.append(...t.children.map(t=>this.#Ei(t))),e}#Si(t){this.#Zt+=1
const e=this.#Zt+""
return this.#Rt.set(e,t),this.#Et.createComment("soeditor-preserved:"+e)}#Bi(){for(const t of Array.from(this.element.querySelectorAll("table"))){this.#Di(t),t.classList.add("soeditor-table-widget"),ll(t,t.getAttribute("class"))
const e=Yc(t,"width")
void 0!==e&&(t.style.width=e)
const i=Yc(t,"height")
void 0!==i&&(t.style.height=i)
const o=Wc(t,"border")
void 0!==o&&(t.style.borderStyle=0===o?"none":"solid",t.style.borderWidth=o+"px")
const s=t.getAttribute("align")
"center"===s?t.style.marginInline="auto":"right"===s?t.style.marginInlineStart="auto":"left"===s&&(t.style.marginInlineEnd="auto")
for(const r of Array.from(t.querySelectorAll("colgroup col"))){this.#Di(r)
const t=Number(r.getAttribute("width"))
Number.isInteger(t)&&t>=40&&t<=1200&&(r.style.width=t+"px")}for(const r of Array.from(t.rows)){this.#Di(r),ll(r,r.getAttribute("class"))
const t=Number(r.getAttribute("height"))
Number.isInteger(t)&&t>=20&&t<=2e3&&(r.style.height=t+"px")}for(const r of Array.from(t.querySelectorAll("td,th"))){this.#Di(r),r.classList.add("soeditor-table-cell"),ll(r,r.getAttribute("class"))
const t=r.getAttribute("align")
"center"!==t&&"left"!==t&&"right"!==t||(r.style.textAlign=t)
const e=r.getAttribute("valign")
"baseline"!==e&&"bottom"!==e&&"middle"!==e&&"top"!==e||(r.style.verticalAlign=e),void 0!==o&&(r.style.borderStyle=0===o?"none":"solid",r.style.borderWidth=o+"px")}}}#Di(t){this.#Tt.has(t)||this.#Tt.set(t,Object.freeze({className:t.getAttribute("class"),style:t.getAttribute("style")}))}#Mi(){return void 0===this.#Dt&&(this.#Ft=new WeakMap,this.#_t=new WeakMap),this.#Le(this.#Dt?.takeRecords()??[]),Array.from(this.element.childNodes,t=>{const e=this.#Ft.get(t)
if(void 0!==e)return e
const i=this.#Ti(t,!0),o=oo({children:void 0===i?[]:[i],type:"document-fragment"})
return this.#Ft.set(t,o),o}).join("")}#Le(t){for(const e of t){for(const i of Array.from(e.addedNodes)){this.#Ft.delete(i)
const t=[i]
for(let e=0;e<t.length;e+=1){const i=t[e]
if(void 0!==i){this.#_t.delete(i)
for(const e of Array.from(i.childNodes))t.push(e)}}}let t=e.target
for(;null!==t&&t!==this.element;)this.#Ft.delete(t),this.#_t.delete(t),t=t.parentNode}}#Ti(t,e=!1){if(e){const e=this.#_t.get(t)
if(void 0!==e)return e}const i=this.#Ri(t,e)
return e&&void 0!==i&&this.#_t.set(t,i),i}#Ri(t,e){if(3===t.nodeType)return{type:"text",value:t.nodeValue??""}
if(8===t.nodeType){const e=t.nodeValue??"",i=/^soeditor-preserved:(\d+)$/u.exec(e)
return void 0===i?.[1]?{type:"comment",value:e}:this.#Rt.get(i[1])}const i=this.#Et.defaultView
if(null===i||!(t instanceof i.Element))return
const o=t.tagName.toLowerCase(),s=this.#Tt.get(t),r=Array.from(t.attributes).filter(({name:e})=>!("contenteditable"===e||"class"===e||"aria-selected"===e&&t.classList.contains("soeditor-table-cell")||void 0!==s&&"style"===e)).map(({name:t,value:e})=>({name:t,value:e}))
if(void 0!==s)null!==s.className&&r.push({name:"class",value:s.className}),null!==s.style&&r.push({name:"style",value:s.style})
else if(t.hasAttribute("class")){const e=t.className.split(/\s+/u).filter(t=>t.length>0&&!t.startsWith("soeditor-")&&"is-editing"!==t&&"is-structurally-selected"!==t).join(" ")
e.length>0&&r.push({name:"class",value:e})}for(const n of this.#Mt.get(t)??[])r.some(({name:t})=>t===n.name)||r.push(n)
return{attributes:Object.freeze(r),children:Object.freeze(Array.from(t.childNodes).flatMap(t=>{const i=this.#Ti(t,e)
return void 0===i?[]:[i]})),namespace:"html",tagName:o,type:"element"}}#mi(t){if(!this.#ce())return
const e=this.#Mi()
if(e!==this.editor.getData()){this.#zt=e
try{this.editor.update(i=>{i.replaceDocument(e),void 0!==t&&((t,e)=>{if(0===e.length)throw new TypeError("A history group ID must not be empty.")
t.setMeta(Io,e)})(i,t)},{origin:"user"}),this.#Le(this.#Dt?.takeRecords()??[])}finally{this.#zt=void 0}}}#Ve(t){this.#zt!==t&&this.#oe(t)}#Pe(){if(this.#I||this.#Ht||void 0!==this.#zt)return
const t=this.editor.getData(),e=io(t),i=e.diagnostics.some(t=>"error"===t.severity)?t:oo(e.document)
this.#Mi()!==i&&this.#oe(t)}#Xe(){const t=this.#Jt?.visible??"wysiwyg"===this.editor.state.mode,e=this.#Ht||(this.#Jt?.readonly??(this.editor.state.readonly||"wysiwyg"!==this.editor.state.mode))
t||this.element.hidden||(this.element.hidden=!0)
const i=e?"false":"true"
this.element.contentEditable!==i&&(this.element.contentEditable=i),this.element.getAttribute("aria-readonly")!==e+""&&this.element.setAttribute("aria-readonly",e+""),t&&this.element.hidden&&(this.element.hidden=!1)}#ce(t=!0){return!this.#I&&!this.#Ht&&this.element.isContentEditable&&(!t||void 0!==this.#bi())}#bi(){if(this.element.hidden)return this.#Vt?.cloneRange()
const t=rl(this.element,this.#Et)
return void 0!==t&&this.element.contains(t.commonAncestorContainer)?(this.#Vt=t.cloneRange(),t):this.#Vt?.cloneRange()}#ai(){if(this.element.hidden)return
const t=rl(this.element,this.#Et)
if(void 0===t)return
if(!this.element.contains(t.commonAncestorContainer))return
this.#Vt=t.cloneRange()
const e=t.commonAncestorContainer instanceof Element?t.commonAncestorContainer:t.commonAncestorContainer.parentElement
null!==e&&(this.#$t=e)}#ri(){const t=this.#Vt
return!(void 0===t||!t.startContainer.isConnected||(this.#si(t),0))}#si(t){const e=sl(this.element,this.#Et)
e?.setBaseAndExtent(t.startContainer,t.startOffset,t.endContainer,t.endOffset),this.#Vt=t.cloneRange()}#Qe(t){const e=this.#bi()
void 0!==e&&(e.collapsed?this.#Yt=this.#Yt===t?void 0:t:this.#Fi(e,e=>{const i=ol(e.commonAncestorContainer,t)
return void 0!==i&&this.element.contains(i)?(nl(i),e):this.#_i(e,()=>this.#Et.createElement(t))}))}#ye(t){return this.#Yt===t||void 0!==this.#we(t)}#ne(t){const e=this.#bi()
void 0===e||e.collapsed||this.#Fi(e,e=>this.#_i(e,()=>{const e=this.#Et.createElement(t.tagName)
return Lc(e,t.attributes),e},Pc))}#ge(t){const e=this.#we(t.tagName)
return void 0!==e&&t.attributes.every(({name:t,value:i})=>e.getAttribute(t)===i)}#Ie(t){const e=this.#bi()
void 0===e||e.collapsed||this.#Fi(e,e=>{const i=[],o=this.#_i(e,()=>{const e=this.#Et.createElement("span")
return e.style.setProperty(t,"initial"),e},t=>{const e=Pc(t)
return i.push(e),e}),s=[]
for(const c of i)el(c,t),0===c.attributes.length?(s.push(...Array.from(c.childNodes)),nl(c)):s.push(c)
const r=s[0],n=s.at(-1)
if(void 0===r||void 0===n||!r.isConnected||!n.isConnected)return o
const a=this.#Et.createRange()
return a.setStartBefore(r),a.setEndAfter(n),a})}#Ce(){const t=this.#bi()
if(void 0===t||t.collapsed)return
const e=this.#Qi().filter(t=>t.matches(_c))
e.length<=1?this.#Fi(t,t=>this.#Oi(t)):this.#ti(()=>{const i=[]
for(const n of e){const e=this.#Ni(t,n)
void 0===e||e.collapsed||i.push(this.#Oi(e))}const o=i[0],s=i.at(-1)
if(void 0===o||void 0===s)return t
const r=this.#Et.createRange()
return r.setStart(o.startContainer,o.startOffset),r.setEnd(s.endContainer,s.endOffset),r})}#Ni(t,e){const i=this.#Et.createRange()
i.selectNodeContents(e)
try{return e.contains(t.startContainer)&&i.setStart(t.startContainer,t.startOffset),e.contains(t.endContainer)&&i.setEnd(t.endContainer,t.endOffset),i}catch{return}}#Oi(t){const e=this.#Et.createElement("span")
e.dataset.Fn="true",e.textContent=t.toString(),t.deleteContents(),t.insertNode(e)
let i=e.parentElement
for(;null!==i&&i!==this.element&&!i.matches(_c)&&i.matches("b,strong,i,em,u,s,strike,sub,sup,font,span[style],span[class]");)al(e,i),i=e.parentElement
const o=this.#Et.createTextNode(e.textContent??""),s=e.closest(_c)??e.parentElement
if(e.replaceWith(o),null!==s){const t=Array.from(s.querySelectorAll("b,strong,i,em,u,s,strike,sub,sup,font,span")).reverse()
for(const e of t)0===(e.textContent??"").length&&null===e.querySelector("img,video,audio,iframe,object,embed,svg,math,br")&&e.remove()}return t.selectNodeContents(o),t}#Se(t){const e=this.#qi(),i=this.#de(),o=t.toUpperCase()
if(0===e.length)return void this.#ji(t)
if(e.every(t=>t.tagName===o&&!hl(t)))return
const s=this.#bi()
this.#ti(()=>{const i=void 0===s?void 0:this.#Gi(s)
let r
for(const s of e){if(!s.isConnected||s.tagName===o&&!hl(s))continue
if(Oc.has(t)&&null!==s.querySelector("caption,details,dl,fieldset,figure,form,hr,menu,ol,table,tbody,td,tfoot,th,thead,tr,ul,video"))continue
const e=this.#Et.createElement(t)
for(const t of Array.from(s.attributes))e.setAttribute(t.name,t.value)
const i=s.tagName.toLowerCase()
"pre"!==i||"p"!==t&&"div"!==t?"p"!==i&&"div"!==i||"pre"!==t||this.#Hi(s):this.#Ki(s)
const n=this.#Yi(s,e,t)
s.replaceWith(...n),r=n.at(-1)}const n=void 0===i?void 0:this.#Wi(i)
return void 0!==n?n:void 0===r?this.#bi():cl(this.#Et,r)}),void 0!==i&&(this.#Pt=void 0,this.setSelection(i))}#Yi(t,e,i){if(!Oc.has(i))return e.append(...Array.from(t.childNodes)),[e]
const o=[]
let s=[]
const r=()=>{if(!s.some(t=>t instanceof Text?t.data.trim().length>0:!(t instanceof HTMLElement&&"true"===t.dataset._n)))return void(s=[])
const t=this.#Et.createElement(i)
t.append(...s),o.push(t),s=[]}
for(const n of Array.from(t.childNodes))if(Al(n)){if(r(),n instanceof HTMLElement)if(n.tagName.toLowerCase()!==i||hl(n)){const t=n.tagName.toLowerCase()
"pre"!==t||"p"!==i&&"div"!==i?"p"!==t&&"div"!==t||"pre"!==i||this.#Hi(n):this.#Ki(n)
const e=this.#Et.createElement(i)
for(const i of Array.from(n.attributes))e.setAttribute(i.name,i.value)
o.push(...this.#Yi(n,e,i))}else o.push(n)}else s.push(n)
if(r(),0===o.length)o.push(e)
else{for(const t of Array.from(e.attributes))o[0].hasAttribute(t.name)||o[0].setAttribute(t.name,t.value)
for(const e of Array.from(t.attributes))o[0].hasAttribute(e.name)||o[0].setAttribute(e.name,e.value)}return o}#ji(t){const e=this.#bi()
if(void 0===e)return
const i=t=>{let e=t
for(;null!==e&&e.parentNode!==this.element;)e=e.parentNode
return e?.parentNode===this.element?e:void 0},o=i(e.startContainer),s=i(e.endContainer)
if(void 0===o||void 0===s)return
const r=Array.prototype.indexOf.call(this.element.childNodes,o),n=Array.prototype.indexOf.call(this.element.childNodes,s)
if(r<0||n<r)return
const a=Array.from(this.element.childNodes).slice(r,n+1)
a.some(t=>t instanceof HTMLElement&&t.matches(_c))||this.#ti(()=>{const i=this.#Gi(e),s=this.#Et.createElement(t)
this.element.insertBefore(s,o)
for(const t of a)s.append(t)
return this.#Wi(i)??cl(this.#Et,s)})}#Ki(t){const e=this.#Et.createTreeWalker(t,this.#Et.defaultView?.NodeFilter.SHOW_TEXT??4),i=[]
for(let o=e.nextNode();null!==o;o=e.nextNode())o instanceof Text&&o.data.includes("\n")&&i.push(o)
for(const o of i){const t=this.#Et.createDocumentFragment(),e=o.data.split("\n")
e.forEach((i,o)=>{i.length>0&&t.append(this.#Et.createTextNode(i)),o<e.length-1&&t.append(this.#Et.createElement("br"))}),o.replaceWith(t)}}#Hi(t){for(const e of Array.from(t.querySelectorAll("br")))"http://www.w3.org/1999/xhtml"===e.namespaceURI&&e.replaceWith(this.#Et.createTextNode("\n"))}#Gi(t){const e=()=>{const t=this.#Et.createElement("span")
return t.setAttribute("data-soeditor-selection-marker","true"),t},i=e(),o=t.collapsed?i:e()
if(!t.collapsed){const e=t.cloneRange()
e.collapse(!1),e.insertNode(o)}const s=t.cloneRange()
return s.collapse(!0),s.insertNode(i),{end:o,start:i}}#Wi(t){const{end:e,start:i}=t
if(i===e){const t=this.#zi(i)
return void 0===t?void 0:this.#Zi(t)}const o=this.#zi(e),s=this.#zi(i)
if(void 0===s||void 0===o)return
const r=this.#Et.createRange()
try{return r.setStart(s.node,s.offset),r.setEnd(o.node,o.offset),r}catch{return}}#zi(t){const e=t.parentNode
if(null===e)return void t.remove()
const i=t.previousSibling,o=t.nextSibling
if(t.remove(),i instanceof Text&&o instanceof Text){const t=i.data.length
return i.appendData(o.data),o.remove(),{node:i,offset:t}}if(i instanceof Text)return{node:i,offset:i.data.length}
if(o instanceof Text)return{node:o,offset:0}
const s=Array.prototype.indexOf.call(e.childNodes,o)
return{node:e,offset:s<0?e.childNodes.length:s}}#Zi(t){const e=this.#Et.createRange()
return e.setStart(t.node,t.offset),e.collapse(!0),e}#pe(t){const e=this.#qi()
return e.length>0&&e.every(e=>e.tagName===t.toUpperCase())}#re(t){const e=this.#Qi()
0!==e.length&&this.#ti(()=>{for(const i of e)Lc(i,t)
return this.#bi()})}#ae(t){const e=this.#Ui()
return void 0!==e&&t.every(({name:t,value:i})=>e.getAttribute(t)===i)}#xe(t){const e=this.#Qi()
0!==e.length&&this.#ti(()=>{for(const i of e)i.style.textAlign=t??""
return this.#bi()})}#le(){const t=this.#bi(),e=this.#Qt
if(e?.isConnected&&(!t||!e.contains(t.startContainer))){const t=this.#Et.createRange()
return t.selectNodeContents(e),t}return t}#me(t){const e=Sc(this.element,this.#le()).alignment
return"uniform"===e.status&&e.value===(t??"left")}#se(t){const e=this.#bi()
if(void 0===e)return
const i=Dc(this.element,e)
0!==i.length&&(i.every(t=>"LI"===t.tagName)?this.#Ji(()=>{((t,e,i)=>{const o=Dc(t,e)
if(0===o.length||o.some(t=>"LI"!==t.tagName))return!1
for(const s of i>0?o:[...o].reverse()){const t=s.parentElement
if(null!==t)if(i>0){const e=s.previousElementSibling
if(!(e instanceof HTMLElement)||"LI"!==e.tagName)continue
let i=e.lastElementChild
i instanceof HTMLElement&&i.tagName===t.tagName||(i=t.cloneNode(!1),i.removeAttribute("id"),i.removeAttribute("start"),i.removeAttribute("reversed"),e.append(i)),i.append(s)}else{const e=t.parentElement
if("LI"!==e?.tagName){Tc(t,new Set([s]),void 0)
continue}if(null!==s.nextSibling){const e=t.cloneNode(!1)
if(e.removeAttribute("id"),"OL"===t.tagName){const i=s.nextElementSibling
null!==i&&e.setAttribute("start",(Mc(t).get(i)??1)+"")}for(;null!==s.nextSibling;)e.append(s.nextSibling)
s.append(e)}e.after(s),t.querySelector(":scope > li")||t.remove()}}})(this.element,e,t)}):this.#ti(()=>{for(const e of i){const i=Number.parseFloat(e.style.marginInlineStart)||0
e.style.marginInlineStart=Math.max(0,i+2*t)+"em"}return this.#bi()}))}#Li(t){const e=this.#Qi(),i=this.#Ui()??e[0]
if(void 0===i)return
const o=i.closest("ol,ul")
if(null!==o){if(o.tagName.toLowerCase()===t)return o
const e=this.#Et.createElement(t)
for(const t of Array.from(o.attributes))["type","start","reversed"].includes(t.name)||e.setAttribute(t.name,t.value)
return e.style.removeProperty("list-style-type"),e.append(...Array.from(o.childNodes)),o.replaceWith(e),e}const s=this.#Et.createElement(t)
if(i.matches("td,th,figcaption")){const t=this.#Et.createElement("li")
return t.append(...Array.from(i.childNodes)),s.append(t),i.append(s),s}const r=e.filter(t=>t.parentNode===i.parentNode&&!t.closest("ol,ul"))
i.before(s)
for(const n of r.length>0?r:[i]){const t=this.#Et.createElement("li")
n.replaceWith(t),t.append(n),s.append(t)}return s}#Re(t){this.#Ji(()=>{const e=this.#bi()
void 0!==e&&((t,e,i)=>{const o=Dc(t,e),s=o.length>0&&o.every(t=>"LI"===t.tagName&&t.parentElement?.tagName.toLowerCase()===i),r=new Map
for(const a of o){const t=a.parentElement
if("LI"===a.tagName&&t?.matches("ol,ul")){const e=r.get(t)??new Set
e.add(a),r.set(t,e)}}for(const[a,c]of r)(s||a.tagName.toLowerCase()!==i)&&Tc(a,c,s?void 0:i)
let n
for(const a of o){if("LI"===a.tagName||!a.isConnected){n=void 0
continue}const e=t.ownerDocument.createElement("li")
if(a.matches("td,th,figcaption")){const o=t.ownerDocument.createElement(i)
e.append(...Array.from(a.childNodes)),o.append(e),a.append(o),n=void 0}else void 0!==n&&n.nextSibling===a||(n=t.ownerDocument.createElement(i),a.before(n)),e.append(a),n.append(e)}})(this.element,e,t)})}#Fe(t,e){("ol"===t?["decimal","decimal-leading-zero","lower-roman","upper-roman","lower-alpha","upper-alpha"]:["disc","circle","square"]).includes(e)&&this.#Ji(()=>{const i=this.#Li(t)
void 0!==i&&(i.removeAttribute("type"),i.style.listStyleType=e)})}#Ji(t){this.#ti(()=>{const e=this.#bi()
if(void 0===e)return
const{startContainer:i,startOffset:o,endContainer:s,endOffset:r}=e
if(t(),!i.isConnected||!s.isConnected)return this.#bi()
const n=this.#Et.createRange()
return n.setStart(i,Math.min(o,3===i.nodeType?i.textContent?.length??0:i.childNodes.length)),n.setEnd(s,Math.min(r,3===s.nodeType?s.textContent?.length??0:s.childNodes.length)),n})}#_e(t,e){const i=Sc(this.element,this.#le()).list
return"uniform"===i.status&&i.value===`${t}:${e}`}#ve(t){const e=Sc(this.element,this.#le()).list
return"uniform"===e.status&&e.value.startsWith(t+":")}#Me(t){const e=this.#Ui()?.closest("ol,ul")
null!=e&&this.#ti(()=>(void 0===t.start?e.removeAttribute("start"):e.setAttribute("start",t.start+""),void 0===t.type?e.removeAttribute("type"):e.setAttribute("type",t.type),this.#bi()))}#De(t){const e=this.#bi()
if(void 0===e)return
const i=this.#we("a")
this.#Fi(e,e=>{if(void 0===t)return void 0!==i&&nl(i),e
const o=i??this.#Et.createElement("a")
if(o.setAttribute("href",t.href),il(o,"target",t.target),il(o,"rel",t.rel),il(o,"title",t.title),void 0!==t.customAttributes){for(const t of o.getAttributeNames())["href","rel","target","title"].includes(t)||o.removeAttribute(t)
for(const e of t.customAttributes)o.setAttribute(e.name,e.value)}return void 0===i&&(e.collapsed?o.textContent=t.href:o.append(e.extractContents()),e.insertNode(o)),e.selectNodeContents(o),e})}#Ae(){const t=this.#we("a"),e=t?.getAttribute("href")
if(void 0!==t&&null!=e)return{href:e,...t.hasAttribute("target")?{target:t.getAttribute("target")??""}:{},...t.hasAttribute("rel")?{rel:t.getAttribute("rel")??""}:{},...t.hasAttribute("title")?{title:t.getAttribute("title")??""}:{},...(()=>{const e=t.getAttributeNames().filter(t=>!["href","rel","target","title"].includes(t)).map(e=>Object.freeze({name:e,value:t.getAttribute(e)??""}))
return 0===e.length?{}:{customAttributes:Object.freeze(e)}})()}}#be(t,e){const i=this.#bi()
if(void 0===i)return
const o=i.cloneRange()
"selection-start"===e?.placement&&o.collapse(!0)
const s=io(t),r=this.#Et.createDocumentFragment()
r.append(...s.document.children.map(t=>this.#Ei(t)))
const n=Array.from(r.childNodes).some(t=>t instanceof Element&&t.matches("address,article,aside,blockquote,div,figure,footer,h1,h2,h3,h4,h5,h6,header,hr,main,nav,ol,p,pre,section,table,ul,video")),a=r.lastChild
this.#ti(()=>{const t=ol(o.commonAncestorContainer,"td,th")
if(void 0!==t&&this.element.contains(t))o.deleteContents(),o.insertNode(r)
else if(n){const t=this.#Ui()
void 0!==t?t.after(r):o.insertNode(r)}else o.deleteContents(),o.insertNode(r)
this.#Bi()
const e=this.#Et.createRange()
return null!==a&&a.isConnected?e.setStartAfter(a):(e.selectNodeContents(this.element),e.collapse(!1)),e.collapse(!0),e})}#ke(t){const e=this.#bi(),i=this.#$t??(e?.commonAncestorContainer instanceof Element?e.commonAncestorContainer:e?.commonAncestorContainer.parentElement)
if(null==i)return
const o="soeditor.table"===t?"table":"soeditor.media"===t?"figure[data-soeditor-media],figure:has(img)":"soeditor.video"===t?"figure[data-soeditor-video],video":"soeditor.cms-embed"===t?"[data-soeditor-embed]":!0===t?.startsWith("soeditor.cms-object.")?"[data-soeditor-object]":"table,figure,video,[data-soeditor-object],[data-soeditor-embed]",s=i.closest(o)
return null!==s&&this.element.contains(s)?s:void 0}#he(t){const e=this.#ke(t)
if(void 0===e)return
const i=this.#Ti(e)
if("element"!==i?.type)return
const o=t??(t=>{if(t.matches("table"))return"soeditor.table"
if(t.matches("figure[data-soeditor-media],figure:has(img)"))return"soeditor.media"
if(t.matches("figure[data-soeditor-video],video"))return"soeditor.video"
if(t.hasAttribute("data-soeditor-embed"))return"soeditor.cms-embed"
const e=t.getAttribute("data-soeditor-object")
return null===e?void 0:"soeditor.cms-object."+e})(e)
return void 0!==o?Object.freeze({attributes:i.attributes,behavior:"atomic",children:i.children,kind:"structured-block",type:o}):void 0}#Be(t,e){const i=this.#ke(t)
if(void 0===i)return
const o=io(oo({children:[{attributes:e.attributes,children:e.children,namespace:"html",tagName:i.tagName.toLowerCase(),type:"element"}],type:"document-fragment"})).document.children[0]
if(void 0===o)return
const s=this.#Ei(o)
if(!(s instanceof Element))return
const r=this.#ue()
let n
this.#ti(()=>{i.replaceWith(s),this.#Bi()
const t=void 0===r?void 0:dl(s,r.anchor.row,r.anchor.column)
if(void 0!==t){n=t,this.#Qt=t
const e=t.closest("table")
return null!==e&&void 0!==r&&(this.#te={range:{anchor:r.anchor,focus:r.anchor},table:e}),this.#$t=t,cl(this.#Et,t)}this.#$t=s
const e=this.#Et.createRange()
return e.selectNode(s),e}),void 0!==n&&this.#gi(n)}#Te(t,e){const i=this.#ke(t)
void 0!==i&&this.#ti(()=>{for(const t of Array.from(i.attributes))i.removeAttribute(t.name)
return Lc(i,e),this.#bi()})}#Ee(t){const e=this.#ke(t)
void 0!==e&&this.#ti(()=>{const t=this.#Et.createRange()
return t.setStartBefore(e),t.collapse(!0),e.remove(),this.#$t=void 0,this.#Qt=void 0,this.#te=void 0,t})}#ue(){const t=this.#te
return!0===t?.table.isConnected?t.range:void 0}#Pi(t,e){const i=this.#Et.defaultView?.CustomEvent??CustomEvent
this.element.dispatchEvent(new i("soeditor:editing-feedback",{bubbles:!0,detail:Object.freeze({message:t,severity:e})}))}#Ci(t,e){if("object"!=typeof e||null===e)return
const i=e,o=zc(i.src)
if(void 0!==o&&(0===o.length||!Kc(o,!0)))return void this.#Pi("Image URL is not safe.","error")
const s=zc(i.link),r=zc(i.linkTarget)
if(void 0!==s&&s.length>0&&!Kc(s,!1))return void this.#Pi("Image link URL is not safe.","error")
if(void 0!==r&&r.length>0&&!/^_(?:blank|parent|self|top)$/u.test(r)&&!/^[A-Za-z][A-Za-z0-9_.:-]*$/u.test(r))return void this.#Pi("Image link target is invalid.","error")
const n=zc(i.srcset)
if(void 0!==n&&!(t=>0===t.trim().length||t.split(",").every(t=>{const e=t.trim().split(/\s+/u,1)[0]
return void 0!==e&&e.length>0&&Kc(e,!0)}))(n))return void this.#Pi("Responsive image sources are not safe.","error")
const a=zc(i.responsiveClass)
if(void 0!==a&&a.length>0&&!/^[a-z][a-z0-9_-]*(?:\s+[a-z][a-z0-9_-]*){0,7}$/iu.test(a))return void this.#Pi("Image CSS classes are invalid.","error")
const c=zc(i.alignment)
void 0===c||["","left","center","right","wide"].includes(c)?this.#ti(()=>{const e=Jc(t.getAttribute("width")),l=Jc(t.getAttribute("height")),A=void 0!==i.width&&i.width+""!=(e??"")+"",h=void 0!==i.height&&i.height+""!=(l??"")+""
if(Zc(t,"src",o,!1),Zc(t,"alt",zc(i.alt),!0),Zc(t,"title",zc(i.title),!1),Uc(t,"width",i.width),Uc(t,"height",i.height),!0===i.aspectLocked&&void 0!==e&&void 0!==l){const i=Jc(t.getAttribute("width")),o=Jc(t.getAttribute("height"))
A&&!h&&void 0!==i?t.setAttribute("height",Math.max(1,Math.round(i*l/e))+""):h&&!A&&void 0!==o&&t.setAttribute("width",Math.max(1,Math.round(o*e/l))+"")}Zc(t,"srcset",n,!1),Zc(t,"sizes",zc(i.sizes),!1),Zc(t,"class",a,!1)
let d=t.closest("figure")
const u=zc(i.caption),f=c,b=void 0!==u||void 0!==f&&f.length>0||"boolean"==typeof i.aspectLocked
if(null===d&&b){d=this.#Et.createElement("figure"),d.dataset.Qn="image"
const e="A"===t.parentElement?.tagName?t.parentElement:t,i=e.parentElement
"P"===i?.tagName&&0===i.textContent?.trim().length&&1===i.children.length?i.replaceWith(d):e.replaceWith(d),d.append(e)
const o=d.parentElement?.closest("p,h1,h2,h3,h4,h5,h6,pre")
if(o&&this.element.contains(o))for(;o.contains(d);){const t=d.parentElement
if(null===t)break
al(d,t)}}if(null!==d&&(il(d,"data-align",f),"boolean"==typeof i.aspectLocked&&il(d,"data-aspect-lock",i.aspectLocked?"true":void 0),void 0!==u)){let t=d.querySelector(":scope > figcaption")
0===u.length?t?.remove():(t??=this.#Et.createElement("figcaption"),t.textContent=u,d.append(t))}if(void 0!==s){const e="A"===t.parentElement?.tagName?t.parentElement:void 0
if(0===s.length)e?.replaceWith(t)
else if(void 0===e){const e=this.#Et.createElement("a")
e.href=s,t.replaceWith(e),e.append(t)}else e.setAttribute("href",s)}if(void 0!==r){const e=t.closest("a")
null!==e&&il(e,"target",0===r.length?void 0:r)}this.#$t=t
const m=this.#Et.createRange()
return m.selectNode(t),m}):this.#Pi("Image alignment is invalid.","error")}#hi(){const t=this.#bi(),e=this.#we("p"),i=e?.parentElement
return!(!t?.collapsed||!e?.textContent?.trim()||"LI"!==i?.tagName||(this.#ti(()=>{const o=[]
for(let e=t.startContainer instanceof Element?t.startContainer:t.startContainer.parentElement;e&&e!==i;e=e.parentElement)o.push(e)
const s=t.cloneRange()
s.setEnd(i,i.childNodes.length)
const r=this.#Et.createElement("li")
for(const t of Array.from(i.attributes))"id"!==t.name&&"value"!==t.name&&r.setAttribute(t.name,t.value)
r.append(s.extractContents())
let n=r
for(const t of[i,...o.reverse()]){if(!(n instanceof Element)||n.tagName!==t.tagName)break
n.removeAttribute("id")
const e=this.#Mt.get(t)
e&&this.#Mt.set(n,e),n=n.firstChild}if(0===r.childNodes.length){const t=e.cloneNode(!1)
t instanceof Element&&t.removeAttribute("id"),r.append(t)}const a=r.firstChild
for(const t of[e,a])t instanceof Element&&!t.textContent&&!t.querySelector("br,img,svg,math")&&t.append(this.#Et.createElement("br"))
i.after(r)
const c=this.#Et.createRange()
return c.selectNodeContents(a??r),c.collapse(!0),c}),0))}#Fi(t,e){this.#ti(()=>e(t))}#ti(t){if(!this.#ce())return
this.#ri()
const e=t()
void 0!==e&&this.#si(e),this.#mi()}#Ui(){if(!0===this.#Qt?.isConnected)return this.#Qt
const t=this.#bi()
if(void 0===t)return
const e=t.commonAncestorContainer instanceof Element?t.commonAncestorContainer:t.commonAncestorContainer.parentElement,i=e?.closest(_c)
return i!==this.element&&null!=i&&this.element.contains(i)?i:void 0}#Qi(){const t=this.#bi()
return void 0===t?[]:this.#ni().filter(e=>t.intersectsNode(e))}#qi(){const t=this.#bi()
return void 0===t?[]:(t.collapsed?[this.#Ui()]:this.#Qi()).filter(t=>void 0!==t&&t.matches("address,blockquote,div,h1,h2,h3,h4,h5,h6,p,pre"))}#_i(t,e,i){const o=[]
for(const r of this.#Vi(t)){if(r.collapsed)continue
const t=e()
t.append(r.extractContents()),r.insertNode(t),o.push(i?.(t)??t)}if(0===o.length)return t
const s=this.#Et.createRange()
return s.setStartBefore(o[0]),s.setEndAfter(o.at(-1)),s}#Vi(t){const e=ol(t.startContainer,_c),i=ol(t.endContainer,_c)
return void 0!==e&&e===i&&this.element.contains(e)?[t.cloneRange()]:this.#Qi().map(e=>{const i=this.#Et.createRange()
return i.selectNodeContents(e),e.contains(t.startContainer)&&i.setStart(t.startContainer,t.startOffset),e.contains(t.endContainer)&&i.setEnd(t.endContainer,t.endOffset),i})}#we(t){const e=this.#bi()
if(void 0===e)return
const i=ol(e.commonAncestorContainer,t)
return void 0!==i&&this.element.contains(i)?i:void 0}#de(){const t=this.#bi()
if(void 0===t)return
const e=this.#ni(),i=gl(e,t.startContainer,t.startOffset),o=gl(e,t.endContainer,t.endOffset)
if(void 0===i||void 0===o)return
const s={anchor:i,focus:o}
return this.#Pt=s,s}#ni(){const t=this.#Et.defaultView
if(null===t)return[]
const e=[]
for(const i of Array.from(this.element.children))i instanceof t.HTMLElement&&("OL"===i.tagName||"UL"===i.tagName?e.push(...Array.from(i.querySelectorAll("li")).filter(e=>e instanceof t.HTMLLIElement)):e.push(i))
return e}#Ii(){const t=this.#bi()
if(void 0!==t)return{end:fl(this.element,t.endContainer),endOffset:t.endOffset,start:fl(this.element,t.startContainer),startOffset:t.startOffset}}#xi(t){const e=this.#Xi(t)
void 0!==e&&this.#si(e)}#Xi(t){const e=bl(this.element,t.start),i=bl(this.element,t.end)
if(void 0===e||void 0===i)return
const o=this.#Et.createRange()
try{return o.setStart(e,Math.min(t.startOffset,ml(e))),o.setEnd(i,Math.min(t.endOffset,ml(i))),o}catch{return}}#ci(t){this.editor.commands.has(t)&&this.editor.commands.canExecute(t)&&this.editor.execute(t)}#g(){if(this.#I)throw new Fc}}function Hc(t,e){const i=e.name.toLowerCase()
return!i.startsWith("on")&&"contenteditable"!==i&&("style"===i?!/(?:expression|url\s*\(|behavior\s*:|-moz-binding)/iu.test(e.value):["href","src","poster","action","formaction"].includes(i)?Kc(e.value,"img"===t):void 0===e.namespace)}function Kc(t,e){const i=t.trim()
return!!/^(?:https?:|blob:|mailto:|tel:)/iu.test(i)||!(!e||!/^data:image\/(?:png|jpe?g|gif|webp|avif);base64,/iu.test(i))||/^(?!\/\/)(?![a-z][a-z\d+.-]*:)[^\s]*$/iu.test(i)}function Yc(t,e){const i=t.getAttribute(e)
if(null===i)return
const o=/^([1-9][0-9]{0,3})(?:px)?$/u.exec(i)
if(void 0!==o?.[1])return o[1]+"px"
const s=/^(100|[1-9]?[0-9])%$/u.exec(i)
return void 0===s?.[1]?void 0:i}function Wc(t,e){const i=t.getAttribute(e)
if(null!==i&&/^\d{1,3}$/u.test(i))return Number(i)}function zc(t){if(void 0!==t)return null===t?"":"string"==typeof t?t:void 0}function Zc(t,e,i,o){void 0!==i&&(0!==i.length||o?t.setAttribute(e,i):t.removeAttribute(e))}function Uc(t,e,i){if(void 0===i)return
const o="number"==typeof i?i+"":i
"string"==typeof o&&/^\d+$/u.test(o)&&Number(o)>0?(t.setAttribute(e,o),""!==t.style.getPropertyValue(e)&&t.style.setProperty(e,o+"px",t.style.getPropertyPriority(e))):""!==o&&null!==o||(t.removeAttribute(e),t.style.removeProperty(e))}function Jc(t){if(null===t||!/^\d+$/u.test(t))return
const e=Number(t)
return e>0?e:void 0}function Lc(t,e){for(const{name:i,value:o}of e)t.setAttribute(i,o)}function Pc(t){const e=t
for(;1===e.childNodes.length&&$c(e.firstElementChild);){const t=e.firstElementChild
tl(t,e),t.replaceWith(...Array.from(t.childNodes))}for(;$c(e.parentElement);){const t=e.parentElement
Vc(t)
const i=Array.from(t.childNodes),o=i.indexOf(e)
if(o<0)break
tl(t,e)
const s=t.cloneNode(!1)
s.append(...i.slice(0,o))
const r=t.cloneNode(!1)
r.append(...i.slice(o+1)),e.remove(),t.replaceWith(...Xc(s)?[s]:[],e,...Xc(r)?[r]:[])}return e}function Vc(t){for(const e of Array.from(t.childNodes))3===e.nodeType&&0===e.nodeValue?.length&&e.remove()}function Xc(t){return Vc(t),t.childNodes.length>0}function $c(t){return"SPAN"===t?.tagName&&1===t.attributes.length&&t.hasAttribute("style")}function tl(t,e){for(let i=0;i<t.style.length;i+=1){const o=t.style.item(i)
o.length>0&&0===e.style.getPropertyValue(o).length&&e.style.setProperty(o,t.style.getPropertyValue(o),t.style.getPropertyPriority(o))}}function el(t,e){const i="background"===e?new Set(["background","background-color"]):new Set([e]),o=(t.getAttribute("style")??"").split(";").map(t=>t.trim()).filter(t=>{if(0===t.length)return!1
const e=t.indexOf(":")
return!(e<0||i.has(t.slice(0,e).trim().toLowerCase()))})
0===o.length?t.removeAttribute("style"):t.setAttribute("style",o.join("; ")+";")}function il(t,e,i){void 0===i?t.removeAttribute(e):t.setAttribute(e,i)}function ol(t,e){const i=t instanceof Element?t:t.parentElement
return i?.closest(e)??void 0}function sl(t,e){const i=t.getRootNode(),o=Reflect.get(i,"getSelection")
if("function"==typeof o){const t=Reflect.apply(o,i,[]),s=e.defaultView?.Selection
if(void 0!==s&&t instanceof s)return t}return e.getSelection()}function rl(t,e){const i=sl(t,e)
if(null===i)return
const o=((t,e)=>{if(0!==t.rangeCount)try{const i=t.getRangeAt(0),o=e.defaultView?.Range,s=e.defaultView?.Node
if(!(void 0!==o&&void 0!==s&&i instanceof o&&i.commonAncestorContainer instanceof s))return
return i}catch{return}})(i,e)
if(void 0!==o&&t.contains(o.commonAncestorContainer))return o
const s=t.getRootNode()
if(!(s instanceof ShadowRoot))return o
const r=Reflect.get(i,"getComposedRanges")
if("function"!=typeof r)return o
let n
try{n=Reflect.apply(r,i,[{an:[s]}])}catch{return o}if(!Array.isArray(n)||0===n.length)return o
const a=n[0]
if("object"!=typeof a||null===a)return o
const c=Reflect.get(a,"startContainer"),l=Reflect.get(a,"endContainer"),A=Reflect.get(a,"startOffset"),h=Reflect.get(a,"endOffset"),d=e.defaultView?.Node
if(!(void 0!==d&&c instanceof d&&l instanceof d&&"number"==typeof A&&"number"==typeof h))return o
const u=e.createRange()
try{return u.setStart(c,A),u.setEnd(l,h),u}catch{return o}}function nl(t){t.replaceWith(...Array.from(t.childNodes))}function al(t,e){if(t.parentElement!==e)return
const i=e.cloneNode(!1),o=e.cloneNode(!1)
for(;null!==e.firstChild&&e.firstChild!==t;)i.append(e.firstChild)
for(;null!==t.nextSibling;)o.append(t.nextSibling)
i.hasChildNodes()&&o.removeAttribute("id"),e.replaceWith(...i.hasChildNodes()?[i]:[],t,...o.hasChildNodes()?[o]:[])}function cl(t,e){const i=t.createRange()
return i.selectNodeContents(e),i.collapse(!1),i}function ll(t,e){if(null===e)return
const i=e.split(/\s+/u).filter(t=>t.length>0)
i.length>0&&t.classList.add(...i)}function Al(t){return t instanceof HTMLElement&&t.matches(Qc)}function hl(t){return null!==t.querySelector(Qc)}function dl(t,e,i){return ul(t)[e]?.[i]}function ul(t){const e=Array.from(t.querySelectorAll("tr")).filter(e=>e.closest("table")===t),i=e.map(()=>[])
for(const[o,s]of e.entries()){let t=0
for(const r of Array.from(s.cells)){for(;void 0!==i[o]?.[t];)t+=1
const s=Math.max(1,r.rowSpan),n=Math.max(1,r.colSpan)
for(let a=o;a<Math.min(e.length,o+s);a+=1)for(let e=t;e<t+n;e+=1){const t=i[a]
void 0!==t&&(t[e]=r)}t+=n}}return i}function fl(t,e){const i=[]
let o=e
for(;o!==t&&null!==o?.parentNode;){const t=o.parentNode
i.unshift(Array.prototype.indexOf.call(t.childNodes,o)),o=t}return o===t?i:[]}function bl(t,e){let i=t
for(const o of e){const t=i.childNodes.item(o)
if(null===t)return
i=t}return i}function ml(t){return 3===t.nodeType?t.nodeValue?.length??0:t.childNodes.length}function pl(t,e){if(!Number.isInteger(e)||e<0)return
const i=t.ownerDocument
if(null===i)return
const o=i.createTreeWalker(t,NodeFilter.SHOW_TEXT)
let s=e,r=o.nextNode()
for(;null!==r;){const t=r.nodeValue?.length??0
if(s<=t)return{node:r,offset:s}
s-=t,r=o.nextNode()}return 0===s?{node:t,offset:t.childNodes.length}:void 0}function gl(t,e,i){const o=t.findIndex(t=>t===e||t.contains(e))
if(o<0)return
const s=e.ownerDocument?.createRange()
return void 0!==s?(s.setStart(t[o],0),s.setEnd(e,i),{block:o,offset:s.toString().length}):void 0}function wl(t){return t.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")}const vl=new WeakMap,yl=new WeakMap,kl=/^(?:\s*|<p(?:\s[^>]*)?>\s*(?:<br\s*\/?>)?\s*<\/p>)$/iu,Cl=new Set(["pageBreak","placeholder","redo","source","sourceFind","specialCharacter","undo"]),Il=[]
function El(t,e,i,o){let s,r,n=!1,a=!1
const c=t=>{if("soeditor:block-hover"!==r?.type)return
const e=r.target
t instanceof MouseEvent&&e instanceof Element&&!(t.relatedTarget instanceof Node&&e.contains(t.relatedTarget))&&(r=void 0)},l=t=>{t?e.addEventListener("pointerout",c):e.removeEventListener("pointerout",c)
for(const o of i)t?e.addEventListener(o,A):e.removeEventListener(o,A)},A=e=>{void 0===s&&(r={detail:Reflect.get(e,"detail"),target:e.target,type:e.type},a||(a=!0,o().then(t=>{if(n)return
const e=r
r=void 0,a=!1,void 0!==e&&(l(!1),s=t(e))}).catch(()=>{n||(a=!1,l(!0),t.notifications.show({message:"Block tools failed to load. Please try again.",severity:"error"}))})))}
return l(!0),()=>{n=!0,l(!1),s?.()}}function Bl(t,e){void 0!==e.On&&(t.style.height=e.On+"px"),void 0!==e.Nn&&(t.style.minHeight=e.Nn+"px"),void 0!==e.qn&&(t.style.maxHeight=e.qn+"px")}function xl(t){const e=[]
for(const i of t)Cl.has(i)||("|"!==i||0!==e.length&&"|"!==e.at(-1))&&e.push(i)
return"|"===e.at(-1)&&e.pop(),Object.freeze(e)}function Sl(t){return"textarea"===t.tagName.toLowerCase()}function Dl(t,e){if(void 0!==t){if("string"!=typeof t||0===t.trim().length)throw new TypeError(`Classic editor ${e} must not be empty.`)
return t}}function Ml(t,e){if(void 0!==t){if(!Number.isFinite(t)||t<=0||t>1e5)throw new TypeError(`Classic editor ${e} must be a positive number up to 100000.`)
return t}}function Tl(t,e,i){if(void 0!==t&&"boolean"!=typeof t)throw new TypeError(`Classic editor ${e} must be a boolean.`)
return t??i}function Rl(t,e){if("string"!=typeof t)throw new TypeError(e+" must be a string.")
return t}const Fl=Object.freeze(Object.defineProperty({__proto__:null,createClassicEditor:async(t,e={})=>{if((t=>{const e=t.ownerDocument.defaultView
if(null===e||!(t instanceof e.HTMLElement))throw new TypeError("A classic editor host must be an HTMLElement.")
if(!t.isConnected)throw new TypeError("A classic editor host must be attached to a window.")})(t),vl.has(t))throw new L
if((t=>{for(const[e,i]of[["onBlur",t.onBlur],["onChange",t.onChange],["onError",t.onError],["onFocus",t.onFocus],["onReady",t.onReady]])if(void 0!==i&&"function"!=typeof i)throw new TypeError(`Classic editor ${e} must be a function.`)})(e),(t=>{if(void 0!==t){if("object"!=typeof t||null===t)throw new TypeError("Classic editor save options must be an object.")
if(void 0!==t.leavePageProtection&&"boolean"!=typeof t.leavePageProtection)throw new TypeError("Classic editor leavePageProtection must be a boolean.")
if(void 0!==t.onStateChange&&"function"!=typeof t.onStateChange)throw new TypeError("Classic editor save onStateChange must be a function.")}})(e.save),void 0===e.preset)throw new TypeError("Classic editor requires a CMS preset.")
const i=(t=>{if("html"!==t.format)throw new TypeError("A classic editor preset must use the HTML format.")
return t})(e.preset),o=Dl(e.placeholder,"placeholder"),s=Dl(e.locale,"locale")??"en",r=[...await(t=>/^zh(?:[_-]|$)/iu.test(t.trim())?vc:[])(s),...Il,...e.translations??[]],n=Qa(s,r,e.direction),a=Dl(e.ariaLabel,"ariaLabel")??((t,e)=>{const i=t.getAttribute("aria-label")?.trim()
if(void 0!==i&&i.length>0)return i
if(Sl(t)&&null!==t.labels){const e=Array.from(t.labels).map(t=>t.textContent?.trim()??"").find(t=>t.length>0)
if(void 0!==e)return e}return e("Rich text editor")})(t,n.translate),c=(t=>{const e=Ml(t.initialHeight,"initialHeight"),i=Ml(t.minHeight,"minHeight"),o=Ml(t.maxHeight,"maxHeight")
if(void 0!==i&&void 0!==o&&i>o)throw new TypeError("Classic editor minHeight must not exceed maxHeight.")
if(void 0!==e&&void 0!==i&&e<i)throw new TypeError("Classic editor initialHeight must not be below minHeight.")
if(void 0!==e&&void 0!==o&&e>o)throw new TypeError("Classic editor initialHeight must not exceed maxHeight.")
if(void 0!==t.autoGrow&&"boolean"!=typeof t.autoGrow)throw new TypeError("Classic editor autoGrow must be a boolean.")
return Object.freeze({autoGrow:t.autoGrow??!1,...void 0===e?{}:{On:e},...void 0===o?{}:{qn:o},...void 0===i?{}:{Nn:i}})})(e),l=Tl(e.maximizable,"maximizable",!0),A=Tl(e.resizable,"resizable",!0),h=new Set(["wysiwyg"])
let d
const u=e.plugins??i.plugins,f=((t,e)=>{const i=t??"wysiwyg"
if(!e.has(i))throw new TypeError(`Classic initialEditingMode "${i}" is not included in editingModes.`)
return i})(e.initialEditingMode,h)
let b=f,m=50
const p=t.ownerDocument,g=((t,e,i,o,s,r,n)=>{const a=t.createElement("div")
a.className="soeditor-classic"
const c=t.createElement("div")
c.className="soeditor-classic__visual",c.tabIndex=0
const l=c.attachShadow({delegatesFocus:!0,mode:"open"}),A=t.createElement("style")
void 0!==n&&(A.nonce=n),A.textContent=':is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=left]{text-align:left}:is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=center]{text-align:center}:is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=right]{text-align:right}:is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=left] img{margin-left:0;margin-right:auto}:is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=center] img{margin-left:auto;margin-right:auto}:is(.soeditor-content,.soeditor-wysiwyg-content) figure[data-align=right] img{margin-left:auto;margin-right:0}:host{min-height:100%;display:block}.soeditor-wysiwyg-content{all:initial;box-sizing:border-box;min-height:100%;padding:1rem;display:block;position:relative}.soeditor-wysiwyg-content[data-soeditor-content-style=minimal]{color:#24292f;background:#fff;font:16px/1.5 system-ui,sans-serif}.soeditor-wysiwyg-content[data-soeditor-content-style=article]{color:#293246;background:#fff;padding:clamp(1.25rem,3vw,2.5rem);font:17px/1.75 Georgia,serif}.soeditor-wysiwyg-content[data-soeditor-content-style=article] blockquote{background:#f4f3ff;border-inline-start:.25rem solid #655ce7;margin-inline:0;padding:.8rem 1rem}.soeditor-wysiwyg-content[data-soeditor-empty=true][data-soeditor-placeholder]:before{color:var(--soeditor-muted,#59636e);content:attr(data-soeditor-placeholder);pointer-events:none;position:absolute}.soeditor-image-resize-overlay{box-sizing:border-box;pointer-events:none;z-index:8;outline:2px solid #377dff;position:absolute}.soeditor-image-resize-preview{opacity:0;pointer-events:none;block-size:100%;inline-size:100%}.soeditor-image-resize-overlay.is-resizing .soeditor-image-resize-preview{opacity:1}.soeditor-image-resize-overlay:after{color:#fff;content:attr(data-dimensions);opacity:0;white-space:nowrap;background:#111827e0;border-radius:.25rem;padding:.2rem .35rem;font:600 11px/1.3 system-ui,sans-serif;position:absolute;inset-block-start:.4rem;inset-inline-start:50%;transform:translate(-50%)}.soeditor-image-resize-overlay.is-resizing:after{opacity:1}.soeditor-image-resize-handle{appearance:none;box-sizing:border-box;pointer-events:auto;touch-action:none;background:#377dff;border:1px solid #fff;border-radius:0;block-size:10px;inline-size:10px;margin:-5px;padding:0;position:absolute}.soeditor-image-resize-handle[data-resize-direction=n],.soeditor-image-resize-handle[data-resize-direction=s]{block-size:6px;inline-size:14px;margin-block:-3px;margin-inline:-7px}.soeditor-image-resize-handle[data-resize-direction=e],.soeditor-image-resize-handle[data-resize-direction=w]{block-size:14px;inline-size:6px;margin-block:-7px;margin-inline:-3px}.soeditor-image-resize-handle[data-resize-direction=nw]{cursor:nwse-resize;inset-block-start:0;inset-inline-start:0}.soeditor-image-resize-handle[data-resize-direction=n]{cursor:ns-resize;inset-block-start:0;inset-inline-start:50%}.soeditor-image-resize-handle[data-resize-direction=ne]{cursor:nesw-resize;inset-block-start:0;inset-inline-end:0}.soeditor-image-resize-handle[data-resize-direction=e]{cursor:ew-resize;inset-block-start:50%;inset-inline-end:0}.soeditor-image-resize-handle[data-resize-direction=se]{cursor:nwse-resize;inset-block-end:0;inset-inline-end:0}.soeditor-image-resize-handle[data-resize-direction=s]{cursor:ns-resize;inset-block-end:0;inset-inline-start:50%}.soeditor-image-resize-handle[data-resize-direction=sw]{cursor:nesw-resize;inset-block-end:0;inset-inline-start:0}.soeditor-image-resize-handle[data-resize-direction=w]{cursor:ew-resize;inset-block-start:50%;inset-inline-start:0}.soeditor-image-resize-handle:focus-visible{outline:2px solid var(--soeditor-focus,#0969da);outline-offset:2px}.soeditor-wysiwyg-content .soeditor-table-widget{background:var(--soeditor-bg,#fff);border:1px solid var(--soeditor-border,#d0d7de);border-radius:var(--soeditor-radius,.375rem);margin-block:1rem;overflow-x:auto}.soeditor-wysiwyg-content .soeditor-table-widget>table{width:100%}.soeditor-wysiwyg-content table.soeditor-table-widget{width:100%;display:table;overflow:visible}.soeditor-wysiwyg-content :is(table.soeditor-table-widget,.soeditor-table-widget>table):not([cellspacing]){border-collapse:collapse}.soeditor-wysiwyg-content .soeditor-table-widget :is(th,td):not(table[cellpadding]>tr>:is(th,td),table[cellpadding]>:is(thead,tbody,tfoot)>tr>:is(th,td)){padding:0}.soeditor-wysiwyg-content .soeditor-table-widget caption{color:var(--soeditor-muted,#59636e);text-align:start;padding-block-end:.45rem;font-weight:600}.soeditor-wysiwyg-content .soeditor-table-widget th,.soeditor-wysiwyg-content .soeditor-table-widget td{border:1px solid var(--soeditor-border,#d0d7de);min-width:5rem}.soeditor-wysiwyg-content .soeditor-table-widget th{text-align:center;background:0 0;font-weight:600}.soeditor-wysiwyg-content[data-soeditor-content-style=article] .soeditor-table-widget th{background:#f2f1ff}.soeditor-wysiwyg-content .soeditor-table-cell{border:1px solid var(--soeditor-border,#d0d7de);color:inherit;cursor:text;font:inherit;text-align:start;background:0 0;width:auto;min-width:5rem;min-height:2.5rem;display:table-cell}.soeditor-wysiwyg-content .soeditor-table-cell img{max-width:100%;height:auto}.soeditor-wysiwyg-content .soeditor-table-cell a{color:linktext;text-decoration:underline}.soeditor-wysiwyg-content .soeditor-table-cell:empty:before{content:" "}.soeditor-wysiwyg-content .soeditor-table-cell:focus-visible{outline:2px solid var(--soeditor-focus-ring,#0969da);outline-offset:-2px}.soeditor-wysiwyg-content .soeditor-table-cell.is-editing{cursor:text;-webkit-user-select:text;user-select:text;outline:none;box-shadow:inset 0 0 0 9999px #add8fa47}.soeditor-wysiwyg-content .soeditor-table-cell.is-structurally-selected{outline:none;box-shadow:inset 0 0 0 9999px #add8fa61}.soeditor-wysiwyg-content .soeditor-table-cell.is-structurally-selected::selection,.soeditor-wysiwyg-content .soeditor-table-cell.is-structurally-selected ::selection{background:0 0}.soeditor-wysiwyg-content .soeditor-table-cell[aria-pressed=true]{background:color-mix(in srgb, var(--soeditor-accent,#0969da) 15%, transparent)}.soeditor-wysiwyg-content .soeditor-table-cell.is-editing[aria-pressed=true]{background:var(--soeditor-bg,#fff)}.soeditor-table-resize-overlay{pointer-events:none;z-index:4;position:absolute}.soeditor-table-resize-overlay :is(.soeditor-table-column-resize,.soeditor-table-row-resize){appearance:none;pointer-events:auto;background:0 0;border:0;margin:0;padding:0;position:absolute}.soeditor-table-resize-overlay .soeditor-table-column-resize{cursor:col-resize;block-size:100%;inline-size:8px;inset-block-start:0}.soeditor-table-resize-overlay .soeditor-table-row-resize{cursor:row-resize;block-size:8px;inline-size:100%;inset-inline-start:0}.soeditor-table-resize-overlay .soeditor-table-column-resize:before,.soeditor-table-resize-overlay .soeditor-table-row-resize:before{background:var(--soeditor-accent,#0969da);content:"";opacity:0;position:absolute}.soeditor-table-resize-overlay .soeditor-table-column-resize:before{inline-size:2px;inset-block:0;inset-inline-start:3px}.soeditor-table-resize-overlay .soeditor-table-row-resize:before{block-size:2px;inset-block-start:3px;inset-inline:0}.soeditor-table-resize-overlay :is(.soeditor-table-column-resize,.soeditor-table-row-resize):is(:hover,:focus-visible):before{opacity:1}.soeditor-wysiwyg-content .soeditor-table-widget>:is(.soeditor-table-column-resize,.soeditor-table-row-resize){appearance:none;pointer-events:auto;z-index:4;background:0 0;border:0;margin:0;padding:0;position:absolute}.soeditor-wysiwyg-content .soeditor-table-widget>.soeditor-table-column-resize{cursor:col-resize;block-size:100%;inline-size:8px;inset-block-start:0}.soeditor-wysiwyg-content .soeditor-table-widget>.soeditor-table-row-resize{cursor:row-resize;block-size:8px;inline-size:100%;inset-inline-start:0}.soeditor-wysiwyg-content .soeditor-table-widget>:is(.soeditor-table-column-resize,.soeditor-table-row-resize):before{background:var(--soeditor-accent,#0969da);content:"";opacity:0;position:absolute}.soeditor-wysiwyg-content .soeditor-table-widget>.soeditor-table-column-resize:before{inline-size:2px;inset-block:0;inset-inline-start:3px}.soeditor-wysiwyg-content .soeditor-table-widget>.soeditor-table-row-resize:before{block-size:2px;inset-block-start:3px;inset-inline:0}.soeditor-wysiwyg-content .soeditor-table-widget>:is(.soeditor-table-column-resize,.soeditor-table-row-resize):is(:hover,:focus-visible):before{opacity:1}.soeditor-wysiwyg-content .soeditor-wysiwyg-preserved-block[hidden],.soeditor-wysiwyg-content .soeditor-wysiwyg-preserved-inline[hidden]{display:none}.soeditor-wysiwyg-content .soeditor-wysiwyg-preserved-inline{display:inline}.soeditor-table-resize-feedback{z-index:5;pointer-events:none;white-space:nowrap;color:#fff;background:#0969da;border-radius:3px;padding:4px 7px;font:12px/1.4 system-ui,sans-serif;position:absolute;box-shadow:0 1px 4px #0003}.soeditor-block-paragraph{opacity:0;box-sizing:border-box;pointer-events:none;z-index:9;outline:2px solid #0000;position:absolute}:is(.soeditor-block-paragraph:has(button:hover),.soeditor-block-paragraph:has(button:focus-visible)){outline-color:#ffca28}.soeditor-block-paragraph button{appearance:none;color:#fff;cursor:pointer;pointer-events:none;background:#377dff;border:1px solid #fff;border-radius:50%;width:24px;height:24px;padding:0;font:700 16px/22px system-ui,sans-serif;position:absolute;box-shadow:0 1px 3px #00000040}.soeditor-block-paragraph.is-hovered{opacity:1}.soeditor-block-paragraph.is-hovered button{pointer-events:auto}.soeditor-block-paragraph [data-insert-paragraph=before]{left:min(32px,15%);top:var(--soeditor-block-offset,-12px)}.soeditor-block-paragraph [data-insert-paragraph=after]{bottom:var(--soeditor-block-offset,-12px);right:min(32px,15%)}.soeditor-block-paragraph[data-block-kind=table] [data-insert-paragraph=before]{top:0;left:-24px}.soeditor-block-paragraph[data-block-kind=table] [data-insert-paragraph=after]{bottom:0;right:-24px}.soeditor-block-paragraph button:hover,.soeditor-block-paragraph button:focus-visible{color:#24292f;outline-offset:1px;background:#ffca28;outline:2px solid #fff}:host:has(.soeditor-image-resize-overlay.is-resizing) .soeditor-block-paragraph{visibility:hidden}@media (forced-colors:active){.soeditor-block-paragraph button,.soeditor-image-resize-handle{border:2px solid buttontext}:is(.soeditor-block-paragraph:has(button:focus-visible),.soeditor-block-paragraph:has(button:hover),.soeditor-image-resize-overlay){outline:2px solid highlight}}'
const h=t.createElement("div")
h.className="soeditor-wysiwyg-content",void 0!==i&&(h.dataset.jn=i),l.append(A,h),Bl(c,o)
const d=t.createElement("div")
d.className="soeditor-classic__source",d.hidden=!0,d.setAttribute("aria-label",e+" HTML source host"),Bl(d,o)
const u=r.has("source")?t.createElement("div"):void 0
void 0!==u&&(u.className="soeditor-classic__pane-resize-handle",u.hidden=!0,u.tabIndex=0,u.setAttribute("role","separator"),u.setAttribute("aria-valuemin","20"),u.setAttribute("aria-valuemax","80"),u.setAttribute("aria-valuenow","50"))
const f=s?t.createElement("div"):void 0
void 0!==f&&(f.className="soeditor-classic__resize-handle",f.tabIndex=0,f.setAttribute("role","separator"),f.setAttribute("aria-label","Resize editor height"),f.setAttribute("aria-orientation","horizontal"),f.setAttribute("aria-valuemin",Math.round(o.Nn??80)+""),f.setAttribute("aria-valuemax",Math.round(o.qn??1e5)+""),f.setAttribute("aria-valuenow",Math.round(o.On??o.Nn??192)+""))
const b=t.createElement("div")
return b.className="soeditor-classic__surfaces",b.append(c),void 0!==u&&b.append(u,d),a.append(b),void 0!==f&&a.append(f),Object.freeze({...void 0===u?{}:{Gn:u},...void 0===f?{}:{Hn:f},root:a,source:d,Kn:b,Yn:c,Wn:h,zn:l})})(p,a,o,c,A,h,e.cspNonce)
let w=e.contentStylePreset??"browser"
Rc(g.Wn,w),Rc(g.Yn,w)
const v=((t,e,i,o)=>{if(void 0===i)return
if(Rl(i,"Classic editor contentStyles"),0===i.trim().length)throw new TypeError("Classic editor contentStyles must not be empty.")
const s=new Uint32Array(4)
e.ownerDocument.defaultView?.crypto.getRandomValues(s)
const r=Array.from(s,t=>t.toString(36)).join("-")
e.dataset.Zn=r
const n=e.ownerDocument.createElement("style")
return void 0!==o&&(n.nonce=o),n.textContent=`@scope ([data-soeditor-content-scope="${r}"]) { ${i} }`,t.append(n),n})(g.zn,g.Wn,e.contentStyles,e.cspNonce),y=t.hidden,k=Sl(t)?t:void 0,C=k?.value,I=k?.form??void 0
let E,B,x,S,D,M=!1,T=!1,R=((t,e)=>void 0!==e?Rl(e,"Classic editor data"):Sl(t)?t.value:t.innerHTML)(t,e.data),F=!1,_=!1
const Q=Object.freeze({})
let O,N,q,j,G,H,K,Y,z,Z,U,J,V,X,$,tt,et=()=>{},it=!1
h.has("source")&&(g.root.dataset.Un="unloaded"),t.after(g.root),t.hidden=!0
const ot=t=>{R=t,g.Wn.dataset.Jn=kl.test(t)+"",void 0!==k&&(k.value=t),(()=>{if(!c.autoGrow||it||void 0!==B)return
const t=p.defaultView
null!==t&&(B=t.requestAnimationFrame(()=>{if(B=void 0,M)return
const t=g.Wn.scrollHeight,e=c.Nn??c.On??0,i=c.qn??1/0,o=Math.min(Math.max(t,e),i)
o>0&&Number.isFinite(o)&&(g.Yn.style.height=o+"px",g.source.style.height=o+"px")}))})()},st=t=>{try{return void e.onError?.(t)}catch(i){return i}},rt=()=>{F||M||(F=!0,e.onFocus?.(yt()))},nt=t=>{const i=t.relatedTarget
i instanceof Node&&g.root.contains(i)||F&&!M&&(F=!1,e.onBlur?.(yt()))},at=t=>{void 0!==k&&void 0!==S&&(k.value=S.getData())},ct=t=>{const e=p.defaultView
e?.setTimeout(()=>{t.defaultPrevented||M||void 0===k||void 0===S||(S.setData(k.value),S.markClean())},0)}
g.root.addEventListener("focusin",rt),g.root.addEventListener("focusout",nt),I?.addEventListener("submit",at,!0),I?.addEventListener("reset",ct)
const lt=g.Hn,At=t=>{const e=c.Nn??80,i=c.qn??1e5,o=Math.min(Math.max(t,e),i)
it=!0,g.Yn.style.height=o+"px",g.source.style.height=o+"px",lt?.setAttribute("aria-valuenow",Math.round(o)+"")},ht=t=>{void 0===tt||_||At(tt.height+t.clientY-tt.y)},dt=()=>{tt=void 0,p.removeEventListener("pointermove",ht),p.removeEventListener("pointerup",dt),p.removeEventListener("pointercancel",dt)},ut=t=>{_||0!==t.button||(t.preventDefault(),tt={height:g.Yn.getBoundingClientRect().height,y:t.clientY},p.addEventListener("pointermove",ht),p.addEventListener("pointerup",dt),p.addEventListener("pointercancel",dt))},ft=t=>{if("ArrowUp"!==t.key&&"ArrowDown"!==t.key)return
t.preventDefault()
const e=t.shiftKey?50:10
At(g.Yn.getBoundingClientRect().height+("ArrowDown"===t.key?e:-e))}
lt?.addEventListener("pointerdown",ut),lt?.addEventListener("keydown",ft)
const bt=g.Gn,mt=t=>{},pt=()=>{p.removeEventListener("pointermove",mt),p.removeEventListener("pointerup",pt),p.removeEventListener("pointercancel",pt)},gt=t=>{t.button},wt=t=>{}
bt?.addEventListener("pointerdown",gt),bt?.addEventListener("keydown",wt),m=Math.max(20,Math.min(80,Math.round(m))),g.Kn.style.setProperty("--soeditor-classic-pane-ratio",m+"%"),g.Kn.style.setProperty("--soeditor-classic-pane-inverse-ratio",100-m+"%"),bt?.setAttribute("aria-valuenow",m+""),ot(R)
const vt=Object.freeze({get destroyed(){return M},get editor(){return kt()},element:g.root,host:t,get contentStylePreset(){return w},get maximized(){return _},get saveWorkflow(){return N},destroy:()=>St(),focus:()=>{It()
const t="source"===kt().services.get(so).snapshot.primary?g.source:g.Wn;(t.querySelector('[contenteditable="true"], textarea, input')??t).focus()},getData:()=>S?.getData()??R,maximize:(t=!_)=>{if(It(),!l&&t)throw new TypeError("This classic editor is not maximizable.")
Et(t)},openPreview:()=>(()=>{throw It(),Error("Classic popup preview is not enabled.")})(),setWorkspaceView:t=>(It(),Bt(t)),retrySave:()=>Ct().retry(),save:()=>Ct().save(),setData:t=>{It(),Rl(t,"Classic editor data")
const e=kt()
e.setData(t),ot(e.getData())},setContentStylePreset:t=>{It(),Rc(g.Wn,t),Rc(g.Yn,t),w=t},setReadonly:t=>{It(),kt().setReadonly(t)}})
function yt(){return vt}function kt(){if(void 0===S)throw Error("The classic editor has not finished initializing.")
return S}function Ct(){if(It(),void 0===N)throw Error("This classic editor has no configured save adapter.")
return N}function It(){if(M||void 0!==E)throw new P}function Et(t){if(_===t)return
_=t,g.root.classList.toggle("is-maximized",t)
const e=g.root.querySelector('[data-classic-action="maximize"]')
if(e?.setAttribute("aria-pressed",t+""),null!==e){const i=O?.translate(t?"Restore":"Maximize")??(t?"Restore":"Maximize")
void 0===O?e.textContent=i:O.setIcon(e,t?"editor.maximize.restore":"editor.maximize",i),e.title=O?.translate(t?"Restore editor size":"Maximize editor")??(t?"Restore editor size":"Maximize editor"),e.setAttribute("aria-label",O?.translate(t?"Restore editor size":"Maximize editor")??(t?"Restore editor size":"Maximize editor"))}t?((t,e)=>{let i=yl.get(t)
void 0===i&&(i={Ln:new Set,Pn:t.body.style.overflow},yl.set(t,i),t.body.style.overflow="hidden"),i.Ln.add(e)})(p,Q):((t,e)=>{const i=yl.get(t)
void 0!==i&&(i.Ln.delete(e),0===i.Ln.size&&(t.body.style.overflow=i.Pn,yl.delete(t)))})(p,Q)}function Bt(t){if("source"===t&&!h.has("source"))throw Error("HTML Source is not enabled.");(t=>{const e=kt(),i=e.services.get(so),o="single"===t?i.snapshot.primary:"wysiwyg"===t||"source"===t?t:void 0
if(void 0===o)throw new TypeError(`Unknown Classic workspace view "${t}".`)
if("wysiwyg"!==(s=o)&&"source"!==s||!h.has(o))throw Error(`Classic workspace view "${t}" requires disabled editing mode "${o}".`)
var s
if(!i.isAttached(o))throw Error(`Classic workspace view "${t}" is not attached.`)
i.get(o).visible||e.execute("projection.show",o),b=o,e.execute("projection.activate",o)
for(const r of["wysiwyg","source"]){if(!i.isAttached(r))continue
const t=i.get(r)
r!==o&&t.visible&&e.execute("projection.hide",r)}xt(),et()})(t)}function xt(){const t=g.Gn
return delete g.Kn.dataset.orientation,delete g.root.dataset.Vn,g.Kn.style.removeProperty("height"),void(void 0!==t&&(t.hidden=!0))}async function St(){if(void 0!==E)return E
const t=Dt()
return E=t,t}async function Dt(){M=!0
const e=[]
try{R=S?.getData()??R,void 0!==k&&(k.value=T?R:C??""),N?.destroy(),N=void 0,q?.(),q=void 0,j?.(),j=void 0,G?.(),G=void 0,K?.(),K=void 0,H?.(),H=void 0,Y?.(),Y=void 0,z?.(),z=void 0,Z?.(),Z=void 0,U?.(),U=void 0,J?.(),J=void 0,et=()=>{},V?.(),V=void 0,d?.destroy(),d=void 0,X?.destroy(),X=void 0,$?.close(),$=void 0,void 0!==x&&await x.destroy()}catch(i){e.push(i)}finally{Et(!1),M=!0,D?.(),D=void 0
const e=p.defaultView
void 0!==B&&null!==e&&e.cancelAnimationFrame(B),B=void 0,g.root.removeEventListener("focusin",rt),g.root.removeEventListener("focusout",nt),dt(),pt(),lt?.removeEventListener("pointerdown",ut),lt?.removeEventListener("keydown",ft),bt?.removeEventListener("pointerdown",gt),bt?.removeEventListener("keydown",wt),I?.removeEventListener("submit",at,!0),I?.removeEventListener("reset",ct),g.root.remove(),v?.remove(),t.hidden=y,vl.delete(t)}if(e.length>0)throw new AggregateError(e,"Classic editor cleanup failed.")}vl.set(t,vt)
try{return x=await(async t=>{let e
const i=[]
let o,s
const r=()=>{if(t.Xn())throw new P},n=()=>(s??=(async()=>{o?.(),o=void 0
const t=[]
for(const e of i.reverse())try{await e.destroy()}catch(s){t.push(s)}i.length=0
try{await(e?.destroy())}catch(s){t.push(s)}if(t.length>0)throw new AggregateError(t,"Classic host cleanup failed.")})(),s)
try{e=await t.$n(),r(),o=e.events.on("document:change",({current:e,previous:i,transaction:o})=>{t.onChange(Object.freeze({origin:o.origin,previousSource:i.source,source:e.source}))})
for(const o of t.attachments)r(),i.push(await o(e)),r()
return Object.freeze({editor:e,destroy:n})}catch(a){try{await n()}catch(c){throw new AggregateError([a,c],"Classic host initialization and cleanup failed.")}throw a}})({attachments:[t=>(t=>new Gc(t))({activateOnFocus:!0,ariaLabel:a,editor:t,element:g.Wn}),t=>(t=>{t.services.get(za)
const o=g.Wn
var s
O=(t=>{if(Va.has(t.element))throw new $a
const e=Ua(t.editor.services.get(za)),i=t.element.ownerDocument,o=(t=>{if(void 0===t)return new Map
if("object"!=typeof t||null===t||Array.isArray(t))throw new TypeError("Editor UI icons must be a plain object.")
const e=new Map
for(const[i,o]of Object.entries(t)){if(!/^[a-z][a-zA-Z0-9._-]{0,95}$/u.test(i))throw new TypeError(`Editor UI icon ID "${i}" is invalid.`)
e.set(i,ic(o,`icon "${i}"`,16))}return e})(t.icons),s=Qa(t.locale,t.translations,t.direction),r=i.createElement("div")
r.className="soeditor-ui__chrome",r.lang=s.locale,r.dir=s.direction
const n=i.createElement("div")
n.className="soeditor-ui__toolbar",n.setAttribute("role","toolbar"),n.setAttribute("aria-label","Editor toolbar")
const a=(t=>{const e=t?.overflow??"wrap"
if("wrap"!==e&&"scroll"!==e)throw new TypeError("Toolbar overflow must be wrap or scroll.")
for(const[i,o]of[["collapsible",t?.collapsible],["sticky",t?.sticky]])if(void 0!==o&&"boolean"!=typeof o)throw new TypeError(`Toolbar ${i} must be a boolean.`)
return Object.freeze({collapsible:t?.collapsible??!1,overflow:e,sticky:t?.sticky??!1})})(t.toolbarLayout)
n.dataset.overflow=a.overflow,n.dataset.ta="true",n.classList.toggle("is-sticky",a.sticky)
const c=i.createElement("div")
c.className="soeditor-ui__status-bar",c.setAttribute("role","status"),c.setAttribute("aria-live","polite")
const l=i.createElement("span")
l.className="soeditor-ui__status"
const A=i.createElement("span")
A.className="soeditor-ui__status-items"
const h=i.createElement("span")
h.className="soeditor-ui__document-status",h.hidden=!0!==t.documentStatus
const d=((t,e)=>{const i=t.createElement("span")
let o
i.className="soeditor-ui__element-path",i.dataset.ea="true",i.hidden=!0
let s=!1,r=""
const n=t.defaultView,a=()=>{if(o=void 0,s)return
const t=e().join(" › ")
t!==r&&(r=t,i.textContent=t,i.hidden=0===t.length)}
return{element:i,update(){s||void 0!==o||(null===n?a():o=n.requestAnimationFrame(a))},destroy(){s=!0,void 0!==o&&n?.cancelAnimationFrame(o),o=void 0,i.remove()}}})(i,()=>"wysiwyg"!==t.editor.state.mode?[]:(t=>{if(void 0===t)return[]
let e=t.commonAncestorContainer
if(!e.isConnected)return[]
t.collapsed||t.startContainer!==t.endContainer||t.endOffset!==t.startOffset+1||(e=t.startContainer.childNodes[t.startOffset]??e)
let i=1===e.nodeType?e:e.parentElement
const o=[]
for(;null!==i;){if(i.classList.contains("soeditor-wysiwyg-content"))return i.hasAttribute("hidden")?[]:o.reverse()
if(i.classList.contains("soeditor-image-resize-overlay"))return[]
o.push(i.localName),i=i.parentElement}return[]})(P.map(t=>Ac(t,i)).find(e=>void 0!==e&&rc(e.startContainer,t.element)&&rc(e.endContainer,t.element))))
d.element.hidden=!0,c.append(l,d.element,h,A)
const u=i.createElement("div")
u.className="soeditor-ui__panels"
const f=i.createElement("div")
f.className="soeditor-ui__notifications",f.setAttribute("role","log"),f.setAttribute("aria-live","polite"),f.setAttribute("aria-label","Editor notifications")
const b=i.createElement("div")
b.className="soeditor-ui__overlays",r.append(n,u,c,f,b)
const m=((t,e,i)=>{const o=new Set,s=new Map
let r=!1
const n=()=>{if(r)throw new _a},a=t=>{const e=t.composedPath()
for(const[i,o]of[...s])e.includes(i.element)||e.includes(o)||i.close()}
t.addEventListener("pointerdown",a,!0),t.addEventListener("focusin",a,!0)
const c=Object.freeze({show:e=>{n(),(t=>{if(0===t.message.length)throw new TypeError("A notification message must not be empty.")
if(void 0!==t.duration&&(!Number.isFinite(t.duration)||t.duration<0))throw new TypeError("Notification duration must be non-negative.")})(e)
const s=t.createElement("div")
s.className="soeditor-ui__notification",s.dataset.severity=e.severity??"info",s.textContent=e.message
const r=ja(()=>{clearTimeout(l),s.remove(),o.delete(a)}),a=Object.freeze({element:s,close:r}),c=e.duration??4e3,l=setTimeout(r,c)
return i.append(s),o.add(a),a}}),l=Object.freeze({open:i=>{n(),(t=>{if(0===t.title.length)throw new TypeError("A dialog title must not be empty.")
for(const e of t.actions??[])if(0===e.label.length||"function"!=typeof e.run)throw new TypeError("A dialog action requires a label and handler.")})(i)
const s=i.returnFocus??t.activeElement,a=t.createElement("dialog")
a.className="soeditor-ui__dialog",a.setAttribute("aria-label",i.title)
const l=t.createElement("h2")
l.className="soeditor-ui__dialog-title",l.textContent=i.title
const A=t.createElement("div")
A.className="soeditor-ui__dialog-body",qa(A,i.content)
const h=t.createElement("div")
h.className="soeditor-ui__dialog-actions"
const d=ja(()=>{a.open&&a.close(),a.remove(),o.delete(u)
const e=t.defaultView
!r&&null!==e&&s instanceof e.HTMLElement&&s.isConnected&&s.focus({Dn:!0})}),u=Object.freeze({element:a,close:d})
for(const e of i.actions??[]){const i=t.createElement("button")
i.type="button",i.className="soeditor-ui__dialog-action",i.classList.toggle("is-primary","primary"===e.kind),i.classList.toggle("is-danger","danger"===e.kind),i.textContent=e.label,i.addEventListener("click",()=>{try{const o=e.run(u);("object"==typeof(t=o)&&null!==t||"function"==typeof t)&&"function"==typeof Reflect.get(t,"then")&&(i.disabled=!0,Promise.resolve(o).then(()=>{i.disabled=!1},t=>{i.disabled=!1,r||c.show({message:Ga(t),severity:"error"})}))}catch(o){r||c.show({message:Ga(o),severity:"error"})}var t}),h.append(i)}const f=t.createElement("button")
f.type="button",f.className="soeditor-ui__dialog-action",f.textContent="Cancel",f.addEventListener("click",d),h.append(f),a.addEventListener("cancel",t=>{t.preventDefault(),d()}),a.append(l,A,h),e.append(a),o.add(u)
try{a.showModal()}catch(b){throw d(),b}return u}}),A=Object.freeze({show:i=>{if(n(),!i.anchor.isConnected)throw new TypeError("A balloon anchor must be connected.")
for(const[t]of[...s])t.element.contains(i.anchor)||t.close()
const r=t.createElement("div")
r.className="soeditor-ui__balloon",r.setAttribute("role","dialog"),qa(r,i.content)
const a=()=>{const e=i.anchor.getBoundingClientRect(),o=t.defaultView,s=o?.innerWidth??t.documentElement.clientWidth,n=o?.innerHeight??t.documentElement.clientHeight
r.style.boxSizing="border-box",r.style.maxHeight=Math.max(0,n-16)+"px",r.style.overflowY="visible",r.scrollHeight>r.clientHeight&&r.offsetHeight>=n-16&&(r.style.overflowY="auto")
const a=r.offsetWidth,c=r.offsetHeight,l=e.top-c-8,A=e.bottom+8,h="above"===i.placement?l>=8||A+c>n-8:A+c>n-8&&l>=8,d=h?l:A,u=e.left+e.width/2-a/2
let f=Math.max(8,Math.min(u,s-a-8)),b=Math.max(8,Math.min(d,n-c-8))
const m=i.avoid?.()??[]
if(m.length>0){const t=(t,e)=>[Math.max(8,Math.min(t,s-a-8)),Math.max(8,Math.min(e,n-c-8))],e=[[f,b],t(u,h?A:l)]
for(const o of m)e.push(t(f,o.top-c-8),t(f,o.bottom+8),t(o.left-a-8,b),t(o.right+8,b))
let i=1/0
for(const[o,s]of e){const t=m.reduce((t,e)=>t+Math.max(0,Math.min(o+a,e.right)-Math.max(o,e.left))*Math.max(0,Math.min(s+c,e.bottom)-Math.max(s,e.top)),0)
if(t<i&&(i=t,f=o,b=s),0===i)break}}r.dataset.placement=h?"above":"below",r.style.left=f+"px",r.style.top=b+"px"},c=t.defaultView,l=c?.ResizeObserver?new c.ResizeObserver(a):void 0,A=ja(()=>{l?.disconnect(),c?.removeEventListener("resize",a),c?.removeEventListener("pointerup",a,!0),c?.removeEventListener("keyup",a,!0),c?.removeEventListener("scroll",a,!0),r.remove(),o.delete(h),s.delete(h),i.anchor.hasAttribute("aria-expanded")&&i.anchor.setAttribute("aria-expanded","false")}),h=Object.freeze({element:r,close:A})
return r.addEventListener("keydown",t=>{"Escape"===t.key&&(t.preventDefault(),t.stopPropagation(),A(),i.anchor instanceof HTMLElement&&i.anchor.isConnected&&i.anchor.focus({Dn:!0}))}),e.append(r),l?.observe(r),l?.observe(i.anchor),c?.addEventListener("resize",a),c?.addEventListener("pointerup",a,!0),c?.addEventListener("keyup",a,!0),c?.addEventListener("scroll",a,!0),a(),o.add(h),s.set(h,i.anchor),h}})
return Object.freeze({balloons:A,dialogs:l,notifications:c,destroy:()=>{if(!r){r=!0,t.removeEventListener("pointerdown",a,!0),t.removeEventListener("focusin",a,!0)
for(const t of[...o])t.close()}}})})(i,b,f),p=((t,e)=>{let i,o=!1
const s=Object.freeze({show:s=>{if(o)throw new _a
if("string"!=typeof s.title||0===s.title.trim().length)throw new TypeError("A panel title must not be empty.")
i?.close()
const r=t.createElement("section")
r.className="soeditor-ui__panel",r.setAttribute("role","region"),r.setAttribute("aria-label",s.title)
const n=t.createElement("header")
n.className="soeditor-ui__panel-header"
const a=t.createElement("h2")
a.className="soeditor-ui__panel-title",a.textContent=s.title
const c=t.createElement("button")
c.type="button",c.className="soeditor-ui__panel-close",c.textContent="Close",c.setAttribute("aria-label","Close "+s.title)
const l=t.createElement("div")
var A,h
l.className="soeditor-ui__panel-body",A=l,void 0!==(h=s.content)&&("string"==typeof h?A.textContent=h:"function"==typeof h?h(A):A.append(h))
let d=!0
const u=Object.freeze({element:r,close:()=>{d&&(d=!1,r.remove(),i===u&&(i=void 0))}})
return c.addEventListener("click",u.close),n.append(a,c),r.append(n,l),e.append(r),i=u,u}})
return Object.freeze({panels:s,destroy:()=>{o||(o=!0,i?.close())}})})(i,u),g=[]
let w
const v=[]
let y,k,C,I,E,B,x,S,D,M,T,R,F=!1,_=[],Q=!1,O=bc(t.theme??"auto"),N=!0
const q=t.element.classList.contains("soeditor-ui"),j=t.element.getAttribute("data-soeditor-theme"),G=new Map,H=Object.freeze({open:t=>{nt()
const e=t.actions?.map(t=>({...t,run:e=>{rt()
try{const i=t.run(e)
return mc(i)?Promise.resolve(i).finally(()=>{e.element.isConnected&&nt()}):(e.element.isConnected&&nt(),i)}catch(i){throw e.element.isConnected&&nt(),i}}})),i=m.dialogs.open({...t,...void 0===e?{}:{actions:e}})
return ct(),i}}),K=Object.freeze({show:t=>m.balloons.show(t)}),Y=Object.freeze({balloons:K,dialogs:H,element:t.element,direction:s.direction,locale:s.locale,notifications:m.notifications,panels:p.panels,statusElement:l,toolbarElement:n,get toolbarExpanded(){return N},get theme(){return O},get destroyed(){return Q},destroy:()=>ot(),icon:(t,e)=>((t,e,i)=>{if(!/^[a-z][a-zA-Z0-9._-]{0,95}$/u.test(e))throw new TypeError(`Editor UI icon ID "${e}" is invalid.`)
return t.get(e)??ic(i,"icon fallback",128)})(o,t,e),setIcon:(t,e,s)=>{const r=o.get(e)
t.replaceChildren(((t,e,i)=>{const o=Pa[e]??{text:i},s=t.createElementNS(Ja,"svg")
s.classList.add("soeditor-ui__icon"),"solid"===o.variant&&s.classList.add("soeditor-ui__icon--solid"),s.setAttribute("viewBox",o.viewBox??"0 0 24 24"),s.setAttribute("aria-hidden","true"),s.setAttribute("focusable","false")
for(const r of o.Xr??[]){const e=t.createElementNS(Ja,"path")
e.setAttribute("d",r),s.append(e)}if(void 0!==o.text){const e=t.createElementNS(Ja,"text")
e.setAttribute("x","12"),e.setAttribute("y","12"),e.textContent=o.text,s.append(e)}return s})(i,void 0===r?e:"",r??ic(s,"icon fallback",128)))},getEditingSelectionText:()=>(st(),k?.toString()??""),getEditingFormatState:e=>{if(st(),void 0!==t.readFormatStates)return k?.startContainer.isConnected&&k.endContainer.isConnected?(C??=t.readFormatStates?.()??{},C[e]??{status:"unavailable"}):{status:"unavailable"}},refresh:()=>W(),restoreEditingSelection:()=>rt(),setToolbarExpanded:t=>{if(st(),"boolean"!=typeof t)throw new TypeError("Toolbar expanded state must be a boolean.")
if(!a.collapsible&&!t)throw new TypeError("This editor toolbar is not collapsible.")
N=t,n.dataset.ta=t+"",S?.setAttribute("aria-expanded",t+""),S?.setAttribute("aria-label",s.translate(t?"Collapse editor toolbar":"Expand editor toolbar"))},setStatus:t=>{st(),I=t,At()},setTheme:e=>{st(),O=bc(e),t.element.dataset.ia=O},setThemeVariables:e=>{st(),oc(t.element,ec(e),G)},translate:t=>s.translate(t)}),W=()=>{if(!Q){C=void 0
for(const e of g)try{e.update?.()}catch(t){ht(t)}for(const e of v)try{e.update?.()}catch(t){ht(t)}for(const t of Array.from(n.querySelectorAll('summary[aria-disabled="true"]'))){const e=t.closest("details")
e&&(e.open=!1)}(t=>{const e=uc(t),i=e.find(e=>e===t.ownerDocument.activeElement)
for(const o of e)o.tabIndex=-1;(i??e[0])?.setAttribute("tabindex","0")})(n),At()}},z=o=>{if("Escape"===o.key){const e=Array.from(t.element.querySelectorAll("details.soeditor-ui__menu[open]")).at(-1)
if(void 0!==e)return o.preventDefault(),e.open=!1,void e.querySelector("summary")?.focus()}const s=o.composedPath().find(e=>e instanceof Element&&rc(e,t.element))
if(o.shiftKey&&"F10"===o.key&&void 0!==s){o.preventDefault(),o.stopPropagation(),rt()
const e=ac(s,i)?.anchorNode,r=1===e?.nodeType?e:e?.parentElement,n=null!=r&&nc(t.element,r)?r:void 0,a=void 0!==n&&n!==hc(n)?n:!0===T?.isConnected&&nc(t.element,T)?T:s
if(a===T){const t=i.createRange()
t.selectNodeContents(a)
const e=ac(a,i)
hc(a)?.focus({Dn:!0}),e?.removeAllRanges(),e?.addRange(t),y=cc(a,i)}return void a.dispatchEvent(new MouseEvent("contextmenu",{bubbles:!0,cancelable:!0,composed:!0,view:i.defaultView}))}if(!((t,e)=>{const i=t.target
if(!(i instanceof HTMLElement&&e.contains(i)))return!1
if(((t,e)=>{const i=t.target
if(!(i instanceof HTMLElement&&e.contains(i)))return!1
if(i.matches('input,textarea,select,[contenteditable="true"]'))return!1
const o=i.closest("details.soeditor-ui__menu")
if(!o)return!1
if("SUMMARY"===i.tagName?!["ArrowDown","ArrowUp"].includes(t.key):!["ArrowDown","ArrowUp","ArrowLeft","ArrowRight","Home","End"].includes(t.key))return!1
if("true"===o.querySelector("summary")?.getAttribute("aria-disabled"))return!1
o.open=!0
const s=Array.from(o.querySelectorAll("button:not(:disabled)")).filter(t=>!t.closest("[hidden]")),r=s.indexOf(i),n="ArrowDown"===t.key||"ArrowUp"===t.key,a=i.parentElement?e.ownerDocument.defaultView?.getComputedStyle(i.parentElement).gridTemplateColumns.split(" ").length??1:1,c=n?a:1,l="Home"===t.key?0:"End"===t.key?s.length-1:r<0?"ArrowUp"===t.key?s.length-1:0:(r+(["ArrowUp","ArrowLeft"].includes(t.key)?-c:c)+s.length)%s.length
return t.preventDefault(),t.stopPropagation(),s[l]?.focus(),!0})(t,e))return!0
const o=uc(e),s=o.indexOf(i)
if(s<0)return!1
let r
if("ArrowRight"===t.key||"ArrowDown"===t.key?r=(s+1)%o.length:"ArrowLeft"===t.key||"ArrowUp"===t.key?r=(s-1+o.length)%o.length:"Home"===t.key?r=0:"End"===t.key&&(r=o.length-1),void 0===r)return!1
t.preventDefault(),t.stopPropagation()
for(const a of o)a.tabIndex=-1
const n=o[r]
return void 0!==n&&(n.tabIndex=0,n.focus()),!0})(o,n))for(const i of e.yn.values())if(Ka(i.En,o)){if(!t.editor.commands.has(i.command)||!t.editor.commands.canExecute(i.command))return
o.preventDefault(),o.stopPropagation()
try{rt()
const e=t.editor.execute(i.command,...i.args??[])
mc(e)&&Promise.resolve(e).catch(ht)}catch(r){ht(r)}return}},Z=e=>{const o=e.composedPath(),s="pointerdown"===e.type&&!o.some(t=>t instanceof Element&&t.matches('a[href],button,input,select,summary,textarea,[contenteditable="true"],[tabindex]:not([tabindex="-1"])'))
let r=!1
for(const n of Array.from(t.element.querySelectorAll("details.soeditor-ui__menu[open]")))o.includes(n)||(r||=s&&n.contains(dc(i)),n.open=!1)
r&&i.defaultView?.setTimeout(()=>rt(),0)},U=t.editor.events.on("state:change",W),J=t.editor.events.on("command:afterExecute",W),L=t.editor.events.on("editor:destroy",()=>ot()),P=((t,e)=>{const i=[e]
for(const o of[t,...Array.from(t.querySelectorAll("*"))])null!==o.shadowRoot&&i.push(o.shadowRoot)
return Object.freeze(i)})(t.element,i),V=()=>{if(F)return
const e=dc(i)
if(void 0!==y&&null!==e&&r.contains(e)&&!rc(e,t.element))return
const o=P.map(t=>Ac(t,i)).find(e=>{const i=e?.startContainer,o=e?.endContainer
return null!=i&&null!=o&&rc(i,t.element)&&rc(o,t.element)}),s=o?.startContainer,n=o?.endContainer
if(void 0===o||null==s||null==n||!rc(s,t.element)||!rc(n,t.element))return y=void 0,k=void 0,void W()
y=Object.freeze({anchor:s,anchorOffset:o.startOffset,focus:n,focusOffset:o.endOffset}),k=o.cloneRange(),W()},X=e=>{const i=e.composedPath(),o=i.includes(r),s=i.some(e=>e instanceof Element&&rc(e,t.element))
o&&!s?nt():s?at():lt()},$=e=>{if(0!==e.button)return
const i=e.composedPath()
i.includes(r)?nt():i.some(e=>e instanceof Element&&rc(e,t.element))?at():lt()},tt=()=>{F&&ct()},et=t=>{if(0!==t.button)return
const e=t.composedPath().find(t=>t instanceof Element&&t.matches("button,summary"))
void 0!==e&&null!==e.closest("[data-toolbar-item]")&&n.contains(e)&&t.preventDefault()},it=o=>{const r=o.composedPath().find(e=>e instanceof Element&&rc(e,t.element))
if(void 0===r)return
const n=2!==o.button&&r===hc(r)&&!0===T?.isConnected?T:r
if(n===T&&r!==n){const t=i.createRange()
t.selectNodeContents(n)
const e=ac(n,i)
hc(n)?.focus({Dn:!0}),e?.removeAllRanges(),e?.addRange(t),y=cc(n,i)}const a=[...e.vn.entries()].filter(([,e])=>{try{return!(!t.editor.commands.has(e.command)||!t.editor.commands.canExecute(e.command))&&(e.when?.({document:i,editor:t.editor,target:n,ui:Y})??!0)}catch(o){return ht(o),!1}})
if(0===a.length)return
o.preventDefault(),M?.close(),T=n
const c=y??cc(n,i),l=i.createElement("div")
l.className="soeditor-ui__context-menu",l.setAttribute("role","menu"),l.setAttribute("aria-label","Editor context menu")
const A=[]
let h
for(const[e,d]of a){const o=d.group??"default"
if(void 0!==h&&o!==h){const t=i.createElement("div")
t.className="soeditor-ui__context-menu-separator",t.setAttribute("role","separator"),l.append(t)}h=o
const r=i.createElement("button")
r.type="button",r.className="soeditor-ui__menu-item",r.dataset.oa=e,r.dataset.sa=o,"danger"===d.tone&&(r.dataset.tone="danger"),r.setAttribute("role","menuitem"),r.textContent=s.translate(d.label),r.addEventListener("click",()=>{rt()
try{const e=t.editor.execute(d.command,...d.args??[])
mc(e)&&Promise.resolve(e).catch(ht)}catch(e){ht(e)}M?.close(),M=void 0}),l.append(r),A.push(r)}l.addEventListener("keydown",t=>{const e=A.indexOf(i.activeElement)
let o
if("ArrowDown"===t.key||"ArrowRight"===t.key)o=(Math.max(e,0)+1)%A.length
else if("ArrowUp"===t.key||"ArrowLeft"===t.key)o=(Math.max(e,0)-1+A.length)%A.length
else if("Home"===t.key)o=0
else if("End"===t.key)o=A.length-1
else if("Escape"===t.key){t.preventDefault(),t.stopPropagation(),M?.close(),M=void 0
const e=()=>{void 0!==c&&(y=c),rt()||hc(n)?.focus({Dn:!0})}
return e(),void i.defaultView?.setTimeout(e,0)}void 0!==o&&(t.preventDefault(),A[o]?.focus())}),M=m.balloons.show({anchor:n,content:l}),M.element.classList.add("soeditor-ui__context-balloon"),l.querySelector("button")?.focus()},ot=()=>{if(Q)return
Q=!0,clearTimeout(B),B=void 0,E=void 0,x=void 0,w?.()
const e=[]
t.element.removeEventListener("keydown",z,!0),t.element.removeEventListener("contextmenu",it),n.removeEventListener("pointerdown",et,!0),i.removeEventListener("pointerdown",Z,!0),i.removeEventListener("pointerdown",$,!0),i.removeEventListener("focusin",Z,!0),i.removeEventListener("focusin",X,!0),i.removeEventListener("scroll",tt,!0),i.defaultView?.removeEventListener("resize",tt)
for(const t of P)t.removeEventListener("selectionchange",V)
if(d.destroy(),R?.disconnect(),R=void 0,E=void 0,x=void 0,lt(),U(),J(),L(),sc(e,()=>(t=>{const e=[]
for(const o of[...t].reverse())try{o.destroy?.()}catch(i){e.push(i)}if(e.length>0)throw new AggregateError(e,"Toolbar item cleanup failed.")})(g)),sc(e,()=>(t=>{const e=[]
for(const o of[...t].reverse())try{o.destroy?.()}catch(i){e.push(i)}finally{o.element.remove()}if(e.length>0)throw new AggregateError(e,"Status item cleanup failed.")})(v)),sc(e,()=>m.destroy()),sc(e,()=>p.destroy()),r.remove(),q||t.element.classList.remove("soeditor-ui"),null===j?t.element.removeAttribute("data-soeditor-theme"):t.element.setAttribute("data-soeditor-theme",j),((t,e)=>{for(const[i,o]of e)0===o.value.length?t.style.removeProperty(i):t.style.setProperty(i,o.value,o.priority)})(t.element,G),Va.delete(t.element),e.length>0)throw new AggregateError(e,"Editor UI cleanup failed.")},st=()=>{if(Q)throw new _a}
function rt(){F=!1,lt()
const e=y
if(!(void 0!==e&&e.anchor.isConnected&&e.focus.isConnected&&nc(t.element,e.anchor)&&nc(t.element,e.focus)))return!1
try{hc(e.anchor)?.focus({Dn:!0})
const t=ac(e.anchor,i)
if(t?.setBaseAndExtent(e.anchor,e.anchorOffset,e.focus,e.focusOffset),t?.anchorNode!==e.anchor||t.anchorOffset!==e.anchorOffset||t.focusNode!==e.focus||t.focusOffset!==e.focusOffset){const e=k
if(void 0===e||!e.startContainer.isConnected||!e.endContainer.isConnected)return!1
t?.removeAllRanges(),t?.addRange(e.cloneRange())}return null!=t}catch{return y=void 0,!1}}function nt(){F||(V(),F=!0),ct()}function at(){F=!1,lt()}function ct(){lt()
const t=k
if(void 0!==t&&!t.collapsed&&t.startContainer.isConnected&&t.endContainer.isConnected)try{const e=t.commonAncestorContainer.getRootNode(),o=e instanceof ShadowRoot?e:i.body
_=Array.from(t.getClientRects(),t=>{const e=i.createElement("span")
return e.dataset.ra="true",e.setAttribute("aria-hidden","true"),e.style.position="fixed",e.style.pointerEvents="none",e.style.zIndex="1",e.style.left=t.left+"px",e.style.top=t.top+"px",e.style.width=t.width+"px",e.style.height=t.height+"px",e.style.background="Highlight",e.style.opacity="0.42",e.style.mixBlendMode="multiply",o.append(e),e})}catch{lt()}}function lt(){for(const t of _)t.remove()
_=[]}const At=()=>{var e
if(l.textContent=I??`${s.translate((e=t.editor.state.mode,0===e.length?e:`${e[0]?.toUpperCase()??""}${e.slice(1)}`))} · ${s.translate(t.editor.state.dirty?"Unsaved":"Saved")}`,!0===t.documentStatus){d.update()
const e=t.editor.getData()
void 0===x?(x=On(i,e),E=e):E!==e&&void 0===B&&(B=setTimeout(()=>{if(B=void 0,Q)return
const e=t.editor.getData()
E!==e&&(x=On(i,e),E=e),At()},100))
const o=((t,e)=>{const{Fr:i,Nr:o,Or:s}=t
return Object.freeze({Fr:i,text:`${s+""} ${e("words")} · ${i+""} ${e("characters")} · ${o+""} ${e("source characters")}`,Nr:o,Or:s})})(x,s.translate)
h.textContent=o.text,h.dataset.Or=o.Or+"",h.dataset.Fr=o.Fr+"",h.dataset.Nr=o.Nr+"",h.dataset.na=t.editor.state.mode}},ht=t=>{Q||m.notifications.show({message:t instanceof Error?t.message:t+"",severity:"error"})}
try{((t,e,i,o,s)=>{let r=!0
for(const n of t){if("|"===n){if(r)throw new TypeError("Toolbar separators must appear between toolbar items.")
const t=o.document.createElement("span")
t.className="soeditor-ui__separator",t.setAttribute("role","separator"),e.append(t),r=!0
continue}if("string"!=typeof n||0===n.trim().length)throw new TypeError("A toolbar item ID must not be empty.")
const t=i.get(n)
if(void 0===t)throw new Xa(n)
const a=t(o)
if("object"!=typeof a||null===a||a.element.ownerDocument!==o.document)throw new TypeError(`Toolbar item "${n}" returned an invalid element.`)
a.element.dataset.Jr=n,e.append(a.element),s.push(a),r=!1}if(r&&t.length>0)throw new TypeError("A toolbar must not end with a separator.")})(t.toolbar??Yn,n,e.In,{document:i,editor:t.editor,ui:Y},g),w=(t=>{const e=t.ownerDocument,i=()=>Array.from(t.querySelectorAll("details.soeditor-ui__menu")),o=t=>{t.querySelector("summary")?.setAttribute("aria-expanded",t.open+"")
const i=t.querySelector(":scope > .soeditor-ui__menu-items, :scope > .soeditor-ui__color-panel")
if(!i)return
if(!t.open)return void(i.matches(":popover-open")&&i.hidePopover())
const o=t.getBoundingClientRect()
"function"==typeof i.showPopover&&(i.setAttribute("popover","manual"),i.style.position="fixed",i.style.inset="auto",i.style.margin="0",i.style.left=o.left+"px",i.style.top=o.bottom+"px",i.matches(":popover-open")||i.showPopover())
const s=i.offsetWidth>0?i.getBoundingClientRect().width/i.offsetWidth:1
i.matches(":popover-open")&&(i.style.left=o.left/s+"px",i.style.top=o.bottom/s+"px")
const r=e.documentElement.clientWidth,n=e.documentElement.clientHeight
i.style.transform="",i.style.boxSizing="border-box",i.style.maxInlineSize=Math.max(0,r-16)/s+"px",i.style.overflowY="auto"
const a=Math.max(0,n-o.bottom-12),c=Math.max(0,o.top-12),l=(i.scrollHeight+i.offsetHeight-i.clientHeight)*s>a&&c>a
i.style.maxBlockSize=Math.max(0,Math.min(n-16,l?c:a))/s+"px"
const A=i.getBoundingClientRect(),h=Math.max(8-A.left,Math.min(0,r-8-A.right)),d=l?o.top-4-A.height:o.bottom+4,u=Math.max(8,Math.min(n-8-A.height,d))-A.top
i.style.transform=`translate(${h/s}px, ${u/s}px)`,i.dataset.placement=l?"above":"below"},s=t=>{const e=t.target
if(e instanceof HTMLDetailsElement&&e.matches(".soeditor-ui__menu")){if(e.open)for(const t of i())t!==e&&(t.open=!1)
o(e)}},r=t=>{if(!(t.target instanceof Element&&t.target.closest(".soeditor-ui__menu-items, .soeditor-ui__color-panel")))for(const e of i())e.open&&o(e)},n=t=>{t.target instanceof Element&&t.target.closest('summary[aria-disabled="true"]')&&t.preventDefault()},a=e.defaultView?.ResizeObserver,c=a?new a(()=>{for(const t of i())t.open&&o(t)}):void 0
for(const l of i()){c?.observe(l)
const t=l.querySelector(":scope > .soeditor-ui__menu-items, :scope > .soeditor-ui__color-panel")
t&&c?.observe(t)
const i=l.querySelector("summary")
if(i&&!i.matches(".soeditor-ui__value-control")&&!i.querySelector(".soeditor-ui__format-arrow")){const t=e.createElement("span")
t.className="soeditor-ui__format-arrow",t.setAttribute("aria-hidden","true"),t.textContent="▾",i.append(t)}o(l)}return t.addEventListener("toggle",s,!0),t.addEventListener("click",n,!0),e.addEventListener("scroll",r,!0),e.defaultView?.addEventListener("resize",r),()=>{c?.disconnect(),t.removeEventListener("toggle",s,!0),t.removeEventListener("click",n,!0),e.removeEventListener("scroll",r,!0),e.defaultView?.removeEventListener("resize",r)}})(n),S=a.collapsible?((t,e)=>{const i=t.createElement("button")
return i.type="button",i.className="soeditor-ui__button soeditor-ui__toolbar-toggle",e.setIcon(i,"ui.toolbar.toggle","Toolbar"),i.setAttribute("aria-expanded","true"),i.setAttribute("aria-label","Collapse editor toolbar"),i.title="Show or hide editor toolbar",i.addEventListener("click",()=>{e.setToolbarExpanded(!e.toolbarExpanded)}),i})(i,Y):void 0,void 0!==S&&n.append(S),D=t.accessibilityHelp?((t,e)=>{const i=t.createElement("button")
return i.type="button",i.className="soeditor-ui__button soeditor-ui__help-button",e.setIcon(i,"ui.accessibility.help","Help"),i.title="Accessibility help",i.setAttribute("aria-label","Accessibility help"),i.addEventListener("click",()=>{e.dialogs.open({title:"Accessibility help",content:e=>{const i=t.createElement("p")
i.textContent="Use Tab to enter controls and Arrow keys to move within toolbars and menus."
const o=t.createElement("ul")
for(const s of["Bold: Control or Command plus B","Italic: Control or Command plus I","New paragraph: Enter","Line break without a new paragraph: Shift plus Enter","Undo: Control or Command plus Z","Redo: Control or Command plus Shift plus Z","Select multiple table cells: Shift plus click another cell","Context menu: Shift plus F10","Close a dialog or menu: Escape"]){const e=t.createElement("li")
e.textContent=s,o.append(e)}e.append(i,o)}})}),i})(i,Y):void 0,void 0!==D&&n.append(D),((t,e,i,o)=>{for(const[s,r]of e){const e=r(i)
if("object"!=typeof e||null===e||e.element.ownerDocument!==i.document)throw new TypeError(`Status item "${s}" returned an invalid element.`)
e.element.dataset.aa=s,t.append(e.element),o.push(e)}})(A,e.Cn,{document:i,editor:t.editor,ui:Y},v),t.element.classList.add("soeditor-ui"),t.element.dataset.ia=O,oc(t.element,ec(t.themeVariables),G),t.element.prepend(r),fc(r,s.translate)
const o=i.defaultView?.MutationObserver
void 0!==o&&(R=new o(t=>{for(const e of t){("characterData"===e.type||"attributes"===e.type)&&fc(e.target,s.translate)
for(const t of Array.from(e.addedNodes))fc(t,s.translate)}}),R.observe(r,{attributeFilter:["aria-label","placeholder","title"],attributes:!0,characterData:!0,childList:!0,subtree:!0})),t.element.addEventListener("keydown",z,!0),t.element.addEventListener("contextmenu",it),n.addEventListener("pointerdown",et,!0),i.addEventListener("pointerdown",$,!0),i.addEventListener("pointerdown",Z,!0),i.addEventListener("focusin",Z,!0),i.addEventListener("focusin",X,!0),i.addEventListener("scroll",tt,!0),i.defaultView?.addEventListener("resize",tt)
for(const t of P)t.addEventListener("selectionchange",V)
return Va.set(t.element,Y),W(),Y}catch(dt){throw ot(),dt}})({readFormatStates:()=>t.services.tryGet(Qo)?.getFormatStates?.()??{},accessibilityHelp:!0,documentStatus:!0,direction:n.direction,editor:t,element:g.root,...void 0===e.icons?{}:{icons:e.icons},locale:n.locale,...void 0===e.theme?{}:{theme:e.theme},themeVariables:{en:"1.875rem",...e.themeVariables},toolbar:xl(e.toolbar??(s=i.toolbar,s)),toolbarLayout:e.toolbarLayout??{collapsible:!0,overflow:"wrap",sticky:!0},translations:r})
const a=O.statusElement.closest(".soeditor-ui__status-bar")
null!==a&&g.Kn.after(a),G=((t,e,i)=>{let o,s,r=!1,n=!1
const a=c=>{if(void 0!==o||0!==c.button)return
const l=c.target
if(l instanceof Element&&null!==l.closest("img"))return
const A=l instanceof Element?l.closest('a[data-soeditor-link="true"], a[href]'):null
null!==A&&i.contains(A)&&(c.preventDefault(),s={event:c,link:A},n||(n=!0,Promise.resolve().then(()=>Ol).then(n=>{if(r)return
i.removeEventListener("click",a),o=n.ca(t,e,i)
const c=s
s=void 0,void 0!==c&&c.link.dispatchEvent(new MouseEvent("click",{bubbles:!0,button:c.event.button,ctrlKey:c.event.ctrlKey,metaKey:c.event.metaKey}))}).catch(()=>{r||(n=!1,i.addEventListener("click",a),e.notifications.show({message:"Link tools failed to load. Please try again.",severity:"error"}))})))}
return i.addEventListener("click",a),()=>{r=!0,i.removeEventListener("click",a),o?.()}})(t,O,o),H=((t,e)=>El(t,e,["soeditor:image-activate","soeditor:image-select"],()=>Promise.resolve().then(()=>Ql).then(i=>o=>i.la(t,e,o))))(O,o)
const c=O
K=El(O,o,["soeditor:image-select","soeditor:table-selection","soeditor:block-hover"],()=>Promise.resolve().then(()=>_l).then(t=>e=>t.Aa(c,o,e))),z=t.services.tryGet(Do)?.subscribe(t=>{O?.notifications.show({message:"Paste was not applied: "+t.message,severity:"error"})})
const A=t=>{const e=Reflect.get(t,"detail")
if("object"!=typeof e||null===e)return
const i=Reflect.get(e,"message"),o=Reflect.get(e,"severity")
"string"==typeof i&&0!==i.length&&O?.notifications.show({message:i,severity:"error"===o?"error":"warning"})}
if(o.addEventListener("soeditor:editing-feedback",A),Z=()=>o.removeEventListener("soeditor:editing-feedback",A),(t=>{const e=t.services.tryGet(so)
if(void 0===e)return
if(t.commands.register({id:"classic.workspace.set",execute:(t,e)=>{if("single"!==(i=e)&&"wysiwyg"!==i&&"source"!==i&&"wysiwyg-source-horizontal"!==i&&"wysiwyg-source-vertical"!==i)throw new TypeError(`Unknown Classic workspace view "${e+""}".`)
var i
return Bt(e)}}),!h.has("source"))return
const i=[["wysiwyg","WYSIWYG"],["source","Source"],["wysiwyg-source-horizontal","WYSIWYG + Source (side by side)"],["wysiwyg-source-vertical","WYSIWYG + Source (stacked)"]],o=p.createElement("div")
o.className="soeditor-classic__workspace-picker",o.dataset.ha="workspace-view",o.setAttribute("role","group"),o.setAttribute("aria-label",O?.translate("Editing view")??"Editing view")
const s={da:"editor.visual",source:"editor.source",ua:"editor.visual","wysiwyg-source-horizontal":"editor.view.sideBySide","wysiwyg-source-vertical":"editor.view.stacked"},r=new Map
for(const[a,c]of i){const e=p.createElement("button"),i=O?.translate(c)??c
e.type="button",e.className="soeditor-ui__button",e.dataset.fa=a,e.title=i,e.setAttribute("aria-label",i),e.setAttribute("aria-pressed","false"),O?.setIcon(e,s[a],i),e.addEventListener("click",()=>{Promise.resolve(t.execute("classic.workspace.set",a)).catch(()=>{})}),r.set(a,e),o.append(e)}O?.toolbarElement.append(o)
const n=()=>{const t=e.snapshot.activities.filter(t=>t.visible&&e.isAttached(t.id))
g.root.dataset.ba=t.length+"",g.root.dataset.ma=t.map(t=>t.id).join(" ")
const i=new Set(t.map(t=>t.id))
h.has("wysiwyg")&&(g.Yn.hidden=!i.has("wysiwyg")),h.has("source")&&(g.source.hidden=!i.has("source"))
for(const[e,o]of r){const t=e===b
o.setAttribute("aria-pressed",t+""),o.classList.toggle("is-active",t)}g.root.dataset.pa=b,xt()}
et=n,n(),J=e.subscribe(n),O?.refresh()})(t),g.root.dataset.ga=t.state.mode,U=t.events.on("mode:change",()=>{if(g.root.dataset.ga=t.state.mode,h.has("source")){const e="source"===t.state.mode?"source":"wysiwyg",i=t.services.get(so).snapshot.activities.filter(t=>t.visible)
1===i.length&&i[0]?.id===e||Promise.resolve(Bt(e)).catch(()=>{})}}),g.Hn?.setAttribute("aria-label",O.translate("Resize editor height")),l){const t=p.createElement("button")
t.type="button",t.className="soeditor-ui__button",t.dataset.ha="maximize",O.setIcon(t,"editor.maximize",O.translate("Maximize")),t.title=O.translate("Maximize editor"),t.setAttribute("aria-label",O.translate("Maximize editor")),t.setAttribute("aria-pressed","false"),t.addEventListener("click",()=>Et(!_)),O.toolbarElement.append(t),O.refresh()}return(t=>{const e=t.querySelector(".soeditor-ui__toolbar-toggle")
null!==e&&(e.hidden=!0,e.tabIndex=-1)
const i=t.ownerDocument.createElement("div")
i.className="soeditor-classic__toolbar-end",i.setAttribute("role","group"),i.setAttribute("aria-label","Editor views and preview")
const o=t.querySelector('[data-toolbar-item="popupPreview"]')
!0===o?.previousElementSibling?.classList.contains("soeditor-ui__separator")&&o.previousElementSibling.remove()
for(const s of['[data-toolbar-item="popupPreview"]',".soeditor-ui__help-button",'[data-classic-action="workspace-view"]','[data-classic-action="maximize"]']){const e=t.querySelector(s)
null!==e&&i.append(e)}i.childElementCount>0&&t.append(i)})(O.toolbarElement),O})(t)],$n:()=>W.create({...void 0===e.config?{}:{config:e.config},data:R,format:"html",plugins:u,readonly:e.readonly??(!0===k?.readOnly||!0===k?.disabled)}),Xn:()=>M,onChange:t=>{ot(t.source),e.onChange?.(t)}}),S=x.editor,S.services.get(so).get(f).visible||S.execute("projection.show",f),S.execute("projection.activate",f),D=S.events.on("editor:destroy",()=>{M||void 0!==E||globalThis.queueMicrotask(()=>{St().catch(st)})}),ot(S.getData()),e.onReady?.(vt),T=!0,vt}catch(Mt){const t=st(Mt)
try{await Dt()}catch(Tt){throw new AggregateError([Mt,...void 0===t?[]:[t],Tt],"Classic editor initialization and cleanup failed.")}if(void 0!==t)throw new AggregateError([Mt,t],"Classic editor initialization and error reporting failed.")
throw Mt}}},Symbol.toStringTag,{value:"Module"}))
Symbol.toStringTag
const _l=Object.freeze(Object.defineProperty({__proto__:null,Aa:(t,e,i)=>{const o=e.ownerDocument,s=o.defaultView,r=e.getRootNode()
let n,a,c,l
const A=()=>{n?.remove(),n=void 0,a=void 0,c=void 0,u?.disconnect(),f?.disconnect(),void 0!==l&&s?.cancelAnimationFrame(l),l=void 0},h=()=>{if(l=void 0,!0!==a?.isConnected||!e.isContentEditable||0===e.getClientRects().length)return void A()
if(void 0===n)return
const i=a.getBoundingClientRect(),o=c?.getBoundingClientRect()??i,s=void 0!==c&&"FIGURE"===a.tagName?Math.max(o.bottom,a.querySelector("figcaption")?.getBoundingClientRect().bottom??o.bottom):o.bottom,r=n.offsetParent instanceof HTMLElement?n.offsetParent:t.element,h=r.getBoundingClientRect()
n.style.left=o.left-h.left-r.clientLeft+r.scrollLeft+"px",n.style.top=o.top-h.top-r.clientTop+r.scrollTop+"px",n.style.width=o.width+"px",n.style.height=s-o.top+"px",n.style.setProperty("--soeditor-block-offset",s-o.top<48?"-24px":"-12px")},d=()=>{void 0!==n&&void 0===l&&(l=s?.requestAnimationFrame(h))},u=null===s?void 0:new s.MutationObserver(d),f=null===s?void 0:new s.ResizeObserver(d),b=i=>{const s=Reflect.get(i,"detail"),l=i.target
if("object"!=typeof s||null===s||!(l instanceof Element))return
const d=Reflect.get(s,"insertParagraph")
if("function"!=typeof d||!e.isContentEditable)return
const b=l.closest("img"),m=Reflect.get(s,"block")
if(m instanceof Element&&e.contains(m)&&r instanceof ShadowRoot)if(a!==m||void 0===n){A(),a=m,null===b||"FIGURE"!==m.tagName&&""!==m.textContent?.trim()||(c=b),n=o.createElement("div"),n.className="soeditor-block-paragraph is-hovered",n.setAttribute("data-block-kind",null!==b?"image":"table")
for(const i of["before","after"]){const s=o.createElement("button")
s.type="button",s.setAttribute("data-insert-paragraph",i)
const r=t.translate("before"===i?"Insert paragraph before this block":"Insert paragraph after this block")
s.addEventListener("focus",()=>n?.classList.add("is-hovered")),s.title=r,s.setAttribute("aria-label",r),s.textContent="↵",s.addEventListener("pointerdown",t=>t.preventDefault()),s.addEventListener("click",()=>{Reflect.apply(d,void 0,[i]),A()}),s.addEventListener("keydown",t=>{"Escape"===t.key&&(t.preventDefault(),A(),e.focus({Dn:!0}))}),n.append(s)}r.append(n),u?.observe(e,{attributes:!0,childList:!0,subtree:!0}),f?.observe(m),void 0!==c&&f?.observe(c),f?.observe(e),f?.observe(r.host),h()}else"soeditor:table-selection"!==i.type&&n.classList.add("is-hovered")},m=t=>{const e=t.composedPath()[0]
void 0===n||t.composedPath().includes(n)||e instanceof Node&&!0===a?.contains(e)||e instanceof Element&&null!==e.closest(".soeditor-image-resize-overlay")||A()},p=t=>{if(t instanceof PointerEvent&&"touch"===t.pointerType)return
const e="pointerout"===t.type&&t instanceof MouseEvent?t.relatedTarget:t.composedPath()[0]
n?.classList.toggle("is-hovered",e instanceof Node&&(!0===(c??a)?.contains(e)||void 0!==c&&!0===a?.querySelector("figcaption")?.contains(e)||n.contains(e)))}
return o.addEventListener("pointermove",p),s?.addEventListener("blur",p),r.addEventListener("pointerout",p),e.addEventListener("soeditor:block-hover",b),e.addEventListener("soeditor:image-select",b),e.addEventListener("soeditor:table-selection",b),o.addEventListener("pointerdown",m,!0),r.addEventListener("focusin",m),o.addEventListener("scroll",d,!0),s?.addEventListener("resize",d),void 0!==i&&b(i),()=>{A(),o.removeEventListener("pointermove",p),s?.removeEventListener("blur",p),r.removeEventListener("pointerout",p),e.removeEventListener("soeditor:block-hover",b),e.removeEventListener("soeditor:image-select",b),e.removeEventListener("soeditor:table-selection",b),o.removeEventListener("pointerdown",m,!0),r.removeEventListener("focusin",m),o.removeEventListener("scroll",d,!0),s?.removeEventListener("resize",d)}}},Symbol.toStringTag,{value:"Module"})),Ql=Object.freeze(Object.defineProperty({__proto__:null,la:(t,e,i)=>{const o=e.ownerDocument,s=o.defaultView,r=e.getRootNode()
let n,a,c,l,A,h
const d=()=>{c?.(),h=void 0,A?.close(),A=void 0,n?.remove(),n=void 0,a=void 0,b?.disconnect(),m?.disconnect(),void 0!==l&&s?.cancelAnimationFrame(l),l=void 0},u=()=>{if(l=void 0,void 0===n)return
if(!0!==a?.isConnected||!e.isContentEditable||0===e.getClientRects().length)return void d()
if(void 0!==c)return
const i=a.getBoundingClientRect(),o=n.offsetParent instanceof HTMLElement?n.offsetParent:t.element,s=o.getBoundingClientRect()
n.style.left=i.left-s.left-o.clientLeft+o.scrollLeft+"px",n.style.top=i.top-s.top-o.clientTop+o.scrollTop+"px",n.style.inlineSize=i.width+"px",n.style.blockSize=i.height+"px",h?.()},f=()=>{void 0!==n&&void 0===l&&(l=s?.requestAnimationFrame(u))},b=null===s?void 0:new s.MutationObserver(f),m=null===s?void 0:new s.ResizeObserver(f),p=i=>{const l=Reflect.get(i,"detail")
if("object"!=typeof l||null===l)return
const f=Reflect.get(l,"element"),p=Reflect.get(l,"update")
if(!(f instanceof HTMLImageElement&&e.contains(f)&&e.isContentEditable&&"function"==typeof p&&r instanceof ShadowRoot))return
d(),a=f,h=()=>{A?.element.isConnected||(A=t.balloons.show({anchor:f,placement:"above",avoid:()=>Array.from(g.querySelectorAll(".soeditor-image-resize-handle"),t=>t.getBoundingClientRect()),content:s=>{s.setAttribute("data-image-tools","true"),s.setAttribute("role","toolbar"),s.setAttribute("aria-label",t.translate("Image tools")),s.style.display="flex",s.style.gap="0.125rem"
const r=[]
for(const[n,a,c]of[["left","Align left","format.alignment.left"],["center","Align center","format.alignment.center"],["right","Align right","format.alignment.right"],["properties","Image properties","image.insert"]]){const l=o.createElement("button")
l.type="button",l.className="soeditor-ui__button",l.setAttribute("aria-label",t.translate(a)),l.title=t.translate(a),t.setIcon(l,c,a),"properties"!==n&&l.setAttribute("aria-pressed",(f.closest("figure")?.getAttribute("data-align")===n)+""),l.addEventListener("click",()=>{e.isContentEditable&&f.isConnected&&("properties"===n?(d(),y(i)):(t.restoreEditingSelection(),Reflect.apply(p,void 0,[{alignment:n}]),A?.close(),A=void 0,u()))}),r.push(l),s.append(l)}s.addEventListener("keydown",t=>{if(!["ArrowLeft","ArrowRight","Home","End"].includes(t.key))return
const e=r.findIndex(t=>t===o.activeElement),i="ArrowRight"===t.key!=("rtl"===getComputedStyle(s).direction),n="Home"===t.key?0:"End"===t.key?r.length-1:(e+(i?1:-1)+r.length)%r.length
t.preventDefault(),t.stopPropagation(),r[n]?.focus()})}}))}
const g=o.createElement("div")
g.className="soeditor-image-resize-overlay"
const w=[]
let v=f
for(;v!==e&&null!==v.parentElement;)w.unshift(`:nth-child(${Array.from(v.parentElement.children).indexOf(v)+1+""})`),v=v.parentElement
const k=o.createElement("style"),C=r.querySelector("style[nonce]")?.nonce
void 0!==C&&(k.nonce=C),k.textContent=`:host:has(.soeditor-image-resize-overlay.is-resizing) .soeditor-wysiwyg-content > ${w.join(" > ")} { visibility: hidden; }`,g.append(k)
const I=o.createElement("img")
I.src=f.currentSrc||f.src,I.alt="",I.draggable=!1,I.className="soeditor-image-resize-preview",I.setAttribute("aria-hidden","true"),g.append(I)
for(const r of["nw","n","ne","e","se","s","sw","w"]){const i=o.createElement("button")
i.type="button",i.className="soeditor-image-resize-handle",i.setAttribute("data-resize-direction",r),i.setAttribute("aria-label",`${t.translate("Resize image")} ${r.toUpperCase()}`)
let n,a,l=0,h=0,d=0,b=0,m=0,w=0,v=0,y=0,k=0
const C=()=>{a=void 0,g.style.inlineSize=y+"px",g.style.blockSize=k+"px",g.style.left=l+(r.includes("w")?m-y:0)+"px",g.style.top=h+(r.includes("n")?w-k:0)+"px",g.setAttribute("data-dimensions",`${y+""} × ${k+""}`)},I=()=>{u()
const t=f.getBoundingClientRect()
if(t.width<=0||t.height<=0)return!1
l=Number.parseFloat(g.style.left),h=Number.parseFloat(g.style.top),m=t.width,w=t.height
const i=e.getBoundingClientRect(),o=s?.getComputedStyle(e),r=Number.parseFloat(o?.paddingRight??"0")||0
return v=Math.min(9999,Math.max(m,i.right-t.left-r)),y=Math.round(m),k=Math.round(w),!0},E=(t,e,i)=>{const o=r.includes("e")?t:r.includes("w")?-t:0,s=r.includes("s")?e:r.includes("n")?-e:0
if(i||"false"!==f.closest("figure")?.getAttribute("data-aspect-lock")){const t=1+o/m,e=1+s/w,i=Math.min(v/m,9999/w,Math.max(24/m,24/w,0===o?e:0===s||Math.abs(t-1)>=Math.abs(e-1)?t:e))
y=Math.round(m*i),k=Math.round(w*i)}else y=Math.min(Math.round(v),Math.max(24,Math.round(m+o))),k=Math.min(9999,Math.max(24,Math.round(w+s)))},B=()=>{void 0!==a&&s?.cancelAnimationFrame(a),a=void 0
const t=n
n=void 0,c=void 0,g.classList.remove("is-resizing"),g.removeAttribute("data-dimensions"),void 0!==t&&i.hasPointerCapture(t)&&i.releasePointerCapture(t)},x=()=>{void 0!==n&&(B(),u())},S=()=>{const t=y!==Math.round(m)||k!==Math.round(w)
B(),t&&e.isContentEditable&&f.isConnected&&Reflect.apply(p,void 0,[{height:k,width:y}]),u(),e.focus({Dn:!0})}
i.addEventListener("pointerdown",t=>{0===t.button&&e.isContentEditable&&(t.preventDefault(),t.stopPropagation(),c?.(),I()&&(d=t.clientX,b=t.clientY,n=t.pointerId,c=x,A?.close(),A=void 0,i.setPointerCapture(t.pointerId),g.classList.add("is-resizing"),C()))}),i.addEventListener("pointermove",t=>{n===t.pointerId&&(E(t.clientX-d,t.clientY-b,t.shiftKey),void 0===a&&(a=s?.requestAnimationFrame(C)))}),i.addEventListener("pointerup",t=>{n===t.pointerId&&(E(t.clientX-d,t.clientY-b,t.shiftKey),S())}),i.addEventListener("pointercancel",x),i.addEventListener("lostpointercapture",x),i.addEventListener("keydown",t=>{if(!t.key.startsWith("Arrow")||void 0!==n||!e.isContentEditable)return
if(t.preventDefault(),!I())return
const i=t.shiftKey?10:1
E("ArrowRight"===t.key?i:"ArrowLeft"===t.key?-i:0,"ArrowDown"===t.key?i:"ArrowUp"===t.key?-i:0,t.shiftKey),(y!==Math.round(m)||k!==Math.round(w))&&Reflect.apply(p,void 0,[{height:k,width:y}]),u()}),g.append(i)}r.append(g),n=g,b?.observe(e,{attributes:!0,childList:!0,subtree:!0}),m?.observe(f),m?.observe(e),m?.observe(r.host),u()},g=t=>{void 0===n||t.composedPath().includes(n)||void 0!==A&&t.composedPath().includes(A.element)||t.composedPath()[0]===a||d()},w=t=>{"Escape"===t.key&&void 0!==n&&(t.preventDefault(),void 0!==c?c():d(),e.focus({Dn:!0}))},v=()=>c?.(),y=i=>{const s=Reflect.get(i,"detail")
if("object"!=typeof s||null===s)return
const r=Reflect.get(s,"element"),n=Reflect.get(s,"update"),a=Reflect.get(s,"remove")
if(!(r instanceof HTMLImageElement&&e.contains(r)&&e.isContentEditable&&"function"==typeof n&&"function"==typeof a))return
d()
const c=r.closest("figure"),l="A"===r.parentElement?.tagName?r.parentElement:void 0,A=c?.querySelector(":scope > figcaption"),h=o.createElement("div")
h.className="soeditor-classic__image-properties"
const u=new Map,f=(t,e,i,s,r,n={})=>{const a=o.createElement("label")
a.className="soeditor-classic__image-field",!0===n.wa&&a.classList.add("soeditor-classic__image-field--wide")
const c=o.createElement("span")
c.textContent=e
const l=o.createElement("input")
if(l.type=i,l.value=s,l.setAttribute("aria-label",e),"number"===i&&(l.min="1"),a.append(c,l),void 0!==n.hint){const t=o.createElement("small")
t.textContent=n.hint,a.append(t)}return u.set(t,l),r.append(a),l},b=t=>{const e=o.createElement("fieldset")
e.className="soeditor-classic__image-group"
const i=o.createElement("legend")
return i.textContent=t,e.append(i),e},m=b("Image and description")
for(const[t,e,o,d,G]of[["src","Image URL","url",r.getAttribute("src")??"",void 0],["alt","Alternative text","text",r.getAttribute("alt")??"","Describe the image for people who cannot see it."],["title","Image title","text",r.getAttribute("title")??"",void 0],["caption","Visible caption","text",A?.textContent??"",void 0]])f(t,e,o,d,m,{wa:"src"===t||"alt"===t,...void 0===G?{}:{hint:G}})
const p=b("Size and placement"),g=f("width","Width","number",r.getAttribute("width")??"",p),w=f("height","Height","number",r.getAttribute("height")??"",p),v=o.createElement("label")
v.className="soeditor-classic__image-aspect"
const y=o.createElement("input")
y.type="checkbox",y.checked="false"!==c?.getAttribute("data-aspect-lock"),y.setAttribute("aria-label","Lock aspect ratio")
const k=o.createElement("span")
k.textContent="Lock aspect ratio",v.append(y,k),p.append(v)
const C=o.createElement("label")
C.className="soeditor-classic__image-field"
const I=o.createElement("span")
I.textContent="Alignment"
const E=o.createElement("select")
E.setAttribute("aria-label","Alignment")
for(const[t,e]of[["","Default"],["left","Left"],["center","Center"],["right","Right"],["wide","Wide"]]){const i=o.createElement("option")
i.value=t,i.textContent=e,E.append(i)}E.value=c?.getAttribute("data-align")??"",C.append(I,E),p.append(C)
const B=Number(g.value),x=Number(w.value),S=B>0&&x>0?B/x:void 0
let D=!1
const M=(t,e,i)=>{if(D||!y.checked||void 0===S)return
const o=Number(t.value)
!Number.isFinite(o)||o<=0||(D=!0,e.value=Math.max(1,Math.round(o*i))+"",D=!1)}
g.addEventListener("input",()=>M(g,w,1/(S??1))),w.addEventListener("input",()=>M(w,g,S??1))
const T=b("Link")
f("link","Link URL","url",l?.getAttribute("href")??"",T,{wa:!0})
const R=o.createElement("label")
R.className="soeditor-classic__image-field soeditor-classic__image-field--wide"
const F=o.createElement("span")
F.textContent="Link target"
const _=o.createElement("select")
_.setAttribute("aria-label","Link target")
for(const[t,e]of[["","Same window"],["_blank","New window or tab (_blank)"],["_parent","Parent frame (_parent)"],["_top","Top frame (_top)"]]){const i=o.createElement("option")
i.value=t,i.textContent=e,_.append(i)}const Q=l?.getAttribute("target")??""
if(Q.length>0&&!Array.from(_.options).some(t=>t.value===Q)){const t=o.createElement("option")
t.value=Q,t.textContent=Q,_.append(t)}_.value=Q,R.append(F,_),T.append(R)
const O=o.createElement("details")
O.className="soeditor-classic__image-advanced"
const N=o.createElement("summary")
N.textContent="Responsive image settings"
const q=o.createElement("div")
q.className="soeditor-classic__image-advanced-fields"
for(const[t,e,o]of[["responsiveClass","Responsive CSS classes",r.getAttribute("class")??""],["srcset","Responsive sources",r.getAttribute("srcset")??""],["sizes","Responsive sizes",r.getAttribute("sizes")??""]])f(t,e,"text",o,q,{wa:!0})
O.append(N,q),h.append(m,p,T,O)
const j=t.dialogs.open({title:"Image properties",content:h,actions:[{label:"Remove image",run:()=>{j.close(),Reflect.apply(a,void 0,[])}},{kind:"primary",label:"Update image",run:()=>{const t=Object.fromEntries([...u].map(([t,e])=>[t,e.value]))
Object.assign(t,{alignment:E.value,aspectLocked:y.checked,linkTarget:_.value}),j.close(),Reflect.apply(n,void 0,[t])}}]})
j.element.classList.add("soeditor-classic__image-dialog"),u.get("src")?.focus()}
return e.addEventListener("soeditor:image-activate",y),e.addEventListener("soeditor:image-select",p),o.addEventListener("pointerdown",g,!0),s?.addEventListener("resize",f),s?.addEventListener("blur",v),o.addEventListener("keydown",w,!0),o.addEventListener("scroll",f,!0),void 0!==i&&("soeditor:image-activate"===i.type?y(i):p(i)),()=>{e.removeEventListener("soeditor:image-activate",y),e.removeEventListener("soeditor:image-select",p),o.removeEventListener("pointerdown",g,!0),o.defaultView?.removeEventListener("resize",f),o.removeEventListener("scroll",f,!0),s?.removeEventListener("blur",v),o.removeEventListener("keydown",w,!0),d()}}},Symbol.toStringTag,{value:"Module"})),Ol=Object.freeze(Object.defineProperty({__proto__:null,ca:(t,e,i)=>{const o=i.ownerDocument
let s,r
const n=()=>{s?.close(),s=void 0,r=void 0},a=t=>{(t.closest(".soeditor-table-cell")??i).focus({Dn:!0})
const e=o.createRange()
e.selectNodeContents(t)
const s=o.getSelection()
s?.setBaseAndExtent(e.startContainer,e.startOffset,e.endContainer,e.endOffset),o.dispatchEvent(new Event("selectionchange"))},c=c=>{if(0!==c.button||c.metaKey||c.ctrlKey)return
const l=c.target
if(l instanceof Element&&null!==l.closest("img"))return void n()
const A=l instanceof Element?l.closest('a[data-soeditor-link="true"], a[href]'):null
null!==A&&i.contains(A)&&(c.preventDefault(),a(A),n(),r=A,s=e.balloons.show({anchor:A,placement:"above",content:i=>{i.setAttribute("aria-label","Link actions")
const s=o.createElement("span")
let c
try{c=t.execute("link.inspect")}catch{c=void 0}const l="object"==typeof c&&null!==c?Reflect.get(c,"href"):void 0
s.textContent="string"==typeof l?l:""
const A=o.createElement("button")
A.type="button",A.className="soeditor-ui__button",e.setIcon(A,"link.edit","Edit link"),A.title="Edit link",A.setAttribute("aria-label","Edit link"),A.addEventListener("click",()=>{const t=r
n(),void 0!==t&&(a(t),e.toolbarElement.querySelector('[data-toolbar-item="link"]')?.click())})
const h=o.createElement("button")
h.type="button",h.className="soeditor-ui__button",e.setIcon(h,"link.remove","Remove link"),h.title="Remove link",h.setAttribute("aria-label","Remove link"),h.addEventListener("click",()=>{const i=r
if(n(),void 0!==i){a(i)
try{t.execute("link.remove")}catch(o){(t=>{e.notifications.show({message:t instanceof Error?t.message:t+"",severity:"error"})})(o)}}}),i.append(s,A,h)}}))},l=t=>{const e=t.composedPath().find(t=>t instanceof Node)
e instanceof Node&&!0!==s?.element.contains(e)&&(e instanceof Element&&e.closest('a[data-soeditor-link="true"], a[href]')===r||n())},A=t=>{"Escape"===t.key&&void 0!==s&&(t.preventDefault(),n(),i.focus({Dn:!0}))}
return i.addEventListener("click",c),o.addEventListener("pointerdown",l,!0),o.addEventListener("keydown",A),()=>{n(),i.removeEventListener("click",c),o.removeEventListener("pointerdown",l,!0),o.removeEventListener("keydown",A)}}},Symbol.toStringTag,{value:"Module"}))
return kc}()
Object.defineProperty(globalThis,"SoEditor",{configurable:!1,enumerable:!0,value:t,writable:!1})
//# sourceMappingURL=soeditor.global.js.map
