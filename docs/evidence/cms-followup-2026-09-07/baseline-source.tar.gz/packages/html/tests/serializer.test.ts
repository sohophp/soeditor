import {
    parseHtmlDocument,
    parseHtmlFragment,
    serializeHtmlDocument,
    serializeHtmlFragment,
} from '../src/index.js';
import { withoutSource } from './helpers.js';

describe('HTML serialization', () => {
    it('preserves long text runs beside entities, raw text and line breaks', () => {
        const text = '中文 👩🏽‍💻 &amp; &lt; text '.repeat(1000);
        const source = `<p>${text}<br>${text}</p><textarea>&lt;br&gt; &amp;</textarea><!--<br>--><style>a::after{content:"<br>"}</style>`;
        const parsed = parseHtmlFragment(source);
        const serialized = serializeHtmlFragment(parsed.document);
        expect(serialized).toContain('<br />');
        expect(serialized).toContain('content:"<br>"');
        expect(withoutSource(parseHtmlFragment(serialized).document)).toEqual(
            withoutSource(parsed.document),
        );
    });
    it('semantically round-trips a complete document with doctype and comments', () => {
        const source =
            '<!doctype html><!--page--><html lang="en"><head><title>Title</title></head><body><main data-layout="wide">Body</main></body></html>';
        const first = parseHtmlDocument(source);
        const serialized = serializeHtmlDocument(first.document);
        const second = parseHtmlDocument(serialized);

        expect(serialized).toContain('<!DOCTYPE html>');
        expect(serialized).toContain('<!--page-->');
        expect(withoutSource(second.document)).toEqual(
            withoutSource(first.document),
        );
    });

    it('semantically round-trips custom markup, comments, and attributes', () => {
        const source =
            '<!--CMS:block:123--><product-card data-id="123" aria-label="Card" custom-property="abc"><strong>Hello</strong></product-card>';
        const first = parseHtmlFragment(source);
        const serialized = serializeHtmlFragment(first.document);
        const second = parseHtmlFragment(serialized);

        expect(serialized).toContain('<!--CMS:block:123-->');
        expect(serialized).toContain(
            '<product-card data-id="123" aria-label="Card" custom-property="abc">',
        );
        expect(withoutSource(second.document)).toEqual(
            withoutSource(first.document),
        );
    });

    it('semantically round-trips SVG, MathML, and namespaced attributes', () => {
        const source =
            '<svg viewBox="0 0 10 10"><use xlink:href="#shape"></use></svg><math><mrow><mi>x</mi><mo>+</mo><mn>1</mn></mrow></math>';
        const first = parseHtmlFragment(source);
        const serialized = serializeHtmlFragment(first.document);
        const second = parseHtmlFragment(serialized);

        expect(serialized).toContain('xlink:href="#shape"');
        expect(withoutSource(second.document)).toEqual(
            withoutSource(first.document),
        );
    });

    it('serializes line breaks with the canonical XML-style closing syntax', () => {
        const parsed = parseHtmlFragment('<img src="image.png"><br>');

        expect(serializeHtmlFragment(parsed.document)).toBe(
            '<img src="image.png"><br />',
        );
    });

    it('does not rewrite literal line-break markup in raw text or comments', () => {
        const parsed = parseHtmlFragment(
            '<script>const value = "<br>";</script><!--<br>--><br>',
        );

        expect(serializeHtmlFragment(parsed.document)).toContain(
            '<script>const value = "<br>";</script><!--<br>--><br />',
        );
    });

    it('serializes recovered malformed nesting as the corrected HTML tree', () => {
        const parsed = parseHtmlFragment('<p>before<div>inside</div>after');
        const serialized = serializeHtmlFragment(parsed.document);

        expect(serialized).toBe('<p>before</p><div>inside</div>after');
        expect(withoutSource(parseHtmlFragment(serialized).document)).toEqual(
            withoutSource(parsed.document),
        );
    });
});
