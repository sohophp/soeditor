import {
    createServiceToken,
    EditorDestroyedError,
    Plugin,
} from '@soeditor/core';

import { defaultShortcuts, defaultToolbarItems } from './defaults.js';
import { freezeShortcut } from './shortcuts.js';
import type {
    ContextMenuItemDefinition,
    KeyboardShortcutDefinition,
    StatusItemFactory,
    ToolbarItemFactory,
    UiRegistryService,
} from './types.js';

interface StoredShortcut extends KeyboardShortcutDefinition {
    readonly parsed: ReturnType<typeof freezeShortcut>['parsed'];
}

interface RegistryRecord {
    readonly contextMenuItems: Map<string, ContextMenuItemDefinition>;
    readonly shortcuts: Map<string, StoredShortcut>;
    readonly shortcutIds: Map<string, StoredShortcut>;
    readonly statusItems: Map<string, StatusItemFactory>;
    readonly toolbarItems: Map<string, ToolbarItemFactory>;
}

const records = new WeakMap<UiRegistryService, RegistryRecord>();

/** Typed identity of the per-editor UI contribution registry. */
export const uiRegistryServiceToken = createServiceToken<UiRegistryService>(
    'soeditor.ui-registry',
);

/** Reports a duplicate toolbar item, shortcut ID, or shortcut chord. */
export class UiContributionAlreadyRegisteredError extends Error {
    constructor(kind: string, id: string) {
        super(`UI ${kind} "${id}" is already registered.`);
        this.name = 'UiContributionAlreadyRegisteredError';
    }
}

/** Registers default UI contributions and a per-editor extension registry. */
export class UiPlugin extends Plugin {
    static readonly id = 'editor-ui';
    #destroyed = false;
    #service: UiRegistryService | undefined;

    override init(): void {
        const record: RegistryRecord = {
            contextMenuItems: new Map(),
            shortcuts: new Map(),
            shortcutIds: new Map(),
            statusItems: new Map(),
            toolbarItems: new Map(),
        };
        const service = Object.freeze<UiRegistryService>({
            registerContextMenuItem: (id, definition) =>
                this.#registerContextMenuItem(record, id, definition),
            registerShortcut: (definition) =>
                this.#registerShortcut(record, definition),
            registerStatusItem: (id, factory) =>
                this.#registerStatusItem(record, id, factory),
            registerToolbarItem: (id, factory) =>
                this.#registerToolbarItem(record, id, factory),
        });
        records.set(service, record);
        this.#service = service;
        for (const [id, factory] of defaultToolbarItems) {
            this.#registerToolbarItem(record, id, factory);
        }
        for (const shortcut of defaultShortcuts) {
            this.#registerShortcut(record, shortcut);
        }
        this.editor.services.register(uiRegistryServiceToken, service);
    }

    override destroy(): void {
        this.#destroyed = true;
        const service = this.#service;
        if (service !== undefined) {
            const record = getUiRegistryRecord(service);
            record.contextMenuItems.clear();
            record.shortcuts.clear();
            record.shortcutIds.clear();
            record.statusItems.clear();
            record.toolbarItems.clear();
        }
        this.#service = undefined;
    }

    #registerToolbarItem(
        record: RegistryRecord,
        id: string,
        factory: ToolbarItemFactory,
    ): () => void {
        this.#assertAlive();
        if (typeof id !== 'string' || id.trim().length === 0) {
            throw new TypeError('A toolbar item ID must not be empty.');
        }
        if (typeof factory !== 'function') {
            throw new TypeError(`Toolbar item "${id}" requires a factory.`);
        }
        if (record.toolbarItems.has(id)) {
            throw new UiContributionAlreadyRegisteredError('toolbar item', id);
        }
        record.toolbarItems.set(id, factory);
        let active = true;
        return () => {
            if (active && record.toolbarItems.get(id) === factory) {
                record.toolbarItems.delete(id);
            }
            active = false;
        };
    }

    #registerContextMenuItem(
        record: RegistryRecord,
        id: string,
        definition: ContextMenuItemDefinition,
    ): () => void {
        this.#assertAlive();
        if (typeof definition !== 'object' || definition === null) {
            throw new TypeError(
                `Context menu item "${id}" requires a definition.`,
            );
        }
        if (
            typeof definition.label !== 'string' ||
            definition.label.trim().length === 0 ||
            typeof definition.command !== 'string' ||
            definition.command.trim().length === 0 ||
            (definition.group !== undefined &&
                (typeof definition.group !== 'string' ||
                    definition.group.trim().length === 0)) ||
            (definition.tone !== undefined &&
                definition.tone !== 'default' &&
                definition.tone !== 'danger') ||
            (definition.when !== undefined &&
                typeof definition.when !== 'function')
        ) {
            throw new TypeError(`Context menu item "${id}" is invalid.`);
        }
        if (typeof id !== 'string' || id.trim().length === 0) {
            throw new TypeError('A context menu item ID must not be empty.');
        }
        if (record.contextMenuItems.has(id)) {
            throw new UiContributionAlreadyRegisteredError(
                'context menu item',
                id,
            );
        }
        const frozen = Object.freeze({
            ...definition,
            ...(definition.args === undefined
                ? {}
                : { args: Object.freeze([...definition.args]) }),
        });
        record.contextMenuItems.set(id, frozen);
        let active = true;
        return () => {
            if (active && record.contextMenuItems.get(id) === frozen) {
                record.contextMenuItems.delete(id);
            }
            active = false;
        };
    }

    #registerStatusItem(
        record: RegistryRecord,
        id: string,
        factory: StatusItemFactory,
    ): () => void {
        return this.#registerFactory(
            record.statusItems,
            'status item',
            id,
            factory,
        );
    }

    #registerFactory<Factory>(
        entries: Map<string, Factory>,
        kind: string,
        id: string,
        factory: Factory,
    ): () => void {
        this.#assertAlive();
        if (typeof id !== 'string' || id.trim().length === 0) {
            throw new TypeError(`A ${kind} ID must not be empty.`);
        }
        if (typeof factory !== 'function') {
            throw new TypeError(`${kind} "${id}" requires a factory.`);
        }
        if (entries.has(id)) {
            throw new UiContributionAlreadyRegisteredError(kind, id);
        }
        entries.set(id, factory);
        let active = true;
        return () => {
            if (active && entries.get(id) === factory) {
                entries.delete(id);
            }
            active = false;
        };
    }

    #registerShortcut(
        record: RegistryRecord,
        definition: KeyboardShortcutDefinition,
    ): () => void {
        this.#assertAlive();
        const shortcut = freezeShortcut(definition);
        if (record.shortcutIds.has(shortcut.id)) {
            throw new UiContributionAlreadyRegisteredError(
                'shortcut ID',
                shortcut.id,
            );
        }
        if (record.shortcuts.has(shortcut.chord)) {
            throw new UiContributionAlreadyRegisteredError(
                'shortcut chord',
                shortcut.chord,
            );
        }
        record.shortcutIds.set(shortcut.id, shortcut);
        record.shortcuts.set(shortcut.chord, shortcut);
        let active = true;
        return () => {
            if (active && record.shortcutIds.get(shortcut.id) === shortcut) {
                record.shortcutIds.delete(shortcut.id);
                record.shortcuts.delete(shortcut.chord);
            }
            active = false;
        };
    }

    #assertAlive(): void {
        if (this.#destroyed) {
            throw new EditorDestroyedError();
        }
    }
}

export function getUiRegistryRecord(
    service: UiRegistryService,
): RegistryRecord {
    const record = records.get(service);
    if (record === undefined) {
        throw new Error('UI registry storage is unavailable.');
    }
    return record;
}
