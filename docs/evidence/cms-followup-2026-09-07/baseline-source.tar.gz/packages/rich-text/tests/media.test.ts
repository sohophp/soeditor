import { Editor } from '@soeditor/core';
import {
    visualEditingServiceToken,
    type EditingStructuredBlock,
    type VisualEditingService,
} from '@soeditor/engine';
import { parseHtmlFragment, serializeHtmlFragment } from '@soeditor/html';
import { describe, expect, it, vi } from 'vitest';

import {
    isSafeMediaPreviewUrl,
    MediaPlugin,
    RichTextArgumentError,
} from '../src/index.js';

describe('structured media feature', () => {
    it('inserts complete CMS image properties with a safe link', async () => {
        const inserted: string[] = [];
        const editor = await Editor.create({ plugins: [MediaPlugin] });
        editor.services.register(
            visualEditingServiceToken,
            visualService(undefined, inserted, () => undefined),
        );

        editor.execute('media.insert', {
            alignment: 'center',
            alt: 'Hero',
            assetId: 'asset-7',
            aspectLocked: true,
            link: '/article',
            linkTarget: '_blank',
            responsiveClass: 'img-fluid cms-image',
            sizes: '(max-width: 800px) 100vw, 800px',
            src: '/hero.jpg',
            srcset: '/hero-400.jpg 400w, /hero.jpg 800w',
            title: 'Article hero',
            width: 800,
        });

        expect(inserted).toEqual([
            '<figure data-soeditor-media="image" data-align="center" data-aspect-lock="true"><a href="/article" target="_blank"><img src="/hero.jpg" alt="Hero" title="Article hero" class="img-fluid cms-image" data-asset-id="asset-7" srcset="/hero-400.jpg 400w, /hero.jpg 800w" sizes="(max-width: 800px) 100vw, 800px" width="800"></a></figure>',
        ]);
        expect(() =>
            editor.execute('media.insert', {
                link: 'javascript:alert(1)',
                src: '/hero.jpg',
            }),
        ).toThrow('safe link URL');
        expect(() =>
            editor.execute('media.insert', {
                src: '/hero.jpg',
                srcset: 'javascript:alert(1) 2x',
            }),
        ).toThrow('safe srcset');
        await editor.destroy();
    });
    it('inserts a semantic figure through the visual editing service', async () => {
        const editor = await Editor.create({ plugins: [MediaPlugin] });
        const inserted: string[] = [];
        editor.services.register(
            visualEditingServiceToken,
            visualService(undefined, inserted),
        );

        editor.execute('media.insert', {
            src: '/photo.png',
            alt: 'A photo',
            caption: 'A caption',
            width: 640,
            height: 480,
        });

        expect(inserted).toEqual([
            '<figure data-soeditor-media="image"><img src="/photo.png" alt="A photo" width="640" height="480"><figcaption>A caption</figcaption></figure>',
        ]);
        expect(() => editor.execute('media.insert', { src: '' })).toThrow(
            RichTextArgumentError,
        );
        await editor.destroy();
    });

    it('updates controlled properties while retaining source attributes', async () => {
        const parsed = parseHtmlFragment(
            '<figure class="hero" data-cms="42"><img src="old.jpg" alt="Old" width="400" height="200" loading="eager" data-id="7"><figcaption class="credit">Old caption</figcaption></figure>',
        ).document.children[0];
        if (parsed?.type !== 'element') {
            throw new Error('A figure fixture is required.');
        }
        let block: EditingStructuredBlock = {
            attributes: parsed.attributes,
            behavior: 'atomic',
            children: parsed.children,
            kind: 'structured-block',
            type: 'soeditor.media',
        };
        const replace = vi.fn(
            (
                _type: string,
                content: Pick<
                    EditingStructuredBlock,
                    'attributes' | 'children'
                >,
            ) => {
                block = { ...block, ...content };
            },
        );
        const editor = await Editor.create({ plugins: [MediaPlugin] });
        const remove = vi.fn();
        editor.services.register(
            visualEditingServiceToken,
            visualService(() => block, [], replace, remove),
        );

        editor.execute('media.update', {
            alignment: 'right',
            src: 'new.webp',
            alt: 'New',
            aspectLocked: true,
            caption: 'New caption',
            link: '/story',
            linkTarget: '_parent',
            responsiveClass: 'img-fluid',
            title: 'New title',
            width: 800,
        });
        expect(html(block)).toBe(
            '<figure class="hero" data-cms="42" data-align="right" data-aspect-lock="true"><a href="/story" target="_parent"><img src="new.webp" alt="New" width="800" height="400" loading="eager" data-id="7" title="New title" class="img-fluid"></a><figcaption class="credit">New caption</figcaption></figure>',
        );
        editor.execute('media.update', { width: null });
        expect(html(block)).not.toContain('width=');
        expect(html(block)).toContain('src="new.webp"');
        editor.execute('media.caption.remove');
        expect(html(block)).not.toContain('figcaption');
        expect(html(block)).toContain('src="new.webp"');
        expect(replace).toHaveBeenCalledTimes(3);
        editor.execute('media.remove');
        expect(remove).toHaveBeenCalledWith('soeditor.media');
        await editor.destroy();
    });

    it('preserves unsupported figures and blocks executable preview schemes', async () => {
        expect(isSafeMediaPreviewUrl('https://example.com/x.png')).toBe(true);
        expect(isSafeMediaPreviewUrl('/x.png')).toBe(true);
        expect(isSafeMediaPreviewUrl('data:image/png;base64,AA==')).toBe(true);
        expect(isSafeMediaPreviewUrl('javascript:alert(1)')).toBe(false);
        expect(isSafeMediaPreviewUrl('data:text/html;base64,AA==')).toBe(false);

        const parsed = parseHtmlFragment(
            '<figure><picture><img src="x.png"></picture><script>kept()</script></figure>',
        ).document.children[0];
        if (parsed?.type !== 'element') {
            throw new Error('A figure fixture is required.');
        }
        const block: EditingStructuredBlock = {
            attributes: parsed.attributes,
            behavior: 'atomic',
            children: parsed.children,
            kind: 'structured-block',
            type: 'soeditor.media',
        };
        const replace = vi.fn();
        const editor = await Editor.create({ plugins: [MediaPlugin] });
        editor.services.register(
            visualEditingServiceToken,
            visualService(block, [], replace),
        );
        expect(() => editor.execute('media.update', { alt: 'Nope' })).toThrow(
            'figure requires one image and an optional caption',
        );
        expect(replace).not.toHaveBeenCalled();
        expect(html(block)).toContain('<script>kept()</script>');
        await editor.destroy();
    });
});

function visualService(
    selected:
        | EditingStructuredBlock
        | undefined
        | (() => EditingStructuredBlock | undefined),
    inserted: string[],
    replace: VisualEditingService['replaceStructuredBlockContent'] = () =>
        undefined,
    remove: NonNullable<
        VisualEditingService['removeSelectedStructuredBlock']
    > = () => undefined,
): VisualEditingService {
    const current = (): EditingStructuredBlock | undefined =>
        typeof selected === 'function' ? selected() : selected;
    return {
        canEdit: () => true,
        getSelection: () => undefined,
        getSelectedStructuredBlock: (type) => {
            const block = current();
            return type === undefined || block?.type === type
                ? block
                : undefined;
        },
        insertHtml: (source) => inserted.push(source),
        isBlockActive: () => false,
        isLinkActive: () => false,
        isListActive: () => false,
        isMarkActive: () => false,
        isStructuredBlockSelected: (type) => {
            const block = current();
            return (
                block !== undefined &&
                (type === undefined || block.type === type)
            );
        },
        replaceStructuredBlockContent: replace,
        removeSelectedStructuredBlock: remove,
        setBlock: () => undefined,
        setLink: () => undefined,
        setSelection: () => false,
        setStructuredBlockAttributes: () => undefined,
        toggleList: () => undefined,
        toggleMark: () => undefined,
    };
}

function html(block: EditingStructuredBlock): string {
    return serializeHtmlFragment({
        children: [
            {
                attributes: block.attributes,
                children: block.children,
                namespace: 'html',
                tagName: 'figure',
                type: 'element',
            },
        ],
        type: 'document-fragment',
    });
}
