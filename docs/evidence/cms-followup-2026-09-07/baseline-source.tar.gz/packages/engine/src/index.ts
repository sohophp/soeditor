export {
    createVisualEditingEngine,
    VisualEditingEngine,
    VisualEditingEngineDestroyedError,
    UnsupportedVisualDocumentFormatError,
} from './visual-editing-engine.js';
export { HistoryPlugin } from './history.js';
export {
    classifyPasteInput,
    PastePipelinePlugin,
    PasteRejectedError,
    pastePipelineServiceToken,
    SOEDITOR_CLIPBOARD_MIME,
} from './paste-pipeline.js';
export type {
    ExternalPastePolicy,
    PasteDiagnostic,
    PasteInputClassification,
    PasteInputFile,
    PastePipelineInput,
    PastePipelineResult,
    PastePipelineService,
    PasteProcessor,
    PasteProcessorContext,
    PasteProcessorResult,
} from './paste-pipeline.js';
export { groupHistoryTransaction } from './history-metadata.js';
export { mapEditingPoint, readEditingOperations } from './operations.js';
export type {
    EditingOperation,
    EditingPointAffinity,
    EditingResult,
} from './operations.js';
export type {
    EditingEngine,
    VisualEditingEngineOptions,
    VisualEditingProjectionId,
} from './visual-editing-engine.js';
export type { EditingPoint, EditingSelection } from './model.js';
export type {
    EditingBlock,
    EditingBlockTag,
    EditingInline,
    EditingElementMark,
    EditingLinkMark,
    EditingMark,
    EditingModel,
    EditingOpaqueBlock,
    EditingOpaqueInline,
    EditingParagraph,
    EditingStructuredBlock,
    EditingStructuredBlockContent,
    EditingTextMark,
    EditingTextRun,
} from './model.js';
export {
    StructuredEditingContributionAlreadyRegisteredError,
    StructuredEditingContributionConflictError,
    StructuredEditingPlugin,
    StructuredEditingRegistrySealedError,
    structuredEditingRegistryToken,
} from './structured-editing.js';
export type {
    StructuredBlockBehavior,
    StructuredBlockConversion,
    StructuredEditingRegistry,
    StructuredNodeViewActions,
    StructuredNodeViewContext,
    StructuredNodeViewFactory,
    StructuredNodeViewInstance,
    StructuredNodeViewSelectionOptions,
    StructuredNodeViewState,
} from './structured-editing.js';
export { visualEditingServiceToken } from './visual-editing-service.js';
export type {
    VisualBlockTag,
    VisualEditingService,
    VisualHtmlInsertionOptions,
    VisualInlineStyle,
    VisualInlineStyleProperty,
    VisualListProperties,
    VisualListStyle,
    VisualFormatProperty,
    VisualFormatState,
    VisualLinkAttributes,
    VisualTextMark,
} from './visual-editing-service.js';
export {
    VisualDecorationsPlugin,
    visualDecorationsServiceToken,
} from './visual-decorations.js';
export type {
    VisualDecoration,
    VisualDecorationsService,
    VisualDecorationStatus,
} from './visual-decorations.js';
