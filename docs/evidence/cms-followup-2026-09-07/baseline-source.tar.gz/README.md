# SoEditor

Lightweight, stable HTML WYSIWYG + Source editing for website CMS administration.

SoEditor is designed for article, page, product and other CMS content fields. It
combines a conventional authoring experience with semantic HTML preservation,
safe paste/media workflows, optional HTML Source control and framework-neutral
integration.

The active direction learns:

- lightweight delivery and practical density from Jodit 4;
- mature CMS behavior and stability from CKEditor 4;
- model/view, command, conversion and plugin separation from CKEditor 5.

It is not pursuing AI, collaboration, review workflows, Markdown, page building,
email design or IDE-like editor modes.

## Status

`@soeditor/*@1.0.0` is the published historical package set. The unpublished
local `1.1.0` candidate contains the completed CMS/WYSIWYG implementation.
The CMS product-surface reset is implemented in the unpublished local `1.1.0`
candidate. Its supported entry is `@soeditor/editor/cms`; compatibility exports
remain available from the package root for SemVer safety but are excluded from
the CMS global and default preset.

The current CMS browser global is 477.20 kB raw / 147.22 kB gzip with 26.78 kB
raw CSS. The packed default CMS startup is 436.65 kB raw / 141.52 kB gzip.
See [the WYSIWYG + Source evidence](docs/wysiwyg-source-evidence.zh-CN.md) for
first-use costs, validation and manual qualification limits.
HTML Source, Preview and save adapters use the explicit
`@soeditor/editor/cms/optional` entry and are not included in the default CMS
entry or standalone browser global.

## Basic integration

```ts
import { createClassicEditor } from '@soeditor/editor/cms/optional';
import '@soeditor/editor/cms/styles.css';

const textarea = document.querySelector<HTMLTextAreaElement>('#content');
if (textarea === null) throw new Error('Missing #content textarea.');

const editor = await createClassicEditor(textarea, {
    locale: 'zh-CN',
    editingModes: ['wysiwyg', 'source'],
});

// The original textarea remains synchronized for native form submission.
// Later: await editor.destroy();
```

Default startup is WYSIWYG-only. Source is a primary editing capability with
first-activation loading; configuring its button does not load CodeMirror.
Import `/cms/optional` when Source, Preview or a save adapter is configured.
Await `editor.setWorkspaceView('source')` before using the Source surface.
Formatting and Preview load separately on first use.

## CMS product capabilities

- textarea/element mounting, form submit/reset, readonly and exact teardown;
- paragraphs, headings, semantic styles and common inline/block formatting;
- nested lists, links, anchors and file links;
- image upload/picker/URL and complete image properties;
- production HTML tables;
- Office/web/plain-text paste cleanup;
- unknown HTML, attributes, comments, custom elements and CMS marker
  preservation;
- inert handling of unsafe or unsupported visual content;
- configurable classic toolbar, responsive UI, localization, IME and keyboard
  operation;
- optional HTML Source, upload, file-manager and save integrations.

## Architecture

HTML is canonical. UI actions invoke commands, commands produce controlled
transactions, and the WYSIWYG DOM is an editing projection rather than
unrestricted persistence state. Core remains framework-independent.

See [product definition](docs/PRODUCT.md), [active roadmap](docs/ROADMAP.md),
[architecture](docs/architecture.md), [WYSIWYG specification](docs/wysiwyg-editor.md),
[performance policy](docs/performance.md), and the current
[package disposition](docs/package-disposition.md).

## Documentation

- [WYSIWYG + Source implementation plan](docs/wysiwyg-source-plan.zh-CN.md)
- [Getting started](docs/getting-started.md)
- [CMS integration](docs/cms-integration.md)
- [Classic UI](docs/classic-ui.md)
- [Configuration](docs/configuration.md)
- [Paste](docs/paste.md)
- [Uploads](docs/uploads.md)
- [Links and CMS objects](docs/links-and-cms-objects.md)
- [Tables and lists](docs/tables-and-lists.md)
- [CMS saving](docs/cms-saving.md)
- [CKEditor 4 migration](docs/ckeditor4-migration.md)
- [Security](docs/security.md)
- [Troubleshooting](docs/troubleshooting.md)
- [Qualification](docs/qualification.md)
- [Deployment and operations](docs/deployment-operations.md)
- [0.9 to 1.0 migration](docs/migration-0.9-to-1.0.md)
- [API overview](docs/api-overview.md)

Historical Markdown, review, framework-adapter, Preview and developer-tool
documents describe published compatibility surfaces. They do not define the
active product roadmap.

## Development

```bash
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

## License

[MIT](LICENSE)
