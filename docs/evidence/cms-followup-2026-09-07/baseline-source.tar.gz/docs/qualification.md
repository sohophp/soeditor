# 1.0 and CMS qualification evidence

> 2026-09-07：当前工作区的优化状态、测量与验证统一见 [CMS 性能与稳定性优化](cms-optimization-2026-09-07.zh-CN.md)。以下日期更早的数字为历史记录；人工设备验收单独列出。

## WYSIWYG + Source automated acceptance (2026-09-05)

Local automated acceptance passes: 233 compatibility Chromium tests, 96
Firefox/WebKit tests with 4 existing Chromium-only skips, and 21 three-browser
Source checks. The full test chain, packed consumers, loading/size budgets,
source-load recovery and Winstar integration pass. See
[current evidence](wysiwyg-source-evidence.zh-CN.md), including raw measurement
artifacts and remaining manual Safari/assistive-technology limits. Earlier
qualification records below describe the pre-WS candidate.

Phase 35 qualified the frozen 1.0 contract with executable evidence. This is a
regression record, not a claim of universal device, browser, assistive-
technology, security, or performance certification.

## User and integrator journeys

| Journey                   | Executable evidence                                                                  |
| ------------------------- | ------------------------------------------------------------------------------------ |
| Ordinary HTML author      | `editor-ui.spec.ts`, `visual-editing.spec.ts`, `table.spec.ts`, `media.spec.ts`      |
| HTML developer            | `developer-tools.spec.ts`, `diagnostics-configuration.spec.ts`, `split-view.spec.ts` |
| Markdown author           | `markdown.spec.ts`, Markdown/Preview split scenarios                                 |
| CMS and SoFinder          | `release-hardening.spec.ts`, `file-manager.spec.ts`, CMS Playground route            |
| Custom widget/plugin      | `node-views.spec.ts`, packed widget consumer, generated plugin consumer              |
| Comments/revisions/review | `comments.spec.ts`, `revisions.spec.ts`, governance adapters                         |
| Workspace recovery        | `workspace.spec.ts` and 14 focused Workspace unit tests                              |
| React and Vue             | SSR unit tests and `framework-adapters.spec.ts` real-browser lifecycle               |
| ESM/NodeNext/Vite/CDN     | packed 24-package consumer, narrow tree-shaking, browser global smoke                |
| CMS Classic acceptance    | `cms-multibrowser.spec.ts` continuous authoring/save/security/teardown journey       |

The scenarios use public package roots. Source, Markdown, Preview, framework,
plugin-tooling, and experimental widget/table/media paths remain separated by
their documented dependency and execution boundaries.

The complete journey evidence is distributed across `comments.spec.ts`,
`developer-tools.spec.ts`, `diagnostics-configuration.spec.ts`,
`distribution.spec.ts`, `editor-ui.spec.ts`, `file-manager.spec.ts`,
`framework-adapters.spec.ts`, `markdown.spec.ts`, `media.spec.ts`,
`node-views.spec.ts`, `qualification.spec.ts`, `release-hardening.spec.ts`,
`revisions.spec.ts`, `split-view.spec.ts`, `table.spec.ts`,
`visual-editing.spec.ts`, and `workspace.spec.ts`.

## CMS Classic continuous journey

Phase 48 adds one uninterrupted public-path browser scenario that proves:

1. named-textarea replacement and initial custom-element/comment preservation;
2. Chinese composition and Latin content in the same canonical document;
3. configured semantic styling and nested-list keyboard behavior;
4. semantic Office paste cleanup with scripts, event handlers, and `mso-*`
   styling rejected;
5. a host upload task plus safe link and structured table insertion;
6. shared undo/redo, HTML Source editing, and native form submission;
7. dangerous source retained canonically but absent from executable Visual DOM;
8. terminal destruction restoring the exact textarea and final source.

The pre-WS repository contained 229 Chromium scenarios. The focused CMS project
runs all three CMS scenarios on Chromium desktop and mobile (six passing runs).
The original full-matrix attempt could not launch Firefox or WebKit on the
Rocky Linux development host because its C++ and desktop runtime libraries are
too old. The cross-browser command now probes both engines before scheduling
the matrix, so an unsupported host reports both dependency failures once rather
than recording every unstarted scenario as a product failure. Phase 57
therefore reruns the focused CMS and complete direct WYSIWYG
corpora in the matching official Playwright Noble image. The current candidate
passes all 96 applicable Firefox/WebKit assertions. Four
browser-tool-specific cases are explicitly skipped: native clipboard
permissions and CDP IME injection are Chromium-only; equivalent cross-engine
composition and synthetic rich-paste paths still run.
An earlier 66-assertion version of the independent CI gate also passed on a
supported Ubuntu runner for commit
`1fe622c8b17771daeabc256e0ea127e52d311c83` in Actions run `33460058428`.

## Accessibility

Automated axe WCAG A/AA scans cover primary Visual, Source, Markdown, Problems,
dialog, and outer Preview UI. Deterministic browser tests additionally cover:

- native names, roles, live status/log regions, iframe titles, and duplicate IDs;
- keyboard command, dialog, table, node-view, review, split-resize, focus, and
  Escape-return paths;
- dark-theme primary action contrast;
- visible split-separator focus in forced-colors mode;
- reduced-motion mode with no SoEditor animation/transition (the standard
  CodeMirror text caret continues to blink);
- readonly controls, dynamic review policy, and lifecycle cleanup.

The current environment does not provide a human screen-reader session, switch
control, voice control, zoom/reflow lab across devices, or dedicated Firefox/
Safari accessibility runs. Therefore SoEditor does not claim WCAG certification
or complete assistive-technology conformance.

## Security

Browser tests verify that preserved scripts, handlers, unsafe links/embeds,
clipboard/drop HTML, FileManager output, UI messages, and Preview templates do
not bypass controlled rendering. Preview uses an empty sandbox and fixed CSP.
Source and Markdown verify application CSP nonces in isolated documents.
Dependency audit, script-disabled package inspection, exact export maps,
provenance metadata, and publication dry-run cover the local supply-chain gate.

The complete threat model and residual host risks are in
[`security.md`](security.md).

## Performance, memory, and lifecycle

Node gates measure 5,000-paragraph canonical replacement, 500 mapped comments,
three projections, 400-cell tables, Workspace recovery, Core startup/teardown,
and explicit-GC retention after 2,000 destroyed editors. Chromium measures
1,000 real Visual paragraphs, `beforeinput`, 400-cell table rendering, and
repeated Editor/Visual/UI lifecycles with DOM residue checks.

Budgets are generous regression thresholds for shared CI, not end-user latency
or memory promises. See [`performance.md`](performance.md).

## Reproduction

```bash
pnpm install --frozen-lockfile
pnpm lint
pnpm typecheck
pnpm test
pnpm test:browser:cross
pnpm build
pnpm release:check-license
pnpm security:audit
pnpm release:dry-run
pnpm release:check-registry
```

Publication and external npm/CDN verification remain separate owner-authorized
operations.
